from __future__ import annotations

import unittest

from lamague_runtime import (
    AbstractInterpreter,
    AuditOutcome,
    CanonicalMilestoneCompiler,
    ConstitutionalAuditor,
    ContextCapsule,
    Parser,
    Registry,
    RegistryError,
    UnsupportedNaturalLanguage,
)


class RegistryTests(unittest.TestCase):
    def test_registry_has_26_operations_and_deterministic_seals(self) -> None:
        registry = Registry()
        self.assertEqual(len(registry.operations), 26)
        self.assertEqual(registry.expand_seal("COR"), ["D", "A", "F", "P", "Y"])
        self.assertEqual(registry.expand_seal("COR"), registry.expand_seal("COR"))


    def test_registry_version_mismatch_fails_visibly(self) -> None:
        registry = Registry()
        with self.assertRaises(RegistryError):
            registry.expand_seal("COR", version="999")

    def test_fro_cor_expands_to_13_operations(self) -> None:
        ast = Parser().parse("FRO -> COR")
        self.assertEqual(len(ast.operation_path), 13)
        self.assertEqual(ast.operation_path[:3], ["O", "S", "N"])
        self.assertEqual(ast.operation_path[-3:], ["F", "P", "Y"])


class ParserTests(unittest.TestCase):
    def test_typed_unknown_round_trip(self) -> None:
        parser = Parser()
        ast = parser.parse("Q -> U<consent> -> G")
        normalized = parser.normalize(ast)
        self.assertEqual(normalized, "Q -> U<consent> -> G")
        self.assertIn("consent", ast.nodes[1].unknowns)

    def test_exchange_annotation(self) -> None:
        ast = Parser().parse("X{from=human,to=ai,value=knowledge,consent=explicit}")
        self.assertEqual(ast.nodes[0].value_flow["consent"], "explicit")


class AuditTests(unittest.TestCase):
    def test_proof_without_evidence_expands(self) -> None:
        ctx = ContextCapsule(
            participants=["researcher"],
            authority=["researcher may run abstract test"],
            consequences=["test output"],
            provenance=["unit test"],
        )
        ast = Parser().parse("P", ctx)
        report = ConstitutionalAuditor().audit(ast)
        self.assertEqual(report.outcome, AuditOutcome.EXPAND)

    def test_exchange_without_consent_isolated(self) -> None:
        ctx = ContextCapsule(
            participants=["human", "AI"],
            authority=["human authorises proposed exchange"],
            consequences=["value movement"],
            provenance=["unit test"],
            execute_requested=True,
        )
        ast = Parser().parse("X", ctx)
        report = ConstitutionalAuditor().audit(ast)
        self.assertEqual(report.outcome, AuditOutcome.ISOLATE)


    def test_certainty_beyond_evidence_requires_repair(self) -> None:
        ctx = ContextCapsule(
            claim="an overstated claim",
            evidence=["weak observation"],
            evidence_score=0.2,
            certainty=0.9,
            participants=["researcher"],
            authority=["researcher may run abstract test"],
            consequences=["test output"],
            provenance=["unit test"],
        )
        report = ConstitutionalAuditor().audit(Parser().parse("O -> E -> P", ctx))
        self.assertEqual(report.outcome, AuditOutcome.REPAIR)

    def test_irreversible_action_without_recovery_rejected(self) -> None:
        ctx = ContextCapsule(
            participants=["operator"],
            affected_parties=["subject"],
            authority=["operator"],
            costs=["irreversible cost"],
            consequences=["irreversible change"],
            consequence_horizon="long",
            provenance=["unit test"],
            risk_level="high",
            irreversible=True,
            execute_requested=True,
        )
        report = ConstitutionalAuditor().audit(Parser().parse("T -> Y", ctx))
        self.assertEqual(report.outcome, AuditOutcome.REJECT)

    def test_high_risk_without_affected_parties_rejected(self) -> None:
        ctx = ContextCapsule(
            participants=["operator"],
            authority=["operator"],
            costs=["system risk"],
            consequences=["high impact"],
            consequence_horizon="long",
            provenance=["unit test"],
            risk_level="high",
            execute_requested=True,
        )
        ast = Parser().parse("T -> Y", ctx)
        report = ConstitutionalAuditor().audit(ast)
        self.assertEqual(report.outcome, AuditOutcome.REJECT)


class MilestoneTests(unittest.TestCase):
    def test_canonical_milestone_is_valid_and_executes(self) -> None:
        text = (
            "Human and AI collaborators examine an unproven claim, preserve uncertainty, "
            "record contributions, and publish only what the evidence supports."
        )
        ast = CanonicalMilestoneCompiler().compile(text)
        self.assertEqual(
            ast.operation_path,
            ["Q", "O", "E", "U", "I", "G", "T", "P", "F", "Y"],
        )
        result = AbstractInterpreter().execute(ast)
        self.assertTrue(result.executed)
        self.assertEqual(result.audit.outcome, AuditOutcome.VALID)
        self.assertEqual(result.state["proof_status"], "context-limited")
        self.assertEqual(result.state["unknowns"], ast.context.unknowns)
        self.assertTrue(result.state["outputs"])


    def test_unsupported_natural_language_refuses_to_invent_structure(self) -> None:
        with self.assertRaises(UnsupportedNaturalLanguage):
            CanonicalMilestoneCompiler().compile("Make the system powerful.")

    def test_unknowns_survive_into_output(self) -> None:
        text = (
            "Human and AI collaborators examine an unproven claim, preserve uncertainty, "
            "record contributions, and publish only what the evidence supports."
        )
        result = AbstractInterpreter().execute(CanonicalMilestoneCompiler().compile(text))
        self.assertEqual(result.state["outputs"][0]["unknowns"], result.state["unknowns"])


if __name__ == "__main__":
    unittest.main()
