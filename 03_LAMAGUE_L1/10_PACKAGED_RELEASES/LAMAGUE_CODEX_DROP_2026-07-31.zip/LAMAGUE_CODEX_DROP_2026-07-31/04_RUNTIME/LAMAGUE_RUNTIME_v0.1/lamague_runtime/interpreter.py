from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from .auditor import ConstitutionalAuditor
from .explainer import Explainer
from .model import AuditOutcome, ExecutionResult, ProgramAST


class AbstractInterpreter:
    """Executes only over an in-memory abstract state record."""

    def __init__(self) -> None:
        self.auditor = ConstitutionalAuditor()
        self.explainer = Explainer()

    def execute(self, ast: ProgramAST, initial_state: dict[str, Any] | None = None) -> ExecutionResult:
        audit = self.auditor.audit(ast)
        state: dict[str, Any] = deepcopy(initial_state or {})
        state.setdefault("observations", [])
        state.setdefault("evidence", [])
        state.setdefault("unknowns", [])
        state.setdefault("invariants", [])
        state.setdefault("transitions", [])
        state.setdefault("memory", [])
        state.setdefault("outputs", [])
        state.setdefault("operations_applied", [])
        trace: list[dict[str, Any]] = []

        if audit.outcome is not AuditOutcome.VALID:
            trace.append({
                "event": "execution_blocked",
                "audit_outcome": audit.outcome.value,
                "time": datetime.now(timezone.utc).isoformat(),
            })
            return ExecutionResult(
                executed=False,
                state=state,
                audit=audit,
                trace=trace,
                explanation=self.explainer.explain(ast),
            )

        ctx = ast.context
        for node in ast.nodes:
            op = node.operation
            state["operations_applied"].append(op)
            event: dict[str, Any] = {
                "node_id": node.node_id,
                "operation": op,
                "operation_name": node.operation_name,
                "time": datetime.now(timezone.utc).isoformat(),
            }
            if op == "Q":
                state.setdefault("queries", []).append(ctx.claim or ctx.purpose or "unresolved target")
            elif op == "O":
                state["observations"].append({
                    "target": ctx.claim or ctx.purpose,
                    "domain": ctx.domain,
                    "provenance": ctx.provenance,
                })
            elif op == "E":
                state["evidence"].extend(x for x in ctx.evidence if x not in state["evidence"])
            elif op == "U":
                typed = node.arguments.get("type")
                values = [typed] if typed else ctx.unknowns
                for value in values:
                    if value and value not in state["unknowns"]:
                        state["unknowns"].append(value)
            elif op == "I":
                state["invariants"].extend(x for x in ctx.invariants if x not in state["invariants"])
            elif op == "G":
                state["guard"] = {
                    "passed": True,
                    "authority": ctx.authority,
                    "boundaries": ctx.boundaries,
                }
            elif op == "T":
                transition = {
                    "purpose": ctx.purpose,
                    "from": state.get("phase", "input"),
                    "to": "evaluated",
                    "invariants": list(state["invariants"]),
                }
                state["transitions"].append(transition)
                state["phase"] = "evaluated"
            elif op == "P":
                if not ctx.evidence:
                    proof_status = "under-determined"
                elif ctx.unknowns:
                    proof_status = "context-limited"
                else:
                    proof_status = "supported"
                state["proof_status"] = proof_status
            elif op == "F":
                state["memory"].append({
                    "claim": ctx.claim,
                    "evidence": list(ctx.evidence),
                    "unknowns": list(ctx.unknowns),
                    "invariants": list(ctx.invariants),
                    "residue": list(ctx.unknowns),
                })
            elif op == "X":
                state.setdefault("ledger", []).append(node.value_flow)
            elif op == "Y":
                output = {
                    "claim": ctx.claim,
                    "proof_status": state.get("proof_status", "not-requested"),
                    "scope": ctx.domain,
                    "unknowns": list(state["unknowns"]),
                }
                state["outputs"].append(output)
            else:
                state.setdefault("generic_records", []).append({
                    "operation": op,
                    "arguments": node.arguments,
                })
            event["state_digest"] = {
                "phase": state.get("phase"),
                "proof_status": state.get("proof_status"),
                "unknown_count": len(state["unknowns"]),
                "output_count": len(state["outputs"]),
            }
            trace.append(event)

        return ExecutionResult(
            executed=True,
            state=state,
            audit=audit,
            trace=trace,
            explanation=self.explainer.explain(ast),
        )
