# LAMAGUE Executable Kernel v0.1

A zero-dependency parser, canonical serializer, typed AST, deterministic interpreter, CLI and local browser playground for a frozen subset of LAMAGUE.

## What changed

The historical corpus already contained symbol classes, a BNF foundation and example expressions, while explicitly recording that a parser/compiler remained future work.

This package implements that missing narrow kernel.

## Quick start

### Browser

Open:

```text
browser/index.html
```

No server or network access is required.

### CLI

```bash
node cli.mjs "Ao → Φ↑ → Ψ"
```

With a custom state:

```bash
node cli.mjs "Ao → Φ↑ → Ψ" --state '{"drift":0.62,"coherence":0.31,"entropy":0.55,"anchor":0.8,"integrity":0.44}'
```

### Tests

```bash
npm test
```

## Executable subset

```text
Ao
Φ↑
Ψ
Ψ_inv
S↓
∅
Ω
→
⊗
⟟
( )
```

## Reserved

```text
↯
⟲
∇cas
⟐
⟁
Z₁ Z₂ Z₃
```

Reserved symbols fail closed with explicit errors.

## Pipeline

```text
source
→ normalize aliases
→ tokenize
→ parse AST
→ type-check
→ canonical serialize
→ execute
→ trace
```

## Current status

```text
Parser                  EXECUTABLE
Canonical serializer    EXECUTABLE
Typed AST               EXECUTABLE
Interpreter             EXECUTABLE
CLI                     EXECUTABLE
Browser playground      EXECUTABLE
Failure corpus          EXECUTABLE
CASCADE adapter          NOT INCLUDED
AURA policy adapter      NOT INCLUDED
TIM receipts             NOT INCLUDED
Empirical validation     NOT CLAIMED
```

## Authority boundary

This is the first executable reference dialect, not the entire historical language.

Read `docs/SEMANTIC_DECISIONS.md` before extending the grammar.
