#!/usr/bin/env node
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const K=require('./src/lamague-core.js');
function usage(){console.log(`LAMAGUE Executable Kernel v${K.VERSION}\n\nUsage:\n  node cli.mjs "Ao → Φ↑ → Ψ"\n  node cli.mjs "Ao → Φ↑ → Ψ" --state '{"drift":0.62,"coherence":0.31,"entropy":0.55,"anchor":0.8,"integrity":0.44}'\n  node cli.mjs "Ao → Φ↑ → Ψ" --ast\n`);}
const args=process.argv.slice(2);if(!args.length||args.includes('--help')){usage();process.exit(0);}const expression=args[0];
const stateIndex=args.indexOf('--state');let state;
if(stateIndex>=0){try{state=JSON.parse(args[stateIndex+1]);}catch(error){console.error('Invalid --state JSON:',error.message);process.exit(2);}}
try{const result=K.execute(expression,state);console.log(JSON.stringify(args.includes('--ast')?result.ast:result,null,2));}
catch(error){console.error(JSON.stringify({name:error.name,code:error.code||'E_UNKNOWN',message:error.message,position:error.position??null,details:error.details??null},null,2));process.exit(1);}
