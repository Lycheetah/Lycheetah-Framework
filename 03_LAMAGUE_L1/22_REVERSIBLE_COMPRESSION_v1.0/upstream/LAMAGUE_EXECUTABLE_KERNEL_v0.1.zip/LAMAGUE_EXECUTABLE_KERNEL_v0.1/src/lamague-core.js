(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports) module.exports=api;
  root.LamagueKernel=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';

const VERSION='0.1.0-kernel';
const CONTRACT='LAMAGUE-KERNEL-0.1';
const DEFAULT_CONFIG=Object.freeze({
  ascentRate:0.35,
  entropyRate:0.40,
  foldMemory:0.35,
  foldCorrection:0.25,
  fixedPointTolerance:1e-6,
  fixedPointMaxIterations:32
});

const ACTIVE=[
  {symbol:'Ψ_inv',name:'INVARIANT_RETURN',aliases:['Psi_inv','INVARIANT']},
  {symbol:'Φ↑',name:'ASCENT',aliases:['PhiUp','ASCENT']},
  {symbol:'S↓',name:'ENTROPY_DESCENT',aliases:['S_DOWN','ENTROPY_DOWN']},
  {symbol:'Ao',name:'ANCHOR',aliases:['A₀','ANCHOR']},
  {symbol:'Ψ',name:'FOLD',aliases:['Psi','FOLD']},
  {symbol:'∅',name:'NULL_RESET',aliases:['NULL','VOID']},
  {symbol:'Ω',name:'INTEGRATE',aliases:['OMEGA','WHOLENESS']}
];

const RESERVED=[
  {symbol:'∇cas',name:'CASCADE_PROPOSAL',aliases:['CASCADE']},
  {symbol:'↯',name:'COLLISION_FAMILY',aliases:['COLLAPSE','COLLISION','JUNCTION']},
  {symbol:'⟲',name:'RECURSION',aliases:['RECURSE']},
  {symbol:'⟐',name:'STABLE_TRIAD',aliases:[]},
  {symbol:'⟁',name:'INTEGRITY_CREST',aliases:[]},
  {symbol:'Z₁',name:'MINIMAL_COMPRESSION',aliases:['Z1']},
  {symbol:'Z₂',name:'HORIZON_COMPRESSION',aliases:['Z2']},
  {symbol:'Z₃',name:'ZENITH_COMPRESSION',aliases:['Z3']}
];

class LamagueError extends Error{
  constructor(code,message,position,details){
    super(message);
    this.name='LamagueError';
    this.code=code;
    this.position=position===undefined?null:position;
    this.details=details||null;
  }
}

function finite(name,v){
  if(typeof v!=='number'||!Number.isFinite(v)) throw new LamagueError('E_STATE',name+' must be finite');
  return v;
}
function unit(name,v){
  finite(name,v);
  if(v<0||v>1) throw new LamagueError('E_STATE',name+' must lie in [0,1]');
  return v;
}
function clamp(v){return Math.max(0,Math.min(1,v));}
function round(v){return Math.round(v*1e12)/1e12;}
function deepClone(x){return JSON.parse(JSON.stringify(x));}

function normalizeConfig(input){
  const c=Object.assign({},DEFAULT_CONFIG,input||{});
  unit('config.ascentRate',c.ascentRate);
  unit('config.entropyRate',c.entropyRate);
  unit('config.foldMemory',c.foldMemory);
  unit('config.foldCorrection',c.foldCorrection);
  finite('config.fixedPointTolerance',c.fixedPointTolerance);
  if(c.fixedPointTolerance<=0||c.fixedPointTolerance>1) throw new LamagueError('E_CONFIG','fixedPointTolerance must lie in (0,1]');
  if(!Number.isInteger(c.fixedPointMaxIterations)||c.fixedPointMaxIterations<1||c.fixedPointMaxIterations>10000)
    throw new LamagueError('E_CONFIG','fixedPointMaxIterations must be an integer in [1,10000]');
  return c;
}

function snapshot(input){
  const s=input||{};
  const out={
    drift:unit('state.drift',s.drift===undefined?0.5:s.drift),
    coherence:unit('state.coherence',s.coherence===undefined?0.5:s.coherence),
    entropy:unit('state.entropy',s.entropy===undefined?0.5:s.entropy),
    anchor:unit('state.anchor',s.anchor===undefined?0.8:s.anchor),
    integrity:unit('state.integrity',s.integrity===undefined?0.5:s.integrity)
  };
  out.history=Array.isArray(s.history)?s.history.map((h,i)=>({
    drift:unit('state.history['+i+'].drift',h.drift),
    coherence:unit('state.history['+i+'].coherence',h.coherence),
    entropy:unit('state.history['+i+'].entropy',h.entropy),
    anchor:unit('state.history['+i+'].anchor',h.anchor===undefined?out.anchor:h.anchor),
    integrity:unit('state.history['+i+'].integrity',h.integrity===undefined?out.integrity:h.integrity)
  })):[];
  return out;
}

function numericState(s){
  return {drift:s.drift,coherence:s.coherence,entropy:s.entropy,anchor:s.anchor,integrity:s.integrity};
}
function cleanState(s,history){
  return {
    drift:round(clamp(s.drift)),
    coherence:round(clamp(s.coherence)),
    entropy:round(clamp(s.entropy)),
    anchor:round(clamp(s.anchor)),
    integrity:round(clamp(s.integrity)),
    history:(history||s.history||[]).map(numericState)
  };
}
function maxDelta(a,b){
  return Math.max(
    Math.abs(a.drift-b.drift),
    Math.abs(a.coherence-b.coherence),
    Math.abs(a.entropy-b.entropy),
    Math.abs(a.anchor-b.anchor),
    Math.abs(a.integrity-b.integrity)
  );
}

function normalizeSource(source){
  if(typeof source!=='string') throw new LamagueError('E_SOURCE','source must be a string');
  let s=source.normalize('NFC');
  const aliases=[];
  ACTIVE.concat(RESERVED).forEach(def=>def.aliases.forEach(alias=>aliases.push([alias,def.symbol])));
  aliases.push(['->','→'],['FIX','⟟']);
  aliases.sort((a,b)=>b[0].length-a[0].length);
  for(const [alias,canonical] of aliases){
    const escaped=alias.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const word=/^[A-Za-z0-9_]+$/.test(alias);
    s=s.replace(new RegExp(word?'\\b'+escaped+'\\b':escaped,'g'),canonical);
  }
  return s;
}

const OPERATORS=[['→','ARROW'],['⊗','FUSION'],['⟟','FIXED'],['(','LPAREN'],[')','RPAREN']];
const SYMBOLS=ACTIVE.concat(RESERVED).sort((a,b)=>b.symbol.length-a.symbol.length);

function tokenize(source){
  const normalized=normalizeSource(source);
  const tokens=[];
  let i=0;
  while(i<normalized.length){
    const ch=normalized[i];
    if(/\s/u.test(ch)){i++;continue;}
    let matched=false;
    for(const [lexeme,type] of OPERATORS){
      if(normalized.startsWith(lexeme,i)){
        tokens.push({type,value:lexeme,position:i});
        i+=lexeme.length;matched=true;break;
      }
    }
    if(matched) continue;
    for(const def of SYMBOLS){
      if(normalized.startsWith(def.symbol,i)){
        const boundary=i+def.symbol.length;
        const next=normalized[boundary]||'';
        if(/[A-Za-z0-9_]/.test(def.symbol.slice(-1))&&/[A-Za-z0-9_]/.test(next)) continue;
        tokens.push({type:RESERVED.includes(def)?'RESERVED':'PRIMITIVE',value:def.symbol,name:def.name,position:i});
        i+=def.symbol.length;matched=true;break;
      }
    }
    if(matched) continue;
    throw new LamagueError('E_TOKEN','Unknown token beginning at "'+normalized.slice(i,i+12)+'"',i);
  }
  tokens.push({type:'EOF',value:'',position:i});
  return {source:normalized,tokens};
}

function parse(source){
  const tokenized=tokenize(source);
  const t=tokenized.tokens;
  let p=0;
  const peek=()=>t[p];
  const take=type=>{
    const token=peek();
    if(token.type!==type) throw new LamagueError('E_PARSE','Expected '+type+' but found '+token.type,token.position,{token});
    p++;return token;
  };

  function sequence(){
    const items=[fusion()];
    while(peek().type==='ARROW'){take('ARROW');items.push(fusion());}
    return items.length===1?items[0]:{type:'Sequence',items};
  }
  function fusion(){
    const items=[postfix()];
    while(peek().type==='FUSION'){take('FUSION');items.push(postfix());}
    return items.length===1?items[0]:{type:'Fusion',items};
  }
  function postfix(){
    let node=primary();
    while(peek().type==='FIXED'){
      const token=take('FIXED');
      node={type:'FixedPoint',expression:node,position:token.position};
    }
    return node;
  }
  function primary(){
    const token=peek();
    if(token.type==='RESERVED'){
      throw new LamagueError('E_RESERVED','Symbol '+token.value+' ('+token.name+') is reserved in v0.1',token.position,{symbol:token.value,name:token.name});
    }
    if(token.type==='PRIMITIVE'){
      p++;
      return {type:'Primitive',symbol:token.value,name:token.name,position:token.position};
    }
    if(token.type==='LPAREN'){
      take('LPAREN');
      const node=sequence();
      take('RPAREN');
      return {type:'Group',expression:node};
    }
    throw new LamagueError('E_PARSE','Expected a primitive or "(" but found '+token.type,token.position,{token});
  }

  if(peek().type==='EOF') throw new LamagueError('E_PARSE','Program is empty',0);
  const ast=sequence();
  if(peek().type==='RESERVED') throw new LamagueError('E_RESERVED','Symbol '+peek().value+' ('+peek().name+') is reserved in v0.1',peek().position,{symbol:peek().value,name:peek().name});
  if(peek().type!=='EOF') throw new LamagueError('E_PARSE','Unexpected token '+peek().value,peek().position);
  return {contractVersion:CONTRACT,languageVersion:VERSION,source:tokenized.source,ast};
}

function typeCheckNode(node,path,diagnostics){
  path=path||'$';diagnostics=diagnostics||[];
  switch(node.type){
    case 'Primitive':diagnostics.push({path,type:'StateTransform',rule:'primitive '+node.symbol+' : State -> State'});return 'StateTransform';
    case 'Group':return typeCheckNode(node.expression,path+'.expression',diagnostics);
    case 'Sequence':
    case 'Fusion':
      node.items.forEach((child,i)=>{
        const type=typeCheckNode(child,path+'.items['+i+']',diagnostics);
        if(type!=='StateTransform') throw new LamagueError('E_TYPE',node.type+' requires StateTransform operands',null,{path});
      });
      diagnostics.push({path,type:'StateTransform',rule:node.type+' composition'});return 'StateTransform';
    case 'FixedPoint':{
      const type=typeCheckNode(node.expression,path+'.expression',diagnostics);
      if(type!=='StateTransform') throw new LamagueError('E_TYPE','FixedPoint requires StateTransform',null,{path});
      diagnostics.push({path,type:'StateTransform',rule:'FixedPoint(StateTransform)'});return 'StateTransform';
    }
    default:throw new LamagueError('E_TYPE','Unknown AST node '+node.type,null,{path});
  }
}
function typeCheck(ast){const diagnostics=[];const type=typeCheckNode(ast,'$',diagnostics);return {type,diagnostics};}

function precedence(node){if(node.type==='Sequence')return 1;if(node.type==='Fusion')return 2;if(node.type==='FixedPoint')return 3;return 4;}
function serializeNode(node,parentPrecedence){
  parentPrecedence=parentPrecedence||0;let text;
  if(node.type==='Primitive') text=node.symbol;
  else if(node.type==='Group') text='('+serializeNode(node.expression,0)+')';
  else if(node.type==='FixedPoint') text=serializeNode(node.expression,precedence(node))+'⟟';
  else if(node.type==='Sequence') text=node.items.map(x=>serializeNode(x,precedence(node))).join(' → ');
  else if(node.type==='Fusion') text=node.items.map(x=>serializeNode(x,precedence(node))).join(' ⊗ ');
  else throw new LamagueError('E_SERIALIZE','Unknown AST node '+node.type);
  return precedence(node)<parentPrecedence?'('+text+')':text;
}
function serialize(ast){return serializeNode(ast,0);}

function traceEntry(symbol,name,before,after,meta){
  return {kind:'operator',symbol,name,before:numericState(before),after:numericState(after),delta:round(maxDelta(before,after)),meta:meta||{}};
}
function pushHistory(before,after,max=16){
  const history=(before.history||[]).concat([numericState(before)]).slice(-max);
  return cleanState(after,history);
}
function weightedHistoryMean(state){
  const points=(state.history||[]).concat([numericState(state)]);
  let total=0;const acc={drift:0,coherence:0,entropy:0,anchor:0,integrity:0};
  points.forEach((point,index)=>{
    const lag=points.length-1-index;const w=Math.exp(-lag);total+=w;
    Object.keys(acc).forEach(k=>acc[k]+=point[k]*w);
  });
  Object.keys(acc).forEach(k=>acc[k]/=total||1);return acc;
}

function applyPrimitive(node,state,config){
  const before=state;let next;let meta={};
  switch(node.name){
    case 'ANCHOR':
      next={drift:Math.min(state.drift,1-state.anchor),coherence:Math.max(state.coherence,state.anchor),entropy:Math.min(state.entropy,1-state.anchor),anchor:state.anchor,integrity:Math.max(state.integrity,state.anchor)};
      meta={property:'idempotent projection'};break;
    case 'ASCENT':{
      const gain=config.ascentRate*(1-state.coherence)*(1-0.5*state.entropy);
      next={drift:state.drift*(1-0.35*config.ascentRate),coherence:state.coherence+gain,entropy:state.entropy*(1-0.20*config.ascentRate),anchor:state.anchor,integrity:state.integrity+0.20*gain*(1-state.integrity)};
      meta={gain:round(gain),ascentRate:config.ascentRate};break;
    }
    case 'FOLD':{
      const mean=weightedHistoryMean(state),m=config.foldMemory,c=config.foldCorrection,blended={};
      ['drift','coherence','entropy','anchor','integrity'].forEach(k=>blended[k]=(1-m)*state[k]+m*mean[k]);
      next={drift:blended.drift*(1-c),coherence:blended.coherence+c*(1-blended.coherence),entropy:blended.entropy*(1-c),anchor:blended.anchor,integrity:blended.integrity+c*0.25*(1-blended.integrity)};
      meta={historyPoints:(state.history||[]).length+1,foldMemory:m,foldCorrection:c};break;
    }
    case 'INVARIANT_RETURN':next={drift:0,coherence:1,entropy:0,anchor:state.anchor,integrity:Math.max(state.integrity,state.anchor)};break;
    case 'ENTROPY_DESCENT':
      next={drift:state.drift,coherence:state.coherence+0.10*config.entropyRate*(1-state.coherence),entropy:state.entropy*(1-config.entropyRate),anchor:state.anchor,integrity:state.integrity};
      meta={entropyRate:config.entropyRate};break;
    case 'NULL_RESET':next={drift:0,coherence:0,entropy:0,anchor:state.anchor,integrity:0};meta={preserved:['anchor']};break;
    case 'INTEGRATE':next={drift:0,coherence:1,entropy:0,anchor:state.anchor,integrity:1};break;
    default:throw new LamagueError('E_RUNTIME','Unknown primitive '+node.name,node.position);
  }
  const after=pushHistory(before,cleanState(next,before.history));
  return {state:after,trace:[traceEntry(node.symbol,node.name,before,after,meta)]};
}

function executeNode(node,state,config){
  switch(node.type){
    case 'Primitive':return applyPrimitive(node,state,config);
    case 'Group':return executeNode(node.expression,state,config);
    case 'Sequence':{
      let current=state;const trace=[];
      node.items.forEach(child=>{const result=executeNode(child,current,config);current=result.state;trace.push(...result.trace);});
      return {state:current,trace};
    }
    case 'Fusion':{
      const branches=node.items.map(child=>executeNode(child,deepClone(state),config));
      const merged={drift:0,coherence:0,entropy:0,anchor:0,integrity:0};
      Object.keys(merged).forEach(k=>{merged[k]=branches.reduce((sum,b)=>sum+b.state[k],0)/branches.length;});
      const after=pushHistory(state,cleanState(merged,state.history));
      return {state:after,trace:[{kind:'fusion',symbol:'⊗',before:numericState(state),after:numericState(after),delta:round(maxDelta(state,after)),branches:branches.map((b,i)=>({index:i,state:numericState(b.state),trace:b.trace}))}]};
    }
    case 'FixedPoint':{
      let current=state;const iterations=[];let converged=false;
      for(let i=1;i<=config.fixedPointMaxIterations;i++){
        const result=executeNode(node.expression,current,config);const delta=maxDelta(current,result.state);
        iterations.push({iteration:i,delta:round(delta),state:numericState(result.state),trace:result.trace});current=result.state;
        if(delta<=config.fixedPointTolerance){converged=true;break;}
      }
      return {state:current,trace:[{kind:'fixed-point',symbol:'⟟',before:numericState(state),after:numericState(current),delta:round(maxDelta(state,current)),converged,tolerance:config.fixedPointTolerance,maxIterations:config.fixedPointMaxIterations,iterations}]};
    }
    default:throw new LamagueError('E_RUNTIME','Unknown AST node '+node.type);
  }
}

function execute(input,stateInput,configInput){
  const parsed=typeof input==='string'?parse(input):{ast:input,source:null};
  const typeResult=typeCheck(parsed.ast),config=normalizeConfig(configInput),initial=snapshot(stateInput),result=executeNode(parsed.ast,initial,config);
  return {
    contractVersion:CONTRACT,languageVersion:VERSION,source:parsed.source,canonical:serialize(parsed.ast),ast:parsed.ast,
    type:typeResult.type,typeDiagnostics:typeResult.diagnostics,initialState:numericState(initial),finalState:numericState(result.state),
    history:result.state.history,trace:result.trace,config,
    boundary:'Deterministic reference semantics for a frozen LAMAGUE subset; not an empirical model of consciousness, truth or ethics.'
  };
}
function roundTrip(source){
  const first=parse(source),canonical=serialize(first.ast),second=parse(canonical);
  return {canonical,stable:JSON.stringify(first.ast)===JSON.stringify(second.ast),first:first.ast,second:second.ast};
}

return {VERSION,CONTRACT,DEFAULT_CONFIG,LamagueError,normalizeSource,tokenize,parse,typeCheck,serialize,execute,roundTrip,snapshot,maxDelta};
});
