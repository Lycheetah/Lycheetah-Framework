# Runtime State and Deterministic Reference Semantics

## State schema

```json
{
  "drift": 0.62,
  "coherence": 0.31,
  "entropy": 0.55,
  "anchor": 0.80,
  "integrity": 0.44,
  "history": []
}
```

All numeric fields must be finite and lie in `[0,1]`.

`history` is optional and may contain prior bounded state snapshots.

## Configuration

```json
{
  "ascentRate": 0.35,
  "entropyRate": 0.40,
  "foldMemory": 0.35,
  "foldCorrection": 0.25,
  "fixedPointTolerance": 0.000001,
  "fixedPointMaxIterations": 32
}
```

## Operators

### `Ao` — anchor projection

```text
drift'     = min(drift, 1 - anchor)
entropy'   = min(entropy, 1 - anchor)
coherence' = max(coherence, anchor)
integrity' = max(integrity, anchor)
```

This operation is idempotent.

### `Φ↑` — ascent

```text
gain       = ascentRate × (1 - coherence) × (1 - 0.5 × entropy)
coherence' = coherence + gain
drift'     = drift × (1 - 0.35 × ascentRate)
entropy'   = entropy × (1 - 0.20 × ascentRate)
integrity' = integrity + 0.20 × gain × (1 - integrity)
```

### `Ψ` — causal fold

Prior states are exponentially weighted. The current state is combined with the history mean using `foldMemory`, then nudged toward the invariant reference using `foldCorrection`.

### `Ψ_inv`

```text
drift'     = 0
coherence' = 1
entropy'   = 0
integrity' = max(integrity, anchor)
```

### `S↓`

```text
entropy'   = entropy × (1 - entropyRate)
coherence' = coherence + 0.10 × entropyRate × (1 - coherence)
```

### `∅`

```text
drift' = coherence' = entropy' = integrity' = 0
anchor is preserved
```

### `Ω`

```text
drift' = 0
coherence' = 1
entropy' = 0
integrity' = 1
anchor is preserved
```

### Fusion `⊗`

Both branches execute from the same input state. Their numeric outputs are merged by equal arithmetic mean. This makes v0.1 fusion commutative under deterministic branches.

### Fixed point `⟟`

The enclosed transformation repeats until maximum numeric state delta is no greater than tolerance, or the iteration bound is reached.

The trace reports whether convergence occurred.

## Honesty boundary

These equations are deterministic reference semantics chosen to make a frozen subset executable.

They are not empirical models of consciousness, truth, ethics or neural state.
