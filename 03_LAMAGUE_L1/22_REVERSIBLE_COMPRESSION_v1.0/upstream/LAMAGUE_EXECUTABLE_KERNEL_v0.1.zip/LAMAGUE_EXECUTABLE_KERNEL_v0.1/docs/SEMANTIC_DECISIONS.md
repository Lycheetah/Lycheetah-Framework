# LAMAGUE v0.1 Semantic Decision Ledger

## Why this ledger exists

The source archive preserves several generations of notation. Those generations do not always assign one symbol one role.

The v0.1 kernel therefore does not claim to reveal the only correct meaning. It freezes a narrow executable dialect and records every collision it resolves or postpones.

## Frozen decisions

### `Ao`

Historical use:
- anchor field;
- stable baseline;
- TRIAD anchoring operator;
- sometimes associated with `⟟`.

v0.1:
- executable idempotent state transformation named `ANCHOR`;
- `⟟` remains a separate fixed-point operator;
- `Ao` and `⟟` are not aliases in canonical serialization.

### `Φ↑`

Historical use:
- ascent;
- orientation;
- coherence-directed correction.

v0.1:
- executable bounded ascent transformation;
- no claim is made that the scalar implementation is a unitary vector operator.

### `Ψ`

Historical use:
- drift field;
- fold;
- causal integration;
- correction;
- consciousness state in extended documents.

v0.1:
- executable `FOLD` operator only;
- field and consciousness meanings remain outside the kernel.

### `↯`

Historical use:
- collapse;
- collision;
- decision junction.

v0.1:
- reserved and rejected;
- no executable meaning chosen.

### `⟲`

Historical use:
- recursion;
- synthesis;
- cycle return.

v0.1:
- reserved until explicit bounds and termination semantics are canonical.

### `∇cas`

Historical use:
- CASCADE reorganisation after a truth-pressure condition.

v0.1:
- reserved;
- the kernel cannot reorganize CASCADE;
- a later adapter may emit a review proposal, never an automatic structural mutation.

### `∅`

Historical use:
- void;
- zero-node;
- null state;
- catastrophic reset expressions.

v0.1:
- deterministic dynamic-state reset;
- external anchor configuration is preserved so reset does not destroy runtime configuration.

### `Ω`

Historical use:
- wholeness;
- limit state;
- integrated state.

v0.1:
- bounded integrated reference transformation.

## Source-derived versus newly operationalized

Source-derived:
- symbol families;
- four-class grammar lineage;
- TRIAD order;
- state/transformation framing;
- compression objective;
- fixed-point, fusion and projection concepts;
- parser/compiler identified as missing work.

New v0.1 operationalization:
- exact parser precedence;
- scalar runtime state schema;
- numeric transition equations;
- fusion merge rule;
- fixed-point tolerance and iteration bound;
- error codes;
- CLI and browser interfaces.

These new choices are executable reference semantics, not discovered laws.
