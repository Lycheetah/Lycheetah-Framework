# Source Basis

The v0.1 kernel was grounded in the uploaded LAMAGUE corpus.

## Source-derived foundations

- LAMAGUE is presented as a symbolic compression and mathematical micro-language.
- The source identifies invariant, dynamic, field and meta symbol classes.
- Expressions are described through state, transformation and state relationships.
- `Ao`, `Φ↑` and `Ψ` form the TRIAD kernel.
- `→`, `⊗`, `⟲` and `⟟` appear as composition or transformation symbols.
- The corpus contains a BNF grammar.
- The corpus explicitly states that the available reference implementation did not implement a LAMAGUE parser/compiler and records that as future work.
- The operating guide emphasizes reversible decompression: an expression should return to plain language without adding or losing meaning.

## Conflicts preserved

- `Ψ` is both field and operator across generations.
- `Ao` is both field and anchoring operator.
- `↯` means collapse, collision and junction in different sources.
- `⟲` means recursion, synthesis and cycle return.
- `⟟` is a fixed point and is sometimes presented near `Ao` as an anchor alias.
- `∇cas` historically implies reorganisation, but its governance and runtime semantics are not frozen.

The executable dialect resolves only what is required for v0.1 and leaves the rest reserved.
