# LAMAGUE Executable Kernel v0.1 Grammar

This grammar is intentionally narrower than the historical LAMAGUE corpus.

```bnf
<program>       ::= <sequence>
<sequence>      ::= <fusion> ( "→" <fusion> )*
<fusion>        ::= <postfix> ( "⊗" <postfix> )*
<postfix>       ::= <primary> ( "⟟" )*
<primary>       ::= <primitive> | "(" <sequence> ")"
<primitive>     ::= "Ao" | "Φ↑" | "Ψ" | "Ψ_inv" | "S↓" | "∅" | "Ω"
```

## Precedence

1. Parentheses
2. Postfix fixed point `⟟`
3. Fusion `⊗`
4. Sequence `→`

## Canonical examples

```lamague
Ao → Φ↑ → Ψ
∅⟟
Ao ⊗ Φ↑
(Ao → Φ↑) ⊗ S↓
Ao → Φ↑ → Ψ_inv
```

## Reserved and rejected in v0.1

```lamague
↯
⟲
∇cas
⟐
⟁
Z₁
Z₂
Z₃
```

These symbols are preserved in the registry but do not yet have frozen executable semantics.
