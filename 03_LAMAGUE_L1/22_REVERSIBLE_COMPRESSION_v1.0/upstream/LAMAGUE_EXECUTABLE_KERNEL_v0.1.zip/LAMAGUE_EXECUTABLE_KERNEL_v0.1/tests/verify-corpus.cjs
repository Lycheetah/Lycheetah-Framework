const fs=require('node:fs');
const path=require('node:path');
const K=require('../src/lamague-core.js');
const corpus=JSON.parse(fs.readFileSync(path.join(__dirname,'failure-corpus.json'),'utf8'));
let passed=0;
for(const c of corpus.cases){
  let actual='VALID';
  try{K.parse(c.expression);}catch(e){actual=e.code||'E_UNKNOWN';}
  if(actual!==c.expected){
    console.error(`❌ ${c.id}: expected ${c.expected}, got ${actual} — ${c.expression}`);
    process.exitCode=1;
  }else{
    passed++;console.log(`✅ ${c.id}: ${actual}`);
  }
}
if(!process.exitCode) console.log(`\n🟢 ${passed}/${corpus.cases.length} failure-corpus cases passed.`);
