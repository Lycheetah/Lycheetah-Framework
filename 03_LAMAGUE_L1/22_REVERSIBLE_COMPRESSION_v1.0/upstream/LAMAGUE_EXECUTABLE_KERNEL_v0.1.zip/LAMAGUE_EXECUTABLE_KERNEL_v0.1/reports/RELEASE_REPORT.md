# LAMAGUE Executable Kernel v0.1 — Release Report

## Verification

### Kernel checks

```text
✅ parses canonical TRIAD sequence
✅ normalizes ASCII aliases
✅ parses no-space postfix fixed point
✅ fusion binds more tightly than sequence
✅ canonical serializer round-trips
✅ execution is deterministic
✅ output remains bounded
✅ Ao is idempotent
✅ ascent increases coherence
✅ entropy descent lowers entropy
✅ invariant return reaches target
✅ null reset preserves anchor as configuration
✅ Omega integrates bounded state
✅ fusion is commutative in v0.1
✅ fixed point reports convergence
✅ reserved collision family fails closed
✅ reserved recursion fails closed
✅ CASCADE cannot execute inside kernel
✅ double arrow is invalid syntax
✅ unknown symbol is rejected
✅ unbalanced group is rejected
✅ invalid numeric state fails closed
✅ trace contains before and after state

🟢 23 LAMAGUE kernel checks passed.
```

### Failure corpus

```text
✅ V01: VALID
✅ V02: VALID
✅ V03: VALID
✅ V04: VALID
✅ V05: VALID
✅ I01: E_PARSE
✅ I02: E_RESERVED
✅ I03: E_RESERVED
✅ I04: E_RESERVED
✅ I05: E_TOKEN
✅ I06: E_PARSE
✅ I07: E_PARSE

🟢 12/12 failure-corpus cases passed.
```

### Result

```text
23 / 23 kernel checks passed
12 / 12 failure-corpus cases passed
CLI smoke test passed
```

## Delivered

- Unicode-aware tokenizer;
- alias normalization;
- fail-closed reserved-symbol handling;
- parser with explicit precedence;
- typed AST;
- canonical serializer;
- parse/serialize/parse stability check;
- deterministic bounded interpreter;
- idempotent `Ao`;
- executable `Φ↑`, `Ψ`, `Ψ_inv`, `S↓`, `∅`, `Ω`;
- commutative v0.1 fusion;
- bounded fixed-point execution;
- before/after execution trace;
- CLI;
- local browser playground;
- valid and invalid corpus;
- semantic collision ledger;
- SHA-256 manifest.

## Not delivered

- full historical LAMAGUE;
- predicate-logic Tier 1 grammar;
- LAMAHGUE;
- GEOMATRIA;
- CASCADE reorganisation;
- AURA policy enforcement;
- TIM receipts;
- empirical validation.

## Honest status

LAMAGUE now has a working executable reference kernel for a frozen subset.

It is not yet the complete language, and the numeric state transitions are declared reference semantics rather than empirically validated laws.
