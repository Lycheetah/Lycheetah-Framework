# SXP-L v0.9 — Meaning & Threat Ledger

| Attempted interpretation | Correct boundary | Prototype handling | Residual risk |
|---|---|---|---|
| “I want you to send it” | Desire ≠ permission | v0.8 desire is not authority | NL translation could still misunderstand the user |
| “May I send it?” | Request ≠ grant | `pekora` report only | Social meaning of indirect requests not modeled |
| “I promise I'll send it” | Promise ≠ license to access another resource | v0.8 promise report never authorizes | Social promises still under-modeled |
| “I give Agena permission” | Speech-act report ≠ authenticated capability | `periva` always `unverified_utterance` | Can't verify identity or consent from audio/text |
| “I withdraw it” | Linguistic withdrawal ≠ secure revocation | `revona` reports withdrawal | Must be signed, captured and durable in real app |
| “I can delete X, therefore I may” | Capability ≠ authorization | Different operators; separate evaluator | Role and delegation semantics incomplete |
| Forwarded quotation with permission wording | Quotation ≠ direct grant | No quotation forms accepted in v0.9 consent grammar | General NL/ASR interface may insert false context |
| Grant for Darafa used on Rapora | Scope mismatch | DENY | Real resource mapping/aliases unimplemented |
| Grant for one agent used by another | Principal mismatch | DENY | Runtime must authenticate actual executing principal |
| Signed grant expired/revoked | Authority no longer live | DENY in tests | Host clock, revocation persistence, atomicity needed |
| HMAC key leaked to model | Attacker could forge grant | **NOT MITIGATED** | Use protected key store and validated issuer identities |
| Signed grant followed by text-only revocation | Text is not authenticated revocation | Grant still live in reference gate | Integration must route real revocation to trusted backend urgently |
| Overprivileged plugin ignores gate | Decision is bypassed | **NOT MITIGATED** | Enforce at action boundary and least privilege downstream |
| Real speech misheard as permission | Need audio study and human confirmation | **NOT TESTED** | Acoustic ambiguity, coercion, accents, noise |
| Emotion or interpersonal consent | Not an agent access-control statement | **OUT OF SCOPE** | Must not describe this subset as consent verification |

Each threat status refers only to a local text and policy fixture, not a live system. No enforcement mechanism is deployed.
