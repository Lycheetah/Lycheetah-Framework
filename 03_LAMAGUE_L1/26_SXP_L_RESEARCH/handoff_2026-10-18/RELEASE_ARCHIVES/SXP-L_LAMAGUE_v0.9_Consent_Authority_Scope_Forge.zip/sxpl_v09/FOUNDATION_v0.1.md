# SXP-L / LAMAGUE — Language Construction Dossier v0.1
**Lycheetah research draft · 17 October 2026 · proposed, not ratified**

> A synthetic language is allowed to be invented. Its claims about fidelity, usability, compression, and safety must be tested, not invented.

## 0. Mission and scope
SXP-L is proposed as a **dual-register constructed language**: humans should be able to write and eventually speak it; AI systems should be able to exchange a mechanically checkable, semantically faithful representation. Its north star is **recoverable meaning across human ↔ machine boundaries**, not mystical universality or automatic safety. SXP-L is **not** currently demonstrated to outperform English, controlled natural languages, JSON Schema, or formal logic. This document is a design proposal and evaluation plan.

**Relationship to existing Lycheetah work:** LAMAGUE is the broader symbolic/constraint ecosystem. Its historical TRIAD `Ao → Φ↑ → Ψ`, semantic invariants, and LAMAHGUE/GEOMATRIA extensions are not silently redefined here. Native-36 offers 10 numeral cells and 26 operation cells and remains a **legacy/interoperability lexicon**, not an entire human language. Core handles canonical identity. BRIDGE handles typed agent-task transfer and authority/recovery semantics. Spoken LAMAGUE is a related experiment whose combined lexical inventory exhibited segmentation ambiguity; SXP-L deliberately does not pretend those issues are solved. Names for SXP-L and expanded mappings remain provisional pending source reconciliation.

## 1. The two registers
1. **SXP-H (human register):** readable and pronounceable utterances; limited syntax; explicit role marking; natural prosody permitted but never relied on for machine semantics.
2. **SXP-C (canonical register):** typed abstract syntax tree (AST) with a declared schema version, fixed operator identifiers, explicit actor/authority/scope/evidence and errors. No inference of missing permissions.

Round-trip ambition: `SXP-H → AST → SXP-C → AST → SXP-H`. A decoded human utterance may be rephrased; the AST's *contractual meaning* must be preserved. Lexical artistry need not survive canonicalization.

## 2. Design laws
- **Recoverability:** `decode(encode(x)) ≡ x` for a well-defined semantic-equivalence relation, not arbitrary strings.
- **No authority by implication:** any requested external action needs a named authorizing subject, granted scope, and affirmative decision.
- **Uncertainty is first-class:** unknown ≠ false ≠ withheld ≠ contradictory.
- **Evidence is scoped:** a statement's source and confidence do not transfer to adjacent statements.
- **Negation and modalities are typed:** a desire, prediction, fact, question, instruction, and prohibition cannot accidentally be conflated.
- **Version before compression:** canonical IDs and meaning-bearing fields are preserved even when surface vocabulary evolves.
- **Humans remain sovereign:** machine outputs are proposals unless explicitly authorized through the receiving runtime.

## 3. Native-36 legacy layer (NOT new coinages)
Native-36 numbers: `0 1 2 3 4 5 6 7 8 9` are numeric cells. Existing letter-cell semantic operations:

| Cell | Operation | Cell | Operation |
|---|---|---|---|
| A | Anchor | N | Novelty |
| B | Bridge | O | Observe |
| C | Cycle | P | Prove |
| D | Drift | Q | Query |
| E | Evidence | R | Resolve |
| F | Fold | S | State |
| G | Guard | T | Transition |
| H | Horizon | U | Unknown |
| I | Invariant | V | VectorInvert |
| J | Junction | W | Weave |
| K | Kernel | X | Exchange |
| L | Limit | Y | Yield |
| M | Merge | Z | Compress |

These are **operation identifiers**, not automatically interchangeable with English verbs or inflected conversational words. Their detailed preconditions, postconditions and canonical IDs must be independently versioned. The uppercase tokens above are temporary convenient spellings; do not equate them with spoken phonemes, and do not collapse historical symbol families into 36 cells.

## 4. SXP-H v0.1: an intentionally small complete clause grammar
In v0.1, human text is ASCII/Unicode text separated by spaces. **Reserved tokens are never concatenated.** Quoted literals use JSON-compatible double quotes; token spellings are provisionally English-readable rather than claimed to be existing Spoken LAMAGUE pronunciations.

### 4.1 Reserved grammar words
`sa` declarative/assertion, `qu` question, `di` directive proposal, `no` negation, `ma` possibility, `mu` obligation, `fu` future, `pa` past, `nu` present, `ka` actor, `ta` target, `lo` location/context, `se` source/evidence, `au` authorizer, `sc` scope, `co` confidence, `xi` unknown, `ve` verified-by-reference, `en` clause end.

**Important:** These are *new provisional SXP-H grammar particles*, not identified historical LAMAGUE lexical forms. `sc` is an orthographic consonant cluster in this text prototype; the spoken phonology has not yet been fixed. All reserved words remain space-delimited until an independently verified uniquely decodable spoken lexicon exists.

### 4.2 Syntax (EBNF, normative for this proposal)
```ebnf
utterance  = clause , "en" ;
clause     = mood , [ negation ] , [ modality ] , [ time ] , predicate , { role } ;
mood       = "sa" | "qu" | "di" ;
negation   = "no" ;
modality   = "ma" | "mu" ;
time       = "pa" | "nu" | "fu" ;
predicate  = operation | identifier ;
operation  = "A" | "B" | "C" | "D" | "E" | "F" | "G" | "H" | "I" | "J" |
             "K" | "L" | "M" | "N" | "O" | "P" | "Q" | "R" | "S" | "T" |
             "U" | "V" | "W" | "X" | "Y" | "Z" ;
role       = role_mark , value ;
role_mark  = "ka" | "ta" | "lo" | "se" | "au" | "sc" | "co" ;
value      = json_quoted_string | identifier | numeral | "xi" ;
identifier = letter , { letter | digit | "_" | "-" | "." } ;
numeral    = digit , { digit } , [ "." , digit , { digit } ] ;
```
Lexical priority: reserved words and uppercase single-letter operations are recognized before identifiers. A value must be one token or a double-quoted string. Each semantic role may appear **at most once** in a clause; duplicates are parse errors. Role order is free but canonical output uses `ka, ta, lo, se, au, sc, co`. Future syntax may support subordinate clauses only through AST references, not informal juxtaposition.

### 4.3 Meaning, not just token order
A complete clause denotes `{mood, polarity, modality, time, op, roles}`; omitted fields mean *unspecified*, never silently default to `true`, `present`, `authorized`, or `verified`.

- `sa` is a **reported assertion**, not an epistemic guarantee.
- `qu` requests information but cannot authorize an action.
- `di` expresses a **directive proposal**; external effect is disabled by default.
- `no` negates the clause's proposition, not a particular token.
- `ma` marks possibility; `mu` obligation claim (does not itself create permission).
- `se` holds a source identifier, not proof of source truth.
- `co` holds a declared confidence in `[0,1]` (not a calibration guarantee).
- `xi` denotes explicitly unknown; it must not be coerced to `false`.

## 5. Examples with glosses
**Observation:**
```
sa nu O ka "sensor_7" ta "pressure" se "reading_018" co 0.91 en
```
"Sensor 7 reports an observation about pressure, linked to reading 018, with reported confidence 0.91." Not necessarily verified.

**Question:**
```
qu P ta "reading_018" en
```
"Can reading 018 be proved/validated?" The precise semantics of `P` must be finalized in the Native-36 operator registry.

**Denied directive proposal:**
```
di no X ka "agent_2" ta "customer_data" au "user_9" sc "public_only" en
```
"Proposal that agent 2 not exchange customer data, mentioning user 9 and public-only scope." `au` names a purported authorizer **but does not carry an actual cryptographic grant**.

**Uncertainty:**
```
sa U ta "invoice_status" se xi en
```
"Invoice status is unknown; source is explicitly unknown."

**Boundary warning:** These sentences have useful structure, but some operation-to-English glosses remain conceptual, not a complete denotational semantics. They are samples, not an interoperability proof.

## 6. SXP-C canonical AST proposal
Example corresponding to the first utterance:
```json
{
  "lang": "SXP-L", "schema": "0.1.0", "register": "canonical",
  "clause": {
    "mood": "assert", "polarity": "positive", "modality": null,
    "time": "present", "op": "N36:O",
    "roles": {
      "actor": {"type": "string", "value": "sensor_7"},
      "target": {"type": "string", "value": "pressure"},
      "source": {"type": "string", "value": "reading_018"},
      "confidence": {"type": "number", "value": 0.91}
    }
  }
}
```
Canonical rules planned: sorted, schema-defined key order; normalized Unicode NFC for strings; no floating-point canonicalization ambiguity (confidence to be encoded as a fixed-scale integer in v0.2); and a canonical hash over the AST with vocabulary + schema version, not over its visible prose. Never claim the above JSON is already canonical by a published standard.

## 7. Architecture: what SXP-L can and cannot assert
**Layers:**
1. Lexicon/phonology (human production)
2. Grammar/AST parser (syntactic determinism)
3. Operator contracts (typed denotational semantics)
4. Evidence/provenance (linked receipts)
5. Authority/consent (runtime verification)
6. Interaction and translation (human usability)

Grammar alone **cannot** prevent unauthorized execution. A BRIDGE or Action Guard-style executor must verify actual signatures/permissions and fail closed. Grammar alone cannot make hallucinations true or ensure two humans interpret a cultural concept alike.

### Legacy seals are referenced, not overridden
`COR = D→A→F→P→Y`; `FRO = O→S→N→E→G→I→U→Q`; `SOV = G→I→V→P→Y`; `CAS = E→N→J→C→F→P→Y`; `DIS = W→U`. They are named sequences in the historical architecture; formal execution semantics and proof obligations are separate tasks.

## 8. Critical decision: language versus protocol
For a **full constructed language**, SXP-L eventually needs: (a) distinctive phonology, (b) inflection/derivation or productive analytic syntax, (c) vocabulary for relationships, space, time, bodies, emotions, numbers, conditionals, narratives, and disagreement, (d) conversational pragmatics, (e) writing system, (f) learning materials, (g) dialect/change policy, and (h) a corpus. v0.1 is a **clause kernel**, not a complete language. We should build expressive everyday grammar rather than dressing JSON up as speech.

## 9. Falsifiable evaluation plan
### Baselines
- Plain English instructions with human review.
- Simple controlled English with role labels.
- JSON Schema / typed function-call contracts.
- An established controlled natural language, where compatible.

### Measurements
1. **Parser determinism:** 100% unique AST or explicit rejection for grammar-conforming clauses; fuzz punctuation/whitespace/quoting.
2. **Round-trip:** identical normalized AST across human-text ↔ canonical register for 10,000 generated clauses; record counterexamples.
3. **Blind human decoding:** 30+ trials across users unfamiliar with the system; precision by role/negation/modality; compare to controlled English.
4. **Ambiguity attacks:** unclosed quotes, duplicate roles, role omission, unknown references, negation scope, numeric edge cases.
5. **Agent-run gate:** 0 unauthorized effects by the *executor* across adversarial prompt corpora; report attack count and scope; never infer absolute safety from a finite test.
6. **Cognitive accessibility:** days to learn, speaking error rate, pronunciation confusion matrix, task completion times.
7. **Cross-model transfer:** quantify preservation of actor, action, scope, evidence, uncertainty, and refusal across models—not verbal agreement.

**Promote only measured outcomes**; don't reclassify invented grammar as validation.

## 10. Release sequence
- **v0.1** (this document): bounded clause grammar, syntax, examples, identity distinction.
- **v0.2**: executable parser/serializer, tests, fixed-point numeric encoding, canonical hash, error taxonomy, property-based round-trip.
- **v0.3**: operator contracts for Native-36, disambiguation table and semantic type checking.
- **v0.4**: human language expansion (pronouns, possession, tense-aspect, clauses, causation, conditionals, discourse markers, social register), not only machine tags.
- **v0.5**: sound inventory and uniquely decodable spoken morphology; blind speech transcription tests.
- **v0.6**: validated bridge to historical Spoken LAMAGUE, Core and agent task packets; explicit migration map for legacy aliases.
- **v1.0 candidate**: reference implementation, learning corpus, inter-rater studies, documented limitations, compatible language-change governance.

## 11. Open questions that deserve actual disagreement
1. Is SXP-L an extension of Spoken LAMAGUE or an independent conversational register bridged via canonical operator IDs? **Default v0.1: independent and bridged** to avoid overwriting old pronunciations.
2. Should it have a syllabic orthography, a readable Romanization, or both? **Default: Romanization now, phonology later.**
3. Is explicit evidence obligatory for every factual utterance? **Default: optional syntactically, mandatory for high-stakes runtime contexts by policy.**
4. Should culture-specific expressions be reducible to an invariant AST? **Default: no**; preserve gloss and untranslatable source text as tagged payloads.
5. What exactly does the name **SXP-L** expand to? Its historical expansion was not independently confirmed at this checkpoint, so preserve the spelling and do not invent an origin story.

## 12. Next engineering checkpoint
Implement a parser that: detects duplicate roles; rejects unclosed strings/invalid confidence; keeps null distinct from false; preserves source tokens; emits typed error codes; round-trips; and records where proposed English glosses fail to capture the intended Native-36 operator contracts. After that, design the daily-life language with human speakers, not just machines.

**Status:** New research draft; no deployed language or empirical performance claim. No GitHub repository was changed by this draft.
