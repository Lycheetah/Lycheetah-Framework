# Research roadmap after v0.9

**P0 — correctness and compatibility:** Property-based generation of adversarial invalid documents; formal typed AST schemas; versioned migration and semantic diff. An independent parser implementation should consume the same corpus.

**P1 — scientific baseline:** Independent annotations of 150+ English/SXP-L/JSON equivalent scenarios. Compare accuracy and reading time on scope, negation, revocation, ambiguity. Preregister scoring; include OPA-like policy decisions separately from linguistic comprehension.

**P2 — real authority integration (sandbox only):** Use a mature IAM or policy engine (OPA/Rego or equivalent), host-issued credentials, real authenticated participants, secure approval UX, event-sourced revocations and replay-safe nonce handling. Maintain `EXTERNAL EFFECTS: DISABLED` until audited.

**P3 — human language:** Speakable dialogue of 1,000+ core expressions, first-person and third-person discourse, recoverable ellipsis, quantification, tense/aspect, modality, polite request, refusal, plural pronouns, ambiguity indicators, names and pronunciation/listening study.

**P4 — real comparative evidence:** Blind listening and translation tests; compare SXP-L and English-only instructions on false positive permission inference with an LLM and under language-model prompt injection. Report negative as well as positive results.

The symbolic foundations (LAMAGUE/Native-36) are kept separately from new SXP-L lexical conventions. No claim of discovering a universal mind-to-mind language.
