# SXP-L × LAMAGUE v0.7 — Provisional Phonology and Spoken-Script Register

**Date:** 17 October 2026. **Status:** runnable constructed-language prototype, not a proven spoken language. **Version of speech codec:** 0.7.0. **Canonical semantics:** unchanged v0.3 AST. **Dialogue format:** v0.7, wraps prior v0.6/v0.5 participant resolver. Native-36 unchanged.

## Research claim (narrow)

This release establishes deterministic conversion between a specified *separated-word textual transcription* of speech and the supported v0.6 compact written grammar, with exact canonical AST preservation. Its phonology can produce draft IPA guides. It **does not** recover boundaries from continuous audio, recognize speech, produce naturally fluent translations, prove acoustic or cross-cultural intelligibility, or establish AI reasoning advantages.

## Why this change matters

v0.6 depended on `@nara`, `(`, `)`, `.` and `?`. Those symbols cannot themselves be uttered without a convention. v0.7 gives structural marks audible names and supports every valid v0.6 identifier by spelling it through an unambiguous framed character code. An opaque `lo "..."` remains **unsupported in spoken form** and is explicitly preserved in the earlier written register instead.

## 1. Draft sound inventory (orthographic / IPA)

- Five vowels: `a /a/`, `e /e/`, `i /i/`, `o /o/`, `u /u/`. Keep them stable rather than reducing vowels to schwa.
- Consonants: `b /b/`, `d /d/`, `f /f/`, `g /ɡ/`, `h /h/`, `k /k/`, `l /l/`, `m /m/`, `n /n/`, `p /p/`, `r /ɾ/`, `s /s/`, `t /t/`, `v /v/`, `y /j/`, `z /z/`.
- The grapheme `q` is *not* part of v0.7 speech. Legacy written `qira` becomes pronounced word `kesari` only in the spoken register. This is not a redefinition of the v0.6 canonical word.
- A word comprises **one or more (C)V syllables**, where the C is optional. Examples: `liva = li-va`, `afela = a-fe-la`, `nara = na-ra`, `gonape = go-na-pe`.
- Draft main stress is on the penultimate syllable for words containing at least two syllables: `liva /ˈli.va/`; `nara /ˈna.ɾa/`; `devora /de.ˈvo.ɾa/`. Monosyllables are unmarked. Prosody, pauses, emphasis, coarticulation, and intonation have not yet been validated.
- Neither the spelling conventions nor an IPA annotation constitute a claim that real listeners can segment unpaused speech.

## 2. Spelling conventions and oral structural markers

| Written compact | Spoken-script token(s) | Purpose |
|---|---|---|
| `(` | `bakumo` | Open embedded proposition |
| `)` | `tesavo` | Close embedded proposition |
| `.` | `devora` | Assertive/directive utterance end |
| `?` | `kevonu` | Question utterance end |
| `@nara` | `gonape nara dimotu` | Literal phonotactic name, explicitly framed |
| `@person_2` | `pulako <37-character code tokens> sanuti` | Spelled machine identifier |
| `qira` | `kesari` | Question mood |
| `dira` | `dutami` | Directive mood, still inert |
| `mira` | `mopaku` | Possibility modal |
| `mura` | `tukemo` | Obligation modal |

`gonape` and `dimotu` frame **exactly one phonotactically valid lowercase name**. It may equal a normal vocabulary word such as `liva`; its position still makes it a name. Names such as `asha`, `mac`, `person_2`, and all identifiers with digits/underscores use `pulako ... sanuti` character spelling; we do not pretend these are normally pronounced words.

The character code spells `abcdefghijklmnopqrstuvwxyz0123456789_` as **37 unique (C)V syllables**, assigned in that order from the first 37 members of `[b,d,f,g,k,m,n,p] × [a,e,i,o,u]`. Thus `a=ba`, `b=be`, `c=bi`, `3=mu`, `_=pe`. These syllables are only interpreted as letters within `pulako ... sanuti`. A spoken-script transcription must contain whitespace between every token. Acoustic segmentation is future work.

## 3. Formal grammar of supported spoken script

```ebnf
spoken_transcription = word, {space, word} ;
word                  = lowercase_a_to_z, {lowercase_a_to_z} ;
spoken_sentence       = [spoken_mood], [spoken_modal], [spoken_time],
                        spoken_entity, ["noka"], root,
                        argument_sequence(root), utterance_end ;
spoken_entity         = "mi" | "ti" | "gonape", phonotactic_name, "dimotu"
                      | "pulako", {letter_code}, "sanuti" ;
spoken_proposition    = "bakumo", spoken_sentence_without_end, "tesavo" ;
utterance_end         = "devora" | "kevonu" ;
```

Authoritative implementation is `spoken.py` -> `compact.hear_compact()` -> `sxpl_v03.parse()`. The grammar above is a readable summary, not an independently complete parser specification. Valency, polarity, mood, tense, modality, and nesting limits are inherited from v0.6. No semantic fields may be dropped. Question mood and end-marker must agree.

## 4. Examples and scope

```
Compact: mi liva ti.
Spoken:  mi liva ti devora
IPA:     /mi ˈli.va ti de.ˈvo.ɾa/
Gloss:   I love you (speaker report).

Compact: mi hira ( fura mi rava @nara ).
Spoken:  mi hira bakumo fura mi rava gonape nara dimotu tesavo devora
Gloss:   I hope that I reconnect with Nara in the future.

Compact: qira ti kena ( @nara luma ti )?
Spoken:  kesari ti kena bakumo gonape nara dimotu luma ti tesavo kevonu
Gloss:   Do you know that Nara misses you?

Compact: mi noka kena ( @nara luma mi ).
Spoken:  mi noka kena bakumo gonape nara dimotu luma mi tesavo devora
Gloss:   I do not know that Nara misses me.

Compact: mi kena ( @nara noka luma mi ).
Spoken:  mi kena bakumo gonape nara dimotu noka luma mi tesavo devora
Gloss:   I know that Nara does not miss me (as reported, not independently verified).
```

## 5. Dialogue wrapper

A v0.7 document begins `diala 0.7`. `lina id ^ <spoken_script>` represents a spoken-script line; `lina id ~ <v0.6 compact>` and `lina id | <v0.5 full surface>` remain permitted. Participants, speaker/addressee binding, and `kora` discourse links retain their validated prior semantics. The renderer chooses `^` only when the utterance has exact spoken/AST parity; for opaque context it retains `~`, and other unsupported compacts remain `|`. No intent/knowledge or consent is inferred from a line.

## 6. Explicit limitations and adverse cases

1. **No natural speech recognition.** The tokenizer receives separated textual words. It cannot infer boundaries from waveform audio or speaker accents.
2. **Near-collisions remain.** `luma`/`loma`, `mi`/`ti`, `liva`/`siva`, and several other words differ by a single letter. Edit distance is not perceptual distance; we require listener tests with multiple accents, including speech in noise.
3. **No free text in spoken register.** `lo "our future"` triggers `E_SPOKEN_QUOTE`; in dialogues it stays in the prior v0.6 written register, not an invented translation.
4. **Long names are verbose.** Spelling identifiers character by character is dependable in a text codec but unlikely to be a preferred conversational strategy.
5. **No productive morphology yet.** One or more (C)V syllables is a phonotactic *shape*, not a full derivational language morphology or an infinite semantic lexicon.
6. **No human performance claim.** Even perfectly reversible machine conversions can be difficult for humans to understand or remember.
7. **Semantic ontology is provisional.** `kena` codes attributed knowledge language, not independently established knowledge; hope, fear, and longing are not proved universals.
8. **No execution authority.** Directive mood is merely a grammatical label. The codec has no tool/network permissions or side effects.

## 7. Evaluation requirements for v0.8

- Blind learning and retention trial: at least 10 volunteer learners, stratified by first-language background where feasible; preregister definitions, recruit without coaching, record time to competence and error distributions.
- Pairwise auditory discrimination: especially `loma` vs `luma` and `mi` vs `ti`; include multi-accent speakers and realistic noise. Retire or replace roots when error is unacceptably high.
- Baselines: controlled English paraphrases, ordinary natural-language statements, and a well-specified controlled-language comparison (e.g. Lojban training samples). Match tasks and exposure time; do not infer superiority from syntax token counts.
- Phrase-level boundary perception: test nested structure with and without pauses; define explicit repair/clarification signals.
- Report both semantic mistakes and unanswered/unsupported constructions. Make ambiguity visible rather than silently resolving it.

## Sources and differentiation

- Lojban chapter on syllables and stress: https://www.lojban.org/publications/reference_grammar/chapter3.html (demonstrates significant prior art, distinct from our syllable and framing choices)
- Lojban chapter on word use and naming: https://www.lojban.org/publications/reference_grammar/chapter2.html (explicit name markers are not a new idea)
- W3C SSML v1.1 phoneme element: https://www.w3.org/TR/speech-synthesis/ (IPA as machine-readable pronunciation; its use here is not novel)
- Grammatical Framework: https://www.grammaticalframework.org/doc/tutorial/gf-tutorial.html (typed abstract/concrete language mappings as prior art)

**Design maxim:** *Meaning should survive the journey between minds; when it does not, the loss should be visible.*
