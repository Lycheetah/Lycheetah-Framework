# SXP-L v0.9 — Consent, Authority & Scope Forge

SXP-L is an experimental constructed human/machine language. This release makes a **strict separation** between *saying permission-related words* and *possessing authenticated authority*.

**Start here**

1. Open `LEARNER_LAB_v0.9.html` in a browser for an offline reading and permission-boundary exercise.
2. Read `SPEC_v0.9.md` for grammar and threat model.
3. Run `python -m unittest discover -p 'test_*.py' -v` (107 local tests).
4. Run `python adversarial_eval.py` (28 hand-authored adversarial fixtures vs deliberately weak shortcut).
5. Run `python authz.py --demo` (no external effects).
6. Run `python dialogue09.py examples/consent_not_execution.sxh --format summary`.

## Files

- `consent.py` — v0.9 new speech acts, typed AST, reversible renderer; v0.8 fallback.
- `authz.py` — deterministic, *non-executing*, cryptographic **fixture** reference gate.
- `dialogue09.py` — complete multi-speaker textual reports, no authentication.
- `adversarial_eval.py` — reproducible selected comparisons + generated JSON/CSV.
- `LEARNER_LAB_v0.9.html` — interactive stand-alone reading lab, no server.
- `SPEC_v0.9.md`, `MEANING_AND_THREAT_LEDGER.md`, `EVIDENCE_REPORT_v0.9.md` — formal notes and limitations.
- `SPEC_v0.5.md`–`SPEC_v0.8.md`, `FOUNDATION_v0.1.md`, original v0.2–v0.8 implementation and tests — continuity snapshots.

**No deployment, authentication of real users, human-consent verification or tool execution.** All grant examples are fictional. Do not use these test fixtures to authorize production actions.
