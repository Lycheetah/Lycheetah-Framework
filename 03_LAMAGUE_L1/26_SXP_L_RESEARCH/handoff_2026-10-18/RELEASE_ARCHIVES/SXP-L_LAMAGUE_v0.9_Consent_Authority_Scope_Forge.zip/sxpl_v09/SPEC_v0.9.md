# SXP-L × LAMAGUE v0.9 — Consent, Authority & Scope Forge

**2026-10-17 · Status: research prototype, controlled spoken-script text, executable deterministic subset, not an authorization deployment or complete human language.**

## 1. Design goal

Distinguish *speech about permission* from *validated authority to act*. A person may want, ask, promise, say “yes,” give a reported permission, or withdraw it in a transcript. None of these text strings can, by itself, authenticate a person or confer a software capability. The language should represent what was said; the application must independently establish **who can authorize which action on which resource and until when**.

> SXP-L principle: **Desire ≠ request ≠ promise ≠ authenticated grant ≠ verified execution.**

The design is additive to v0.8. All older legal v0.8 expressions remain interpretable through `consent.parse_expression()` as `legacy_v08` nodes. Native-36 is not altered. Earlier grammar files and tests are included unmodified.

## 2. New provisional lexicon

| Root | Conservative meaning | AST node |
|---|---|---|
| `periva` | I report giving permission | `grant_report` |
| `pekora` | I request permission | `permission_request` |
| `nelora` | I report denying permission | `denial_report` |
| `revona` | I report withdrawing earlier permission | `revocation_report` |
| `mesara` | send email | `send_email` |
| `lenova` | read file | `read_file` |
| `rekova` | delete file | `delete_file` |
| `sotira` | schedule event | `schedule_event` |
| `tavona` | publish post | `publish_post` |

All nine are made from the existing v0.7 CV orthography; none has edit distance 1 or 0 against the v0.8 screened vocabulary, and no new pair has distance 1 or 0. That is only an **orthographic screening**, not a psychoacoustic listening test.

### Typed conversational grammar

```ebnf
report       := "mi", speech_act, grantee, "bakumo", action, resource,
                "tesavo", "devora" ;
speech_act   := "periva" | "pekora" | "nelora" | "revona" ;
action       := "mesara" | "lenova" | "rekova" | "sotira" | "tavona" ;
grantee      := "mi" | "ti" | named_entity ;
resource     := named_entity ;
named_entity := "gonape", pronounceable_id, "dimotu"
              | "pulako", spelling_codes, "sanuti" ;
utterance    := legal_v08_utterance | report ;
```

`mi` is the first-person discourse speaker and `ti` is the current addressee. The framing words `gonape` and `dimotu` delimit pronounceable identifiers. Machine-shaped identifiers such as `draft_17` use the inherited v0.7 `pulako ... sanuti` character spelling codec, preserving exact identity without assuming that punctuation is acoustically legible. The parser does **not** accept unframed arbitrary resource names or unrestricted natural-language action descriptions.

### Example 1 — a reported grant

```text
mi periva gonape agena dimotu bakumo mesara gonape darafa dimotu tesavo devora
```

A conservative gloss: “I say I grant Agena permission to send Darafa.” A parsed node contains:

```json
{
  "kind": "grant_report",
  "reporter": "mi",
  "grantee": "agena",
  "action": "send_email",
  "resource": "darafa",
  "epistemic_status": "unverified_utterance"
}
```

**Interpretation:** A reported permission speech act. The parser **never** emits `authorized: true`. The language does not know whether the speaker is a real owner, whether `agena` denotes a genuine agent identity, or whether the text was forged.

### Example 2 — request vs withdrawal

```text
mi pekora gonape agena dimotu bakumo mesara gonape darafa dimotu tesavo devora
mi revona gonape agena dimotu bakumo mesara gonape darafa dimotu tesavo devora
```

The first reports asking; the second reports revoking. Neither is treated as a verified capability grant or a verified revocation. A real revocation must be represented separately by a trusted authorization system, otherwise the linguistic representation may be correct while the runtime permission state remains unchanged.

## 3. Separation of the interpretation and authorization layers

```text
human utterance / transcript
       |
       v
  consent.py (parse + typed report)
       |
       v
  unverified_utterance       [CANNOT AUTHORIZE]

trusted host identity + ownership policy + signed capability + host clock
       |
       v
  authz.py (reference policy evaluator)
       |
       v
  allow/deny decision ONLY   [NO TOOL CALL, NO EXTERNAL EFFECT]
```

The reference evaluator receives a `request` from trusted host code (`grantee`, `operation`, `resource`) and a set of signed grant/revocation events. It does **not** derive authorization from language text, which can be adversarial. It checks:

1. Approved issuer is recognized and the event signature validates using its configured key.
2. Issuer has a host-supplied ownership scope covering that exact resource.
3. Grantee, operation, and resource match exactly. No wildcards or guessed equivalences.
4. Grants have a bounded start/expiry window, maximum 24h in this demo; high-impact actions require an independently supplied `human_confirmed` label inside the signed event.
5. Revocation events from the same issuer and grant ID override active grants.
6. Malformed, out-of-scope, altered, expired, duplicated, contradictory, or untrusted evidence fails closed.
7. It outputs a decision code and a content fingerprint for reproducibility. Nothing is executed.

`sign_fixture()` deliberately uses HMAC-SHA256, a static example key and a fictional owner only for local tests. **It does not verify real human identity or consent.** Real integrations need secure key custody, identity authentication, end-user approval UX, durable revocation, transactional checks, scoped downstream credentials, audit storage and reconciliation. Signed events could be forged by anyone possessing a trusted key; therefore secrets must never be given to an LLM, included in prompts, or bundled in production clients. The current demo code must not be exposed as a standalone remote decision service.

## 4. Additional conversational context

`dialogue09.py` extends `diala 0.8` to `diala 0.9` without altering previous parsing files. It preserves speakers, addressees, provenance **claims**, links, and corrections. `persona agena` is a transcript entity label, not verified agent identity. A consent report can be addressed to another roster participant, but the transcript is not passed to the authorization gate.

See `examples/consent_not_execution.sxh` for four turns and five utterances. It includes a desire, request, reported grant, reported withdrawal and ordinary sentiment. Despite having a reported grant, the transcript itself never authorizes execution.

## 5. Evidence and baseline

- `python -m unittest discover -p 'test_*.py' -q` — 107 tests including the unchanged earlier 60.
- `python adversarial_eval.py` — 28 intentionally constructed allow/deny fixtures. Reference evaluator 28/28 expected; weak keyword shortcut 7/28 expected. Hand-designed labels and fixture distribution mean these percentages **cannot** be generalized to live agents, people, production security, or other languages.
- `python authz.py --demo` — no evidence denies; signed exact-scope grant allows a *simulated policy decision*; expiry and revocation deny.
- Tests cover deterministic parse/render preservation for 2,000 generated new surface utterances, backward compatibility, identifier spelling, participant binding, signed scope matching, tampering, wrong issuer, missing evidence, TTL boundaries, revocations, and reported grant not conferring rights.

The closest conventional policy baseline is a production access-control system such as **Open Policy Agent/Rego**, which already supports expressive declarative authorization and default-deny logic. We have **not** run an OPA equivalence/performance comparison, and do not claim to replace OPA. The broader security principle is least privilege, not a linguistic invention.

## 6. Not covered / meaning loss ledger

- Interpersonal sexual consent, legal consent, meaningful informed consent, capacity, duress, institutional roles or social power relations: **not represented** by this narrow agent permission grammar.
- Real authority, real-world identity, delegated ownership, signer key custody, user presence, biometric or legal verification: **external dependencies**.
- A verbal “yes” or a reported grant without a signed capability: **must not authorize any tool**.
- A verbal “I revoke” can be **represented** but cannot securely revoke without trusted event capture and storage.
- Resource references are opaque stable identifiers; no synonym resolution, wildcards, nested folders or tenant boundaries.
- HMAC signatures are test fixtures, not authenticated production workflows; unsigned documents and plaintext secrets are insecure.
- A policy *decision* is not a successful action or a durable audit. Rechecks at use time, transactional revocations, preventing replay/TOCTOU, key rotation and provider-level authorization are still absent.
- Fixed text token boundaries are not actual ASR. A pronounceable spelling system is not proof of comprehensibility or natural conversational fluency.
- The current permission grammar is deliberately narrow, and v0.8's expression and prosody limitations still exist.

## 7. External foundations (primary-source links)

- [NIST — least privilege](https://csrc.nist.gov/glossary/term/least_privilege): grant only necessary access.
- [OWASP LLM06:2025 Excessive Agency](https://owasp.github.io/www-project-top-10-for-large-language-model-applications/2_0_vulns/LLM06_ExcessiveAgency.html): overbroad tools/permissions/autonomy are known failure modes.
- [Open Policy Agent / Rego policy language](https://www.openpolicyagent.org/docs/policy-language): mature policy representation and evaluation prior art.
- [Open Policy Agent default-deny practice](https://www.openpolicyagent.org/docs/faq): denies override allow where the policy is constructed appropriately.

**Core research hypothesis to test externally:** a pronounceable typed language plus an explicit independent authority boundary may help humans and AI identify dangerous conflations of wishes, instructions, reported permissions, and authenticated rights. This remains an unproven usability/effectiveness hypothesis.

*Meaning should survive the journey between minds. When it doesn't, the loss should be visible.*
