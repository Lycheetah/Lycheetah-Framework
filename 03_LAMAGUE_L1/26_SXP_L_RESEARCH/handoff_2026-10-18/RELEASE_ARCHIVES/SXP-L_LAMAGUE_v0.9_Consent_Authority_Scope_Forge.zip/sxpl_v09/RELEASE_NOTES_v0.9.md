# SXP-L v0.9 — Release Notes

**Focus:** Linguistically distinguish requesting, reporting a grant, reporting a denial and reporting withdrawal; require external trusted proof before an AI agent action is authorized.

**Added:** `consent.py`, `dialogue09.py`, `authz.py`, `adversarial_eval.py`, four new docs, learner lab, CSV/JSON adversarial results and new tests.

**Retained:** v0.2–v0.8 core modules, earlier tests, foundation and previous version grammar specifications. No original LAMAGUE/Native-36 symbol was redefined.

**Status:** 107/107 selected local regression tests passed. 28/28 hand-built gate cases matched expectations; deliberately weak keyword heuristic 7/28. 2,000 generated language round trips passed. No independent evaluation, listening study, external actions or deployment.

**Next:** independent blind human comprehension/permission annotation study, structured JSON and mature policy-engine baselines, real identity/authorization integration in an isolated sandbox, and fluent third-person consent/authority discourse.
