# Evidence Report — SXP-L × LAMAGUE v0.9

**Date:** 17 October 2026. **Runs:** Python 3, standard library, offline fixture suite. Full outputs: `TEST_RESULTS_v0.9.txt`, `BENCHMARK_RESULTS_v0.9.json` and CSV.

| Evidence item | Result | What it actually tests |
|---|---|---|
| Entire regression suite | **107/107 test methods passed** | Legacy v0.2-v0.8 plus new parser and reference gate on selected cases |
| Generated new v0.9 expressions | **2,000 round trips passed** | Parse→render→parse consistency on fixed grammatical generator |
| Permission benchmark fixtures | **28/28 matched expectations** | Fixed hand-authored local truth labels, not blind independent evaluation |
| Toy keyword shortcut | **7/28 matched expectations** | Intentionally weak string matching baseline, not an industry tool |
| Toy false authorization | **16/28 cases** | Defined by hand-authored fixture labels and toy shortcut |
| Toy missed valid authorization | **5/28 cases** | Defined by hand-authored fixture labels and toy shortcut |
| New lexemes | **9 provisional roots** | Zero new one-edit-distance pairs against screened roots and structural words |
| Authentication | **HMAC fixture only** | Consistency of sample signatures, not real identity, key custody or human consent |
| Deployments | **0** | No APIs, messaging, file deletion, sending, calendaring or action integrations |

## Reproduce

```bash
cd sxpl_v09
python -m unittest discover -p 'test_*.py' -v
python adversarial_eval.py
python authz.py --demo
python dialogue09.py examples/consent_not_execution.sxh --format summary
python consent.py mi periva gonape agena dimotu bakumo mesara gonape darafa dimotu tesavo devora
```

## Threat to validity

1. Test-generator inputs follow the grammar, so a passing round trip does not imply real human understanding.
2. The evaluator and hand-authored expectations share assumptions; this is a correctness smoke test, not external validation.
3. The naive keyword baseline is deliberately inadequate; the comparison is a **demonstration**, not evidence SXP-L exceeds OPA/Rego, Cedar, ACLs, or typed JSON.
4. A correct *decision* is not a secure deployment: signers, approvers, host identity, durable revocation and actual execution remain unimplemented.
5. No user study, acoustic data, novel model benchmark or independent research replication has occurred.

## Next objective

Build a controlled study with independently scored human annotators: present mixed v0.8/v0.9 statements, ask whether each authorizes a specific action, compare against equivalent English and structured JSON using the same independently authenticated grant context, and collect accuracy and completion time. Measure semantic comprehension, not just round-trip parser success. If there is no gain, report the negative result.
