# SXP-L v0.5 Research Specification — Dialogue, Identity, and Draft Lexicon

**17 October 2026 · Authoring phase: research prototype, no performance superiority claimed**

## What is new

SXP-L v0.5 extends *the document format*, not v0.3's clause schema (`0.3.0`) or the Native-36 semantic operations. The new document schema is `0.5.0`. A valid dialogue carries named participants, attributed speaker turns, independently addressable utterances, and discourse relations between utterances. All decoded clauses remain structured reports, not established truths.

## Document grammar (normative for this prototype)

```ebnf
dialogue = "diala 0.5", NL,
           persona, { persona }, turn, { turn } ;
persona  = "persona", SP, identifier, NL ;
turn     = "tura", SP, identifier, SP, "to", SP, (identifier | "none"), NL,
           event, { event }, "enda", NL ;
event    = utterance | connective ;
utterance= "lina", SP, identifier, SP, "|", SP, sxp_surface_utterance, NL ;
connective = "kora", SP, ("and" | "but" | "because"),
             SP, utterance_id, SP, utterance_id, NL ;
```

Whitespace in the EBNF is schematic. Concretely, a line begins with a control word, and `lina id | ` is the delimiter separating the line ID from its v0.4-compatible human utterance. Empty lines and full-line `#` comments are ignored. Participants must be declared before the first turn. Each turn requires a named speaker and either a named addressee or `none`. Nested `lina` clauses use the v0.3 syntax routed through v0.4 surface decoding.

Participant and line identifiers match `[a-z][a-z0-9_]{0,39}`. `mi`, `ti`, and `none` cannot be participant names. Participants must be unique. Utterance IDs must be unique across the document. A connective must refer to two distinct, previously introduced utterances; it is attributed to the *current speaker*. Cross-turn linkage is permitted; it does not mean the earlier speaker endorses the link.

Document limits: 200,000 characters, 64 participants, 256 turns, 2,048 utterances, and 16,384 characters per physical line. Individual nested utterances retain v0.3 limits, including a recursion depth of 8.

## Pronoun binding

`nami mi` denotes the *current speaker*; `nami ti` denotes the *explicit addressee*. These pronouns resolve only in the `ka` (`actor`), `ta` (`target`), and `vi` (`viewpoint`) slots and inside nested propositions. In unrelated slots they are literal identifiers. Quotes are never rewritten, e.g. `nami "mi"` remains a quoted string `"mi"`. The `ka` actor and `vi` viewpoint must resolve to declared participants; the target may also be an inanimate symbolic topic.

An omitted addressee never means “the most likely listener”: `ti` without an addressee produces `E_UNBOUND_YOU`. No unnamed third-person pronouns are introduced in v0.5; names must remain explicit.

## Connective interpretation (conservative)

| Surface connective | Stored relation | Meaning of annotation | Not warranted |
|---|---|---|---|
| `and` | `and` | Current speaker groups two utterances | Logical conjunction truth, mutual speaker agreement |
| `but` | `but` | Current speaker presents a contrast | Formal contradiction or a proven causal relation |
| `because` | `because` | Current speaker offers an explanation | Verified real-world causality or evidentiary proof |

Connectives must never change the scope of negation inside either utterance. They link stable IDs, not free-text substitutions.

## Draft pronounceable roots

All new roots here are newly proposed SXP-L spellings, not historically proven LAMAGUE mappings. Sense distinctions and phonological collision tests with speech recordings remain future tasks.

| Opaque semantic label | Draft root | Reading gloss |
|---|---|---|
| believe | vela | entertain a proposition as believed |
| know | kena | claim knowledge of a proposition |
| hope | hira | desire that a proposition become true |
| miss | luma | experience absence/longing for someone |
| reconnect | rava | reconnect with someone |
| feel | fela | report experienced emotion |
| understand | nela | understand a proposition/person |
| love | liva | report loving attachment |
| longing | loma | subjective longing |
| affection | afela | affection |
| joy | yora | joy |
| fear | fera | fear |
| sadness | sada | sadness |
| see | siva | see/observe |
| arrive | ariva | arrive |
| remember | mora | remember |

`lami <root>` uses this registered lexicon **only in predicate and typed feeling positions**; `nami <value>` preserves an arbitrary canonical token without meaning mapping. Participant names, other semantic roles, and quoted strings remain raw even when their spelling matches a gloss. Compare `lami vela` (*believe*) with `nami vela` (the literal arbitrary identifier `vela`). The marker is not removable without risking collisions. Quoted content is always raw and may contain any registered root string.

## Scope of uncertainty

A clause `not know(P)` alone does **not** express `not know whether P`. A more cautious operational paraphrase of the latter (for a question with exhaustive truth alternatives) is the pair `not know(P)` **and** `not know(not P)`. In v0.5 that can be represented as two utterances plus an attributed `kora and` link. This is a model of epistemic distinction, not a claim to formal possible-world semantics.

The demo dialogue says someone believes another person misses them, hopes for reunion, is challenged to distinguish hope from knowledge, and then asserts non-knowledge of both P and not-P, along with personal longing. It does **not** conclude that the other person misses them.

## Invariants tested

1. For any accepted dialogue `d`, `parse_document(render_document(d)) == d` (validated for constructed cases and generated documents).
2. For a clause `c` expressible in the root register, `parse_v03(hear_roots(speak_roots(c))) == parse_v03(c)` (tested for selected samples).
3. Speaker-target references resolve by the turn header, including nested propositions; quoted literals remain unchanged.
4. Missing dialogue references, duplicate IDs, malformed surface tokens, absent addressees, and unlisted actors are rejected.

AST equality verifies only structural consistency relative to the grammar. It does **not** establish human interpretation equivalence, lexicon correctness, machine reasoning improvement, or speech comprehension.

## Comparative prior art and originality boundary

Lojban already has an extensive reference grammar including anaphora, connectives, and scope, and Grammatical Framework (GF) already separates abstract and concrete syntax. SXP-L should be evaluated against these existing ideas rather than marketed as the first language to formalize meaning. Reference: https://www.lojban.org/publications/reference_grammar/chapter7.html and https://www.grammaticalframework.org/doc/tutorial/gf-tutorial.html.

The distinctive *hypothesis to test* is whether a dual-register, provenance-aware protocol with explicit loss reporting can make human–agent transfer more reliable under specified tasks. No such superiority has been measured in v0.5.

## Next falsifiable stages

- **v0.6:** mark independent evidence and reported belief at document level; add relation-scoped authorization disclaimers, typed goals and time reference.
- **v0.7:** stress-test pronunciation and lexical segmentation using naive listeners (and native speakers of diverse languages), settle stress and orthography.
- **Comparative eval:** prepare equivalent controlled English, JSON frames, SXP-L, and optionally GF/Lojban presentations, then measure blind decoding and learning time with externally recruited readers.
- **Hard problem:** cultural nuance, irony, metaphor, identity shift, speech acts, pragmatics, and complex social context are largely outside this kernel.

**Ethical constraint:** no grammar token can grant runtime permission. No part of this parser executes directives.
