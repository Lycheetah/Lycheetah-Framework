# SXP-L × LAMAGUE — v0.6 Compact Conversational Register

**Date:** 17 October 2026  
**Status:** executable research prototype, constructed-language hypothesis; no human proficiency trial yet.  
**Compatibility:** v0.2–v0.3 canonical clauses, v0.4 controlled surface, and v0.5 conversation documents. Native-36 semantic inventory is not modified.

## 1. Design contract

The v0.6 compact register minimizes repeated role markers by using **typed, positional argument slots**. It is **not** an independent unrestricted language: it describes a reversible subset of the v0.3 abstract semantic representation. Unsupported propositions either remain in the v0.5 full register in a dialogue or are rejected by the standalone compact encoder. The program never guesses the missing meaning.

For a supported statement `c`, `parse_v03(hear_compact(speak_compact(c))) == parse_v03(c)` must hold. This is *structural semantic conservation relative to our schema*, not proof that the English gloss or human interpretation is equivalent.

## 2. Spoken-ish grammar

```ebnf
compact_utterance = clause, ("?" if mood=question else ".") ;
clause = [mood], [modal], [time], entity, ["noka"], predicate,
         arguments(predicate), ["lo", quoted_string] ;
mood   = "sava" | "qira" | "dira" ;      # default sava (assert)
modal  = "mira" | "mura" ;               # default absent
time   = "pana" | "nura" | "fura" ;      # default nura (present)
entity = "mi" | "ti" | "@" identifier ;  # names ALWAYS prefixed @
predicate = registered lexical root ;
arguments(transitive) = entity ;
arguments(feel) = feeling_root, [entity] ;
arguments(attitude) = "(", clause, ")" ;
```

Syntax uses an ASCII-written abbreviation register. Parentheses are meaningful nesting delimiters and `@` is a lexical disambiguator, **not yet a settled phonological morpheme**. Question punctuation is required only for `qira`; sentence periods for other moods. Word order is fixed. Any unexpected or trailing token is rejected. `lo` contexts are JSON-escaped quoted strings only; this is a deliberate escape hatch, **not** a natural-language semantics for those strings.

The language defaults to **assert + present + no modality** for unmarked clauses. That omission is not semantic deletion: the defaults are **inserted explicitly into the v0.3 AST**. These choices remain revisable before public language freeze. A present tense is not an automatic claim of universal or timeless truth.

### Predicate valencies

| Root | Canonical predicate | Compact argument signature |
|---|---|---|
| `liva` | love | entity target |
| `luma` | miss | entity target |
| `rava` | reconnect | entity target |
| `nela` | understand | entity target |
| `siva` | see | entity target |
| `ariva` | arrive | entity target (destination/target placeholder) |
| `mora` | remember | entity target |
| `diva` | differ | entity target (new provisional root in 0.6) |
| `fela` | feel | feeling root, optional entity target |
| `vela` | believe | proposition in parentheses |
| `kena` | know | proposition in parentheses |
| `hira` | hope | proposition in parentheses |
| `fera` | fear | proposition in parentheses |

Emotion roots usable after `fela`: `loma` (longing), `afela` (affection), `yora` (joy), `fera` (fear), `sada` (sadness), `hira` (hope). Predicate/feeling positions disambiguate shared roots. Many of these sense definitions still need native-speaker and cross-cultural testing; none are being advertised as universal semantics.

### Examples

```text
mi liva ti.
# sa nu love ka mi ta ti en

mi fela loma @nara.
# sa nu feel ka mi ta nara fe longing en

mi hira ( fura mi rava @nara ).
# sa nu hope ka mi pr [ sa fu reconnect ka mi ta nara en ] en

mi noka kena ( @nara luma mi ).
# sa no nu know ka mi pr [ sa nu miss ka nara ta mi en ] en

mi noka kena ( @nara noka luma mi ).
# sa no nu know ka mi pr [ sa no nu miss ka nara ta mi en ] en
```

`not know(P)` alone does not equal `not know whether P`; the above *pair* offers a bounded representation of not knowing P and not knowing not-P. We do not infer that P or not-P is true.

## 3. v0.6 conversation wrapper

```text
diala 0.6
persona mac
persona asha
tura mac to asha
lina a1 ~ mi liva ti.
lina a2 ~ mi fera ( mi diva ti lo "our future" ).
kora but a1 a2
enda
```

`lina id ~ compact_utterance` decodes into precisely the v0.5 `lina id | registered_root_surface` clause representation. Full `|` lines remain allowed. `kora but` is an **attributed discourse contrast**, not a formal conjunction, logical incompatibility, or proved fact. v0.5 pronoun resolution and participant validation apply unchanged.

`render_document()` prefers compact where exact AST equality is verified. If a valid utterance uses roles or predicates absent from this subset, it emits the original full `|` representation (zero silent dropping). The dialogue AST now has schema `0.6.0`, while all previously accepted participant, utterance, and discourse fields retain their meaning.

## 4. What is *not* asserted

- `mi` and `ti` refer to speaker and explicitly identified addressee **only within a validated dialogue**; a stand-alone clause is a template pending context.
- A statement like `mi fera ( mi diva ti lo "our future" ).` encodes the speaker's *fear of a proposition*. It does **not** establish that two people differ in outlook, nor faithfully express every nuance of English "we see the future differently."
- Quoted strings are opaque labels. Their meaning isn't formally derived from their English words.
- v0.3 `di`/v0.6 `dira` is a labelled directive **without** granting the runtime permission to perform actions.
- Attitudes such as `know` and `believe` are **self-reported predicates**, not proof of factual knowledge or belief.
- We have not shown phonetic ease, literacy, multilingual learnability, pragmatic adequacy, faster AI reasoning, or formal consistency of the entire human semantic domain.

## 5. Invariants and safety boundaries

1. Pure local standard-library Python; no network calls, code execution from language input, filesystem mutations from input, or external side effects.
2. No unsafe implicit name binding: names need `@` and the existing v0.5 dialogue requires actors/viewpoints to be declared participants.
3. Negation scope is recursively encoded, never flattened. `noka kena(P)` and `kena(noka P)` are different ASTs.
4. Full-register fallback on unsupported compact syntax; direct `speak_compact()` rejects unsupported canonical ASTs.
5. Input bounds: 16,000 characters, 4,096 compact tokens, recursive clauses at most v0.3's depth bound of 8; document constraints from v0.5 still apply.
6. Render uses exact AST equality checks. Tests include escaped quotes, root/name collisions, malformed fields, nested negation, and v0.5 migration.

## 6. Design debt and roadmap

- **v0.7:** establish phoneme inventory, stress, spoken versions of `@`/parentheses, minimal-pair checks with actual human recordings. Make lexical morphology productive rather than merely adding invented roots.
- **v0.8:** model tense/aspect, plural and shared actors, counterfactuals, quantifiers, desires vs plans, social register, and explicit reported-source attachment within compact clauses.
- **v0.9:** formal interlingua mapping, explicit information-loss / untranslatable fields, and baseline-aligned human and model evaluations.
- **1.0 candidacy:** grammar freeze only after blind reader testing and published test corpus, plus a language reference suitable for somebody to learn without access to its designers.

## 7. Relevant prior art

Our separation between an abstract syntax and surface representation is **not** new: see the Grammatical Framework tutorial and reference manual: https://www.grammaticalframework.org/doc/tutorial/gf-tutorial.html. Lojban's grammar already addresses anaphora, scope and connectives: https://www.lojban.org/publications/reference_grammar/chapter7.html. Attempto Controlled English has a working formal parser and logic-oriented outputs: https://github.com/Attempto/APE. Future work needs comparisons on shared comprehension tasks; we claim no demonstrated performance advantage over these.
