# SXP-L × LAMAGUE v0.8 — Pragmatics Forge

**Date:** 2026-10-17. **Status:** experimental, executable *controlled-language* subset; **not** a complete constructed natural language, acoustic speech recognizer, or verified AI reasoning enhancement. This specification is additive to v0.7; prior versions remain unchanged. Native-36 is NOT modified.

## Mission

Express different kinds of claims without conflating them: *wanting*, *intending*, *hoping*, *asserting*, *promising*, *being unable to promise*, and *conditional assertion*. Record discourse contrasts, self-repairs and claimed provenance without treating any of them as verified reality. Maintain deterministic AST serialization and fail rather than silently simplifying unsupported meaning.

## Two levels of semantics

1. **Propositional content.** A v0.3 canonical clause, interpreted through v0.7 controlled spoken-script form (`mi liva ti devora`), or new unary `satoma` (*stay*) with actor, tense and scoped negation. It is a representation of what somebody said—not a verified observation.
2. **Pragmatic envelope.** v0.8 typed wrapper around a proposition, with `kind`, `holder`/`promisor`, polarity, and special constraints. This is not backward-compatible with v0.3 ASTs *as an entire envelope*; the **embedded propositions** remain v0.3-compatible.

## Pronounceable additions — provisional lexicon

| Spoken-script word | Meaning/role | Type |
|---|---|---|
| `satoma` | stay / remain | Intransitive predicate, current or time-marked |
| `vanira` | want/desire that ... | Attitude report |
| `nivara` | intend that ... | Attitude report |
| `pamisa` | express a promise to ... | Promise report, not external authority |
| `kapera` | (be) capable of promising ... | Reported capacity for a candidate act |
| `sivane` | if ... | Conditional antecedent introducer |
| `tanaro` | then ... | Conditional consequent introducer |

The earlier roots `hira` (hope), `fera` (fear), `vela` (believe), and `kena` (reported know) can scope over new `satoma` through the v0.8 wrapper. Pre-existing sentences containing these verbs and **v0.7-recognized** propositions retain their original v0.7 canonical parsing. Roots are provisional and do not carry universal claims about human emotion.

Pronunciation follows v0.7 orthographic /a e i o u/, (C)V syllables, penultimate stress. For example `satoma` ≈ /sa.ˈto.ma/. IPA is from deterministic spelling rules, **not** experimental acoustic validation.

### Examples

| Spoken-script SXP-L | Conservative English reading | Typed representation |
|---|---|---|
| `mi liva ti devora` | I love you (as reported) | `proposition` |
| `fura mi satoma devora` | I will stay / I stay in future (speaker claim, not guarantee) | `proposition` |
| `mi vanira bakumo fura mi satoma tesavo devora` | I want to stay | `attitude_report.desire` |
| `mi nivara bakumo fura mi satoma tesavo devora` | I intend to stay | `attitude_report.intention` |
| `mi hira bakumo fura mi satoma tesavo devora` | I hope to stay | `attitude_report.hope` |
| `mi pamisa bakumo fura mi satoma tesavo devora` | I promise to stay (wording in transcript; not proof of obligation or delivery) | `promise_report` |
| `mi noka pamisa bakumo fura mi satoma tesavo devora` | I am not promising to stay | `promise_report` with negative polarity |
| `mi noka kapera bakumo mi pamisa bakumo fura mi satoma tesavo tesavo devora` | I report that I cannot promise to stay | `capacity_report` with *candidate*, not performed, promise |
| `sivane bakumo fura mi satoma tesavo tanaro bakumo fura ti satoma tesavo devora` | If I stay, then you stay (as speaker-described hypothetical) | `conditional` |

**Scope distinction:** `mi noka pamisa ...` negates an expressed promise; `mi noka kapera bakumo mi pamisa ...` negates a claim of capacity **to make** a candidate promise. Those are not equivalent. Neither implies that the future action will occur. A positive `pamisa` represents an *uttered promise in the transcript*; nothing here executes an action or checks consent. A promise is restricted to a future action with the same actor as the promisor.

## Grammar summary (v0.8 direct register)

```ebnf
utterance          := legacy_v07_utterance
                    | extended_declaration, "devora" ;
extended_declaration
                   := new_proposition
                    | subject, ["noka"], attitude_root, "bakumo", proposition, "tesavo"
                    | subject, ["noka"], "pamisa", "bakumo", future_self_action, "tesavo"
                    | subject, ["noka"], "kapera", "bakumo", positive_promise_body, "tesavo"
                    | "sivane", "bakumo", proposition, "tesavo",
                      "tanaro", "bakumo", proposition, "tesavo" ;
attitude_root     := "vanira" | "nivara" | "hira" | "fera" | "vela" | "kena" ;
new_proposition   := ["pana" | "nura" | "fura"], subject, ["noka"], "satoma" ;
subject           := "mi" | "ti" | spoken_v07_framed_identifier ;
proposition       := assertive_v07_clause_without_end | new_proposition ;
future_self_action:= "fura", subject, ["noka"], "satoma"
                    | v07_future_action_with_actor_equal_promisor ;
```

This is a *readable summary*. Authoritative behavior is `pragmatics.py` and its tests. Input tokens remain whitespace-delimited written transcriptions (there is no ASR). It uses v0.7 `hear_spoken` and v0.3 `parse` as validators; no unbounded/free-text vocabulary is admitted. v0.7 questions and inert directives remain accepted at the top level. New wrapper forms are declarative only. Time and polarity belong to the proposition and are not inferred from intentions or promises.

## Dialogue register

A dialogue begins `diala 0.8`. Existing `persona`, `tura`, `lina`, `kora`, `enda` conventions are preserved conceptually. Every utterance is encoded `lina id ^ <full v0.8 spoken-script utterance>`. New event forms:

- `evida id self_report|hearsay|document_claim|sensor_claim|unknown`: provenance class *claimed by the current speaker*, always `verified: false` in the AST. No `verified` lexical escape hatch.
- `repara earlier_id later_id`: explicit same-speaker correction. Both utterances remain present. Later ID must have occurred after the earlier one. The repair records **supersession**, not historical deletion.
- `kora and|but|because id1 id2`: link supplied by the speaker, not a machine-established logical relation or causal demonstration.

Speaker/recipient identity is tied to roster entries. `mi` means turn speaker; `ti` means addressee. A top-level positive reported promise cannot be attributed as if the current speaker made a promise for someone else. Target and other-person internal states are **never** independently confirmed by the grammar.

## Safety and rejection behavior

- Rejects a promise to do another person's action, or promise with present/past temporal scope.
- Rejects candidate promises that are negated or attributed to a different person inside capacity framing.
- Rejects unmatched frames, invalid roots, mismatched question ending, unsupported free text, invalid identifiers, spoofed promisor, non-forward self-repair, cross-speaker repair, and false `verified` evidence labels.
- Accepts legacy v0.7 question, directive and assertion transcriptions unchanged. All directives remain semantically inert.
- Every successful output has an exact parse → render → parse equality check. Meaning equality is **relative to this grammar**, not English, speech, speakers' intentions, social contexts or truth in the world.

## Important unresolved semantics

- `kapera` expresses the *speaker's report of their capacity*. It does not distinguish physical, social, moral or emotional senses of "cannot". Explicit inability **does not** prove incapacity.
- The current `promise_report` does not model uptake by a listener, institutional felicity conditions, sincerity or discharge. It is a record of words, not a binding legal contract.
- A `because` link is an attributed interpretation and has no model-theoretic entailment yet.
- A conditional does not establish either branch and is not automatically interchangeable with material implication in classical logic.
- No generalized aspect, open-class nominal morphology, plural quantification, metaphor, free speech, prosodic emphasis, or idiomatic pragmatics.
- No synthesis/ASR or listening data and no demonstration of net advantage over English, GF, ACE, Lojban or JSON protocols.

## Research baselines

- [Grammatical Framework official tutorial](https://www.grammaticalframework.org/doc/tutorial/gf-tutorial.html): explicit typed abstract syntax and reversible concrete linearizations already exist. SXP-L is not entitled to claim novelty for reversibility alone.
- [Stanford Encyclopedia of Philosophy, Pragmatics](https://plato.stanford.edu/entries/pragmatics/): speech acts and promises cannot be reduced to asserted proposition content alone.
- Existing Lojban sound/word-form references from v0.7 and the prior prototype comparison notes remain relevant.

**Research maxim:** *Meaning should survive the journey between minds. When it doesn't, the loss should be visible.*
