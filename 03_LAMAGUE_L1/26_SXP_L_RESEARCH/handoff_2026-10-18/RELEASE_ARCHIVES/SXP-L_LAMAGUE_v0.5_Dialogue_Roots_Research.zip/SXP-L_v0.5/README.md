# SXP-L × LAMAGUE v0.5 — Dialogue & Provisional Roots

**Status:** Experimental constructed-language engineering artifact; human fluency and language performance unverified.

This release adds:

- `dialogue.py`: parse/normalize named, multi-turn SXP-L dialogue with explicit interlocutors, stable utterance IDs, and connectives (`and`, `but`, `because`) attributed to a speaker.
- Controlled co-reference: `mi` = current speaker; `ti` = explicit current addressee, only in participant-valued semantic roles. Unbound references fail rather than being guessed.
- `roots.py`: 16 new **provisional** pronounceable lexical mappings; `lami` denotes a registered root and `nami` denotes raw content. The underlying v0.3 AST and Native-36 operator inventory are unchanged.
- A three-turn dialogue in `examples/first_dialogue.sxh` that distinguishes lack of knowledge of `P` from lack of knowledge of `not P`.
- Unit, regression and deterministically generated tests.

## Run

Python 3.10+ and standard library only.

```bash
cd sxpl_v05
python -m unittest test_dialogue test_surface test_v03 -v
python dialogue.py examples/first_dialogue.sxh
python dialogue.py examples/first_dialogue.sxh --output json
python dialogue.py examples/first_dialogue.sxh --output normalized
```

The `dialogue.py` parser is **not** an English-to-SXP translator, a proof of a person's beliefs, or an executor of an action. It neither sends messages nor contacts external systems. Dialogue tokens and link words are user-authored representations.

See `SPEC_v0.5.md` for grammar and failure behavior, `LEARNER_CARD_v0.5.md` for reading lessons, and `TEST_REPORT.txt` for local evidence. The original v0.1 foundation and v0.4 spec are included unchanged for provenance; old runtime files are copies, not new implementations of previous versions.
