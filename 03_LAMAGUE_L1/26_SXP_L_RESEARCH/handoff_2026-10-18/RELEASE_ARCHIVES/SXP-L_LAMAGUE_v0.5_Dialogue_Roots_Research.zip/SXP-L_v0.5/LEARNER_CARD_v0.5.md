# First conversation in SXP-L v0.5 — learner card

We have something worth practising now. **Read the markers as rhythm, not as English punctuation.** Pronunciations are provisional until we test them with real speakers.

## Your foundation words

| Word | Current reading |
|---|---|
| `sava` | a person asserts/reports |
| `qira` | a person asks |
| `nura` | present; `fura` future; `pana` past |
| `noka` | negation (watch the scope!) |
| `ami` | actor |
| `tavi` | target |
| `pari nesti ... nesta` | a proposition nested inside another |
| `ena` | closes a clause |
| `nami` | literal or name coming next |
| `lami` | registered draft root coming next |
| `mi` | I, when bound to actor/target/viewpoint |
| `ti` | you, when bound to explicit addressee |
| `tura` | a new speaker turn in a written transcript |
| `lina` | an individually addressable line |
| `kora` | a speaker-attributed connection |

## Root words for this conversation

- `vela` = believe; `kena` = know; `hira` = hope.
- `luma` = miss somebody; `rava` = reconnect.
- `fela` = feel; `loma` = longing.

## Learn three actual clauses

**1) “I feel longing for Nara.”**

```text
sava nura lami fela ami nami mi feli lami loma tavi nami nara ena
```

Breakdown: [assert present] [feel] [actor me] [feeling longing] [target Nara] [end].

**2) “I hope that I reconnect with Nara in the future.”**

```text
sava nura lami hira ami nami mi pari nesti sava fura lami rava ami nami mi tavi nami nara ena nesta ena
```

The `pari nesti ... nesta` enclosure is the thing being hoped for. **Hope is not a prediction.**

**3) “Do you know that Nara misses you?”**

```text
qira nura lami kena ami nami ti pari nesti sava nura lami luma ami nami nara tavi nami ti ena nesta ena
```

`ti` refers to the declared recipient of this turn. The question doesn't assert the nested proposition is true.

## Your first real semantic puzzle

There are TWO different statements:

```text
sava noka nura lami kena ami nami mi pari nesti sava nura lami luma ami nami nara tavi nami mi ena nesta ena
```

I do not know **that** Nara misses me.

```text
sava noka nura lami kena ami nami mi pari nesti sava noka nura lami luma ami nami nara tavi nami mi ena nesta ena
```

I do not know **that** Nara does not miss me.

Putting both together makes a useful *approximation* of not knowing whether Nara misses me. Notice the SECOND `noka` is **inside** the nested proposition. A parser cannot confuse those positions.

## Try reading aloud

Suggested first-pass reading (not yet IPA or standardized pronunciation):

- **sa-va nu-ra** — assert now.
- **la-mi hi-ra** — registered root for hope.
- **a-mi na-mi mi** — actor, specifically me.
- **pa-ri ne-sti ... ne-sta** — inside a proposition.
- **e-na** — stop/end.

Our next challenge is the hard one: shorten without losing unambiguous parsing, expand beyond emotion words, and make a real pronunciation/understanding study possible.
