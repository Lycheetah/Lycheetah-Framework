# SXP-L v0.7 — Reproducible Evidence Report

**Run:** 17 October 2026, local CPython standard library (not a deployed service).

## Pass/fail

- Test invocation: `python -m unittest test_spoken test_compact test_dialogue test_surface test_v03 -v`
- Outcome: **34/34 test methods passed**. Full output is `TEST_REPORT.txt`.
- New v0.7 seeded generator: **3,600** supported nested sentences; round-tripped from written compact to spoken-script, back to canonical AST, and back again to the identical spoken-script form.
- Retained older generators remain in the regression suite: v0.6 includes 2,400 compact cases, v0.5 includes 1,500 dialogues, v0.4 includes 3,000 nested cases, and v0.3 retains its prior generator. These are constructed tests, not independent human observations.
- Coverage includes names colliding with verbs; 37-symbol spelling code; nested negation; modal/time/mood; literal names; punctuation failure; unknown words; quoted-text rejection; three-speaker dialogue and lossless written fallback.

## Important risk check — grapheme-distance **screening only**

- v0.6 fixed orthographic lexicon: **29** words; **28** one-edit-distance pairs.
- v0.7 spoken lexical+control inventory: **37** words; **16** one-edit-distance pairs.
- All eight new structural delimiters have a nearest-neighbor edit distance of **at least 3** to another word in the spoken inventory.
- Four v0.6 written control words receive different audible aliases: `qira → kesari`, `dira → dutami`, `mira → mopaku`, `mura → tukemo`.
- **Caution:** inventories differ (v0.7 adds framing vocabulary). The lower pair count does not measure actual speech confusion, hearability, or acoustic error reduction. There are still 16 near pairs, including `loma/luma` and `mi/ti`.

### One tested round trip

```text
Written: mi hira ( fura mi rava @nara ).
Spoken:  mi hira bakumo fura mi rava gonape nara dimotu tesavo devora
Restored written: mi hira ( fura mi rava @nara ).
```

`parse(hear_spoken(spoken)) == parse(hear_compact(written))` for this case and generated cases (see executable tests). This is **schema-relative**, not a proof of meaning preservation through human interpretation.

## Not done

- No speech input, audio recognition, real-time segmentation, speaker study, or phonetic error-rate measurement.
- No cross-language native-speaker evaluation.
- No semantic parsing of opaque natural-language quotations (fail-closed in spoken register).
- No controlled baseline against Lojban/English on identical tasks.
- The optional generated WAV is a generic *approximation*, not a validated phonetic recording.

## Reproduce

Run all tests from the extracted directory and inspect `spoken.py` / `conversation_v07.py`. Parser and renderer use no hidden model and no online dependency. Compare actual outputs to the versioned examples.
