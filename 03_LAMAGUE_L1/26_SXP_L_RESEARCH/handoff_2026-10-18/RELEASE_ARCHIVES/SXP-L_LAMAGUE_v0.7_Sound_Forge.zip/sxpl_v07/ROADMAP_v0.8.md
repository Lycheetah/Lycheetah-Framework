# SXP-L v0.8 research agenda — from transcribed speech to believable conversation

## Highest priority: the first adversarial listening study

**Hypothesis:** listeners hearing untrained SXP-L speech will confuse some single-edit-distance pairs even when the machine parser never does. Start with `loma`/`luma`, `mi`/`ti`, `fela`/`fera`, `liva`/`siva`. Generate short context-neutral stimuli and record two or more speakers who have independently learned the pronunciation rules. Avoid using Esperanto/English TTS as experimental reference audio.

**Protocol draft:** randomly play word pairs to blinded participants, log forced-choice accuracy, per-phoneme confusions, learner language background, playback device/noise, and response time. Predefine pass/fail thresholds before testing. Prefer an exploratory pilot followed by a held-out validation group. Ask speakers to reproduce nested sentence boundaries orally and have other listeners reconstruct the AST/English meaning.

## The grammar debt we should not ignore

1. ***Not knowing whether P*:** distinguish two explicit non-knowledge claims from a natural interrogative complement in a scoped mental-state logic.
2. ***Conjunction and contrast*:** links `kora but` currently only work as discourse metadata; introduce true compositional connectives with defined truth conditions or evidential attribution.
3. ***Desire vs intention vs promise*:** do not treat a person's hope as a commitment; add first-class and testable illocutionary force.
4. ***Shared identity and groups*:** plural, collective and distributive arguments; deictic `we` with clear membership.
5. ***Provenance*:** evidence type, who reported it, when, and whether it has been validated.
6. ***Repaired speech*:** self-correction and confirmation; this is an essential real-world safety feature, not decoration.
7. ***Morphology*:** develop derivational word formation only after ensuring forms do not collapse semantic distinctions or create excessive sound collisions.
8. ***Interoperation*:** compare fairly against controlled English, typed JSON records, and existing conlang approaches; test end-to-end agent instructions separately from natural-language glosses.

## Milestones and evidence bars

- **0.8a**: recorded human minimal-pair pilot with aggregate confusion matrix (not just computed edit distances).
- **0.8b**: conditionals, desire/intent, and quoted attribution with exact parse/render/semantic tests.
- **0.8c**: explicit meaning-loss scoring and provenance fields; exact behavior on unsupported constructions.
- **0.9**: publish data, train/test splits, and blind controlled-language baseline comparisons.

The primary outcome should not be a larger version number; it should be **an independently reproducible way of finding when meaning changes**.
