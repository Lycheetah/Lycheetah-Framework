# SXP-L v0.7 — Meaning and Usability Risk Ledger

| Case | Software behavior | Meaning / practical limitation | Next experiment |
|---|---|---|---|
| Plain declarative (`mi liva ti.`) | Exact typed AST round trip | Still a self-report of love, not a verified relation | Translation comprehension study |
| Embedded thought | `bakumo` and `tesavo` delimit scopes | Requires explicit words to be retained by listener | Nested-scope listening trial |
| Negation | `noka` scope survives exact round trip | Does not imply objective facts about another person's mind | Blind paraphrase/entailment check |
| Names that equal roots (`@liva`) | `gonape liva dimotu` remains an entity | A name has no implied lexical relationship to the predicate | Proper-name dictation study |
| Non-native / machine identifiers | Character spelling inside `pulako ... sanuti` | Very long and possibly awkward; orthographic protocol not fluent speech | Human-friendly names policy |
| Opaque `lo "..."` strings | `E_SPOKEN_QUOTE` on direct conversion; dialogue uses written fallback | No translation was provided or silently invented | Quotation/provenance layer |
| Collision: `loma` vs `luma` | Written forms both parse distinctly | Listener might hear one as the other | Accented audio minimal-pair study |
| Short pronouns: `mi` vs `ti` | Parse distinct | Single consonant difference, possible high-stakes error | Repeat-back/confirmation policy |
| Mood/directive | Inert grammatical tags | A spoken command is never action authorization | Agent authorization boundary tests |
| Spaced text input | Deterministic token segmentation | No continuous-speech segmentation/ASR, no acoustic channel validated | Human dictation and ASR trial |
| English emotion gloss | Informal translation only | Glosses may shift meaning by culture or context | Bilingual elicitation and review |

## Baseline convention

The phrase “spoken register” here means **a pronounceable, separated-word *text transcript***. Do not market it as natural continuous speech recognition or a fully realized constructed spoken language. Exact round-trip equality demonstrates that *the implementation* keeps a selected semantic structure stable, not that a human hearing the utterance arrives at that structure.
