# SXP-L v0.7 — Sound Forge

**17 October 2026 | Research software and language-development material | Python 3.10+ / standard library.**

This version extends SXP-L v0.6 with a provisional phonemic spelling system and a strict *spoken-script* representation, **not speech recognition**.  The v0.3 clause AST and all previous semantic roots are preserved. New surface conventions deliberately do not rewrite historical LAMAGUE Native-36 IDs.

## Three-sentence demonstration

```
mi liva ti.
→ mi liva ti devora

mi fela loma @nara.
→ mi fela loma gonape nara dimotu devora

mi hira ( fura mi rava @nara ).
→ mi hira bakumo fura mi rava gonape nara dimotu tesavo devora
```

An older v0.6 sentence with an opaque quoted context **cannot** be spoken via this codec yet; the dialogue renderer keeps it in the written register. Speaker/addressee reference checks continue to run through v0.5/v0.6 validation.

## Run from extracted directory

```bash
python spoken.py say 'mi liva ti.'
python spoken.py hear 'mi liva ti devora'
python spoken.py ipa 'mi liva ti devora'
python spoken.py audit
python conversation_v07.py examples/first_spoken_dialogue.sxh --output normalized
python -m unittest test_spoken test_compact test_dialogue test_surface test_v03 -v
```

`spoken.py` does not generate audio; optional `audio/approximation_mi_liva_ti.wav` is a **non-authoritative Esperanto-voice TTS approximation**, not recorded SXP-L speech. The spec is the normative provisional *textual* phonology.

## Included

- `spoken.py`, `conversation_v07.py`, `test_spoken.py`: new speech-script engine, dialogue bridge, tests
- `SPEC_v0.7.md`: phonology, grammar, mappings and limitations
- `EVIDENCE_REPORT_v0.7.md`, `MEANING_LOSS_LEDGER_v0.7.md`: local checks and explicit debt
- `LEARNER_LAB_v0.7.html`: offline interactive IPA viewer and reading drill, no speech recognition
- `examples/first_spoken_dialogue.sxh`: multi-speaker demonstration with fallback when speaking would lose meaning
- Prior v0.6/v0.5–v0.2 code, regressions, and archival design docs
- `MANIFEST_SHA256.txt`: digests of archive members

## Research boundaries

A deterministic reversible surface conversion does not establish a fluent human language or a cognition improvement. Short paired roots remain a concern: `loma` vs `luma` and `mi` vs `ti`. The experiment needs independent listeners.
