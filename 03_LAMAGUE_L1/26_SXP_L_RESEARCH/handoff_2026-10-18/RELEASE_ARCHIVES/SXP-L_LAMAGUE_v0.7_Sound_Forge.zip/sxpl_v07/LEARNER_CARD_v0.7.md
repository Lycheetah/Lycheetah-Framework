# SXP-L v0.7 — First Speaking Card

The writing system is **provisional**. Say vowels consistently: `a` as /a/, `e` as /e/, `i` as /i/, `o` as /o/, `u` as /u/. The `r` is a tap /ɾ/. Put emphasis on the next-to-last syllable in a word.

- **mi** /mi/ — I, when the speaker is known.
- **ti** /ti/ — you, when the addressee is known.
- **liva** /ˈli.va/ — love (reported predicate).
- **luma** /ˈlu.ma/ — miss someone.
- **loma** /ˈlo.ma/ — longing (a feeling).
- **fela** /ˈfe.la/ — feel.
- **hira** /ˈhi.ɾa/ — hope.
- **devora** /de.ˈvo.ɾa/ — statement end.
- **kesari** /ke.ˈsa.ɾi/ — question form of the written `qira`.
- **kevonu** /ke.ˈvo.nu/ — question end.
- **gonape** /ɡo.ˈna.pe/ ... **dimotu** /di.ˈmo.tu/ — named person brackets.
- **bakumo** /ba.ˈku.mo/ ... **tesavo** /te.ˈsa.vo/ — inner-proposition brackets.

Read aloud, with clear word boundaries:

```
mi liva ti devora
mi fela loma gonape nara dimotu devora
kesari ti liva mi kevonu
mi hira bakumo fura mi rava gonape nara dimotu tesavo devora
```

Approximate English:

1. I love you.
2. I feel longing for Nara.
3. Do you love me?
4. I hope to reconnect with Nara in the future.

Read carefully: **luma** (“miss”) and **loma** (“longing”) are a problematic near pair; **mi** vs **ti** differs by one consonant. This is a design finding, not something to hand-wave away. Human auditory testing may require changing vocabulary before publication.

The TTS sample in the archive is an *illustrative machine accent*, not a reference performance; no audio accuracy testing was conducted. The free-standing HTML lab works offline and provides immediate feedback for 7 reading questions.
