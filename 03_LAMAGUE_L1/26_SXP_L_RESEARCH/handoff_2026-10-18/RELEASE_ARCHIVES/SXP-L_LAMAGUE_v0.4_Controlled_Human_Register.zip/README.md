# SXP-L v0.4 — Controlled Human Register

An executable reversible bridge from the SXP-L v0.3 canonical semantic syntax to an intentionally controlled human-pronounceable register.

```bash
python test_surface.py
python surface.py speak sa no nu know ka self pr '[' sa nu understand ka person_2 ta self en ']' en
python surface.py hear sava nura nami feel ami nami self feli nami longing ena
```

`surface.py` is an encoding/decoding experiment, **not** a free-form English translator. It preserves statements without giving them real-world truth or authority. For grammar details, read `RESEARCH_v0.4.md`.

Bundled foundations: `sxpl_v03.py`, `sxpl_v02.py`, `FOUNDATION_v0.1.md`.
