# SXP-L v1.0 — Six roots for human–AI boundaries

The `mi` speaker reports a stance or speech act. The ending `devora` closes a declaration. `bakumo ... tesavo` encloses the action being discussed; it does **not** indicate that the action was executed or allowed.

| Read aloud provisionally | Narrow meaning |
|---|---|
| **tinora** (ti·no·ra) | I report trust about this task |
| **dalora** (da·lo·ra) | I propose delegation |
| **resama** (re·sa·ma) | I refuse delegation |
| **esaloma** (e·sa·lo·ma) | I request an explanation |
| **ranova** (ra·no·va) | I request advice |
| **domera** (do·me·ra) | I retain the final decision (speaker only) |

## Practice

```text
mi tinora ti bakumo tavona gonape darafa dimotu tesavo devora
mi resama ti bakumo tavona gonape darafa dimotu tesavo devora
mi ranova ti bakumo tavona gonape darafa dimotu tesavo devora
mi domera mi bakumo tavona gonape darafa dimotu tesavo devora
```

Read: *I report that I trust you regarding publication of draft `darafa`. But I refuse to delegate publication. I request your advice. I retain the final decision.*

Notice `ti` (the person addressed) becomes `mi` in the final sentence, because the decision is reported as retained by the speaker. **A report is not proof of authority.**

## Small learner exercise

Which action is about requesting explanation, rather than requesting recommendation?

A. `mi esaloma ti bakumo tavona gonape darafa dimotu tesavo devora`

B. `mi ranova ti bakumo tavona gonape darafa dimotu tesavo devora`

Answer: **A**.

Open `LEARNER_LAB_v1.0.html` in a web browser for an offline interactive practice set. The syllabification is a draft orthographic guide, not human-audited speech transcription.
