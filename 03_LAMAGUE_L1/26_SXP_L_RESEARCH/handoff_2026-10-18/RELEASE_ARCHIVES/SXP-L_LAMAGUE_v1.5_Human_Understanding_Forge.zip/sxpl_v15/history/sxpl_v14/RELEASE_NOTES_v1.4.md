# Release notes — Nested Perspectives Forge v1.4

**New executable layer**: `perspective14.py`, preserving the v1.3 transcript grammar and extending it with `naveriko` (reported speech), `belareko` (belief), and `nesaluko` (not knowing whether). Each frame explicitly names the holder and local addressee.

**New check**: separate `oracle14.py` and `reference_benchmark14.py`, with a fixed 90-case CSV and an intentionally naïve role-baseline contrast.

**Learning and review**: new offline learner lab, eight-turn transcript, formal specification, threat/meaning ledger, planned independent study, and Argon audit brief.

**Local evidence**: 181 methods passed across four separate suites; 90/90 restricted reader agreement; 127 inherited archive entries byte-for-byte unchanged. The monolithic test command timed out and is not represented as a successful run.

**No claimed deployment or authorization.** Frame contents remain an outer speaker's reports. The software does not take real actions or verify anyone's state of mind.
