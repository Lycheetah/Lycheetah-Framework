# Release notes — SXP-L 1.3.0 (The Continuity Forge)

**Added:** a reversible transcript envelope, stable pronounceable turn references, third-person `sivena` with explicit ambiguity, `rasufe` single-turn anchors, reply-to pointers, a 12-turn illustrative dialogue, limited independent oracle, 60-case synthetic comparison, offline eight-question learner lab, and an audit handoff.

**Preserved:** historical v1.2 and earlier code; no word changes to `mi liva ti`; no merging of quoted permission with authenticated authority.

**Rejected:** third-person pronoun in embedded/reported speech until scope-aware nested resolution is specified; guessed referents when more than one participant is eligible.

**Evidence boundary:** local deterministic tests and a handcrafted baseline. No human study, acoustic test, external authentication, or production deployment.
