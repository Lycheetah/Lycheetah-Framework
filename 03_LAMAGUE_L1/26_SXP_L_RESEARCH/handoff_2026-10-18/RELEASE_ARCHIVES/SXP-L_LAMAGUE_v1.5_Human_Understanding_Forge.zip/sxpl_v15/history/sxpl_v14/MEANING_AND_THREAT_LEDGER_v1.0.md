# SXP-L v1.0 meaning and threat ledger

| Pitfall | Current representation | Consequence / missing work |
|---|---|---|
| Reported trust interpreted as permission | `trust_report`, `authorizes=false` | Text never becomes grant; app needs trusted host authorization |
| Delegation proposal interpreted as grant | `delegation_proposal`, `authorizes=false` | No action permitted by proposal alone |
| Refusal interpreted as durable revocation | `delegation_refusal`, unverified | Real capability requires authenticated revocation event; stale grants may exist |
| “Retain final decision” treated as verified ownership | `decision_reservation`, actor `mi` only | Verbal claim does not establish owner or identity; conflict warning advisory only |
| Advice request read as command | `recommendation_request` | No execution; proposals still need later host approval |
| Asked for explanation → answer invented as evidence | `explanation_request` | No provenance verification of any future explanation yet |
| Reported v0.9 grant/withdrawal | Kept via `legacy_v09` | Still mere transcript; host authorization remains independent |
| Unframed resource or hostile root | Reject as malformed | No unrestricted natural-language parsing; may false-reject valid human expression |
| Timed grant/race/replay | `authz.py` fixture gate | Production requires durable logs, identity, secure keys, just-in-time enforcement and replay defense |
| People hear similar roots | Word edit-distance screen only | Needs actual recorded speech and listening tests |
| Correct AST matches programmer assumptions | 105 minimal pairs and 2,500 generated cases | Need an independent parser and real human evaluation |
| Explicit words imply complete human language | Six controlled new roots only | No full morphology, phonological study or broad discourse coverage |

**Threat model:** untrusted text, user prompts, transcript files, model-generated messages, hostile resources and speaker claims must not be elevated to actions or verified facts without independent host controls.
