# Next forge — SXP-L v1.1 priorities

1. **Independent grammar implementation** to confirm the parser is not only agreeing with its own renderer.
2. **Blind human comprehension pilot** using the counterbalanced materials, including learning-time penalty and null-result reporting.
3. **Balanced authorization study**: actual host-authenticated grant contexts plus text-only descriptions, with both allowed and denied cases.
4. **Better conversation grammar**: natural conjunction without per-line meta tags, deictic pronouns and plural participants, quotation, scoped questions, and polite refusal.
5. **Spoken trial**: record diverse human speakers with consent, listen without text, measure confusion matrices for near-neighbor roots.
6. **Agent-safety integration only in a sandbox**, delegating enforcement to a mature engine such as OPA/Rego, not to linguistic text.
7. **Linguistic lineage ledger**: maintain separate original LAMAGUE/Native-36 symbols, provisional SXP-L roots, retired forms, and versioned migrations; do not conflate tests with deployed performance.

Research hypothesis: a designed expressive register plus explicit structured boundaries might lower erroneous assumptions in human–AI communication. It is **not yet established**.
