# ARGON independent challenge brief — v1.4

Audit existing v1.3 unchanged and the additive `perspective14.py` code. Focus on **false certainty and perspective contamination**.

1. Verify all 127 inherited v1.3 release entries are unchanged (hash comparison).
2. Re-run `python -m unittest test_perspective14 -v` and `python reference_benchmark14.py`.
3. Investigate where v1.4's `leaf_roles` could be misunderstood as binding deeper inner v1.2 clauses.
4. Attempt frame injection, anchors to wrong local participant, unknown speakers, malformed close tags, deep nesting, and mutation of authenticated/authorization flags.
5. Challenge the distinction between `naveriko` report, `kavira` reported quotation, and `nimareko` reported paraphrase.
6. Compare against DRT-style referent accessibility, typed logical/JSON attribution, and controlled English, rather than a toy recency baseline.
7. Stress-test whether new roots sound distinguishable, not merely a spelling-distance screen.
8. Design a preregistered human-comprehension study testing roles, ambiguity detection, and false-truth attribution.

**Do not** modify older releases in place. Label independent results separately from the self-reported local suite. Preserve `mi liva ti` and its meaning.
