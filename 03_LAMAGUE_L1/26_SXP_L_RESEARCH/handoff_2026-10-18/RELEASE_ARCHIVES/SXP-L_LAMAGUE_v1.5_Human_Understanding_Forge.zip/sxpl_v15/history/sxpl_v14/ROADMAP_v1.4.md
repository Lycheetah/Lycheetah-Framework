# Proposed v1.4 — Nested Perspectives & Human Learnability

Prioritize formal scope over new vocabulary.

1. **Nested viewpoint semantics:** define and independently test which source binds `mi`, `ti`, and `sivena` inside direct and indirect speech. Until proven safe, reject ambiguous cases.
2. **Quantified and dynamic discourse referents:** optional introductions during conversation, with strict backward non-retroactivity; plural, singular, and discourse-accessibility constraints.
3. **Anaphora to events/propositions:** distinguish *“she doesn't”* (ellipsis), *“I agree with that”* (content pointer), and mere reply links.
4. **Human learner study:** pre-register matched SXP-L/controlled-English/JSON tests with strangers to the project; measure correct reference choice, abstention, time, and subjective difficulty.
5. **Sound experiments:** collect anonymized listening tests for minimally distinct roots (`luma`/`loma`), multiple accents, and word-boundary ambiguity. Do not claim robust phonology before testing.
6. **Adversarial auditing:** have Argon run its own parser and property-based fuzzer; preserve full trace of every failure.

### Gate for claiming value

Only describe human/agent communication benefits beyond *structural preservation* if compared on a controlled, independently executed dataset against serious baselines. A version number alone is not a breakthrough.
