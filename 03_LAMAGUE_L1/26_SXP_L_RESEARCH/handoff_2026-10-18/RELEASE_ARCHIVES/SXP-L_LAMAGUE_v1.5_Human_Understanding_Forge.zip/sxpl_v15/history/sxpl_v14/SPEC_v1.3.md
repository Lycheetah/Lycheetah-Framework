# SXP-L × LAMAGUE v1.3 — The Continuity Forge

**Release type:** Experimental bounded textual discourse layer; not a complete conversational language or a real-world safety system.

## Why this layer exists

SXP-L v1.2 has reversible expression parsing but cannot assign a durable named speaker or addressee to each turn. Its `mi` and `ti` refer to the utterance's perspective, which changes with the speaker. This release adds a **separate transcript envelope** rather than editing the v1.2 sentence grammar. It also introduces one deliberately limited third-person pronoun, **`sivena`**, which means an unspecified eligible third person; it does **not** mean specifically *she* or *he*.

**Original foundation unchanged:** `mi liva ti` means “I love you”; `mi liva ti devora` is the existing spoken-script sentence. `liva` is not renamed or aliased to `jiva`. All v1.2 source files in the release are byte-for-byte copied.

## Six provisional new words

| Word | Syntactic purpose | Semantics |
|---|---|---|
| `norava` | Participant declaration | Introduces an available named reference; not proof of identity |
| `taviro` | Turn header | Establishes reported speaker and reported addressee |
| `tevaro` | Turn terminator | Closes exactly one utterance |
| `sivena` | Third-person placeholder | Refers to one eligible third person, **only if** uniquely established |
| `rasufe` | Scoped referent anchor | Names the intended third person for the *current turn only* |
| `repira` | Explicit reply link | Records the earlier utterance being replied to; no agreement inferred |

The word forms pass our project's existing **spelling-distance >1** screen against the historical registered vocabulary and against each other. This is not a phonological confusion or intelligibility test. Spoken-script proper names must be CV-pronounceable, and the bounded turn identifiers are generated using CV-CV forms, such as `taba`, `tabe`, and `tadu`.

## Document syntax

```ebnf
transcript = participant_decl, participant_decl, { participant_decl }, turn, { turn } ;
participant_decl = "norava", named_person ;
turn = "taviro", named_person, named_person, [ anchor ], [ reply ], expression, "tevaro" ;
anchor = "rasufe", named_person ;
reply = "repira", named_turn_id ;
expression = canonical_expr12 | expr_with_sivena ;
expr_with_sivena = canonical_expr12_with_one_or_more_outer_role_name_slots_replaced_by_sivena ;
named_person = "gonape", pronounceable_name, "dimotu" ;
named_turn_id = "gonape", cv_turn_id, "dimotu" ;
```

Here `canonical_expr12` means exactly the grammar accepted by the unmodified v1.2 `discourse12.parse_expression`. The placeholder may occur only at **outer utterance scope**; if it appears inside `bakumo ... tesavo` (quoted, reported or other embedded content), this v1.3 layer refuses the expression. Mixed-role nesting and quotation-induced shift of `mi`/`ti` are future work; no unsafe default is applied.

A line contains one grammatical operation; declarations precede all turns. Participants are fixed for the transcript in v1.3. Blank lines are allowed. The parser limits participants (32), turns (100), total lines (420), source characters (120,000), and lexical length.

## Example: one ambiguity, deliberately retained

```text
norava gonape maka dimotu
norava gonape nara dimotu
norava gonape sela dimotu
norava gonape vera dimotu

taviro gonape maka dimotu gonape nara dimotu
mi liva sivena devora
tevaro
```

- Speaker: Maka; audience: Nara.
- Eligible third persons: Sela, Vera.
- Result: `status=ambiguous`, `candidates=[sela,vera]`, `chosen=null`, `expression_ast=null`.
- **No** inference that the last-mentioned person is correct.

Insert `rasufe gonape sela dimotu` between header and sentence, and that one turn acquires `status=explicit_anchor`, `chosen=sela`, a v1.2 canonical expansion `mi liva gonape sela dimotu devora`, and its parsed typed AST. A subsequent turn must still clarify its own third-person reference when multiple options exist.

With exactly one eligible third party, the status is `unique_candidate` and the expression is expanded and parsed. With no eligible third party, status is `unresolved`, not the identity of the speaker or addressee.

## Speaker, addressee and viewpoint

- A turn's outer `mi` is annotated as the **reported** speaker declared in `taviro`.
- A turn's outer `ti` is annotated as the **reported** addressee in `taviro`.
- These are annotation/binding statements, not independent verification of the utterance or source identity.
- When earlier v1.1 or v1.2 constructs report speech, embedded role shifts remain governed by their prior specifications; v1.3 will not flatten them. It explicitly rejects `sivena` inside `bakumo` nesting.
- `repira` links a turn to an earlier turn ID only. It does not assert agreement, contradiction, entailment, or truth.

## Evaluation and security semantics

`render_transcript` reparses its output and checks exact document equality. This rejects modified metadata such as changing `authorizes=false`, fabricating a reference choice, or marking identities authenticated. A not-uniquely-resolvable sentence can be syntactically validated through a *temporary probe*, but the probe's identity is never stored as the interpreted referent and no expression AST is returned.

**All source utterances are inert.** Reported permission is a linguistic claim. No utterance authenticates grants, identities, or delegation, and no tool calls are made by this module. The v0.9 policy boundary remains separate.

## What is missing

This is not yet a general coreference model. It does not resolve *she* vs *he*, plurals, pronouns introduced in hypothetical or quoted scope, implicit addressees, perspective shift inside indirect speech, topic salience, anaphoric events, unspoken ellipsis (“she doesn't”), speaker-hearer alignment, false/misleading source attribution, emotional truth, or actual human linguistic comprehension. It has no audio transcription or acoustic validation. The participants are declared at the beginning rather than dynamically introduced in discourse.

## Prior art we explicitly acknowledge

- Discourse Representation Theory and accessible discourse referents: https://plato.stanford.edu/entries/discourse-representation-theory/
- W3C PROV provenance for entity/agent/activity distinctions: https://www.w3.org/TR/prov-primer/
- Grammatical Framework abstract/concrete grammars: https://www.grammaticalframework.org/

These concepts predate SXP-L; we are testing a narrow implementation, not claiming to invent reference resolution or provenance.
