# SXP-L × LAMAGUE v1.2 — Directed Meaning & Indirect Speech Forge

**Maturity:** Experimental construction. Tested text grammar for a bounded subset; **not** proof of natural-language comprehension, acoustic reliability, causal truth, authentication, or trustworthy deployment.

## Non-negotiable language continuity

- `mi liva ti` (*I love you*) remains the compact spelling. In the existing v0.7+ spoken-script sentence form, `mi liva ti devora` terminates the utterance. **No changes to `liva`**; `jiva` is not inserted into the dictionary.
- All v0.1–v1.1 sources are preserved without changing definitions. v1.1's `borema` remains a *directionally underspecified* claimed connection. We do not silently reinterpret its historical expressions.
- v1.2 parses prior v1.1 expressions unchanged as `legacy_v11` nodes.

## Why this revision exists

v1.1 could encode `mi borema [A] [B]`, meaning the speaker presents a reported explanation relation. The grammar was intentionally silent about the **cause–effect direction**. This is a serious interoperability gap: translators might read it as `A because B` while another system reads `B because A`.

v1.2 introduces two directional **constructions**. Both preserve a reporter's **claimed** causal relation, not a verified physical or logical cause.

| Root | Form | Surface interpretation | AST direction |
|---|---|---|---|
| `larumeko` | `mi larumeko bakumo EFFECT tesavo bakumo CAUSE tesavo devora` | E **because** C | `cause=C, effect=E` |
| `voraneku` | `mi voraneku bakumo CAUSE tesavo bakumo EFFECT tesavo devora` | C; **therefore** E | `cause=C, effect=E` |
| `nimareko` | `mi nimareko SOURCE bakumo CLAIM tesavo devora` | I report SOURCE **as saying / conveying** CLAIM (paraphrase) | indirect, no authenticated words |

Each bracketed item `CAUSE`, `EFFECT`, or `CLAIM` is a **canonical complete v1.0 sentence**, including its own `devora`. In raw v1.2 syntax the English uppercase labels are placeholders and never literal language tokens.

## Formal subset

```ebnf
expr12 = expr11 | directed | indirect ;
directed = "mi", ("larumeko" | "voraneku"),
           "bakumo", expr10, "tesavo",
           "bakumo", expr10, "tesavo", "devora" ;
indirect = "mi", "nimareko", source,
           "bakumo", expr10, "tesavo", "devora" ;
source = "mi" | "ti" | framed_name | spelled_identifier ;
```

`expr11` is the old parser's entire accepted grammar, and `expr10` is the older canonical bounded expression grammar. This grammar is **single-level** for new v1.2 forms: nesting them inside one another is disallowed. Their embedded v1.0 forms may of course contain earlier v1.0 nested framing.

The new words use the provisional CV sound inventory. Their minimum orthographic Levenshtein edit distances from prior screened controls/roots are 4 for `larumeko`, 4 for `voraneku`, 4 for `nimareko` (see script); phonological clarity has **not** been empirically checked.

## Semantic contracts

### Cause versus effect

The AST for either directed construction explicitly stores `cause_ast` and `effect_ast`, canonical lexical forms for each, plus `construction` (because/therefore). Both constructions can therefore express **the same directional content** with different discourse ordering. The code does not assert that cause logically necessitates effect, that a sequence is historically true, or that a claim about causal direction is supported by evidence.

`connection_status = speaker_supplied_unverified`; `authorizes = false`.

### Direct quote versus indirect reporting

The older `kavira` means a reporter claims to be quoting another speaker. The v1.1 AST stores `quoted_words` and requires the words to match the embedded syntax at normalized-token level. It is **not authenticated** or acoustically verbatim.

The new `nimareko` instead represents a reported **paraphrase or propositional content**. It intentionally does **not** store a `quoted_words` field, and `wording_status = paraphrase_not_verbatim`. It cannot be misread as an authenticated literal quotation. Source identity is unverified and `embedded_mi_binding` denotes the **alleged source**, not the reporting speaker. The embedded `ti` remains unresolved until a later discourse/reference system can establish a recipient.

**No spoken string is executable permission.** For both reported claims and direct quotes the reference interpretation sets `authorizes=false` and never calls a tool or changes a host policy.

## Examples

```text
mi liva ti devora

mi larumeko bakumo mi nivara bakumo fura mi satoma tesavo devora tesavo bakumo mi liva ti devora tesavo devora

mi voraneku bakumo mi liva ti devora tesavo bakumo mi nivara bakumo fura mi satoma tesavo devora tesavo devora

mi nimareko gonape nara dimotu bakumo mi periva ti bakumo tavona gonape darafa dimotu tesavo devora tesavo devora
```

The directed examples read roughly **“I intend to stay because I love you”** and **“I love you; therefore I intend to stay.”** Both encode the same *reported* cause/effect roles and different discourse order. They are not independent psychological evidence of why a person intends to stay. The indirect example reports that Nara conveyed a claim of permission, not that permission was truly issued. The message is not an authorization token.

## Parsing/validation boundary

- Input lexical rules: ASCII lowercase words with explicit whitespace separation. Acoustic segmentation is not implemented.
- New constructs admit only canonical v1.0 embedded syntax, not arbitrary English or recursive v1.2 embeddings.
- AST rendering rejects altered metadata, fields, clause words or language/version tags. `render_expression` validates by reparsing.
- An AST's `construction` may be changed from because to therefore while keeping `cause` and `effect` identical: this changes presentation, **not** the directional claim. This is an intentional property, not an authorization bypass.
- A second code path (`oracle12.py`) checks the directionality and indirect-report category for a **restricted subset** of v1.0 action reports and one love sentence. It does not import the new parser, but shares the project's language specification.

## Limitations and honest interpretation

These tests evaluate *programmatic structure preservation on synthetic examples*. They do not prove that human speakers can reliably infer causal direction, that any statement is true, or that SXP-L beats controlled English, typed JSON or Lojban. Notably, the vocabulary is still small; proper names can require laborious spelling codes; pronouns remain context-dependent; metaphor and temporal causation aren't modeled; and v1.1 `borema` remains underspecified by design.

## Existing prior art

- Grammatical Framework: reversible abstract/concrete syntax, https://www.grammaticalframework.org/
- Stanford Encyclopedia of Philosophy, *Quotation*, https://plato.stanford.edu/entries/quotation/
- Discourse Representation Theory, Stanford Encyclopedia of Philosophy, https://plato.stanford.edu/entries/discourse-representation-theory/

This project does not claim to have invented scope, attribution, reversible grammar or discourse semantics.
