# SXP-L × LAMAGUE v1.1 — Attribution & Scope Forge

**Goal:** prevent a mentioned quotation from being confused with an enacted utterance; introduce controlled contrast and reported explanatory links. Earlier versions remain preserved in `history/` and the unchanged v1.0 source modules are included at the top level.

## Start here

- `SPEC_v1.1.md` — precise grammar, examples, scope caveats
- `discourse11.py` — executable parser/renderer/structured interpretation
- `oracle11.py` — separate, deliberately limited parser for cross-checks
- `test_discourse11.py` — targeted semantic and adversarial tests
- `examples/` — human-readable examples
- `LEARNER_LAB_v1.1.html` — offline practice UI
- `EVIDENCE_REPORT_v1.1.md` — tests reproduced and limits
- `ROADMAP_v1.2.md` — next research steps
- `history/` — historical archive unchanged from earlier handoff

## Run

Python 3.10+ (standard library only). At the repository root:

```bash
python -m unittest discover -v
python discourse11.py mi kavira ti bakumo mi periva ti bakumo tavona gonape darafa dimotu tesavo devora tesavo devora
python oracle11.py  # module is imported by tests; no standalone CLI required
```

All embedded statements and relation links are informational reports. **No authority or tools are delegated, granted, or executed.**

## Status labels

- **Implemented:** word-framed quote and relation parsing, typed AST, re-rendering, token-level opacity, source-report distinction.
- **Tested locally:** old v1.0 regression methods and new v1.1 cases, deterministic grammar-scope generators and a restricted independent reader.
- **Not verified:** actual quotations, human comprehension, spoken ambiguity, comparative AI reliability, multi-language translation, real-world production authorization.

## Integration note for Argon

Do not conflate the original LAMAGUE/Native-36 symbols with SXP-L's new provisional roots. Run the tests from source, audit the reference oracle as well as the main parser, and report any observed discrepancy as a counterexample. Treat the bundled full archive as immutable history rather than an automatically authoritative specification.
