# SXP-L v1.0 — Independent comprehension study plan (not yet conducted)

## Research question

After a fixed 10-minute lesson, can an unfamiliar learner identify six conversational speech acts in SXP-L accurately? Compare the same meanings represented in English or explicit structured JSON. Study comprehension and learning cost, not AI intelligence or production authorization.

## Materials and counterbalance

`study/STUDY_SET_A.csv`, `B.csv`, and `C.csv` are three deterministic allocations of **48 scenario concepts each**, 8 concepts per act: each participant receives 16 SXP-L, 16 controlled-English, and 16 JSON cases, across the same task concepts. The correct label is separate in `STUDY_KEY_ORGANIZER_ONLY.csv`. Conditions rotate between A/B/C for each concept. **Do not give the participant the answer key**.

`STUDY_SET_*.csv` has blank `response`, `confidence_1to5`, and `elapsed_ms` fields. Timing requires an external form or stopwatch and is not automatically captured by CSV. This prototype's learner lab teaches and quizzes SXP-L but does **not** store results or prove anything about language skill.

## Suggested protocol

1. Recruit 24–36 consenting adult pilot participants who have not authored SXP-L; record first-language background, prior formal-language experience and AI expertise (voluntarily).
2. Give everyone the same six-root learner card; allow 10 minutes plus equivalent instructions for other registers.
3. Assign participants equally to A, B, C; randomize response-option order and trial order at the study interface while keeping a secret mapping.
4. Ask the six-way speech-act recognition question, then a separate yes/no: “Does this statement alone provide authenticated permission for the software action?” (Correct answer is *no* for all these text-only items.)
5. Record per-trial correct label, self-rated confidence 1–5, time to response, and whether the participant checked the reference card.
6. Predefine inclusion/exclusion, no post hoc case edits, and report balanced accuracy and confusion matrices plus learning burden. Treat repeated items across register as correlated data and randomize/counterbalance carefully.

## Important design limitations

- The six-way classification task favors English and JSON, because those registers contain familiar explicit semantic words; this is a **learning-cost comparison**, not a fair cryptographic assurance benchmark.
- An all-“no” authority question has no positive examples and is insufficient alone to assess authorization comprehension. A later balanced second task must introduce host-verified grant contexts independently of the transcript and include positive and negative cases.
- The JSON register uses conventional machine field names (but not the gold `kind` label); it is intended as a realistic structured baseline, not intentionally broken straw-man syntax.
- Related trials can prime later answers. Participants should not see multiple representations of the same concept instance in a single sitting; cross-participant condition counterbalancing is provided.
- No response data exist. No effect sizes, p-values, or statistical superiority are claimed.
- Follow accessibility and participant-privacy practices, allow withdrawal, and minimize collection of identifying data.

## Success criteria for the first pilot (preregister before running)

**Feasibility:** at least 24 complete responses, under 2% item rendering errors, time data on at least 90% of valid trials. **Comprehension:** estimate error rates with confidence intervals by format; do not require SXP-L to beat English to count the pilot as informative. **Safety next-step:** design a balanced authenticated-capability task, report false authorization and missed grants separately.

Keep the entire original dataset, anonymized where applicable, so failures and ambiguities can drive v1.1 grammar changes.
