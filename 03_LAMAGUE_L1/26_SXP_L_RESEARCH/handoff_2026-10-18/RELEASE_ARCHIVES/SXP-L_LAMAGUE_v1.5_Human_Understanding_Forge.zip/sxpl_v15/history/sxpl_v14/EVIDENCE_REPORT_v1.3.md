# SXP-L v1.3 — Reproducible local evidence

**Date:** 18 October 2026. **Status:** tested experimental text-language extension; no deployment or independent human study.

## Full inherited test suite

Running `python -m unittest discover -v` from the release directory completed with exit code **0**: **168/168 unittest methods passed in 57.274 seconds**. See `TEST_RESULTS_v1.3_FULL.txt` for the full test names and output.

This includes **153 inherited v1.2 test methods** and **15 new v1.3 methods**. The new tests include **1,200 seeded generated context cases** using participant rotations, zero/one/multiple eligible referents, and explicit anchors. This test count reports test methods, not a number of independent experimental participants.

Targeted rerun: `python -m unittest test_continuity13 -v` => **15/15** in 1.584 seconds. See `TEST_RESULTS_v1.3_NEW.txt`.

## Synthetic reference comparison

`python reference_benchmark13.py` generated 60 fixed-seed cases and compared the reference-state outcome to independently written, **limited** single-turn reader `oracle13.py`:

| Metric | Result |
|---|---:|
| Synthetically generated cases | 60 |
| Agreement between primary resolver and limited oracle | 60/60 |
| Primary resolver explicit abstentions (`ambiguous` or `unresolved`) | 39 |
| Deliberately naïve recency shortcut unsupported identity assignments | 24 |
| Primary resolver unsupported identity assignments | 0 |

This is **not a matched comparison to a capable coreference system**. No ground truth exists about which actual person the ambiguous user meant; an “unsupported assignment” is a structural overcommitment under the stated grammar, not an independently judged semantic error. The limited reader does not validate the full v1.2 expression grammar. Therefore this result only verifies our reference-status rule on synthetic inputs.

## Tested safety boundaries

- Speaker/addressee context switches over 12 turns.
- A link to an earlier turn identifies that earlier turn, not agreement or truth.
- With two eligible participants, `sivena` does not produce a fabricated named AST.
- With zero eligible participants, `sivena` is unresolved rather than bound to speaker or addressee.
- A turn-level `rasufe` anchor resolves only that turn, never implicitly the next.
- Contradictory/duplicate headers, wrong turn references, forged AST semantics and noncanonical expressions are rejected.
- `sivena` inside nested reported or quoted syntax is rejected to avoid a false viewpoint binding.
- A reported grant remains inert and `authorizes` is always false in v1.3 output.

## Source integrity

The **109 files** contained in `SXP-L_LAMAGUE_v1.2_Directed_Meaning_Forge.zip` were checked against their copied counterparts in the v1.3 directory: **109/109 SHA-256 content matches**. No inherited files were edited. The final release contains its own SHA-256 file list `MANIFEST_SHA256_v1.3.txt` and an archive checksum file alongside the ZIP.

## What cannot be concluded

No human study, listening experiment, independent transcription, semantic equivalence verification on naturally occurring dialogue, or real agent authorization has been run. The language remains heavily constrained. This extension deliberately avoids treating the claim that someone said something as evidence that they truly said it.

## External prior art (not validation of this project)

- Discourse Representation Theory (accessibility of referents): https://plato.stanford.edu/entries/discourse-representation-theory/
- W3C PROV entity/agent/activity provenance: https://www.w3.org/TR/prov-primer/
