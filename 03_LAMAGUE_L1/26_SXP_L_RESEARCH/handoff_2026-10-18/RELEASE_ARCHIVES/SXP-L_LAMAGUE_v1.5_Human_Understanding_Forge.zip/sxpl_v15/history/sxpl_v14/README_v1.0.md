# SXP-L × LAMAGUE v1.0 — Sovereignty Forge

Research milestone, not complete language or production authorization system.

## What's new

- `sovereignty.py`: six new controlled speech acts, typed parser, deterministic renderer; v0.9 compatibility.
- `dialogue10.py`: multi-turn discourse parsing, claimed provenance, explicit *but* links, corrections, participant-label resolution.
- `authority_bridge.py`: non-executing audit linking linguistic reports and a **separately supplied** signed-fixture authorization decision. Speech NEVER grants authority.
- `minimal_pair_eval.py`: 105 deterministic semantic contrasts using v1.0 and v0.9 speech acts.
- `study_builder.py`: 48 paired meaning concepts and 3 counterbalanced study forms (SXP-L, English, structured JSON), with separate answer key.
- `LEARNER_LAB_v1.0.html`: offline learner exercise; no tracking or network calls.
- `SPEC_v1.0.md`, `STUDY_PROTOCOL_v1.0.md`, `LEARNER_CARD_v1.0.md`: written specification, boundaries, and pilot methodology.
- Original modules and tests from v0.9 retained for regression coverage.

## Reproduce, Python 3.10+ standard library

```bash
python -m unittest discover -p 'test_*.py' -q
python minimal_pair_eval.py
python study_builder.py
python authority_bridge.py
python dialogue10.py examples/sovereignty_is_not_permission.sxh --format summary
python sovereignty.py mi tinora ti bakumo tavona gonape darafa dimotu tesavo devora
```

Run from the `sxpl_v10` directory. No API, credentials, app installation, cloud access or live policy integration required.

## What is NOT done

No real permission/consent mechanism; no speaker authentication; no human study; no speech recognition or auditory validation; no comparison showing superiority to Lojban, GF, OPA, English, or typed JSON; no universal translation model; no production tool effects. `authz.py` remains a **fixture-only reference policy gate**.

**Status:** proposal + tested local code + generated study designs. Deployment count: **zero**.
