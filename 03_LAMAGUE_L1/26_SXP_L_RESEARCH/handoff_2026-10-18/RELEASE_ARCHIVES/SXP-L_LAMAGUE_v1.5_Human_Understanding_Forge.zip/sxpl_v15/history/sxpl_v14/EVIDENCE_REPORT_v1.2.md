# SXP-L v1.2 — Reproducible local evidence

**Status:** locally tested research software only. **Date:** 18 October 2026.

## Test result

- `python -m unittest discover -v` run from the release folder: **153/153 test methods passed**, **50.212 seconds**, exit code **0**. Full run transcript: `TEST_RESULTS_v1.2.txt`.
- 141 inherited test methods plus 12 new v1.2 tests.
- v1.2 tests include **1,800 seeded generated cross-reader cases**, mutation tests, malformed frame rejection, quotation/paraphrase distinction, two causal orderings, and exact preservation of `mi liva ti devora`.
- All three new `.sxh` example utterances passed parse-render-parse and non-authorization assertions.
- The offline HTML learner's JavaScript passes Node v22 syntax compilation. Browser usability and audio were **not** evaluated.

## Version integrity

- **94 pre-existing v1.1 ZIP file entries compared byte-for-byte to v1.2 copies: 0 differences.**
- v1.1 already includes a nested, preserved v0.1–v1.0 historical ZIP.
- Only new v1.2 files were added. The lexer/legacy parsers were not overwritten or monkeypatched.

## New root spelling-distance screen

Orthographic Levenshtein minimum distance against existing screened roots and words:

- `larumeko`: **4 edits**
- `nimareko`: **4 edits**
- `voraneku`: **4 edits**

These are **not** auditory or cross-accent tests.

## Semantic invariants observed

- Given the same embedded contents, `larumeko`/`voraneku` can reconstruct the same cause/effect roles with distinct presentation order.
- An old `borema` node does not acquire new direction metadata.
- Reported `nimareko` indirect content has no verbatim `quoted_words` field and never becomes verified speech or authorization.
- AST mutation of `authorizes`, evidence tags, lexically bound content, or referent framing fails closed in the tested cases.

## What was NOT measured

No users or independent linguists were tested. No original voice recordings, comprehension-time data, human preference scores, model-vs-model comparisons, true causal inference tests, or deployed action/consent systems exist in this release.

## Reproduction

```bash
python -m unittest test_discourse12 -v
python -m unittest discover -v
python discourse12.py mi liva ti devora
```

The limited oracle reuses lexical and action signatures from `oracle11.py` but not the new parser, and both readers reflect the same specification. Its agreement is useful regression evidence, not independent confirmation of human meaning.
