# SXP-L × LAMAGUE v1.0 — The Sovereignty Forge

**Date:** 2026-10-18  
**Status:** executable research prototype, controlled text register; **NOT** a complete spoken language, consent system, verified identity system, or production agent runtime.  
**Compatibility:** additive to v0.9. Native-36 / original symbolic LAMAGUE is not modified.

## Thesis

SXP-L attempts to make semantic boundaries explicit in a human-readable—and eventually spoken—language. The v1.0 target is not “AI that obeys anything phrased as a command.” It is **human–AI collaboration with inspectable limits**. In particular:

> **Trust ≠ delegation proposal ≠ authenticated authority ≠ action execution.**  
> **Advice ≠ decision.**  
> **Self-reported final say ≠ proof of legal or operational authority.**

A 1.0 version number is a research milestone, **not a declaration of linguistic completeness or production readiness**.

## Controlled semantics and new roots

| Root | AST `kind` | Narrow meaning; does NOT imply |
|---|---|---|
| `tinora` | `trust_report` | Reporter says they trust a counterparty regarding an action. Does **not** create delegation or prove actual trust. |
| `dalora` | `delegation_proposal` | Reporter raises delegation as a proposal. **Not** a grant. |
| `resama` | `delegation_refusal` | Reporter refuses to delegate the scoped action. **Not** an authenticated policy revocation. |
| `esaloma` | `explanation_request` | Reporter asks for an explanation of the scoped action. **Not** execution authority. |
| `ranova` | `recommendation_request` | Reporter asks for advice on the action. **Not** execution authority. |
| `domera` | `decision_reservation` | Reporter states the final decision remains with themselves. **Not** a proof of ownership or authority. |

All six roots obey the inherited v0.7 **written CV** syllable specification, were checked against v0.9's screened vocabulary for 0–1 edit-distance collisions, and are proposals. **No auditory or comprehension test has been run.**

## Grammar

```ebnf
v10_report   ::= "mi" v10_root actor "bakumo" action resource "tesavo" "devora" ;
v10_root     ::= "tinora" | "dalora" | "resama" | "esaloma" | "ranova" | "domera" ;
actor        ::= "mi" | "ti" | framed_id ;
resource     ::= framed_id ;
action       ::= "mesara" | "lenova" | "rekova" | "sotira" | "tavona" ;
framed_id    ::= "gonape" cv_identifier "dimotu" | "pulako" spelling_codes "sanuti" ;
v10_expr     ::= v09_expr | v10_report ;
```

**Special rule:** `domera` requires actor `mi`. This records that the current *reporter* retains the final decision, not the listener. The parser cannot authenticate that claim. `mi` and `ti` resolve to roster labels only in a dialogue document; in a stand-alone expression they remain deictic pronouns. The parser refuses unframed resources, unknown verbs, malformed word boundaries, extra arguments, unsupported moods on new acts, and non-reversible AST edits.

The exact new typed structure:

```json
{
  "lang": "SXP-L",
  "schema": "1.0.0",
  "register": "sovereignty_spoken_script",
  "node": {
    "kind": "decision_reservation",
    "reporter": "mi",
    "counterparty": "mi",
    "action": "publish_post",
    "resource": "darafa",
    "epistemic_status": "unverified_utterance"
  }
}
```

`render_expression(parse_expression(text))` normalizes valid controlled expressions without losing their parsed meaning. It does **not** guarantee semantic fidelity to unrestricted English, spoken acoustic inputs, or another person's subjective intent.

## Human-facing example

```text
mi tinora ti bakumo tavona gonape darafa dimotu tesavo devora
mi resama ti bakumo tavona gonape darafa dimotu tesavo devora
mi ranova ti bakumo tavona gonape darafa dimotu tesavo devora
mi esaloma ti bakumo tavona gonape darafa dimotu tesavo devora
mi domera mi bakumo tavona gonape darafa dimotu tesavo devora
```

Conservative gloss:

1. I report trusting you regarding publishing draft `darafa`.
2. I refuse to delegate publishing draft `darafa` to you.
3. I ask for your advice regarding that publication.
4. I request an explanation about that publication.
5. I state that I retain the final decision over it.

These are **separate** utterances. The two-part contrast is represented in a transcript by `kora but trusta refusala`, whose link is itself explicitly a *speaker-supplied link*. This version does not yet offer free-form subordination, natural pronoun ellipsis, multi-actor role binding, or fluent everyday syntax.

The example in `examples/sovereignty_is_not_permission.sxh` includes eight utterances across three turns: five new acts, an older promise, a reported v0.9 grant, and a reported v0.9 withdrawal. Even the reported grant is not treated as authenticated authority.

## Interpreter and host policy architecture

```text
SXP-L sentence / text transcript (unverified)
             |
             v
   sovereignty.py + dialogue10.py
             |
             v
   attributed typed speech reports  ---------> review / explanation UI only

Host-authenticated identity, issuer policy, exact scope, signed events and host clock
             |
             v
          authz.py  ---------------------------> simulation: ALLOW or DENY
             |
             v
    no tools, files, emails, posts, calendars, or other effects
```

`authority_bridge.py` intentionally passes **only host-provided request, signatures, ownership, and time** into the policy evaluator. It never upgrades any SXP-L transcript into a capability. `review_advised` is advisory: it flags a reported refusal or retained decision alongside a separately valid signed grant. The language does **not** override the host policy or assert that a report itself is authenticated. A production host must define how such contradictions are resolved before attempting any effect.

**Critical limitation inherited from v0.9:** `authz.py` uses HMAC fixture keys, short-lived scope and a test clock; it is not production identity, key custody, revocation persistence, TOCTOU-safe provider-level enforcement, audit storage, or legal consent verification. No external effects are enabled.

## Evidence at release

- **131/131 local unittest methods passed**: inherited tests v0.2 through v0.9, plus v1.0 tests for new acts, dialogue, compatibility, attack-shaped inputs, round trips, and study materials.
- **2,500 seeded, generated v1.0 expressions** pass parse → render → parse and normalized-string checks. These are grammar-sampled cases, not independent usage.
- **105/105 deterministic minimal-pair checks** distinguish seven linguistic act labels (six v1.0 acts plus v0.9 reported grant) across five action types. This checks a typed AST, not a person's understanding.
- **Three counterbalanced pilot sets with 48 paired scenario concepts each** were generated. There are **no participant responses or accuracy findings**.
- **0 production deployments. 0 tool executions.**

All results reflect deterministic local fixtures and are reproducible with the included standard-library-only Python source.

## Comparison to established work

- **Grammatical Framework (GF)**: already separates abstract syntax from concrete syntax and supports parsing and linearization. SXP-L does not invent this capability. <https://www.grammaticalframework.org/doc/tutorial/gf-tutorial.html>
- **Lojban**: already has sophisticated negation and scope structures, and has a far more developed speech grammar. <https://lojban.org/publications/cll/cll_v1.1_book.pdf>
- **Open Policy Agent (OPA)/Rego**: a mature policy engine, with application policy enforcement separated from decision calculation. SXP-L is not a substitute. <https://www.openpolicyagent.org/docs>

If SXP-L has a useful niche, it must be empirically demonstrated against controlled English and comparably explicit JSON—not asserted on the basis of good-looking syntax or easy fixtures.

## Known meaning losses / unsupported expressions

- No real natural-language translator, human audio corpus, phonetic disambiguation, or speech recognition.
- No social/romantic/medical/sexual/legal consent semantics; “permission” in v0.9 is specifically narrow software-resource language.
- No legal ownership validation or identity authentication from words or conversation participants.
- Trust is **self-report**, not inferred belief intensity, emotional truth or a durable credential.
- “I refuse to delegate” does not automatically revoke a genuine credential: authenticated revocation is a separate trusted event.
- “I retain the final decision” does not prove the speaker actually controls the resource. A conflict with an existing signed capability raises an advisory flag only.
- Quotation, irony, deception, context-dependent intent, indirect requests, politeness, coercion, irony, unbounded vocabulary and complex future conditionals are mostly outside the controlled grammar.
- The morphology is still draft, and future roots can collide perceptually even when spelling-distance audit looks clean.
- The lexical roots have not been formally standardized by independent language users.
- Semantic preservation is tested **within the defined AST**, not against unrestricted human speech or mental states.

## Next scientific milestone: v1.1 / independent comprehension

Preregister a small pilot with people who did not write the grammar. Teach the six roots using the learner lab. Randomize equivalent English, SXP-L, and structured JSON scenarios across three balanced sets. Ask which speech act is reported, whether it is a grant, and which actor retains decision power. Record accuracy, confidence, completion time, task order and background familiarity. Blind the answer key from participants. Analyse error types and report null results; compare both *accuracy* and *cost of learning*.

Before claiming acoustic usability, collect actual human speech, unfamiliar listener transcription and word-boundary confusion matrices. Before claiming agent safety gains, run independent models against matched English/SXP-L/JSON instructions with authenticated host-grant conditions and a real policy engine as baseline.

> **Language should make semantic loss observable—not disguise it with certainty.**
