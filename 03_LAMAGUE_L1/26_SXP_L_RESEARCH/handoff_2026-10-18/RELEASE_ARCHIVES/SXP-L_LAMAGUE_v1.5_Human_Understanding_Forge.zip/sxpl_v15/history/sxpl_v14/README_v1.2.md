# SXP-L × LAMAGUE v1.2 — Directed Meaning Forge

**Research branch. Not a completed human language. Not a policy engine.**

This release preserves all v1.1 files byte-for-byte (apart from the newly generated test-output file for this release) and adds:

- `discourse12.py` — parser, strict AST renderer and information-only reader for direction-marked because/therefore and indirect reporting
- `oracle12.py` — independent-of-primary-parser, restricted second reader
- `test_discourse12.py` — regression, mutation/adversarial and generated tests
- `SPEC_v1.2.md` — language rulebook and semantic/epistemic limits
- `LEARNER_LAB_v1.2.html` — offline first-person reading exercise
- `STUDY_PROTOCOL_v1.2.md` — independent comprehension test proposal
- `ROADMAP_v1.3.md` — reference binding and genuine human evaluation roadmap
- `EVIDENCE_REPORT_v1.2.md` and `TEST_RESULTS_v1.2.txt` — actual local evidence, not implied external validation

## Try it

From this directory:

```bash
python -m unittest test_discourse12 -v
python -m unittest discover -v
python discourse12.py mi liva ti devora
python discourse12.py mi nimareko ti bakumo mi liva ti devora tesavo devora
```

## Our language promise

**`mi liva ti` is unchanged.** That is the preserved original compact phrase. The spoken-script form adds the established `devora` terminator to make complete utterance boundaries explicit.

The project principle is **“Meaning should survive the journey between minds. And when it doesn't, the loss should be visible.”** These are testable aspirations, not measured end-user outcomes.

## For Argon or a new contributor

Read `SPEC_v1.1.md` first, then `SPEC_v1.2.md`. Reproduce tests. Inspect the quoted versus indirect forms, old `borema` versus new directional forms, and tamper tests. Do not assert an independent comprehension improvement without blinded people and a conventional baseline. Keep earlier releases unchanged; report flaws as findings.
