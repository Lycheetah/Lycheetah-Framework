# Evidence report — SXP-L × LAMAGUE v1.0

**Date:** 18 October 2026. **Status:** reproducible **local** engineering tests on a controlled grammar. No participant experiment, external action, spoken-language validation, or independent security review.

| Measurement | Local result | Valid scope of inference |
|---|---:|---|
| Unittest methods | **131/131 passed** | Regression correctness for designed cases, including v0.2–v0.9 historical suite |
| Newly generated v1.0 parse/render/parse cases | **2,500 passed** | Fixed-seed, grammar-generated strings; not human translation accuracy |
| Deterministic minimal-pair checks | **105/105 passed** | Seven reported speech-act labels × five action roots; exact AST label distinction |
| Pilot materials | **48 matched semantic concepts, A/B/C sets** | Balanced materials constructed, **not a conducted experiment** |
| Per participant study condition mix (each set) | **16 SXP-L, 16 English, 16 JSON** | Stimulus allocation counts only |
| Browser learner script | **syntax checked (Node)** | Basic JS parse, not accessibility/browser-device compatibility |
| Host authorization demonstration | **DENY_NO_EXACT_GRANT** | No signed host grant in fixture; no tools executed |
| External deployments | **0** | No live automation, email, file changes, social publishing, or policy service |
| Independent participants | **0** | No comprehension, audio, or learning effect claims |

## Reproduce locally

```bash
cd sxpl_v10
python -m unittest discover -p 'test_*.py' -q
python minimal_pair_eval.py
python study_builder.py
python authority_bridge.py
python dialogue10.py examples/sovereignty_is_not_permission.sxh --format summary
```

Keep `study/STUDY_KEY_ORGANIZER_ONLY.csv` separate from test participants. All examples are fictional, and every text-derived speech act is unverified.

## Limits and conventional baselines

The grammar engine proves self-consistency only over **its restricted syntax**; the AST semantics were assigned by our implementation. The reference authorization gate itself is a simplified fixture. A full alternative comparison should use **typed JSON and controlled English**, a proper independently specified parser, and—if authorization is tested—OPA/Rego or another mature host policy engine. None has yet been run as an independent behavioral benchmark. The shared phrase “sovereignty” is a design commitment, not a demonstrated technical guarantee.
