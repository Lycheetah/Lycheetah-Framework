# v1.4 Meaning-loss and scope ledger

| Risk | Current treatment | Remaining evidence gap |
|---|---|---|
| Outer “I” mistaken for quoted/believing “I” | Each frame names holder and addressee; last frame binds leaf outer `mi`/`ti` | Real humans must learn the frame ordering |
| Belief mistakenly taken as fact | Typed `belief` with `evidence=outer_speaker_claim_unverified`; `proposition_accepted_as_fact=false` in interpretation | Host integrations could ignore the fields |
| Quoted words mistaken for actual speech | `naveriko` is explicitly indirect reported content, **not** literal quote | Source verification outside language |
| Speaker’s uncertainty mistaken for truth or negation | `nesaluko=not_know_whether`, not P or not-P | Full scope logic not yet implemented |
| Third person assigned to arbitrary recent name | Local-scope candidates; abstention when ambiguous | No salience or coreference model |
| Third-person pronoun hidden inside quotation | Reject nested lexical `sivena` | Explicit nested referent support later |
| Permissions accidentally enacted from language | No code path to trusted capabilities; `authorizes=false` throughout | Security review needed before application embedding |
| Semantically altered AST accepted | Renderer reparses entire generated transcript and equality-checks original AST | Formal verification and fuzzing later |
| Names and frame vocabulary hard to pronounce | CV spelling screen | No listening comprehension evidence |
| Long frame chains difficult to read | Six-frame bound; simple visual learner lab | Human study and abbreviation research |
