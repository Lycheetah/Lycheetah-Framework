# ARGON — Adversarial audit brief, SXP-L v1.1

You are auditing a language-invention **research prototype**, not certifying it as complete. Historical v0.1–v1.0 ZIP is included unchanged in `history/`; version 1.0 working modules are copied alongside the v1.1 extension.

1. Independently rerun all regression tests. Compare source SHA manifest.
2. Compare `discourse11.py` with `oracle11.py`; flag every shared assumption and unsupported oracle case. Find valid expressions accepted by one and rejected by the other within their common declared subset.
3. Challenge nested `mi`/`ti` binding across quote boundaries, source impersonation, frame-in-frame parsing, source-name spelling and quoted directives.
4. Inspect `borema` for missing causal-direction specification. Propose a direction-explicit repair rather than silently inferring English "because".
5. Separate *word-token fidelity*, *semantic AST equality*, *human comprehension* and *speech acoustics*. None implies the others.
6. Compare with GF's reversible syntax systems and existing quotation semantics. Avoid unsupported novelty claims.
7. Audit for denial-of-service risks, parsing ambiguity, malicious AST payloads and implicit grants. This is **not** a production authorization layer.
8. Report fixes as small patches on top of history rather than rewriting the older releases.

Deliver a prioritized findings table: severity, exact counterexample, actual vs expected, reproduction command, minimal patch, regression test, and whether independently verified.
