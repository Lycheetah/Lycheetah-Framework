# SXP-L × LAMAGUE v1.4 — Execution evidence

**Date:** 18 October 2026. **Status:** local reproducible program checks; neither human-language nor scientific validation.

## Test runs completed (from the release directory)

| Run | Command | Observed result |
|---|---|---|
| V1.4 targeted | `python -m unittest -v test_perspective14` | **13/13** methods passed, 2.379 s. Includes 1,800 seeded generated nested viewpoint cases, malformed frames, ambiguity, role rebinding, mutation rejection, v1.3 12-turn parity and consent inertness |
| Prior continuity, quotation, safety | `python -m unittest -v test_continuity13 test_discourse11 test_authz test_sovereignty test_consent test_pragmatics` | **111/111** methods passed, 26.956 s |
| Prior language and study modules | `python -m unittest -q test_adversarial test_compact test_dialogue test_meaning_diff test_spoken test_study test_surface test_v03` | **45/45** methods passed, 8.063 s |
| V1.2 directed language module | `python -m unittest -v test_discourse12` | **12/12** methods passed, 17.384 s; exit code 0 |

**181 test methods passed in four independent executions.** The initial monolithic `python -m unittest discover -v` attempted from this release **hit the 125-second tool execution timeout** before completion, without a test assertion failure. Therefore this report **does not** claim a successful single all-in-one run. The four split runs together cover every `test_*.py` module in the release, with no duplicates.

## Independent restricted reader

`python reference_benchmark14.py` yielded:

- **90/90** agreement with `oracle14.py` on explicitly generated, restricted love/third-person scenarios.
- A deliberately naïve outer-speaker-role shortcut would assign both the leaf first person and second person correctly on **31/90** of those cases.
- **40/90** cases had `ambiguous` or `unresolved` third-person referents (requiring abstention).
- This is a synthetic fixture comparison against a weak shortcut, not comparison against full DRT, Grammatical Framework, human readers, or production systems.

`oracle14.py` was authored separately without importing `perspective14.py`. It only recognizes two leaf patterns (`mi liva ti devora` and `mi liva sivena devora`) and does **not** validate all pre-existing expressions.

## Regression continuity

Compared every one of the **127 file entries** inside `SXP-L_LAMAGUE_v1.3_Continuity_Forge.zip` to its corresponding file under the new v1.4 folder; **127/127** matched byte-for-byte. New files are additive. In particular, `mi liva ti` remains unchanged; the new grammar does not add a `jiva` alias.

## Reproducible demo

```
python perspective14.py examples/nested_perspectives_8_turns.sxh
```

Eight turns, including:
- Speaker Maka addressing Nara while reportedly attributing belief to Sela, with Vera as Sela's local addressee;
- a `not_know_whether` frame followed by an attributed belief;
- an ambiguous third-person candidate and a later explicit anchor;
- reported permission that never produces executable authority.

## Unresolved limitations

No listening test; no independent learner study; no ASR; no actual speaker authentication or enforcement of permissions; no de re/de dicto theory; no cross-world anaphora; no general nested pronominal `sivena` inside pre-existing `bakumo` clauses; no natural-language translation. Frames are explicit scaffolding, not spontaneous conversational fluency. `not_know_whether` is a scoped representational tag, not a theorem prover.
