# Proposed human study — NOT YET RUN

## Question
Can a novice, after a standardized lesson, identify the correct nested viewpoint holder and addressee more reliably from a readable SXP-L register than from compact controlled English or a JSON event-tree presentation?

## Design (proposal)
Randomize training order and test-condition order; score participants blind to claims of superiority. Use matched 2–4-layer examples with multiple names, false beliefs, reported speech and `not know whether`. Every item has a predefined answer key for (a) outer speaker, (b) leaf first person, (c) leaf addressee, (d) whether content is verified, (e) unresolved third-person references. Separate exact retention, comprehension accuracy, reaction time, and subjective effort. Include practice items not counted toward the final score. Do not treat a sample of enthusiastic insiders as a generalizable population. Pilot for comprehension of instructions, then preregister an appropriately powered confirmatory test; sample size needs power analysis.

## Comparators
SXP-L spoken-script, matched controlled English with explicit perspective labels, and readable JSON structures. Fairly matched information must be offered in every condition. Compare short vs long frame chains, not only cherry-picked love statements. Test distractor clauses that contain linguistic permission without an actual grant.

## Current status
No participants recruited. No human comprehension, retention or acoustics results. No claims of relative learnability are justified by the local software tests.
