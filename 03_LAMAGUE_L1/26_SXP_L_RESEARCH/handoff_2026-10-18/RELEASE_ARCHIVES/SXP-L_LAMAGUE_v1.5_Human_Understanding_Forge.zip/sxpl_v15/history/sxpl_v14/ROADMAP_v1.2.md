# SXP-L v1.2 proposal — from parser agreement to interpretable discourse

Priorities by scientific value, not by version theatrics:

1. **Unambiguous causal direction** and role binding across relation clauses. Today's `borema` preserves the link and clause order but does not standardize explanatory direction.
2. **Indirect speech versus lexical quotation:** introduce a different construction for *I believe she said X*, *I heard she said X*, and *I have a recording she said X*; never imply quote authentication from syntax.
3. **Genuine pronoun tests:** nested `mi` / `ti` with three or more participants, reported speakers, and indirect quotations; require independent gold annotations, not parser agreement alone.
4. **Human comprehension study** based on blind scenarios, with English and structured JSON comparison and study-time penalty.
5. **Acoustics**: multiple speakers, confusion matrices, speech recognition error isolation, and explicit uncertainty rather than silent inference.
6. **Broader linguistic construction:** plurality, tense/aspect scope, aspectual verbs, quantifiers, negation over conjuncts, anaphora, polite refusal, emotion intensity, figurative speech, and nonassertive question scope.
7. **Independent model evaluation**, separated from tool execution, to see whether the language changes misinterpretation rates versus a typed JSON baseline.

Version status: **experimental**. Strong claims require external validation.
