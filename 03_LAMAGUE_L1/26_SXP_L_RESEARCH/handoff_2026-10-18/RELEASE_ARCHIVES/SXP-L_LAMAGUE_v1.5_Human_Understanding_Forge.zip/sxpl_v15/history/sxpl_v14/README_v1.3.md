# SXP-L v1.3 — The Continuity Forge

An **additive, experimental** text-based conversation-reference layer built on the unchanged SXP-L v1.2 language engine. The 12-turn demonstration shows reported speaker/addressee continuity, explicit reply links, and third-person ambiguity without silently guessing.

**Start here:**

1. `LEARNER_LAB_v1.3.html` — standalone interactive lesson (offline browser).
2. `examples/continuity_12_turns.sxh` — the demonstration transcript; intentionally includes unresolved ambiguity.
3. `python continuity13.py examples/continuity_12_turns.sxh` — print reference decisions.
4. `python -m unittest test_continuity13 -v` — targeted v1.3 tests.
5. `python -m unittest discover -v` — full inherited regression suite; see `TEST_RESULTS_v1.3_FULL.txt` for the observed run.
6. `python reference_benchmark13.py` — regenerates the 60-case synthetic comparison and limited independent oracle agreement.

Contents:

- `continuity13.py`: parser, round-trip renderer, and strict reference interpretation.
- `oracle13.py`: independently written **limited** flat single-turn reader (not a full v1.3 parser).
- `test_continuity13.py`: targeted tests, including generated contexts and adversarial mutations.
- `REFERENCE_BENCHMARK_v1.3.csv`, summary JSON: toy recency-baseline evaluation.
- `SPEC_v1.3.md`: exact grammar, new lexical forms, semantics and limitations.
- `EVIDENCE_REPORT_v1.3.md`, `MEANING_LOSS_LEDGER_v1.3.md`: reproducibility and failure boundaries.
- `ARGON_AUDIT_BRIEF_v1.3.md`: independent review instructions.
- `ROADMAP_v1.4.md`: proposed experiments, not implemented claims.
- Everything else from the v1.2 release copied byte-for-byte, including prior sources and historical archive.

**No real-world permissions, source identities, or third-party assertions are verified.** The system parses provided text only and never executes an external action.

**`mi liva ti` stays original.**
