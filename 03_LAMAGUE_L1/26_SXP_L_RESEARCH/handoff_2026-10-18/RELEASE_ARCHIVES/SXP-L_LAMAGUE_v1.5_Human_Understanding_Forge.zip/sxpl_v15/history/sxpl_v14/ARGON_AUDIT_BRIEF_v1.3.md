# Argon — adversarial independent audit brief, SXP-L v1.3

You are joining the Lycheetah SXP-L × LAMAGUE project as a technical challenger. Audit, don't praise by default.

**Do not overwrite or normalize historical source.** Compare v1.2 and v1.3 manifests; report any discrepancy.

Your priority questions:

1. Does `continuity13.py` validate **all** ambiguous expressions syntactically even when refusing to choose a referent?
2. Can lexical framing, nested `bakumo` scope, malformed participant names, or noncanonical input bypass ambiguity handling?
3. Does `_third_person_occurrences` correctly reject pronoun use in reported/quoted scope? Find counterexamples.
4. Could `repira` turn references imply something they shouldn't (agreement, evidence, authorization)?
5. Are `mi` and `ti` binding only as much as the interpreter promises? Investigate nested indirect-speech perspective shifts.
6. Reimplement a separate reader for the full transcript grammar rather than relying on `oracle13.py` (limited one-turn scanner).
7. Independently generate ambiguity, zero-candidate, unique-candidate and explicit-anchor cases with randomized participant renaming and ordering.
8. Try to falsify the 60-case synthetic result. Compare against a *serious* established coreference/discourse system under a matched evaluation once available; the current recency heuristic is intentionally weak.
9. Design a blinded human task comparing SXP-L with controlled English and typed JSON, matched for meaning, learning exposure and scenario length. Record refusals and confidence as well as accuracy.
10. Assess whether our new lexemes are pronounceable and perceptually distinct under our provisional phonology.

Expected output: reproducible bug reports, severity, exact triggering text, a proposed minimal fix, independent test results, and a recommendation to accept/revise/reject the v1.3 design. Distinguish linguistic plausibility, syntactic round trips, and empirically validated performance.

**Unchanged principle:** `mi liva ti`; do not introduce `jiva` as a retrospective alias. Human sovereignty and unverified linguistic authority must remain explicit.
