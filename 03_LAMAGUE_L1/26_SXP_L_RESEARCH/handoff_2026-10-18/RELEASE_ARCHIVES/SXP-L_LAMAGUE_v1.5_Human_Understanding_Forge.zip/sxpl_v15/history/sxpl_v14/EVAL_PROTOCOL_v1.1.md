# External evaluation plan — SXP-L v1.1

**Study not conducted.** These are materials and preregistration recommendations only.

## Hypothesis

After equal instruction time, learners can distinguish direct reported grants, attributed quotations, speaker-linked contrasts, and speaker-linked causal claims from one another. The relevant external comparison is not a straw-man keyword classifier; use conventional English and JSON controls with comparable semantic annotations.

## Candidate pilot design

- Recruit 18–30 consenting adult volunteers without involvement in the language construction. Predeclare exclusion criteria before viewing data.
- Randomize order and version of equivalent statements into SXP-L, controlled English, and schema-constrained JSON. Balance target types. Predeclare the number of familiarization minutes per system or explicitly measure learning time.
- Use two tasks: choose the intended semantic type; and mark whether the statement independently grants execution authority (correct answer: **never from the text alone**).
- Measure accuracy, response time, per-condition confusion matrix and ability to explain quote-source and `mi` binding. Collect failures and null results, not just successes.
- Include unexpected/malformed expressions and explicit "cannot determine" options; penalize unjustified certainty.
- Do **not** use actual private communications or real credentials in the evaluation.

## Required acceptance metrics (not results)

Precision/recall per act; over-permission false-positive rate; comprehension weighted by training time; unexpected-message rejection; identity/coreference error types. Compare to a competent structured baseline and a grammar familiarization control.

## Important limitation

A syntactic parser that returns identical trees after re-rendering has not proved that a person or AI actually intended that meaning. Quotation veracity and authority must be established outside linguistic content.
