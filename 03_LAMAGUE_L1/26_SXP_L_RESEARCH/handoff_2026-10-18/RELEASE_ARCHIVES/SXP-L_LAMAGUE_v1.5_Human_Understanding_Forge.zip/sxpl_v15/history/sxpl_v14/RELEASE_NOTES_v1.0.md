# Release notes — SXP-L 1.0: Sovereignty Forge

**Release:** 2026-10-18  
**Type:** controlled spoken-script research prototype  
**Security status:** local text parser, fixture-only policy gate, no external effects

## Shipped

- Six new SXP-L roots for trust, delegation proposals/refusals, explanation, advice, and final decision reservation.
- Versioned AST with parser, renderer, typed conservative interpretation, and v0.9 compatibility.
- Dialogue 1.0 transcript grammar with speaker/addressee references, links, corrections and provenance claims.
- Trusted-host policy boundary demo, never deriving grants from transcript content.
- 131/131 software unit tests, 2,500 generated v1.0 expressions, 105 semantic minimal-pair fixtures.
- Offline learner lab, 48 matched pilot study concepts with three counterbalanced forms and organizer key.
- Specifications, learner card, risk ledger, roadmap, test log, evidence report and SHA-256 manifest.

## Not shipped

Natural SXP-L-to-English translation, model-specific adapter, speech recognition, independently validated pronunciation, real legal consent, secure host identity, persistent revocation, OPA integration, live agents, real user studies, meaningful claims of statistical superiority, or production deployment.

> `v1.0` denotes an internally reproducible research release, **not** a fully constructed human language.
