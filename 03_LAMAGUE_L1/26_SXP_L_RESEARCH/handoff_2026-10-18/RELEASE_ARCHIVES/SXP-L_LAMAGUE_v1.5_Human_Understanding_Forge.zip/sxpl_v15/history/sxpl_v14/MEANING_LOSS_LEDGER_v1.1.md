# SXP-L v1.1 meaning-loss and ambiguity ledger

| Boundary | Representation | Preserved by software | Still missing |
|---|---|---|---|
| Direct report vs quotation | `legacy_v10` vs `attributed_quote` | Yes, in supported textual inputs | Evidence that purported speaker ever uttered the words |
| `mi` in quotation | `quoted_mi_binding=quoted_source_not_reporter` | Declared explicitly | Complete 3+ party deictic binding and speech recognition |
| Quoted surface | `quoted_words` plus nested parsed AST | Normalized word-token identity | Exact whitespace, punctuation, prosody, original recording |
| Reported source | source pronoun or framed identifier | Identifier or pronoun retained | Any authenticated source identity; full audience/addressee resolution |
| Contrast vs causality | `contrast_report` / `causal_claim_report` | Distinct type and ordered arguments | Fully specified causal direction; implied discourse nuances |
| Causal link credibility | `relation_status=speaker_supplied_not_verified` | Yes | Independent proof of causation or explanation |
| Old language | `legacy_v10` wrapper | v1.0 expressions unchanged | Semantic equivalence to arbitrary English |
| Authorization | All v1.1 constructs set `authorizes=false` | Yes, in non-executing reference interpreter | No production security claims; host policy independent |
| Pronunciation | Three roots checked for CV shape, grapheme distance | Yes | Human listening test, rhythm, collision acoustic measurements |
| Language productivity | Fixed quote/contrast report operators over v1.0 AST | Tested bounded composition | Open-ended syntax, tense scope, honorifics, metaphor, plural reference |

### Key non-inferences

- Reporting *"I give you permission"* is **not** a new permission grant.
- Quoting a claim is **not** endorsing the claim or verifying its provenance.
- Claiming *A because B* is **not** presenting independently verified causation.
- Parser round-trip consistency is **not** evidence of meaning preserved from unconstrained speech.
- An AI's comprehension of a request **never itself implies authorization to execute it**.
