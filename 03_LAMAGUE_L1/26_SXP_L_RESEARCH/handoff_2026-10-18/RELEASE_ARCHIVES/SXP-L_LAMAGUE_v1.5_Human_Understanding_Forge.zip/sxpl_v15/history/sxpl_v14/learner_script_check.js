
'use strict';
const roots=[
 ['tinora','trust_report','I report trust','mi tinora ti bakumo tavona gonape darafa dimotu tesavo devora'],
 ['dalora','delegation_proposal','I propose delegation','mi dalora ti bakumo tavona gonape darafa dimotu tesavo devora'],
 ['resama','delegation_refusal','I refuse delegation','mi resama ti bakumo tavona gonape darafa dimotu tesavo devora'],
 ['esaloma','explanation_request','I request an explanation','mi esaloma ti bakumo tavona gonape darafa dimotu tesavo devora'],
 ['ranova','recommendation_request','I request advice','mi ranova ti bakumo tavona gonape darafa dimotu tesavo devora'],
 ['domera','decision_reservation','I reserve the final decision','mi domera mi bakumo tavona gonape darafa dimotu tesavo devora']
];
function vowels(word){const a=word.match(/(?:[bdfghklmnprstvyz]?[aeiou])/g)||[];return a.join('·');}
document.getElementById('lexicon').innerHTML=roots.map(r=>`<article class="card"><div class="root">${r[0]}</div><div class="ipa">${vowels(r[0])} · syllable spelling</div><div class="meaning">${r[2]}</div><div class="spelling">${r[3]}</div></article>`).join('');
const qs=[...roots,...roots.slice().reverse()];let i=0,correct=0,answered=false;
function show(){answered=false;const r=qs[i];document.getElementById('progress').textContent=`Exercise ${i+1} / ${qs.length}`;document.getElementById('question').textContent=r[3];document.getElementById('score').textContent=`Correct: ${correct} / ${i}`;document.getElementById('feedback').textContent='';document.getElementById('answers').innerHTML='';const choices=[...roots].sort((a,b)=>a[0].localeCompare(b[0]));for(const choice of choices){const b=document.createElement('button');b.textContent=choice[2];b.onclick=()=>{if(answered)return;answered=true;const ok=choice[1]===r[1];if(ok)correct++;document.getElementById('feedback').textContent=ok?'Correct — the meaning was preserved.':`Not quite. This means: ${r[2]}.`;document.getElementById('score').textContent=`Correct: ${correct} / ${i+1}`;for(const btn of document.querySelectorAll('#answers button'))btn.disabled=true;};document.getElementById('answers').appendChild(b);}}
document.getElementById('next').onclick=()=>{if(!answered){document.getElementById('feedback').textContent='Choose an answer before moving on.';return;}i++;if(i===qs.length){i=0;correct=0;}show();};show();
