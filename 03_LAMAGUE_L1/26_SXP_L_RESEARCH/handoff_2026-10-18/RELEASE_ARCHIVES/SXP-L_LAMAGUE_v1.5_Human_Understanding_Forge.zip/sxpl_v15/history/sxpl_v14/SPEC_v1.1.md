# SXP-L × LAMAGUE v1.1 — The Attribution & Scope Forge

**Status:** locally tested research implementation, **not** a complete natural language, a validated audio system, a verified quotation service, or an access-control runtime.

**Compatibility:** all v1.0 sentences remain accepted as `legacy_v10`; earlier versions remain unmodified. Lexical roots here are *provisional*, not Native-36 replacements.

## The problem

A person can quote a promise, threat, consent claim, or command without making that utterance themselves. An AI that confuses *mentioning* a grant with *issuing* a grant can cause real harm. Similarly, "because" may indicate a speaker's causal interpretation rather than established causality. SXP-L v1.1 introduces explicit syntactic scope and epistemic boundaries around both.

## New words

| Surface root | Controlled sense | Semantics |
|---|---|---|
| `kavira` | reported quotation | Report that another speaker uttered the embedded words; source/attribution **unverified** |
| `kasora` | contrast | Reporter links left/right statements by contrast; link is a report, not a logical inconsistency proof |
| `borema` | causal claim | Reporter claims a causal/explanatory link; not independently established |

The three follow the existing v0.7 written syllable inventory and screen at edit-distance **greater than one** against the previous screened vocabulary. Character edit distance is **not** an acoustic confusability test.

## EBNF — bounded v1.1 subset

```ebnf
v11_expr  ::= v10_expr | quote | relation ;
quote     ::= "mi" "kavira" speaker "bakumo" v10_expr "tesavo" "devora" ;
relation  ::= "mi" ("kasora" | "borema") "bakumo" v10_expr "tesavo"
              "bakumo" v10_expr "tesavo" "devora" ;
speaker   ::= "mi" | "ti" | framed_id ;
framed_id ::= "gonape" literal_name "dimotu" | "pulako" spelling_codes "sanuti" ;
```

The `v10_expr` is an **already valid complete** v1.0 expression, including its own final `devora`. Framed delimiters are parsed with a lexical depth counter, not string substitution. Quotes and relation clauses are single-level in this release: their embedded expressions must be from v1.0, never from the new v1.1 constructs. Only canonical v1.0 surface word forms are accepted as nested material.

### Quotational identity rule

`mi kavira ti bakumo mi periva ti bakumo tavona gonape darafa dimotu tesavo devora tesavo devora`

Conservative gloss: **I report you saying, "I grant you permission to publish darafa."** Both the reported source and its actual words remain unverified.

Here the inner `mi` refers to **the *alleged quoted speaker***, not the outer reporter. The quoted grant does not become an authenticated grant, and the inner reported speaker's `ti` is unresolved until an explicit context establishes an addressee. Pronouns are deliberately not rewritten across the quote boundary.

The AST includes both the quote's normalized literal word tokens and its parsed v1.0 structure. Those must match exactly during validation. This is lexical preservation at the **normalized word-token level**, not verbatim audio, pause/prosody, exact whitespace, or original orthographic punctuation preservation. Independent records would be required to establish who actually said what.

### Contrast as a speaker-supplied relation

`mi kasora bakumo mi liva ti devora tesavo bakumo mi noka kapera bakumo mi pamisa bakumo fura mi satoma tesavo tesavo devora tesavo devora`

Conservative gloss: **I love you, but I report that I cannot promise to stay.** It preserves the two speech contents and the claimed contrast. Neither emotional intensity nor social implications are computed.

### Because is a reported causal relation

`mi borema bakumo ...statement A... tesavo bakumo ...statement B... tesavo devora`

Semantically **a speaker presents A as causally/explanatorily connected to B**. It never turns B into causal evidence or a proven inference. This first version does **not** define a universal direction for natural-language "because" in translation: the AST explicitly stores `left` and `right`; human glosses must separately specify the intended direction. Until a direction-marker design is independently validated, write explicit "reporter links A and B by an explanatory claim," not "A because B". This is a known linguistic incompleteness rather than silently invented semantics.

## Preservation guarantees of the code

1. Quote versus direct utterance have distinct node types.
2. Source attribution is an `unverified_report` rather than authenticated evidence.
3. Embedded text can be parsed as v1.0 syntax, yet cannot authorize an action or change host policy.
4. `kasora` and `borema` are distinct relationship kinds; neither is factual proof.
5. Modified ASTs that change quoted words, authorization flag, status, or parsed content fail validation.
6. Existing v1.0 forms continue unchanged under `legacy_v10`.

These are restricted software properties. No independent user comprehension, audio transcription, grammar learning, agent training, or production security guarantee has been measured.

## Independent oracle

`oracle11.py` is a second lexical and framing parser that does **not import** the principal parser or v1.0 code. It reads a documented subset: quoted and linked action reports from v0.9 and v1.0 plus `mi liva ti devora`. Its semantic signatures are checked against the main parser in 2,500 deterministic generated cases. The two still share a *written specification*, so this is a useful cross-implementation test, not proof of English fidelity or an independent audit of every grammar version.

## Security and epistemic model

This module is **non-executing**. It does not authenticate identities, consent, truth, or authority. The v0.9 host-authenticated capability gate remains a separate example for policy decisions; it receives no grants from v1.1 quoted content. Quoted malicious text is stored as mentioned data only.

## Prior art to acknowledge

- Stanford Encyclopedia of Philosophy, *Quotation* (updated 2023): https://plato.stanford.edu/entries/quotation/ — quotation, opacity, and the use/mention distinction are established topics.
- Grammatical Framework reference manual: https://www.grammaticalframework.org/doc/gf-refman.html — abstract/concrete syntax and reversible parsing are established technology.

This work does not claim invention of those underlying principles.
