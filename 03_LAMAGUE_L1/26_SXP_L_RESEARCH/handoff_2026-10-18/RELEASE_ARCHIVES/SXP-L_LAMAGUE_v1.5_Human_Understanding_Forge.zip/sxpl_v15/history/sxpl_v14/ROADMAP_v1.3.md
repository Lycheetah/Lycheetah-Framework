# SXP-L v1.3 candidate direction — reference and context

**Priority is evidence, not version count.**

1. Stable named participants and pronouns across at least ten turns: explicit speaker, audience, quoted source and reported addressee; ambiguity must be surfaced, not guessed.
2. Distinguish direct quotation, indirect speech, hearsay, observed utterance and retrieved/verified transcript using separately authenticated *outside-language* provenance.
3. Teach exactly the directional cause/effect distinctions from v1.2 to a small number of new learners. Compare against controlled English and JSON on matched scenarios, randomly reordered; publish errors and uncertainty.
4. Test acoustic contrasts (especially luma/loma) with multiple speakers and untrained listeners; report confusion matrix and comprehension time.
5. Develop morphology, adjective/modifier scope, quantification, dialogue politeness and figurative language. Keep conceptual meaning distinct from parser syntax correctness.
6. Assess practical value on human/AI-agent tasks in a sandbox while holding the model, policy and task constant across representation conditions.

Stop rule: if SXP-L underperforms established representations under controlled study, document it and adapt the design rather than claiming success.
