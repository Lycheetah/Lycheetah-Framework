# SXP-L v1.2 — Directed Meaning & Indirect Speech Forge

This release is a **working experimental text-language extension**, not a natural-language standard or validated production agent protocol.

### What changed

1. `larumeko`: **EFFECT because CAUSE**, with typed `cause_ast` and `effect_ast`.
2. `voraneku`: **CAUSE; therefore EFFECT**, preserving the same directional semantic relation when clauses are reordered.
3. `nimareko`: reported indirect speech, with `wording_status=paraphrase_not_verbatim`; it is distinct from v1.1's `kavira` claimed lexical quote.
4. An independent limited reader (`oracle12.py`), mutation/adversarial tests and a browser-based learner exercise.
5. An explicitly written independent-learning study protocol, including a control for underspecified historical `borema`.

### What did not change

- **`mi liva ti` remains “I love you.”** No `jiva` replacement or silent alias.
- All pre-existing v1.1 files and grammar meanings were copied unchanged; no historical rewrite.
- `borema` keeps its original directionally underspecified meaning.
- No reported grant or quotation becomes executable authority.

### Interpretation boundary

Directional marks refer to **speaker-supplied** causal claims, not verified causal facts. Quotation and indirect reporting remain unauthenticated. Success on deterministic synthetic test cases cannot establish human learnability, real spoken accuracy, translation fidelity outside the grammar, or advantage over other languages.

### Next investigation

v1.3 should focus on explicit cross-turn person-reference binding, real human comprehension, and spoken-word discrimination. See `ROADMAP_v1.3.md`.
