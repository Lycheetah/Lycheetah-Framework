# SXP-L × LAMAGUE v1.4 — Nested Perspectives Forge

Experimental language engineering: **nested reported speech, belief, uncertainty, and local-person reference**.

Read `SPEC_v1.4.md` first. The v1.3 code is inherited byte-for-byte; only new v1.4 files implement the feature. Original `mi liva ti` and its meaning remain unchanged.

## Quick start

```bash
python perspective14.py examples/nested_perspectives_8_turns.sxh
python -m unittest -v test_perspective14
python reference_benchmark14.py
```

`LEARNER_LAB_v1.4.html` is a standalone offline HTML page for practising first/second-person scopes. `oracle14.py` is an independent restricted reader, **not** a complete alternative parser. `REFERENCE_BENCHMARK_v1.4.csv` reports deterministic synthetic comparison cases.

## Research boundaries

No real agent actions, authentication, mind-reading, acoustic evaluation, or proven advantage over existing formal languages. Local tests measure specified invariants. Viewpoint frames describe the outer reporter's claims, not verified speech or beliefs. See `EVIDENCE_REPORT_v1.4.md` for executed commands and measured results.
