# SXP-L v1.3 — Meaning / reference / threat ledger

| Situation | Current behavior | What would be lost by guessing | Status |
|---|---|---|---|
| `mi liva ti` in declared turn | Annotate outer `mi` as reported speaker and `ti` as reported addressee | Original conversational perspective | Supported within stated metadata boundary |
| `sivena` with two eligible people | Mark `ambiguous`, preserve candidate set, no semantic AST | Identity uncertainty | Supported with abstention |
| `sivena` with no eligible third person | Mark `unresolved`, no semantic AST | Unresolved identity | Supported with abstention |
| `sivena` with one eligible person | Expand to named participant before v1.2 parse | Identity specificity | Supported; not independently authenticated |
| `rasufe` in one turn | Apply exact referent anchor only to that turn | Explicit disambiguating choice | Supported |
| `repira` reference to prior turn | Preserve pointer, no sentiment/entailment attached | Distinction between reply and assent | Supported |
| Third-person word inside quotation/report frame | Reject rather than bind to outer context | Speaker perspective shift and source attribution | Unsupported, explicitly rejected |
| “I know, but she doesn't” | Reject/unsupported outside bounded grammar | Ellipsis and embedded belief scope | Not implemented |
| First mention introduced after prior turns | Requires participants predeclared | Natural real-time discourse introduction | Not implemented |
| Alleged “I grant permission” | Inert utterance; no authorization issued | Real authenticated policy evidence | Separate host policy required |
| “She” vs “he” / singular they | `sivena` carries no gender | Gender, number, person agreement | Not implemented |
| Natural voice | Textual whitespace tokenization only | Audio segmentation, stress and listening comprehension | Not tested |
| Confirming human source | Role annotations remain claims | Authenticated provenance, recording chain | Not implemented |

Synthetic benchmark note: a deliberately naïve “last declared eligible person” heuristic commits to one person even when the grammar cannot identify them. In 60 constructed cases it made 24 such unsupported commitments; our bounded reference system made zero. We cannot claim that either system understood the intended real-world referent in ambiguous cases, because **no such truth label exists**.
