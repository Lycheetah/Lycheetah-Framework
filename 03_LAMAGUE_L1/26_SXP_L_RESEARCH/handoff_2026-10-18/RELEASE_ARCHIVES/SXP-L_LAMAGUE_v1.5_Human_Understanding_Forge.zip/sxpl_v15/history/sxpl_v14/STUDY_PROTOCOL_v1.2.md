# v1.2 independent-learning experiment — prepared, NOT run

## Aim

Test whether a learner can identify the direction of claimed causality and distinguish quotation from paraphrase in v1.2 sentences after a limited tutorial. **Do not** infer real-world causality from reported causes.

## Design

Recruit novice participants who have not seen this grammar. Assign balanced conditions: SXP-L v1.2, controlled English, typed JSON. Each condition gets training matched for concepts and practice time, and the same held-out semantic scenarios. Counterbalance which scenario each participant receives in which register; randomize presentation order and distractor placement.

Primary outcomes: (a) accurate cause/effect mapping and (b) accurate literal-quote-versus-paraphrase classification. Secondary: comprehension time, confidence, perceived cognitive effort, unexplained-abstention rate, and skill after a delay. Predefine scoring and statistical analysis before recruitment.

## Non-negotiable controls

- Do not include training sentences in the scored test; do not score a repeated template with identical lexical items as independent generalization.
- Explanatory relationship remains *speaker-claimed*, not verified as a physical fact.
- Explicitly ask whether a reported grant authorizes a software action; expected answer is **NO without separate authenticated policy**.
- Include older underspecified `borema` sentences, where the correct answer is **direction unknown**; count guessed direction as error.
- Check actual listening separately from reading; no speech audio from a generic TTS voice can establish canonical SXP-L pronunciation.
- Publish anonymized counts including failures; compare the same task, not generative output verbosity.

## Status

Only a proposal. No participants were recruited or tested and no statistical advantage is claimed.
