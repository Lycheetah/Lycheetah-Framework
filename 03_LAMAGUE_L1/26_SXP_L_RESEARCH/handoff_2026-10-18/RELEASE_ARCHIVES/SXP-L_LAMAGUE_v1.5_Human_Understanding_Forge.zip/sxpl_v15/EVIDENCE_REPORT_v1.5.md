# SXP-L × LAMAGUE v1.5 — Evidence report

**Recorded:** 18 October 2026. **Release status:** synthetic/local engineering QA only; **ZERO independent human participants**, **ZERO human comprehension claims**, **ZERO authorized agent actions**.

## What actually ran

| Check | Observed result | Scope |
|---|---|---|
| New v1.5 Python suite | **15/15 methods passed** | Gold consistency, per-arm condition/depth balancing, protected synthetic scorer, malformed files, train/test separation, preserved `mi liva ti` |
| Focused inherited v1.4 suite | **13/13 methods passed** | Nested perspective scopes, reference abstention, compatibility and error cases |
| Independent restricted reader | **27/27 gold answers agree** | `oracle14.read` independently parses the same bounded simple clauses; not a general human proof |
| Browser walk-through | **6 practice + 27 scored items completed** | Headless Chromium, full-page self-contained HTML loaded into browser; 27-row CSV exported and read |
| Browser JS runtime errors | **0 detected** | Only this scripted happy-path test, not comprehensive device/accessibility coverage |
| CSV analysis synthetic fixtures | **3 sessions / 81 rows accepted with explicit `--allow-synthetic`** | Entirely fabricated responses, no people |
| Synthetic protection | **rejects SIMULATED IDs without explicit flag** | Prevents accidental confusing with actual participant files; cannot authenticate participant identity |
| Prior v1.4 release | **151/151 files unchanged** | SHA-256 byte comparison, copied from sealed v1.4 archive |

## Instrument

- **27** unique scored semantic scenarios; three groups of nine: `holder`, `stance`, `reference`.
- **27** matched SXP-L representations; **27** controlled-English renderings; **27** JSON renderings.
- Each of 3 assignment arms gets **9 scored questions per register**: each register gets 3 of each task, nesting depths 1, 2, and 3.
- **6** separate feedback practice items; no scored item is used in practice.
- **No new SXP-L roots** and no changes to `mi liva ti`.

## Explicit non-results

No real human consented to, completed, or was recruited for the instrument in this session. There is no human accuracy rate, speed finding, retention result, effect size, p-value, or claim that the constructed language outperforms English/JSON.

Synthetic sample means in `SYNTHETIC_PIPELINE_REPORT.json` are generated entirely by fake fixed answer patterns for QA. They must never appear in results sections about participants.

## Known gaps

1. Controlled test sentences use only `liva` as a predicate; not linguistic generalization.
2. English and JSON formats contain the same semantic information but vary substantially in surface length and prior familiarity. Some clues may be easier to read than others.
3. The key originates in `perspective14.py` and was cross-checked only with `oracle14.py` for a narrow grammar; not independently graded by a human expert.
4. Browser QA exercised a successful full session via `set_content`; local `file://` navigation was blocked by this environment's Chromium administration policy, not tested across real user devices.
5. No accessibility audit, random participant sampling, or ethics review has been performed.
6. No pretrained agent, LLM, or human semantic transfer benchmark has been conducted.
7. Answer keys are included in the *research archive*, so to keep a test blind distribute the standalone participant HTML only, or create and protect a fresh holdout bank for later trials.

**Next research hinge:** a consent-based, independently run pilot, analyzed separately from synthetic fixtures. Only afterward decide how to broaden the grammar and study.
