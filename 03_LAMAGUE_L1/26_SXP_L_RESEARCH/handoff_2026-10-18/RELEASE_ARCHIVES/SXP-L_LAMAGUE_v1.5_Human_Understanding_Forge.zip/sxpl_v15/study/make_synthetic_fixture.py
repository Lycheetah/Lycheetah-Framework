"""Generate SIMULATED ONLY responses to verify CSV and scorer; not human evidence."""
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
items=json.loads((ROOT/'participant_items.json').read_text())
key={x['id']:x['correct_answer'] for x in json.loads((ROOT/'ANSWER_KEY_ORGANIZER_ONLY.json').read_text())}
fields=['version','session','arm','seed','trial_index','item_id','task','condition','difficulty','response','confidence','elapsed_ms']
regs=['sxpl','english','json']
for arm in range(3):
 path=ROOT/('SIMULATED_PIPELINE_ARM_'+ 'ABC'[arm]+'.csv')
 with path.open('w',newline='',encoding='utf8') as f:
  wr=csv.DictWriter(f,fieldnames=fields);wr.writeheader()
  for i,x in enumerate(items):
   # deliberately vary outcomes in a deterministic manner: synthetic, meaningless
   response=key[x['id']] if (i+arm)%7!=0 else 'Unsure'
   wr.writerow(dict(version='1.5.0',session='SIMULATED_'+str(arm),arm='ABC'[arm],seed=100+arm,
     trial_index=i+1,item_id=x['id'],task=x['task'],condition=regs[((i//9)+arm)%3],
     difficulty=x['difficulty'],response=response,confidence=3,elapsed_ms=3000+i*70))
 print(path)
