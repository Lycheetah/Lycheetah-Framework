"""SXP-L v1.5, deterministic matched stimuli built from an actual v1.4 parser.

Source-of-truth is the parsed meaning of each text item, not a human-invented
answer key. The English and JSON views explicitly render the same frame chain.
Each participant sees each scenario once, with counterbalanced presentation.
"""
from __future__ import annotations
import json, random, sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'history'/'sxpl_v14'))
from perspective14 import parse_transcript,render_transcript,interpret_transcript

NAME_POOL=['maka','nara','sela','vera','luma']
FRAMES={'naveriko':'reported_speech','belareko':'belief','nesaluko':'not_know_whether'}
STANCE={'reported_speech':'Reported speech','belief':'Belief','not_know_whether':'Does not know whether'}
REFERENCE={'explicit_anchor':'Explicitly anchored', 'unique_candidate':'Only one eligible person','ambiguous':'Ambiguous / not resolved','unresolved':'Ambiguous / not resolved'}
QOPTS={'holder':['Maka','Nara','Sela','Vera','Luma'],
       'stance':['Reported speech','Belief','Does not know whether'],
       'reference':['Explicitly anchored','Only one eligible person','Ambiguous / not resolved']}
QUESTIONS={'holder':'Who does “mi” / “I” refer to in the final clause?',
           'stance':'What type of claimed perspective directly surrounds the final clause?',
           'reference':'How is the third-person reference resolved?'}

def cap(n):return n.title()

def build_item(i:int)->dict:
    rng=random.Random(19000+i)
    task=['holder','stance','reference'][i%3]
    k=i//3
    # Reference items deliberately split 3/3/3 across explicit, unique, ambiguous.
    n=(3 if k%3==0 else 4) if task=='reference' else (3 if k%3==0 else 4 if k%3==1 else 5)
    ppl=NAME_POOL[:n]
    speaker,audience=rng.sample(ppl,2)
    depth=(k%3)+1
    frame_roots=[]
    for d in range(depth):
        root=(['naveriko','belareko','nesaluko'][(k+d)%3] if task!='stance' or d!=depth-1 else ['naveriko','belareko','nesaluko'][k%3])
        holder,addressee=rng.sample(ppl,2)
        frame_roots.append((root,holder,addressee))
    local_mi,local_ti=frame_roots[-1][1:3]
    anchor=None
    if task=='reference' and k%3==1:
        anchor=rng.choice([p for p in ppl if p not in (local_mi,local_ti)])
    leaf='mi liva sivena devora' if task=='reference' else 'mi liva ti devora'
    lines=[f'norava gonape {p} dimotu' for p in ppl]
    lines.append(f'taviro gonape {speaker} dimotu gonape {audience} dimotu')
    if anchor: lines.append(f'rasufe gonape {anchor} dimotu')
    for op,h,a in frame_roots:
        lines.append(f'{op} gonape {h} dimotu gonape {a} dimotu')
    lines.extend([leaf,'tevaro'])
    sxpl='\n'.join(lines)+'\n'
    ast=parse_transcript(sxpl)
    assert render_transcript(ast)==sxpl
    tr=ast['turns'][0]
    if task=='holder':gold=cap(tr['leaf_roles']['mi'])
    elif task=='stance':gold=STANCE[tr['frames'][-1]['kind']]
    else:gold=REFERENCE[tr['reference']['status']]
    assert gold in QOPTS[task]
    en=[f'Participants: {", ".join(cap(p) for p in ppl)}.',
        f'Outer turn: {cap(speaker)} addresses {cap(audience)}.']
    if anchor:en.append(f'Third-person reference is explicitly anchored to {cap(anchor)}.')
    for d,(op,h,a) in enumerate(frame_roots,1):
        if op=='naveriko':t=f'{cap(h)} is reported as communicating the embedded content to {cap(a)}.'
        elif op=='belareko':t=f'{cap(h)} is attributed a belief about the embedded content, with {cap(a)} as local addressee.'
        else:t=f'{cap(h)} is described as not knowing whether the embedded content is true, with {cap(a)} as local addressee.'
        en.append(f'Claimed perspective {d}: {t}')
    en.append('Final clause in the innermost local perspective: “I love '+('you.' if task!='reference' else 'a third person.')+'”')
    en.append('All attributions are unverified reports; they are not verified facts or permissions.')
    english='\n'.join(en)
    obj={'participants':ppl,'outer_turn':{'speaker':speaker,'addressee':audience},
         'perspective_frames':[{'kind':FRAMES[op],'holder':h,'local_addressee':a} for op,h,a in frame_roots],
         'third_person_anchor':anchor,
         'final_clause':{'subject':'mi','predicate':'liva','object':'sivena' if task=='reference' else 'ti'},
         'claimed_not_verified':True,'authorizes':False}
    js=json.dumps(obj,ensure_ascii=False,indent=2)
    return {'id':f'S{i+1:02}','task':task,'difficulty':depth,'question':QUESTIONS[task],
           'options':QOPTS[task] if task!='holder' else [cap(p) for p in ppl],
           'gold':gold,'sxpl':sxpl.strip(),'english':english,'json':js,
           'semantic':{'speaker':speaker,'audience':audience,'frames':tr['frames'],
                       'leaf_roles':tr['leaf_roles'],'reference':tr['reference']['status'],
                       'chosen_ref':tr['reference']['chosen'],'authorizes':tr['authorizes']}}

def build():
    items=[build_item(i) for i in range(27)]
    assert len({x['id'] for x in items})==len(items)
    assert {t:sum(x['task']==t for x in items) for t in QOPTS}=={'holder':9,'stance':9,'reference':9}
    # one third of trials per condition within each question type for each of A/B/C
    for arm in range(3):
        for task in QOPTS:
            assert sorted(sum(x['task']==task and ['sxpl','english','json'][((i//9)+arm)%3]==c for i,x in enumerate(items)) for c in ['sxpl','english','json'])==[3,3,3]
    # all task categories have at least two nesting depths
    return items

if __name__=='__main__':
    out=BASE/'study';items=build();(out/'items_private.json').write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
    key=[{'id':x['id'],'task':x['task'],'correct_answer':x['gold'],'difficulty':x['difficulty']} for x in items]
    (out/'ANSWER_KEY_ORGANIZER_ONLY.json').write_text(json.dumps(key,indent=2)+'\n')
    # participant bundle carries no gold or derived resolved semantic roles
    public=[{k:x[k] for k in ('id','task','difficulty','question','options','sxpl','english','json')} for x in items]
    (out/'participant_items.json').write_text(json.dumps(public,indent=2,ensure_ascii=False)+'\n')
    print('generated',len(items),'gold items',len(key))
