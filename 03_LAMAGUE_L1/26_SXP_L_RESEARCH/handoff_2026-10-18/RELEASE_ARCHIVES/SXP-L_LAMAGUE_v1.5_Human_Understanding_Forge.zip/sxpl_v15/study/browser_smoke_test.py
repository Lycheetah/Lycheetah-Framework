"""Open the offline HTML in Chromium and click through all 33 trials.
Synthetic QA only, with fake responses. Output must never be analyzed as human.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path(__file__).with_name('SXP-L_HUMAN_STUDY_LAB_v1.5.html')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 context=browser.new_context(accept_downloads=True)
 page=context.new_page()
 errors=[]
 page.on('pageerror',lambda e: errors.append(str(e)))
 page.set_content(html.read_text(),wait_until='domcontentloaded')
 assert page.locator('#intro').is_visible()
 page.locator('#agree').check()
 page.locator('#arm').select_option('B')
 page.locator('#begin').click()
 assert page.locator('#lesson').is_visible()
 page.locator('#practiceStart').click()
 for _ in range(6):
  assert page.locator('#task').is_visible()
  page.locator('input[name=answer]').first.check()
  page.locator('#next').click()
  assert page.locator('#feedback').is_visible()
  page.locator('#next').click()
 for i in range(27):
  assert page.locator('#task').is_visible(),f'not in study at {i}'
  page.locator('input[name=answer]').first.check()
  page.locator('#confidence').select_option('3')
  page.locator('#next').click()
 assert page.locator('#complete').is_visible()
 with page.expect_download() as download_event: page.locator('#download').click()
 dl=download_event.value
 result=Path(__file__).with_name('SIMULATED_BROWSER_QA.csv')
 dl.save_as(result)
 import csv
 rows=list(csv.DictReader(result.open()))
 assert len(rows)==27 and all(r['arm']=='B' for r in rows)
 # Rename the tool-generated session to synthetic so the scorer *refuses* to treat it as a participant.
 for r in rows:r['session']='SIMULATED_BROWSER_QA'
 with result.open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 assert not errors,errors
 print('PASS: intro -> lesson -> six practices -> 27 scored -> anonymous CSV download')
 print('export rows:',len(rows),'script errors:',len(errors))
 page.screenshot(path=str(Path(__file__).with_name('BROWSER_QA_COMPLETE.png')),full_page=True)
 browser.close()
