
'use strict';
const ITEMS=JSON.parse(document.getElementById('itemsData').textContent);
const PRACTICE=JSON.parse(document.getElementById('practiceData').textContent);
const $=id=>document.getElementById(id);
const REGISTERS=['sxpl','english','json'];
let arm=0,phase='intro',order=[],idx=0,practiceIndex=0,records=[],startTime=0,responded=false;
let session='',seed=0,prng=()=>Math.random();
function show(id){for(const x of ['intro','lesson','task','complete'])$(x).classList.toggle('hidden',x!==id)}
function randomInt(){const a=new Uint32Array(1);if(window.crypto&&crypto.getRandomValues){crypto.getRandomValues(a);return a[0]>>>0}return Math.floor(Math.random()*4294967295)}
function makePrng(n){let state=n>>>0;return()=>{state+=0x6D2B79F5;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
function shuffle(xs,rng){for(let i=xs.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[xs[i],xs[j]]=[xs[j],xs[i]]}return xs}
function registerForScored(s){return REGISTERS[(Math.floor((Number(s.id.slice(1))-1)/9)+arm)%3]}
function safeText(id,s){$(id).textContent=s}
function render(){responded=false;const isP=phase==='practice',i=isP?PRACTICE[practiceIndex]:order[idx];
 const reg=isP?REGISTERS[practiceIndex%3]:registerForScored(i);safeText('stageLabel',isP?'UNSCORED PRACTICE':'SCORED STUDY');
 safeText('counter',isP?`${practiceIndex+1} / ${PRACTICE.length}`:`${idx+1} / ${ITEMS.length}`);
 $('bar').style.width=((isP?practiceIndex/PRACTICE.length:idx/ITEMS.length)*100)+'%';
 safeText('conditionHeader',reg==='sxpl'?'SXP-L':reg==='english'?'Controlled English':'Structured JSON');safeText('stimulus',i[reg]);safeText('question',i.question);
 $('feedback').classList.add('hidden');safeText('feedback','');const box=$('choices');box.replaceChildren();
 for(const opt of [...i.options,'Unsure']){const label=document.createElement('label');label.className='choice';const input=document.createElement('input');input.type='radio';input.name='answer';input.value=opt;input.addEventListener('change',()=>$('next').disabled=false);label.append(input,document.createTextNode(opt));box.appendChild(label)}
 $('confidence').value='';$('next').disabled=true;safeText('next',isP?'Check practice':'Submit answer');startTime=performance.now();}
function checked(){const e=document.querySelector('input[name="answer"]:checked');return e?e.value:null}
function withdraw(){records=[];order=[];phase='intro';idx=0;practiceIndex=0;session='';$('agree').checked=false;$('begin').disabled=true;show('intro')}
$('agree').addEventListener('change',()=>$('begin').disabled=!$('agree').checked);
$('begin').addEventListener('click',()=>{arm={A:0,B:1,C:2}[$('arm').value];if(!$('agree').checked)return;phase='lesson';show('lesson')});
$('practiceStart').addEventListener('click',()=>{phase='practice';practiceIndex=0;show('task');render()});
$('exitLesson').addEventListener('click',withdraw);$('withdraw').addEventListener('click',withdraw);$('erase').addEventListener('click',withdraw);
$('next').addEventListener('click',()=>{
 const selection=checked();if(!selection)return;
 if(phase==='practice'){
  if(!responded){const expected=PRACTICE[practiceIndex].gold;safeText('feedback',(selection===expected?'Correct. ':'Not quite. ')+'Reference answer: '+expected+'.');$('feedback').classList.remove('hidden');safeText('next',practiceIndex+1===PRACTICE.length?'Begin scored study':'Next practice');responded=true;return;}
  practiceIndex++;
  if(practiceIndex>=PRACTICE.length){phase='study';seed=randomInt();prng=makePrng(seed);order=shuffle(ITEMS.slice(),prng);session='SXPL-'+randomInt().toString(36).padStart(7,'0');idx=0;records=[];}else{render();return}
 }
 else if(phase==='study'){
  const item=order[idx],condition=registerForScored(item),duration=Math.max(0,Math.round(performance.now()-startTime));
  records.push({version:'1.5.0',session,arm:['A','B','C'][arm],seed,trial_index:idx+1,item_id:item.id,task:item.task,condition,difficulty:item.difficulty,response:selection,confidence:$('confidence').value,elapsed_ms:duration});idx++;
  if(idx===order.length){phase='complete';show('complete');return}
 } else return;
 render()
});
function csvCell(x){return '"'+String(x??'').replaceAll('"','""')+'"'}
$('download').addEventListener('click',()=>{
 if(phase!=='complete'||records.length!==ITEMS.length)return;
 const headers=['version','session','arm','seed','trial_index','item_id','task','condition','difficulty','response','confidence','elapsed_ms'];
 const csv=[headers.join(','),...records.map(r=>headers.map(h=>csvCell(r[h])).join(','))].join('\r\n')+'\r\n';
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`sxpl_v15_anonymous_${session}.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
 safeText('exportStatus','Download requested. You can close this tab and share the CSV with the study facilitator if you wish.');
});
