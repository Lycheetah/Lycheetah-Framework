"""SXP-L v1.5 fixture, assignment, historical and synthetic analysis checks."""
import csv,copy,json,sys,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from build_items import build,build_item
from analyze_responses import validated_sessions,summarize

class Study15Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.items=build()
    def test_total_type_balance(self):
        self.assertEqual(len(self.items),27)
        self.assertEqual({t:sum(x['task']==t for x in self.items) for t in ('holder','stance','reference')},dict(holder=9,stance=9,reference=9))
        self.assertEqual(len(set(x['id'] for x in self.items)),27)
    def test_independent_restricted_reader_agrees_on_gold(self):
        sys.path.insert(0,str(HERE.parent/'history'/'sxpl_v14'))
        from oracle14 import read
        from build_items import STANCE,REFERENCE
        for x in self.items:
            o=read(x['sxpl'])[0]
            if x['task']=='holder':comparison=o['local_mi'].title()
            elif x['task']=='stance':comparison=STANCE[o['frame_kinds'][-1]]
            else:comparison=REFERENCE[o['reference_status']]
            self.assertEqual(comparison,x['gold'],x['id'])

    def test_trial_option_gold(self):
        self.assertTrue(all(x['gold'] in x['options'] for x in self.items))
        self.assertTrue(all('mi liva ' in x['sxpl'] for x in self.items))
    def test_reference_outcomes_balanced(self):
        from collections import Counter
        self.assertEqual(set(Counter(x['gold'] for x in self.items if x['task']=='reference').values()),{3})
    def test_stance_balanced(self):
        from collections import Counter
        self.assertEqual(set(Counter(x['gold'] for x in self.items if x['task']=='stance').values()),{3})
    def test_conditions_and_depth_balanced_per_arm(self):
        regs=['sxpl','english','json']
        for arm in range(3):
            for task in ('holder','stance','reference'):
                for cond in regs:
                    matching=[x for j,x in enumerate(self.items) if x['task']==task and regs[((j//9)+arm)%3]==cond]
                    self.assertEqual(len(matching),3)
                    self.assertEqual(set(x['difficulty'] for x in matching),{1,2,3})
    def test_all_three_registers_present(self):
        self.assertTrue(all(x['sxpl'] and x['json'] and x['english'] for x in self.items))
    def test_answer_key_is_not_embedded_in_participant_html(self):
        page=(HERE/'SXP-L_HUMAN_STUDY_LAB_v1.5.html').read_text()
        self.assertNotIn('"gold":',page.split('<script id="itemsData"')[1].split('</script>')[0])
        self.assertNotIn('ANALYTICS',page)
    def test_practice_is_disjoint(self):
        ids={x['sxpl'] for x in self.items}
        from bs4 import BeautifulSoup
        doc=BeautifulSoup((HERE/'SXP-L_HUMAN_STUDY_LAB_v1.5.html').read_text(),'html.parser')
        practice=json.loads(doc.find('script',id='practiceData').text)
        self.assertEqual(len(practice),6)
        self.assertTrue(all(x['sxpl'] not in ids for x in practice))
    def test_synthetic_blocked_without_flag(self):
        with self.assertRaises(ValueError):validated_sessions([HERE/'SIMULATED_PIPELINE_ARM_A.csv'])
    def test_fixture_analysis(self):
        paths=[HERE/f'SIMULATED_PIPELINE_ARM_{arm}.csv' for arm in 'ABC']
        sessions=validated_sessions(paths,allow_synthetic=True)
        r=summarize(sessions)
        self.assertEqual(r['trials'],81)
        self.assertEqual(r['sessions'],3)
        self.assertEqual(set(r['by_condition']),{'sxpl','english','json'})
    def test_tampered_condition_rejected(self):
        path=HERE/'SIMULATED_PIPELINE_ARM_A.csv'
        with path.open(newline='') as f:rows=list(csv.DictReader(f))
        rows[0]['condition']='json' if rows[0]['condition']!='json' else 'sxpl'
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'tampered.csv'
            with p.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):validated_sessions([p],allow_synthetic=True)
    def test_duplicate_row_rejected(self):
        path=HERE/'SIMULATED_PIPELINE_ARM_A.csv'
        with path.open(newline='') as f:rows=list(csv.DictReader(f))
        rows[1]=copy.deepcopy(rows[0])
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'tampered.csv'
            with p.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):validated_sessions([p],allow_synthetic=True)
    def test_refuse_incomplete_response_file(self):
        path=HERE/'SIMULATED_PIPELINE_ARM_A.csv'
        with path.open(newline='') as f:rows=list(csv.DictReader(f))[:-1]
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'partial.csv'
            with p.open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            with self.assertRaises(ValueError):validated_sessions([p],allow_synthetic=True)
    def test_historical_expression_kept(self):
        from build_items import parse_transcript
        x=self.items[0]['sxpl']
        self.assertIn('mi liva ti devora',x)
        self.assertFalse(parse_transcript(x)['authorizes'])

if __name__=='__main__':unittest.main()
