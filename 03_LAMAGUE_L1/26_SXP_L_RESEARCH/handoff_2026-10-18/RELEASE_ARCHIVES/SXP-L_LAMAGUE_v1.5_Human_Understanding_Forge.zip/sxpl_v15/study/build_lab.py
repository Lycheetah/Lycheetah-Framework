"""Build one offline participant page. No network, persistent state, or participant keys."""
import json,html
from pathlib import Path
from build_items import build_item,build
root=Path(__file__).resolve().parent
scored=[{k:x[k] for k in ('id','task','difficulty','question','options','sxpl','english','json')} for x in build()]
practice=[]
seen={x['sxpl'] for x in build()};pertype={'holder':0,'stance':0,'reference':0}
for n in range(27,300):
    x=build_item(n)
    if x['sxpl'] in seen or pertype[x['task']]>=2:continue
    practice.append({k:x[k] for k in ('id','task','difficulty','question','options','gold','sxpl','english','json')})
    seen.add(x['sxpl']);pertype[x['task']]+=1
    if len(practice)==6:break
assert len(practice)==6

scored_json=json.dumps(scored,ensure_ascii=False).replace('<','\\u003c')
practice_json=json.dumps(practice,ensure_ascii=False).replace('<','\\u003c')
page=r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>SXP-L v1.5 | Human Understanding Forge</title>
<style>
:root{color-scheme:dark;--bg:#0b1018;--panel:#151f2a;--panel2:#1a2b35;--line:#30444c;--text:#eff6f7;--muted:#abc3ca;--mint:#74dbba;--blue:#91b3ff;--amber:#e9bd7f}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 70% -10%,#193640 0,transparent 45%),var(--bg);color:var(--text);font:16px/1.6 system-ui,-apple-system,Segoe UI,sans-serif}
main{max-width:900px;margin:auto;padding:32px 20px 80px}.eyebrow{color:var(--mint);font-size:.8rem;text-transform:uppercase;letter-spacing:.18em;font-weight:700}
h1{line-height:1.15;font-size:clamp(2rem,6vw,3.2rem);margin:12px 0 8px}h2{font-size:1.4rem;margin:0 0 16px}h3{font-size:1.05rem;color:var(--mint)}p{color:var(--muted)}
.panel{background:var(--panel);border:1px solid var(--line);padding:26px;border-radius:16px;margin:24px 0}.notice{border-left:3px solid var(--amber);padding:12px 16px;background:#2a271f;color:#f6e7ce;margin:16px 0}.subtle{color:var(--muted);font-size:.89rem}
pre{white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid var(--line);background:#0b161d;color:#e4f4f4;border-radius:12px;padding:18px;line-height:1.65;font-size:.92rem;max-height:440px;overflow:auto}
button,.buttonlike{font:inherit;cursor:pointer;border-radius:10px;border:1px solid var(--mint);background:var(--mint);color:#07221c;padding:10px 18px;font-weight:750}button.secondary{background:transparent;color:var(--text);border-color:var(--line)}button:disabled{opacity:.4;cursor:not-allowed}button:focus-visible,select:focus-visible,input:focus-visible{outline:3px solid var(--blue);outline-offset:3px}
select{background:#111f27;border:1px solid var(--line);color:white;border-radius:8px;padding:12px;font:inherit}label{cursor:pointer}.options{display:grid;gap:10px;margin:18px 0}.choice{display:block;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:#152530}.choice:has(input:checked){border-color:var(--mint);background:#1e3d3f}.choice input{margin-right:8px}
.row{display:flex;flex-wrap:wrap;gap:12px;align-items:center}.spaced{justify-content:space-between}.progress{height:8px;background:var(--line);border-radius:10px;overflow:hidden}.progress div{height:100%;background:var(--mint)}
.inlinecode{font-family:ui-monospace,monospace;color:#e5f5f4;background:#23323a;border-radius:5px;padding:2px 5px}.mini{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px}.mini article{background:var(--panel2);border-radius:10px;padding:12px}.mini strong{color:var(--mint)}
footer{color:var(--muted);margin-top:60px;font-size:.85rem}details{margin:12px 0;border:1px solid var(--line);padding:12px;border-radius:10px}summary{cursor:pointer;font-weight:600}.hidden{display:none!important}
</style></head><body><main>
<div class="eyebrow">Lycheetah / SXP-L × LAMAGUE / Research v1.5</div>
<h1>The Human Understanding Forge</h1>
<p>Can a newly learned constructed language preserve viewpoint and uncertainty as intelligibly as controlled English or structured JSON?</p>
<div id="intro" class="panel">
<h2>Independent comprehension pilot</h2>
<p>This is an <strong>experimental offline prototype</strong>, not a validated psychometric test. You will see a short tutorial, six unscored practice items, and 27 scored questions. Approximately 15–30 minutes depending on reading speed.</p>
<div class="notice">For adult volunteers (18+). Participation is optional. Do not enter a real name, contact details, or sensitive information. Nothing is transmitted. Answers stay in this browser tab until you explicitly export a CSV. Closing the tab loses the data. Withdraw any time without exporting.</div>
<label for="arm">Assignment supplied by the facilitator:</label>
<select id="arm"><option value="A">Arm A</option><option value="B">Arm B</option><option value="C">Arm C</option></select>
<p class="subtle">For comparisons, the facilitator should allocate successive volunteers A, B, C in rotation. The three conditions are balanced within each arm for task and difficulty. Participants should not choose based on preference.</p>
<p><label><input id="agree" type="checkbox"> I am 18 or older, understand the study, and voluntarily agree to participate.</label></p>
<div class="row"><button id="begin" disabled>Read training</button></div>
</div>
<div id="lesson" class="panel hidden">
<h2>The three equivalent reading formats</h2>
<p>All trials describe <strong>someone's report</strong>. A reported belief or uncertainty is not automatically a fact, and no transcript grants permission to act.</p>
<div class="mini">
<article><strong>SXP-L vocabulary</strong><div><span class="inlinecode">norava</span> declares a person</div><div><span class="inlinecode">gonape X dimotu</span> names X</div><div><span class="inlinecode">taviro</span> begins a turn</div><div><span class="inlinecode">tevaro</span> ends a turn</div><div><span class="inlinecode">devora</span> ends a sentence</div></article>
<article><strong>Perspective operators</strong><div><span class="inlinecode">naveriko</span> reportedly conveyed</div><div><span class="inlinecode">belareko</span> attributed belief</div><div><span class="inlinecode">nesaluko</span> not knowing whether</div><div>Each operator names a <em>holder</em> and local <em>addressee</em>.</div></article>
<article><strong>Reference and care</strong><div><span class="inlinecode">mi</span> local first person (I)</div><div><span class="inlinecode">ti</span> local second person (you)</div><div><span class="inlinecode">liva</span> love</div><div><span class="inlinecode">sivena</span> a third person</div><div><span class="inlinecode">rasufe</span> explicit third-person anchor</div></article>
</div>
<p><strong>Scope rule:</strong> the <em>last</em> perspective operator names who “mi” and “ti” refer to in the final clause. If no operator appears, use the outer speaker and addressee. For <em>sivena</em>, exclude the local speaker and addressee. With one remaining named candidate it is uniquely inferred; with multiple candidates it remains ambiguous unless <em>rasufe</em> names the person.</p>
<p>In controlled English, read the perspective lines in order. In JSON, read the <span class="inlinecode">perspective_frames</span> array in order and use its last element. English, JSON and SXP-L show the same invented scenario.</p>
<details><summary>Example: a nested belief (all three formats)</summary><p><strong>Answer:</strong> Sela is local “I”, and the innermost perspective is belief.</p>
<pre>norava gonape maka dimotu
norava gonape nara dimotu
norava gonape sela dimotu
norava gonape vera dimotu
taviro gonape maka dimotu gonape nara dimotu
naveriko gonape nara dimotu gonape maka dimotu
belareko gonape sela dimotu gonape vera dimotu
mi liva ti devora
tevaro</pre>
<p>Controlled English: Maka to Nara. Nara reportedly conveyed something to Maka. Within it, Sela is attributed a belief, addressed locally to Vera. Final clause: “I love you.”</p>
<pre>{"outer_turn":{"speaker":"maka","addressee":"nara"},"perspective_frames":[{"kind":"reported_speech","holder":"nara","local_addressee":"maka"},{"kind":"belief","holder":"sela","local_addressee":"vera"}],"final_clause":{"subject":"mi","predicate":"liva","object":"ti"}}</pre>
</details>
<p class="subtle">Practice has immediate feedback. The 27 scored questions give no correctness feedback. “Unsure” is a valid response. Reading time is measured by the browser and is approximate.</p>
<div class="row"><button id="practiceStart">Start unscored practice</button><button class="secondary" id="exitLesson">Withdraw</button></div>
</div>
<div id="task" class="panel hidden">
<div class="row spaced"><div id="stageLabel" class="eyebrow">Practice</div><span class="subtle" id="counter"></span></div>
<div class="progress"><div id="bar" style="width:0"></div></div>
<h2 id="conditionHeader" style="margin-top:20px"></h2>
<pre id="stimulus"></pre><p id="question" style="font-weight:650;color:var(--text)"></p>
<fieldset style="border:0;padding:0"><legend class="subtle">Choose your interpretation</legend><div class="options" id="choices"></div></fieldset>
<label for="confidence">Confidence (optional): </label><select id="confidence"><option value="">Not stated</option><option value="1">1 – guessing</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5 – certain</option></select>
<div id="feedback" class="notice hidden" role="status"></div>
<div class="row" style="margin-top:20px"><button id="next" disabled>Submit answer</button><button class="secondary" id="withdraw">Withdraw and erase responses</button></div>
</div>
<div id="complete" class="panel hidden">
<h2>Study complete</h2>
<p>Your answers have not been sent anywhere. Export the CSV if you choose to share it with the facilitator. A separate organizer-only answer key is used for analysis; you will not see scored feedback here.</p>
<div class="row"><button id="download">Export anonymous CSV</button><button id="erase" class="secondary">Erase without exporting</button></div>
<p id="exportStatus" class="subtle">No file has been downloaded yet.</p>
</div>
<footer>Experimental SXP-L v1.5 · no cookies · no network requests · no persistent storage · no live permissions · “mi liva ti” remains unchanged.</footer>
</main>
<script id="itemsData" type="application/json">__SCORED__</script>
<script id="practiceData" type="application/json">__PRACTICE__</script>
<script>
'use strict';
const ITEMS=JSON.parse(document.getElementById('itemsData').textContent);
const PRACTICE=JSON.parse(document.getElementById('practiceData').textContent);
const $=id=>document.getElementById(id);
const REGISTERS=['sxpl','english','json'];
let arm=0,phase='intro',order=[],idx=0,practiceIndex=0,records=[],startTime=0,responded=false;
let session='',seed=0,prng=()=>Math.random();
function show(id){for(const x of ['intro','lesson','task','complete'])$(x).classList.toggle('hidden',x!==id)}
function randomInt(){const a=new Uint32Array(1);if(window.crypto&&crypto.getRandomValues){crypto.getRandomValues(a);return a[0]>>>0}return Math.floor(Math.random()*4294967295)}
function makePrng(n){let state=n>>>0;return()=>{state+=0x6D2B79F5;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
function shuffle(xs,rng){for(let i=xs.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[xs[i],xs[j]]=[xs[j],xs[i]]}return xs}
function registerForScored(s){return REGISTERS[(Math.floor((Number(s.id.slice(1))-1)/9)+arm)%3]}
function safeText(id,s){$(id).textContent=s}
function render(){responded=false;const isP=phase==='practice',i=isP?PRACTICE[practiceIndex]:order[idx];
 const reg=isP?REGISTERS[practiceIndex%3]:registerForScored(i);safeText('stageLabel',isP?'UNSCORED PRACTICE':'SCORED STUDY');
 safeText('counter',isP?`${practiceIndex+1} / ${PRACTICE.length}`:`${idx+1} / ${ITEMS.length}`);
 $('bar').style.width=((isP?practiceIndex/PRACTICE.length:idx/ITEMS.length)*100)+'%';
 safeText('conditionHeader',reg==='sxpl'?'SXP-L':reg==='english'?'Controlled English':'Structured JSON');safeText('stimulus',i[reg]);safeText('question',i.question);
 $('feedback').classList.add('hidden');safeText('feedback','');const box=$('choices');box.replaceChildren();
 for(const opt of [...i.options,'Unsure']){const label=document.createElement('label');label.className='choice';const input=document.createElement('input');input.type='radio';input.name='answer';input.value=opt;input.addEventListener('change',()=>$('next').disabled=false);label.append(input,document.createTextNode(opt));box.appendChild(label)}
 $('confidence').value='';$('next').disabled=true;safeText('next',isP?'Check practice':'Submit answer');startTime=performance.now();}
function checked(){const e=document.querySelector('input[name="answer"]:checked');return e?e.value:null}
function withdraw(){records=[];order=[];phase='intro';idx=0;practiceIndex=0;session='';$('agree').checked=false;$('begin').disabled=true;show('intro')}
$('agree').addEventListener('change',()=>$('begin').disabled=!$('agree').checked);
$('begin').addEventListener('click',()=>{arm={A:0,B:1,C:2}[$('arm').value];if(!$('agree').checked)return;phase='lesson';show('lesson')});
$('practiceStart').addEventListener('click',()=>{phase='practice';practiceIndex=0;show('task');render()});
$('exitLesson').addEventListener('click',withdraw);$('withdraw').addEventListener('click',withdraw);$('erase').addEventListener('click',withdraw);
$('next').addEventListener('click',()=>{
 const selection=checked();if(!selection)return;
 if(phase==='practice'){
  if(!responded){const expected=PRACTICE[practiceIndex].gold;safeText('feedback',(selection===expected?'Correct. ':'Not quite. ')+'Reference answer: '+expected+'.');$('feedback').classList.remove('hidden');safeText('next',practiceIndex+1===PRACTICE.length?'Begin scored study':'Next practice');responded=true;return;}
  practiceIndex++;
  if(practiceIndex>=PRACTICE.length){phase='study';seed=randomInt();prng=makePrng(seed);order=shuffle(ITEMS.slice(),prng);session='SXPL-'+randomInt().toString(36).padStart(7,'0');idx=0;records=[];}else{render();return}
 }
 else if(phase==='study'){
  const item=order[idx],condition=registerForScored(item),duration=Math.max(0,Math.round(performance.now()-startTime));
  records.push({version:'1.5.0',session,arm:['A','B','C'][arm],seed,trial_index:idx+1,item_id:item.id,task:item.task,condition,difficulty:item.difficulty,response:selection,confidence:$('confidence').value,elapsed_ms:duration});idx++;
  if(idx===order.length){phase='complete';show('complete');return}
 } else return;
 render()
});
function csvCell(x){return '"'+String(x??'').replaceAll('"','""')+'"'}
$('download').addEventListener('click',()=>{
 if(phase!=='complete'||records.length!==ITEMS.length)return;
 const headers=['version','session','arm','seed','trial_index','item_id','task','condition','difficulty','response','confidence','elapsed_ms'];
 const csv=[headers.join(','),...records.map(r=>headers.map(h=>csvCell(r[h])).join(','))].join('\r\n')+'\r\n';
 const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`sxpl_v15_anonymous_${session}.csv`;document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
 safeText('exportStatus','Download requested. You can close this tab and share the CSV with the study facilitator if you wish.');
});
</script></body></html>'''
page=page.replace('__SCORED__',scored_json).replace('__PRACTICE__',practice_json)
(root/'SXP-L_HUMAN_STUDY_LAB_v1.5.html').write_text(page,encoding='utf8')
print('HTML bytes',len(page.encode('utf8')))
