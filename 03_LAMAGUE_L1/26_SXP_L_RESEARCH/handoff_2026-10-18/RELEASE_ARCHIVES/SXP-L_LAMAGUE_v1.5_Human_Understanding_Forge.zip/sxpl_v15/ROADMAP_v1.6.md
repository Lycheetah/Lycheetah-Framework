# v1.6 candidate: Generalization and natural conversation

This is a **proposal**, not an implemented feature.

If the v1.5 pilot reveals that independent people can actually learn the controlled scope rules, the strongest next experiment is not arbitrary vocabulary expansion but **transfer**:

- unfamiliar predicates and everyday scenarios unrelated to `mi liva ti`;
- varied clause lengths and held-out proper names;
- two-to-four-turn context tasks with quote and perspective scope;
- optional audio-based phoneme listening only after vetted native pronunciation recordings and accessible alternatives;
- ambiguity detection where the correct response is *unresolved*;
- case-based comparison against a well-engineered existing controlled language and modern agent protocol, not a deliberately weak baseline.

Advance only after a critical audit; keep the human-learnability track separate from executable authorization (which remains host-controlled).
