# Study protocol — v1.5 pilot (NOT YET RUN)

## Primary purpose

Check that the instruments, lessons, choices, and scoring workflow are understandable to **independent adult volunteers**. The proposed metric is exact multiple-choice comprehension of 27 controlled propositions after a shared tutorial.

## Hypotheses to test rather than assert

H1 (descriptive): a beginner can distinguish the holder of `mi`, the immediate reported stance, and whether `sivena` is uniquely identified after a short explanation. H2 (comparative, exploratory): accuracy/effort differs between SXP-L, controlled English, and JSON when item semantics are matched. No direction or superiority is assumed.

## Participant-facing process

1. Seek appropriate research/ethics review for your context, particularly if results may be publicly described as research. Obtain informed adult consent; recruitment must not be coercive.
2. Give the participant **only** the standalone HTML, never the source ZIP, gold key or analyst report.
3. Assign consecutive volunteers A, B, C in rotation. Record assignment count *without* names. Avoid recruiting only SXP-L enthusiasts if general learners are the eventual target.
4. Let participants read shared instruction, complete 6 feedback-based practice items, then 27 randomized scored items; do not coach after scored items begin.
5. Allow “Unsure”. The browser logs a chosen answer, optional confidence 1–5, and approximate elapsed time for each scored item.
6. No data is uploaded. They choose whether to export their anonymous CSV and optionally give it to the facilitator. Closing/withdrawing erases the in-memory session without upload.
7. Use the separate answer key and `analyze_responses.py` to validate allocation and score exported complete files. Reject duplicates/tampering and clearly mark any exclusion.

## Outcomes and reporting

**Primary descriptive outcomes:** per-person exact accuracy by condition, and task-specific counts (holder, stance, reference). Analyze paired participant-level differences only; item-level observations are not independent participants. Do not claim speed advantage based on noisy browser timing alone. Report withdrawal, incomplete files, device differences, prior exposure, and participant source when known from consented, separately managed administrative records—not from secret tracking.

The scorer offers participant-level bootstrap intervals only when n ≥ 5, but that *technical threshold is not a scientifically justified sample size*. For an initial usability pilot, a small convenience sample can expose instruction flaws, not establish superiority. For confirmatory claims: specify hypotheses, target population, randomization, effect size, exclusion policy, sample-size/power rationale, and analysis plan *before collecting data*. A statistician or study-methods reviewer should inspect these materials first.

## Fairness and non-independence risks

- SXP-L is novel whereas English is likely familiar and JSON familiarity varies. Format differences may reflect prior experience, not an intrinsic property.
- English has conventional paraphrase while JSON has literal typed structure. These are different reading tasks.
- Items reuse one predicate (`liva`); not a general language exam.
- Even balanced register assignments do not control prior knowledge, reading ability or demand effects.
- Source code includes an organizer key elsewhere in the ZIP. Independent participants must not see it. A public GitHub release containing the key compromises future blind testing unless new private holdout items are generated.
- Participants might know the co-creators and want the language to succeed. Label that limitation.
- Browser timing reflects display, deliberation, pauses, and input mechanics; it is not a direct measure of semantic processing.

## Privacy

No personal identifiers, typed free text, cookies, client storage, network requests, microphone, camera, or remote analytics are used by the offline lab. Random session IDs are ephemeral, and can be exported only at participant discretion. An exported CSV could still be linked to someone if the recipient retains outside knowledge—store it responsibly and delete on request where feasible.

**Current result:** no human participant was recruited, administered the study, or scored. Synthetic fixtures and browser automation are only engineering QA.
