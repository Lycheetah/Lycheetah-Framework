# SXP-L × LAMAGUE v1.5 — Human Understanding Forge

**Date:** 18 October 2026  
**Maturity:** Research instrument / offline pilot, not completed human research or a validated language-learning assessment.

The v1.4 Nested Perspectives language and every historical file are **preserved unchanged** under `history/sxpl_v14/` (151 files from the v1.4 release archive). The phrase **`mi liva ti`** remains unchanged. No lexicon, grammar or parser semantics were altered in this v1.5 release.

## A change in what we measure

Versions 0.1–1.4 mainly tested *structural* properties: round-trip parsing, attribution scopes, ambiguous references, quoted permissions, and compatibility. v1.5 creates the machinery for a **human** test of those distinctions. It does **not** report such a test as completed.

- Three format conditions: `sxpl`, `english`, `json`.
- 27 separate **scored** concepts, one presentation per participant (9 concepts per condition).
- 9 each of: leaf first-person holder, innermost frame kind, third-person reference status.
- Each format gets 3 instances of each question type at nesting depths 1, 2, 3 for each assignment arm.
- Three arms A/B/C rotate which concept appears in which format across people.
- Six unscored, disjoint practice items with immediate feedback.
- On-device trial-time and confidence capture; free "Unsure" response.
- No identity collection, cookies, network requests, external effects or autosaved state.
- CSV participant export + separate, organizer-only answer key + standard-library Python scorer.

## What to open

For volunteers, distribute **only** `study/SXP-L_HUMAN_STUDY_LAB_v1.5.html` (standalone HTML). **Never distribute the full researcher ZIP before study completion**: it includes the answer key and synthetic fixtures.

For the organizer:

```bash
python study/build_items.py
python study/build_lab.py
python -m unittest discover -s study -p 'test_study15.py' -v
python study/analyze_responses.py participant_01.csv participant_02.csv --out summary.json
```

Assign volunteer one of A/B/C in rotation. The browser includes consent information and permits withdrawal by erasing in-memory responses. It does not upload records anywhere. The organizer alone decides whether to collect exported CSVs, with informed consent and appropriate local research safeguards.

### Synthetic end-to-end checks

The bundled `SIMULATED_*.csv` files are **not participant results** and are explicitly rejected by the scorer unless `--allow-synthetic` is provided. The browser-clicked QA fixture is also renamed `SIMULATED_BROWSER_QA`.

```bash
python study/analyze_responses.py --allow-synthetic study/SIMULATED_PIPELINE_ARM_*.csv
python study/browser_smoke_test.py  # requires Playwright + Chromium for QA; optional
```

All implementation code for the study except QA browser automation uses the Python standard library. The HTML lab needs only a modern browser. No Python is required for a participant.

## Claims this release does *not* make

- That people comprehend, remember, or prefer SXP-L better than English, JSON, Lojban, or any other language.
- That grammatical reversibility means shared understanding of the speaker's intent.
- That local machine fixtures constitute an independent human study.
- That a browser-based time measurement proves cognitive efficiency.
- That this is a complete spoken language or production authorization system.

Read `STUDY_PROTOCOL_v1.5.md`, `EVIDENCE_REPORT_v1.5.md`, and `ARGON_AUDIT_BRIEF_v1.5.md` before running a study or publishing quantitative claims.
