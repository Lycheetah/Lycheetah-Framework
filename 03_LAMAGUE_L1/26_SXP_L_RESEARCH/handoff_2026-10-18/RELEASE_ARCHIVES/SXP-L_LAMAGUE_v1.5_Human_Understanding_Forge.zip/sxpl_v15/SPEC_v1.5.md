# SXP-L × LAMAGUE v1.5 — Evaluation-layer specification

**Version:** 1.5.0. **Scope:** Evaluation of the *existing v1.4 grammar*, not a language grammar revision.

## Preservation

`mi liva ti` = **I love you**. No `jiva` replacement or alias. The v1.4 interpretation of `naveriko`, `belareko`, `nesaluko`, `rasufe`, `sivena`, `mi`, `ti`, and all other terminals remains identical. This version introduces no new SXP-L word.

## Comprehension task ontology

Each item is a valid single-turn v1.4 transcript with 3–5 named people and a chain of 1–3 nested perspective frames. Exactly three item families exist:

- **Holder:** identify the bound `mi`/“I” of the final clause. The last frame, not the outer reporter, determines it.
- **Stance:** identify the last frame as reported speech, belief, or not knowing whether. An attribution remains speaker-supplied and unverified.
- **Reference:** determine if `sivena` is explicitly anchored (`rasufe`), uniquely eligible, or ambiguous. Ambiguity must not be silently resolved.

The base proposition is a controlled *love* clause (`mi liva ti devora` or `mi liva sivena devora`), chosen intentionally to prevent verb-vocabulary variation from masking the scope issue. **It also limits generalization to other propositions.**

## Three matched written registers

The `sxpl` register is exactly the transcript parsed and re-rendered by `perspective14.py`. The `english` register renders equivalent participant, frame, anchor, and clause information in deliberately explicit English; it is not unrestricted natural English. The `json` register encodes the same declarations and frame chain as structured fields. None of the registers authenticates claims or confers authority.

The answer key is computed from parsed v1.4 semantic fields (`leaf_roles`, `frames[-1].kind`, `reference.status`) by `build_items.py`. Test variants do not modify the underlying scenario. The same item should be presented in *only one register* to a given person.

## Counterbalancing

There are 27 scenarios `S01`...`S27`: 9 task cycles × 3 questions. Let `i` be the zero-based item number, `a ∈ {0,1,2}` the assigned arm, and register labels `[sxpl, english, json]`. Assign:

```text
register = labels[(floor(i/9) + a) mod 3]
```

This creates 9 trials per register, each with three holder, three stance, and three reference items, spanning each 1–3 frame nesting depth. Across all three arms, the same scenario is seen once in each format (between different people). Within a person, item order is seeded-shuffled and response time is measured between item display and submission.

**Caveats:** conventional English familiarity, instruction demand, invented proper names, word-count differences, and the experimental glossary introduce confounds. An equitable match of *information* is not a match of language familiarity, reading time, or token count.

## Interpretation of the experiment

The experiment asks a narrow, verifiable question: given a brief glossary and training, can a reader determine these 3 specified semantic properties, and how does their *within-person pilot performance* vary by rendering? It cannot adjudicate spontaneous spoken fluency, full-language learnability, emotional expressiveness, real AI comprehension, or impact on agent safety.
