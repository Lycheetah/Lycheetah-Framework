# ARGON — Independent challenge brief for SXP-L v1.5

The SXP-L human comprehension study instrument is now executable, but **no real human results exist**. Test it adversarially:

1. Verify all 151 historical v1.4 archive members are byte-identical under `history/sxpl_v14/`; inspect the checksum manifest.
2. Regenerate every stimulus using `study/build_items.py`, independently parse its `sxpl` text with a separate parser or manual inspection, and verify `english`/`json` express exactly the same case.
3. Analyze how explicit English phrasing and JSON structure may leak the answer more readily than SXP-L, and whether use of a single love predicate makes the item bank too narrow.
4. Verify format allocation for A/B/C gives identical scenario coverage between cohorts, and within each participant balances question type, depth, and reference-status difficulty.
5. Try to corrupt CSV condition/task labels, insert duplicate items, forge session IDs, or include a synthetic fixture without `--allow-synthetic`. Distinguish functional validation from authenticity; no signed participant records exist.
6. Challenge the 6 practice examples for accidental reuse, answer leakage, or confounding due to uneven exposure.
7. Audit privacy and browser behavior offline. Test back/refresh, refusal/withdrawal, response times, export, and accessibility. A recent Chromium `set_content` end-to-end run passed, but real file-opening behavior is environment-dependent.
8. Propose unbiased participant instructions, ethical recruitment requirements, pilot acceptance criteria, independent holdout items, and a properly powered follow-on study.
9. Assess whether we should add a new non-`liva` predicate cohort to investigate generalization, without changing historical grammar.
10. Challenge the broader claim: demonstrate precisely which human–AI capability (if any) improves over conventional formats *after* real results are available.

Please do not describe synthetic numbers as human comprehension, infer statistical significance from three fake subjects, or claim acoustic or deployable agent-security benefits.
