# SXP-L × LAMAGUE complete historical release bundle

Release bundles v0.2–v1.0, plus the v0.1 draft where present.
These are historical research snapshots, not independently validated or production-ready systems.
Extract the individual version ZIPs to inspect source, tests and documentation.
Review all contents for suitability before publishing publicly to GitHub.

## SHA-256 checksums

- `v0.1/SXP-L_LAMAGUE_Language_Construction_v0.1.md` — `7b9d22a55e33f33b3763bd94db028f3f6b7358a49a470a2193c5e91d3ce6caae`
- `releases/SXP-L_LAMAGUE_v0.2_Research_And_Executable_Kernel.zip` — `a6ce8c43fa8ebb9d86918c5f2ef27c326ac0cc41935c9f41d21fb2d3a46af699`
- `releases/SXP-L_LAMAGUE_v0.3_Human_Expression_Kernel.zip` — `e9ed28403187b2c46c7e07039abb0d4187d317d18dc0706a5020cf44a20ee228`
- `releases/SXP-L_LAMAGUE_v0.4_Controlled_Human_Register.zip` — `9e570de974bf746239e9c0d6be73438a32537848ff6e78472ad76918066a8b39`
- `releases/SXP-L_LAMAGUE_v0.5_Dialogue_Roots_Research.zip` — `02bfb1aa78f0dd23158282336e32de61d4560346a384dcd155b80e506958319b`
- `releases/SXP-L_LAMAGUE_v0.6_Compact_Conversation_Lab.zip` — `cb945f959998984f82a3e54ae8bd8a04258ae844d5b8c707aa178b516655a077`
- `releases/SXP-L_LAMAGUE_v0.7_Sound_Forge.zip` — `3bb58259d54a538cf39ee76d05dfaf630374c7c2317f2bf33552596d01c479be`
- `releases/SXP-L_LAMAGUE_v0.8_Pragmatics_Forge.zip` — `4520278ac9b00b20e6d95ad536a5d70834849e9524215df6ca8acda252a9b363`
- `releases/SXP-L_LAMAGUE_v0.9_Consent_Authority_Scope_Forge.zip` — `39424519565102b213d13de85906b0e64188ae74ab029424df0bbf7179a294ea`
- `releases/SXP-L_LAMAGUE_v1.0_Sovereignty_Forge.zip` — `0c4cdf6a5cdb50b9e9af4ee35faa0c1852be016275ed3c478420737b11d746d4`
