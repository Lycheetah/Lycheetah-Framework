# SXP-L v0.6 — Test Evidence Report

**Run:** local deterministic test suite on 17 October 2026. All claims are limited to this artifact.

- Command: `python -m unittest test_compact test_dialogue test_surface test_v03 -v`.
- Result: **23 test methods passed**; no external deployment or usability testing.
- Nested-v0.6 generator: **2,400 cases**, PRNG seed 60617.
- Retained v0.5 dialogue generator: **1,500 cases**, PRNG seed 20261017.
- Retained v0.4 generator: **3,000 nested cases** (plus other inherited tests).
- Parser round trips establish equality of *supported ASTs only*. The generated cases are not independent observations of language users.

## Surface length comparison

Measured using the repository's own lexical tokenizers (`compact.lex` and `sxpl_v03.tokens`), **not** any LLM tokenizer and not spoken syllables. Six hand-picked, semantically identical sentence pairs, each encoded once in the compact register and once in the earlier v0.5 full root register. This is a convenience sample, not a representative corpus.

| Compact example | v0.6 lexical tokens | v0.5 full-register tokens | Reduction |
|---|---:|---:|---:|
| `mi liva ti.` | 4 | 11 | 63.6% |
| `mi fela loma @nara.` | 5 | 14 | 64.3% |
| `mi hira ( fura mi rava @nara ).` | 9 | 22 | 59.1% |
| `mi noka kena ( @nara luma mi ).` | 9 | 23 | 60.9% |
| `mi fera ( mi diva ti lo "our future" ).` | 10 | 25 | 60.0% |
| `qira ti kena ( @nara luma ti )?` | 9 | 22 | 59.1% |

**Aggregate across these six examples:** 46 vs 117 tokens, a 60.7% reduction by this internal counting method. This is **not** evidence of lower API cost, faster comprehension, or improved reasoning.

## Negative results / intended limits

- Unregistered roots, missing `@`, malformed punctuation, unmatched parentheses, unknown emotions, extra trailing text, and deep recursion are rejected.
- Valid full-register clauses with unsupported compact roles are preserved in full form instead of stripped.
- Quotes stay typed quoted content; names matching registered roots remain names when prefixed with `@`.
- Speaker reference resolution is delegated to the v0.5 parser, which rejects unbound pronouns.
- For example, `mi noka kena ( @nara luma mi ).` differs from `mi noka kena ( @nara noka luma mi ).`; the nested clause polarity is explicitly different.

## Unverified claims

No human fluency study, phonetic test, model benchmark, external code audit, or live agent deployment was performed. See `EVAL_PROTOCOL.md`.
