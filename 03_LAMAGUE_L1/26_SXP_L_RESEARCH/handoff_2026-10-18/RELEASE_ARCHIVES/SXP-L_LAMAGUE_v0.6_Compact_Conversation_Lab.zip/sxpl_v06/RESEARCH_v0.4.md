# SXP-L × LAMAGUE — v0.4 Controlled Human Register
17 October 2026 · Research prototype · Not an interoperable standard

## Design commitment
**Meaning should survive the journey between minds; when it does not, the loss should be visible.**

A semantic machine core and a human-pronounceable surface need **a reversible mapping** before broader free-form interpretation is attempted. This release establishes a deliberately controlled pronunciation-oriented register, NOT a complete language spoken naturally, NOT automatic translation from English, and NOT validated improvement in AI reasoning.

## Relationship to prior work
- v0.1: proposed language foundations (bundled unchanged).
- v0.2: flat typed-clause interpreter (bundled as `sxpl_v02.py`).
- v0.3: recursively nested claims, feelings, relationships, views (bundled as `sxpl_v03.py`).
- v0.4: separate human register encoder/decoder; preserves v0.3 AST and canonical wire grammar.
- Native-36 remains original operation namespace; this release does not redefine its semantics.

## Syntax
The human register is a token-mapped grammar. Every control token has a pronounceable form; every free lexical item begins with the content marker `nami` to avoid collisions between user names and grammar words. Quoted strings remain literals and are **not translated**.

| Canonical | Human register | Purpose |
|---|---|---|
| sa | sava | assertion |
| qu | qira | question |
| di | dira | directive (not executable permission) |
| no | noka | negation |
| ma | mira | possibility |
| mu | mura | obligation (claimed; not authority) |
| pa / nu / fu | pana / nura / fura | past / present / future |
| ka | ami | actor |
| ta | tavi | target |
| lo | lori | context |
| se | seni | source |
| au | auni | stated authorizer |
| sc | sori | scope |
| co | cori | reported confidence |
| fe | feli | feeling |
| re | reli | relationship |
| vi | viri | viewpoint |
| pr | pari | nested proposition |
| [ / ] | nesti / nesta | proposition boundaries |
| en | ena | clause terminator |
| xi | xira | unknown |
| content | nami content | quoted or unquoted atomic value |

`nami` is the sole newly introduced meta-token of v0.4; it encodes, rather than translates, arbitrary lexemes. The surface intentionally remains explicit and repetitive.

## Examples
Canonical:
```
sa nu feel ka self fe longing ta person_2 en
```
Pronounceable register:
```
sava nura nami feel ami nami self feli nami longing tavi nami person_2 ena
```

Canonical uncertainty about another person's understanding:
```
sa no nu know ka self pr [ sa nu understand ka person_2 ta self en ] en
```
Surface:
```
sava noka nura nami know ami nami self pari nesti sava nura nami understand ami nami person_2 tavi nami self ena nesta ena
```

This is distinct from knowing the other person **does not** understand:
```
sa nu know ka self pr [ sa no nu understand ka person_2 ta self en ] en
```
The different scope of negation is faithfully preserved by round-trip parsing.

## Formal reversible subset
For any canonical v0.3 text `x` accepted by its parser:

`parse_v03(hear(speak(x))) == parse_v03(x)`

This guarantees AST equivalence for the tested and supported sublanguage, not human comprehension or equivalence to natural-language meaning.

## Tests, local only
- 5 groups: hand-selected, 3,000 generated nested clauses, malformed register rejects, lexical collision regression, negation-scope distinction.
- 3,000 deterministic pseudo-random generated clauses passed round-trip checks.
- v0.3 prior regression suite run separately. A repeated generated template is not a representative language dataset.

## Explicit nonclaims
No original semantics for words `feel`, `believe`, etc. are scientifically demonstrated. Inference, consent, co-reference across turns, prosody, unrestricted human vocabulary, ambiguity negotiation, multi-sentence discourse, social pragmatics, and translation from English remain open.

## Priority v0.5 experiments
1. **Dialogue and co-reference:** speaker/participant identifiers and turn-scoped contexts.
2. **Coordination:** and/but/because, wanting vs planning vs doing, intensifiers and comparisons.
3. **Evidence models:** typed distinction among first-hand report, inference and externally verified source.
4. **Human phonology:** syllable inventory, stress, pronunciation guide, audio testing with learners; decide how quoted atoms become pronounceable.
5. **Measured comparator:** controlled English and JSON-schema frames on a blinded suite of negation scope, nested uncertainty, pronouns, temporal intent; measure accuracy and time-to-learn, not just string round-trips.
6. **Integrity:** avoid treating grammar tokens like `auni` as actual authorization. Parser output never executes actions.

## Protocol note
The surface implementation uses the same v0.3 grammar but is not a new v0.4 versioned AST format. Wire schema is still 0.3.0. This is intentional for compatibility. User lexemes may match surface control words because `nami` disambiguates them.
