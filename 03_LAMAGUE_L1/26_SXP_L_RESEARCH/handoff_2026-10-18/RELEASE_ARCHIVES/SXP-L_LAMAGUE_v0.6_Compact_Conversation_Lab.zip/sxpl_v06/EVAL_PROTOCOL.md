# Evaluation protocol proposal — NOT YET EXECUTED

## Hypothesis, not conclusion

**H1:** Following equal instruction time, novice readers of the compact SXP-L subset identify actor, polarity, and nested proposition scope at least as accurately as those reading the v0.5 controlled long register, while using fewer displayed tokens.

**H2:** A structured SXP-L transfer may show fewer unwanted inferences about another person's mental state compared with unconstrained paraphrase, when judged against blinded human-annotated source propositions.

Neither hypothesis has been tested with participants or external model baselines.

## Study A: human learnability

- Randomly allocate volunteers to SXP-L 0.5 full form vs SXP-L 0.6 compact; give each group equivalent training examples and time. Reconcile item difficulty and matching lexical content.
- Use unseen items, with at least 30–50 participants **per arm as a pilot target**, then power the confirmatory study from the observed variance rather than pretending the target guarantees significance.
- Pre-register scoring: exact identification of subject, negative-scope location, temporal reference, and proposition vs speaker attitude. Collect time per item and a confidence report.
- Counterbalance pronouns, real proper names, and root/name collisions. Include consent, accessible alternatives, and voluntary withdrawal.
- Failure criteria: high ambiguity rate, weaker accuracy than v0.5 baseline, pronounced subgroup accessibility disparity, or unaided speech confusion.

## Study B: agent semantic preservation

- Prepare 100–300 source cases with pre-specified grounded AST meanings and ambiguity annotations. Keep test cases held out from lexical examples.
- Conditions: controlled English, typed JSON schema, SXP-L 0.5, SXP-L 0.6; optionally Lojban / GF / ACE where genuinely equivalent coverage exists.
- Standardize models, temperature, token budgets, prompt lengths, and tool access. Blind raters to condition on decoded content.
- Primary measures: semantic slot error rate, negation-scope error, unjustified inference of others' beliefs, preservation of explicit uncertainty, and missing-content report accuracy.
- Secondary measures: request length, parse failures, response latency and training cost. **Do not** equate lower syntactic token count with lower model token cost without tokenizer measurements.
- Publish source cases, prompt templates, data dictionary, parser version and environment so others can reproduce both successes and failures.

## Important confounders

A short constructed grammar may help only because it has fewer things it can express. Compare matched expressive subsets and always count rejected or dropped information in the denominator. Do not score incomprehensible but structurally consistent outputs as success.
