# SXP-L v0.6 — Meaning Conservation / Loss Ledger

## No-loss cases relative to our own AST

- Actor, named target, registered predicate, polarity, mood, present/past/future, optional modality.
- Typed feeling, nested proposition, typed quoted context.
- v0.5 dialogue speaker/addressee identity, explicit pronouns and attributed links.
- Exact conversion to/from v0.3 AST for **supported** compact utterances; this is checked programmatically.

## Visible failure or full-form fallback

- Unsupported canonical predicates, Native-36 direct operators, unusual role combinations, quoted actors/targets, sources, provenance annotations, confidence values or authorizations: `speak_compact()` errors, but `render_document()` preserves their original full register.
- Undeclared person referenced as actor in a dialogue: error, not invention.
- Natural-language phrases, unmarked proper nouns, unknown roots, noun/verb homonyms without an explicit position, improper punctuation, trailing clauses, unknown emotional roots: error.
- Unbound `ti`: v0.5 dialogue error, not a guess.

## Meaning not actually modeled yet

- Shared subject `we`, plural, temporal aspect, counterfactual, negation of *part* of a clause, implied intentions, figurative speech, sarcasm, politeness, local customs, indirect speech acts.
- Distinguishing personal fear, epistemic uncertainty, possibility, and measurable probability in every grammatical construction.
- Provenance confidence and authorizations are in the legacy AST but not in compact syntax.
- The opaque content of `lo "our future"` is **not** a semantically typed claim about ownership, collectivity, or time.

## Not experimentally evaluated

No blind human learning/comprehension tests, spoken phonetic tests, model decoding accuracy studies, cross-cultural corpus coverage, reasoning benchmarks, or baseline comparison to Lojban, ACE, JSON, and GF have yet been performed. Internal round-trip tests do not answer those questions.

## Proposed future loss annotation

For v0.7+, produce a machine-readable `loss_report.json` with fields `{source, target, conserved, unmapped, coerced, reviewer_notes}`. Avoid automatically claiming a literal English gloss faithfully represents every semantic nuance.
