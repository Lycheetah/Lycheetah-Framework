# SXP-L × LAMAGUE 0.6 — Compact Conversation Prototype

**Experimental research software · Python 3.10+ · standard library only.**

The new v0.6 language register supports sentences as short as:

```text
mi liva ti.
mi fela loma @nara.
mi hira ( fura mi rava @nara ).
mi noka kena ( @nara luma mi ).
```

Their semantics are represented by the original v0.3 clause AST. The old v0.5 dialogue engine still resolves pronouns and retains attributed links such as `kora but`. Nothing in the parser executes commands.

## Run

```bash
cd sxpl_v06
python compact.py hear 'mi hira ( fura mi rava @nara ).'
python compact.py speak 'sa nu hope ka mi pr [ sa fu reconnect ka mi ta nara en ] en'
python conversation_v06.py examples/conversation_v06.sxh
python conversation_v06.py examples/conversation_v06.sxh --output normalized
python -m unittest test_compact test_dialogue test_surface test_v03 -v
```

## Contents

- `SPEC_v0.6.md` — grammar, valencies, semantics, boundary conditions, references
- `compact.py` — bidirectional compact/canonical translator
- `conversation_v06.py` — dialogue parser and backward-compatible normalization
- `examples/conversation_v06.sxh` — 3-person dialogue with explicit contrast and uncertain knowledge
- `LEARNER_CARD_v0.6.md` — practice and glosses
- `LEARNER_LAB_v0.6.html` — optional offline, browser-based reading quiz (not a language parser)
- `MEANING_LOSS_LEDGER.md` — precise coverage boundaries
- `EVIDENCE_REPORT.md` and `TEST_REPORT.txt` — reproducible local tests, compression measurement
- `roots.py`, `dialogue.py`, `surface.py`, `sxpl_v03.py`, `sxpl_v02.py` — retained engine ancestry
- old documents/reference tests preserved for provenance

## Principles

A **synthetic language is legitimate**; its capabilities still require evidence. v0.6 is an implementation, not linguistic fluency or AI superiority. All meanings and pronunciation suggestions are provisional. `@` is a written name marker; not yet a settled spoken phoneme.

**Meaning should survive the journey between minds. When it doesn't, the loss should be visible.**
