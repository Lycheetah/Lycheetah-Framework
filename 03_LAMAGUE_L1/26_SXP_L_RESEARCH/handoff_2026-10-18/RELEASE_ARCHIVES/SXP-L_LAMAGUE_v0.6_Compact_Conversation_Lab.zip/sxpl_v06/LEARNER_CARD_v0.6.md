# SXP-L v0.6 — First compact conversation

This is a **reader practice card** for our experimental written register, not a verified pronunciation standard.

## The important words

| Form | Meaning / job |
|---|---|
| `mi` | I / me (current named speaker in a dialogue) |
| `ti` | you (the addressed participant, if named) |
| `@nara` | the explicitly named person Nara (`@` is written name marker) |
| `liva` | love |
| `luma` | miss someone |
| `loma` | longing |
| `fela` | experience a feeling |
| `hira` | hope; with `fela`, hope as a feeling |
| `kena` | know (someone's **reported** knowledge claim) |
| `fera` | fear; with `fela`, fear as a feeling |
| `diva` | differ (new draft v0.6 root) |
| `noka` | not, applying to the verb of that clause |
| `fura` | future; `pana` past; unmarked tense is present |
| `( ... )` | proposition held *inside* a belief, hope, fear or knowledge claim |
| `qira` + `?` | question |
| `lo "..."` | explicitly labelled context (still an opaque quotation) |

Read a word like `liva` provisionally as *LEE-vah*, `hira` as *HEE-rah*, `kena` as *KEH-nah*. These are teaching approximations, **not standardized phonology**. The written `@` and punctuation still need a proper spoken form.

## Dialogue A — love and uncertainty

```text
mac:  mi liva ti.
mac:  mi fera ( mi diva ti lo "our future" ).
```

**Approximate English:** “I love you. I fear our outlooks on the future may differ.”

Important: the second line is **not evidence** the speakers differ. It labels a fear of a difference. We used `lo "our future"` as contextual text; the concept of *our* is not yet modeled separately.

In a structured dialogue `kora but a1 a2` attributes the contrast to Mac; contrast is not a mathematical contradiction.

## Dialogue B — what we know and what we hope

```text
asha: qira ti kena ( @nara luma ti )?
mac:  mi noka kena ( @nara luma mi ).
mac:  mi noka kena ( @nara noka luma mi ).
mac:  mi fela loma @nara.
mac:  mi hira ( fura mi rava @nara ).
```

**Approximate English:**
- Asha: “Do you know that Nara misses you?” (The outer `ti` is Mac; the nested `ti` also refers to Mac.)
- Mac: “I don't know that Nara misses me.”
- Mac: “I don't know that Nara does not miss me.”
- Mac: “I feel longing for Nara.”
- Mac: “I hope I'll reconnect with Nara in the future.”

Notice that longing and hope can be asserted as *personal reports*, while Nara's feelings remain unknown. This distinction is central to the design.

## Five-second comprehension drill

Translate each before reading the answers:

1. `mi liva ti.`
2. `mi noka liva ti.`
3. `qira ti liva mi?`
4. `mi hira ( fura ti rava mi ).`
5. `mi fela yora.`

### Answers

1. I love you (as asserted by the current speaker).
2. I do not love you (a negative assertion, not necessarily indifference).
3. Do you love me? (a question, not an assertion).
4. I hope that *you* reconnect with *me* in the future.
5. I experience joy.

### The next human-language challenge

Try talking about a promise, a shared memory, and a condition (“If the train is late, I'll call”). We cannot express these fully yet in compact SXP-L. **That is useful failure evidence**, not something to hide.
