# SXP-L × LAMAGUE — Executable Language Kernel v0.2
**17 October 2026 · Lycheetah · experimental, not ratified**

## What changed since v0.1
A standalone Python implementation now tokenizes, parses, validates, serializes, fingerprints and renders a narrowly specified dual-register clause language. It does **not** require dependencies outside the Python standard library. Source includes an executable test suite. This version does not modify any GitHub repository.

## Evidence ledger
| Claim | Status | Evidence / constraint |
|---|---|---|
| 5,000 deterministic randomly generated clauses round-tripped to equal canonical representations | Locally tested | Seeded Python unittest run on this release |
| Six manually chosen v0.1 examples/variants round-trip | Locally tested | test_examples |
| Twelve malformed examples rejected | Locally tested | test_rejection |
| 3 test methods passed | Locally tested | python -m unittest -v |
| Arbitrary valid human speech interpretable | NOT demonstrated | Phonology, broad semantics and discourse absent |
| Outperforms Lojban / controlled English / JSON | NOT demonstrated | Requires independent comparative evaluation |
| Safe authorization for agents | NOT demonstrated | Runtime auth needed, authorizer role is only an assertion |
| Semantically meaningful native-36 contracts | NOT demonstrated | Operator symbols still lack complete operational semantics |

## Formal choices v0.2
1. One single clause, ending with `en`, with mood `sa|qu|di`.
2. Order: mood, optional `no`, optional `ma|mu`, optional `pa|nu|fu`, predicate, then zero or more marked roles.
3. Native-36 predicates `A..Z` use `N36:` namespaces; user-defined predicates are `USR:`. Symbols are *identifiers*, not proof of interpreted meaning.
4. Marked roles: `ka` actor, `ta` target, `lo` context, `se` evidence source, `au` claimed authorizer, `sc` claimed scope, `co` declared confidence.
5. Value types: JSON-string literal (normalized to Unicode NFC); unquoted symbol; decimal number string; unknown `xi`. No implicit truth value or authorization.
6. Confidence must be a decimal 0–1 with at most six fractional digits. Canonical representation is an integer number of millionths (`fixed6`), never a binary float.
7. Repeated semantic roles and malformed inputs are hard failures. Renderer produces a canonical space-delimited human rendering; it does not preserve original whitespace or quoting style.
8. Canonical bytes are sorted-key compact UTF-8 JSON, prefixed with `SXP-L` and zero byte for a SHA-256 content fingerprint. This is a local design, **not** an externally standardized canonicalization mechanism.

## A useful everyday language, not merely a task protocol
The language must eventually express something like: “I love my sister, although I'm uncertain whether she understands why I left; tomorrow I want to talk with her, but I won't impose.” Present v0.2 can only express shallow isolated predicates with simple roles; it cannot faithfully encode nested emotion, concession, first-person deixis, temporal relation, negation scope in subordinate clauses, or noncoercive interpersonal intent. Treat this as a *required v0.3+ design challenge*, not a solved problem.

### Proposed SXP-H spoken-language expansion (DRAFT, not implemented)
- **Pronouns and persons:** speaker, addressee, third parties, inclusive/exclusive we, anaphora.
- **Relations:** possession, kinship, social roles, spatial relation, comparison.
- **Clauses:** subordinate quotation, conditionals, causal connectives, concessives, relative clauses; each with explicit scope.
- **Aspect:** ongoing, completed, habitual, prospective; separate from past/present/future.
- **Evidentiality:** firsthand, hearsay, inference, memory, imagined. Keep evidence source separate from truth conditions.
- **Dialogue:** greetings, repairs, clarifications, boundaries, hedges, refusal and negotiation.
- **Expressive and poetic use:** metaphor must be representable as metaphor, not silently flattened to literal claims.
- **Phonology:** inventory and syllable constraints selected via independent pronunciation/segmentation tests, not by ad hoc Romanization.

## Operator discipline
Do not derive N36:A = full English word “anchor” in every context merely because the legacy glossary names it Anchor. To turn the operator into an executable semantic primitive, define its input types, output types, side-effect class, failure states and test vectors. Proposed registry format:

```
identifier: N36:O
historical_gloss: Observe
semantic_contract: UNDEFINED
input_types: UNDEFINED
output_types: UNDEFINED
side_effects: UNDEFINED
source_provenance: legacy glossary, pending direct source reconciliation
```

## How to run
From the folder containing the two Python files:

```sh
python -m unittest -v
python sxpl.py 'sa nu O ka "sensor_7" ta "pressure" se "reading_018" co 0.91 en'
```

## Threat model and known limitations
This grammar does not prevent lying about source, spoofing names in `au`, forged citations, runtime authorization bypass, unsafe execution or model confabulation. The parser limits syntax, not intent. An explicitly unknown `xi` is not equivalent to false. `di` is still only a proposed directive. Lexical aliases, homophones and culturally situated meanings are unsolved. There is no streaming parser or resource exhaustion budget. Do not put its output directly on an unguarded execution path.

## Next milestones / acceptance criteria
**v0.3**: operator registry with typed contracts; parser error corpus; stricter JSON AST validation; resource limits; adversarial and property-based fuzzing; independent canonicalization checks.

**v0.4**: human grammar for multi-clause thought, agent/patient/theme distinctions, quotation, possession, quantifiers, conditionals and scope. Write ≥100 paired examples containing emotionally meaningful everyday usage and evaluate with human readers.

**v0.5**: phoneme inventory, native orthography, phonotactics, prosodic cues, pronunciation lexicon; measure segmentability and homophone incidence; do not assume a one-to-one oral ↔ written mapping.

**v0.6**: provenance map and bridges to canonical LAMAGUE Core, Spoken LAMAGUE, Native-36 and BRIDGE packets. Never silently change their versions or names.

## Source continuity
The previous design checkpoint is included as `FOUNDATION_v0.1.md`. Existing historical TRIAD `Ao → Φ↑ → Ψ`, legacy seals and framework layering are preserved as references, not rewritten. SXP-L expansion remains unspecified until verified. This prototype is a fresh independent language kernel and an interoperability hypothesis.
