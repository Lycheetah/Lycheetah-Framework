import random
import unittest
from sxpl import parse,render,canonical,fingerprint,SXPError
class LanguageTests(unittest.TestCase):
    def test_examples(self):
        examples=[
            'sa nu O ka "sensor_7" ta "pressure" se "reading_018" co 0.91 en',
            'qu P ta "reading_018" en',
            'di no X ka "agent_2" ta "customer_data" au "user_9" sc "public_only" en',
            'sa U ta "invoice_status" se xi en',
            'sa ma fu N ka "mac" ta "lumière" en',
            'qu no mu pa R ta project_8 en',
        ]
        for s in examples:
            with self.subTest(s=s):
                a=parse(s);b=parse(render(a));self.assertEqual(canonical(a),canonical(b));self.assertEqual(fingerprint(a),fingerprint(b))
    def test_rejection(self):
        bad=['sa O ka bob ka alice en','sa O co 1.1 en','sa O co -0.1 en',
             'sa O co 0.1234567 en','di O sc en','sa O ta "unterminated en',
             'sa no no O en','sa O ta "x" en en','sa O ta "a" "b" en',
             'sa O co xi en','sa O en ta bob', 'sa O se "line\\q" en']
        for s in bad:
            with self.subTest(s=s):self.assertRaises(SXPError,parse,s)
    def test_deterministic_generated_5000(self):
        rnd=random.Random(20261017)
        moods=['sa','qu','di'];ops=list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
        roles=['ka','ta','lo','se','au','sc']
        values=['"hello world"','"naïve"','"🌱"','xi','abc_2','2.5','0']
        for i in range(5000):
            ts=[rnd.choice(moods)]
            if rnd.randrange(2):ts.append('no')
            if rnd.randrange(2):ts.append(rnd.choice(['ma','mu']))
            if rnd.randrange(2):ts.append(rnd.choice(['pa','nu','fu']))
            ts.append(rnd.choice(ops))
            for r in rnd.sample(roles,rnd.randrange(0,len(roles)+1)):
                ts += [r,rnd.choice(values)]
            if rnd.randrange(2):ts+=['co',str(rnd.randrange(1000001)/1000000)]
            ts+=['en']
            a=parse(' '.join(ts));b=parse(render(a))
            self.assertEqual(canonical(a),canonical(b),i)
if __name__=='__main__':unittest.main()
