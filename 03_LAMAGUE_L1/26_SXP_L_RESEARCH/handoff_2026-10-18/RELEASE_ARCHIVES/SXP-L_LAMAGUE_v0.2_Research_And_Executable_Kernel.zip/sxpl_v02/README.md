# SXP-L × LAMAGUE v0.2

**Executable clause-language prototype plus honest research dossier.**

- `FOUNDATION_v0.1.md`: original conceptual grammar and scope.
- `RESEARCH_AND_GRAMMAR_v0.2.md`: engineering checkpoint, linguistic expansion path, evidence ledger and boundaries.
- `sxpl.py`: zero-dependency Python parser, canonical renderer, validator and SHA-256 fingerprint.
- `test_sxpl.py`: seeded 5,000-clause round-trip test and malformed-input suite.

Run `python -m unittest -v` from this directory. All design choices are provisional. No actual cross-model, human fluency, authorization safety or comparative performance claims are made.
