# SXP-L / LAMAGUE v0.3 — Human Expression Kernel

**Status:** experimental structured-meaning language, with a working deterministic parser. Not a complete natural language or a claim of better model intelligence. **Date:** 17 October 2026.

## Vision
Create a human-learnable expressive language and a separate machine-verifiable semantic representation. Preserve distinctions between observation, inference, emotion, desire, belief, assertion, uncertainty, and permission. Evaluate round-trip integrity rather than presuming it.

## Provenance and compatibility
The v0.2 engine is copied unchanged as `sxpl_v02.py`, for historical inspection. This v0.3 grammar extends v0.2 but declares its own schema version. Native-36 uppercase operators remain reserved, but their pre-existing semantics are **not** redefined here. Lowercase `USR:` predicates are experimental and do not constitute a settled SXP-L lexicon.

## Grammar (provisional)

```ebnf
clause      = mood, [ "no" ], [ modality ], [ time ], predicate, { role_value }, "en" ;
mood        = "sa" | "qu" | "di" ;
modality    = "ma" | "mu" ;
time        = "pa" | "nu" | "fu" ;
predicate   = upper_case_native36 | user_identifier ;
role_value  = ("ka" | "ta" | "lo" | "se" | "au" | "sc" | "co" | "fe" | "re" | "vi"), atom
            | "pr", "[", clause, "]" ;
atom        = quoted_JSON_string | symbol | number | "xi" ;
```

Each role may appear once per clause. Embedded clauses are recursive to depth 8, with a 4,096-token ceiling. A `pr` value is a syntactic proposition, not an automatically proven truth. `co` is **self-reported confidence**, never a calibrated probability unless independently validated. `fe` requires a named feeling symbol from the provisional starter vocabulary. `re` is a coarse relation label; no ontology, speaker identity, or real-world authorization is inferred from it. `vi` is viewpoint, not a verified perspective attribution.

## Worked semantics, without overclaiming

Source English: “I miss someone I love, but I don't know whether they understand how much I want to see them.”

**Provisional structured representation (multiple clauses):**

```text
sa nu feel ka self fe longing ta person_2 en
sa nu love ka self ta person_2 re loves en
sa no nu know ka self pr [ sa nu understand ka person_2 lo "how much I want to see them" en ] en
```

This is an **interpretive paraphrase**, not an equivalent translation. It loses the English connective *but*, the degree of wanting to see the person, and the exact scoping of “whether.” In the third statement the outer negation means “I do not know [P]”; it does **not** mean “I know [not P].” The content of the quoted context has not itself been parsed into semantic roles. These are the next formalization tasks.

## Assessment

- **Implemented and locally tested:** lexical boundary checks inherited from v0.2, parser, nested propositions, canonical rendering, SHA-256 fingerprint of the normalized AST, starter emotion/relation labels, bounded recursion, and error rejection.
- **Observed local test results:** four test groups passed; 3,000 deterministic generated examples round-tripped; eleven rejection examples and a recursion-depth rejection were exercised; five illustrative examples passed.
- **Not established:** paraphrase equivalence, usable phonology, consistent speech-to-text, semantic truth, cross-model reliability, efficiency improvement, robustness against adversarial prompts, and safety authorization.
- **Comparison protocol proposed:** compare SXP-L representations against controlled English, JSON ASTs, and other formal semantic encodings on 100 blinded prompts. Blindly judge role/polarity/scope recovery; report exact-match, meaning-preservation rates, error types, human learning time, and token overhead. Publish failures as well as successes.

## v0.4 backlog

1. Formal operators for conjunction/contrast and quantifiers, including compositional scope.
2. Explicit desire predicates with intensity and referent resolution.
3. Evidentiality: self-report vs observation vs third-party attribution.
4. Phonology, pronunciation and natural spoken surface form (should remain separate from canonical wire encoding).
5. Human bilingual corpus, annotation guidelines, and held-out evaluation.

## Usage

```bash
python test_sxpl.py
python sxpl.py sa no nu know ka self pr '[' sa nu understand ka person_2 en ']' en
```

The executable does not talk to other agents, claim emotion detection, or execute any external effects.
