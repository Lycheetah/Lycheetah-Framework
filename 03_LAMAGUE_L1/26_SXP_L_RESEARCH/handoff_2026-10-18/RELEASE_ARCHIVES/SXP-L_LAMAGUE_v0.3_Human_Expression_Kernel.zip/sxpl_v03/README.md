# SXP-L v0.3

Research-grade exploratory language kernel for representing nested propositions, feelings, and relationships.

Run from this folder:

```bash
python test_sxpl.py
python sxpl.py sa nu feel ka self fe longing ta person_2 en
```

Files:
- `sxpl.py` — v0.3 parser, renderer, serializer, fingerprint
- `test_sxpl.py` — deterministic regression and fuzz-style generated examples
- `sxpl_v02.py` — unchanged baseline copy from v0.2
- `RESEARCH_v0.3.md` — grammar, examples, limits, and experiment plan
- `FOUNDATION_v0.1.md` — original v0.1 foundation

Do not use the parser for execution authorization or security decisions. The v0.3 wire grammar is not a final spoken language.
