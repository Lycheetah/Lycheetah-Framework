"""Tests for authoring notation, legacy parity, append-only repairs, and pair integrity."""
import copy
import random
import unittest
from studio17 import parse_studio, verify_pair, inspect
from sxpl_v03 import SXPError

EXAMPLE='''people maka nara sela vera
maka > nara : mi liva ti
nara > maka ?1 : mi luma ti
maka > nara ~1 : mi luma ti
sela > vera ^belareko(maka,nara) : mi liva ti
maka > nara #sela : mi liva sivena
'''

def fails(src):
    with unittest.TestCase().assertRaises(SXPError):parse_studio(src)

class StudioTests(unittest.TestCase):
    def test_example(self):
        parsed=parse_studio(EXAMPLE)
        self.assertEqual(parsed['sidecar']['turns'][0]['corrected_by'],3)
        self.assertEqual(parsed['legacy_doc']['turns'][3]['leaf_roles']['mi'],'maka')
        self.assertEqual(parsed['legacy_doc']['turns'][4]['reference']['chosen'],'sela')
        self.assertEqual(len(parsed['meaning_loss_if_only_sxh']),2)
        self.assertEqual(verify_pair(parsed['legacy_sxh'],parsed['sidecar'])['sidecar'],parsed['sidecar'])
        self.assertFalse(parsed['sidecar']['authorizes'])
    def test_preserve_liva(self):
        s='people maka nara\nmaka > nara : mi liva ti'
        d=parse_studio(s)
        self.assertIn('mi liva ti devora\ntevaro',d['legacy_sxh'])
        fails(s.replace('liva','jiva'))
    def test_no_fake_clarification_implemented_in_native_language(self):
        d=parse_studio(EXAMPLE)
        # Old .sxh only knows reply_to, not whether question or correction.
        self.assertEqual(d['legacy_doc']['turns'][1]['reply_to'],d['legacy_doc']['turns'][2]['reply_to'])
        self.assertNotIn('clarification_request',d['legacy_sxh'])
        self.assertNotIn('self_correction',d['legacy_sxh'])
    def test_missing_link(self):
        fails('people maka nara\nnara > maka ?1 : mi liva ti')
        fails('people maka nara\nmaka > nara : mi liva ti\nnara > maka ?4 : mi liva ti')
    def test_correction_ownership(self):
        fails('people maka nara\nmaka > nara : mi liva ti\nnara > maka ~1 : mi luma ti')
    def test_correction_fork_rejection(self):
        fails('people maka nara\nmaka > nara : mi liva ti\nmaka > nara ~1 : mi luma ti\nmaka > nara ~1 : mi rava ti')
    def test_clarification_ownership(self):
        fails('people maka nara\nmaka > nara : mi liva ti\nmaka > nara ?1 : mi luma ti')
    def test_framed_identity(self):
        d=inspect('people maka nara sela vera\nmaka > nara ^belareko(sela,vera) : mi liva ti')
        self.assertEqual(d['turns'][0]['local_first_person'],'sela')
        self.assertEqual(d['turns'][0]['local_second_person'],'vera')
    def test_ambiguity_visible(self):
        s='people maka nara sela vera\nmaka > nara : mi liva sivena'
        t=inspect(s)['turns'][0]
        self.assertEqual(t['third_person_status'],'ambiguous')
        self.assertEqual(t['third_person_candidates'],['sela','vera'])
        self.assertIsNone(t['third_person_chosen'])
    def test_explicit_anchor(self):
        s='people maka nara sela vera\nmaka > nara #sela : mi liva sivena'
        self.assertEqual(inspect(s)['turns'][0]['third_person_chosen'],'sela')
    def test_anchors_checked_by_authoritative_parser(self):
        fails('people maka nara sela\nmaka > nara #maka : mi liva sivena')
        fails('people maka nara sela\nmaka > nara #sela : mi liva ti')
    def test_unknown_frame_rejected(self):
        fails('people maka nara sela\nmaka > nara ^hopareko(sela,maka) : mi liva ti')
    def test_unknown_root_rejected(self):
        fails('people maka nara\nmaka > nara : mi unverifiedroot ti')
    def test_malformed_syntax_rejected(self):
        fails('people maka nara\nmaka >> nara : mi liva ti')
        fails('people maka nara\nmaka > nara : mi liva ti\nmaka > nara @1 ?1 : mi liva ti')
        fails('people maka nara\nmaka > nara : mi liva ti\nnara > maka ~1 : mi liva ti')
    def test_tamper_legacy_hash_rejected(self):
        d=parse_studio(EXAMPLE)
        with self.assertRaises(SXPError):verify_pair(d['legacy_sxh']+' ',d['sidecar'])
    def test_tamper_sidecar_rejected(self):
        d=parse_studio(EXAMPLE)
        mutators=[lambda x:x.update(authorizes=True),
          lambda x:x['turns'][0].update(corrected_by=99),
          lambda x:x['turns'][1]['link'].update(kind='self_correction'),
          lambda x:x['turns'][4].update(anchor='vera'),
          lambda x:x['turns'][3].update(frames=[['belareko','nara','maka']]),
          lambda x:x['turns'][2].update(speaker='nara')]
        for f in mutators:
            dirty=copy.deepcopy(d['sidecar']);f(dirty)
            with self.subTest(f=f),self.assertRaises(SXPError):verify_pair(d['legacy_sxh'],dirty)
    def test_generated_600_roundtrips(self):
        rng=random.Random(170017)
        for n in range(600):
            length=rng.randint(2,12)
            people=['maka','nara','sela','vera'][:rng.randint(2,4)]
            lines=['people '+' '.join(people)]
            speakers=[];corrected=set()
            for i in range(1,length+1):
                speaker=rng.choice(people)
                target=rng.choice([p for p in people if p!=speaker])
                options=[('','')]
                if i>1:
                    same=[j for j,x in enumerate(speakers,1) if x==speaker and j not in corrected]
                    different=[j for j,x in enumerate(speakers,1) if x!=speaker]
                    if same:options.extend([('~',str(rng.choice(same)))])
                    if different:options.extend([('?',str(rng.choice(different)))])
                kind,ref=rng.choice(options)
                if kind=='~':corrected.add(int(ref))
                mods=f' {kind}{ref}' if kind else ''
                verb=rng.choice(['liva','luma','rava'])
                lines.append(f'{speaker} > {target}{mods} : mi {verb} ti')
                speakers.append(speaker)
            data='\n'.join(lines)
            d=parse_studio(data)
            self.assertEqual(verify_pair(d['legacy_sxh'],d['sidecar'])['sidecar'],d['sidecar'])
            self.assertEqual(len(d['legacy_doc']['turns']),length)
    def test_non_authorization(self):
        x=inspect(EXAMPLE)
        self.assertFalse(x['authorizes'])
        self.assertTrue(all(t['authorizes'] is False and t['speech_authenticated'] is False for t in x['turns']))

if __name__ == '__main__':unittest.main()
