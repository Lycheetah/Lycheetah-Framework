# SXP-L v1.8 — Conditional roadmap, not an implemented feature

1. **Language-native repairs:** design actual spoken questions and repair acts. Replace authoring shortcuts with independently pronounceable structures only after checking structural and acoustic collisions. Do not overwrite v1.7 annotations.
2. **Conversation-without-notation study:** show a true learner a short dialogue and ask them to paraphrase and correct an earlier statement without help. Record where the grammar fails, rather than filling gaps with English assumptions.
3. **Counterfactual and temporal anchoring:** formalize "I meant that yesterday, but I don't believe it now" distinct from "what I said yesterday was false".
4. **Compositional lexicon:** grow social relations, events and nonliteral speech with derivational morphology and learner feedback, not arbitrary root multiplication.
5. **Fair baselines:** compare against a mature controlled English or typed schema using equal training time and meaningful controls. No claims of superiority before a real study.
6. **Keep agent policy out of natural-language claims:** all authority remains separately authenticated and scoped.
