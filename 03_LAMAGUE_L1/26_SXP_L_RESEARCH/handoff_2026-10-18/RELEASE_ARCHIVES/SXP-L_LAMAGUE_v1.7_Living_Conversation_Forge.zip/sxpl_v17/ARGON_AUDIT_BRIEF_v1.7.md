# Argon adversarial assignment — SXP-L v1.7

Audit the **actual** `studio17.py` + `examples` + `test_studio17.py`, not just the release narrative.

1. Verify `mi liva ti` remains identical and that historical v1.6 files are byte-for-byte preserved.
2. Reproduce the 18 v1.7 test methods, the 13 v1.4 tests, the 12 v1.6 transfer-study checks. The 600 generated examples are looped inside one test method; do not add these counts together as methods.
3. Try malformed modifiers, duplicate corrections, fabricated identities, references to the future, ambiguous `sivena`, noncanonical transcript strings, and forged JSON sidecars.
4. Try to make `verify_pair` accept a sidecar that changes a correction into a clarification, or alters scoped `mi`/`ti` bindings.
5. Flag that `?k` is authoring *metadata*, not a genuine question in the v1.4 spoken grammar. Identify stronger design options for a future native conversational-repair syntax.
6. Check whether SHA-256 matching is ever described incorrectly as authenticating the speaker. It must not be.
7. Compare this overlay to **conversation analysis repair**, versioned event logs, discourse-representation updates, and conventional editor/annotation formats. Describe what is truly useful and what is ordinary prior art.
8. Audit offline browser preview independently. It supports a **subset** of the full Python grammar and should never be used as the authority for open-ended SXP-L correctness.
9. Provide a failing fixture before proposing each grammar/semantic change. Do not rewrite any historical release.
10. Recommend a disciplined v1.8 language-native repair experiment followed by real human learnability testing.

Deliver: precise findings (file/line, reproducible input, expected vs actual), code-level fixes, gap register, and explicit separation between locally tested behavior, linguistic hypothesis, and human-language evidence.
