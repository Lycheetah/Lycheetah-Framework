# Your first SXP-L Conversation Studio exercise

The original phrase remains **mi liva ti** — "I love you."

This learner exercise contains **two different notations**:

**Actual inherited SXP-L words:** `mi` (I, locally bound); `ti` (you, locally bound); `liva` (love); `luma` (miss); `rava` (reconnect); `sivena` (unresolved or anchored third person). The old transcript compiler adds `devora` as a sentence terminator.

**New Studio-only shorthand:** `name > name :` marks a speaker and audience, `@1` links to earlier turn 1, `?1` tags a clarification request about turn 1, and `~1` tags a correction of one's own turn 1. Those symbols are **not spoken SXP-L**; they simplify writing experiments.

## Read

```text
people maka nara sela vera
maka > nara : mi liva ti
nara > maka ?1 : mi luma ti
maka > nara ~1 : mi luma ti
sela > vera ^belareko(maka,nara) : mi liva ti
maka > nara #sela : mi liva sivena
```

- Turn 1 is Maka's utterance, "I love you", addressed to Nara.
- Turn 2 is Nara's utterance, "I miss you", plus a Studio **request for clarification** about turn 1. The language itself does **not** encode the interrogative force of the leaf.
- Turn 3 is Maka's utterance, "I miss you", tagged as a **self-correction** of turn 1. Turn 1 remains visible in the audit trail.
- Turn 4 is Sela's report of an attributed belief whose local first person is Maka and local second person is Nara. It is not proof of Maka's belief.
- Turn 5 says Maka loves `sivena`; the explicit anchor selects Sela, rather than guessing among third-person candidates.

**Important:** These are deliberately artificial exercises for testing the semantic mechanism, not yet smooth natural conversation. The next linguistic task is inventing and validating *spoken* repair grammar without losing these distinctions.

## Your exercise

Change turn 3 from `mi luma ti` to `mi rava ti`. Run the Studio. Notice that turn 1 still exists, but the corrected intended statement is now "I reconnect with you." Then remove `#sela` from turn 5: the third-person interpretation becomes ambiguous because both Sela and Vera are possible. The proper answer is "unresolved", not a guessed name.
