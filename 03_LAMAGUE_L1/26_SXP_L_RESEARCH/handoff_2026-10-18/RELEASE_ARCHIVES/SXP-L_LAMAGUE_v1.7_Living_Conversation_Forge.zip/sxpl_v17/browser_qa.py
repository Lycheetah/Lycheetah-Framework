"""Offline UI smoke test. Runs only with local headless Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page(accept_downloads=True, viewport={'width':1280,'height':850})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content((p/'LEARNER_LAB_v1.7.html').read_text(encoding='utf8'))
 assert page.locator('#counter').inner_text()=='5 turns checked'
 assert page.locator('.turn').count()==5
 assert 'Meaning-loss warning' in page.locator('#alert').inner_text()
 with page.expect_download() as req:page.locator('#download').click()
 dl=req.value;assert dl.suggested_filename=='conversation.studio'
 dl.save_as(p/'BROWSER_DOWNLOADED_EXAMPLE.studio')
 assert (p/'BROWSER_DOWNLOADED_EXAMPLE.studio').read_text().startswith('people maka nara')
 page.locator('#source').fill('people maka nara\nmaka > nara : mi liva ti')
 page.locator('#check').click()
 assert page.locator('#counter').inner_text()=='1 turns checked'
 assert 'Preview valid' in page.locator('#alert').inner_text()
 page.locator('#source').fill('people maka nara\nmaka > nara : mi jiva ti')
 page.locator('#check').click()
 assert page.locator('#counter').inner_text()=='Needs correction'
 page.locator('#reset').click()
 assert page.locator('#counter').inner_text()=='5 turns checked'
 page.screenshot(path=str(p/'BROWSER_QA_v1.7.png'),full_page=True)
 assert errors==[],errors
 print('PASS: five-turn initial preview, offline export, valid simple sentence, rejection of unknown root, reset, zero browser errors')
 b.close()
