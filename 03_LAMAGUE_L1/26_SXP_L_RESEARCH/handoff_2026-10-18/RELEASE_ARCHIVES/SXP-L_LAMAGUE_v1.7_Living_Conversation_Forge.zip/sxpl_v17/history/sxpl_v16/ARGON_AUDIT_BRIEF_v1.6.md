# Argon independent audit — v1.6 transfer study

Start by validating the release ZIP's `MANIFEST_SHA256_v1.6.txt` and comparison with the sealed v1.5 archive. Do **not** rewrite inherited files.

Prioritize these adversarial checks:

1. Rebuild the 30 stimuli. Confirm every SXP-L text is accepted by `perspective14.parse_transcript` and renders identically; verify each private key independently against `oracle16.py` and by manual review of a random sample.
2. Challenge the 3-turn reply semantics. Does `repira` point to an earlier turn without implying agreement? Can invalid or forward references bypass rejection?
3. Analyze the new predicates and names for lexical ambiguity and scope leakage. Could `sivena` resolve differently under conventional Discourse Representation Theory or conversation context? Explicitly identify where the simplified resolver diverges from established linguistics.
4. Verify allocation A/B/C across tasks, depths, names and predicate roots—not just total condition counts. Find unbalanced covariates, item memorization, or cues in English/JSON.
5. Test whether `participant_items_v1.6.json` and HTML leak scored gold. Do not confuse practice feedback with leakage of scored answers.
6. Check CSV tampering, duplicate rows, incorrect version/arm, and synthetic-result safeguards. Never equate valid CSV with evidence of a real participant.
7. Conduct a controlled critique of the fairness of comparing a novel orthography with explanatory English and JSON. Propose an appropriate familiarization protocol.
8. Review accessibility, readability and browser compatibility. Separate software QA from human comprehension evidence.
9. Assess whether the current study actually measures *transfer* beyond trained examples. Identify the minimal improved design for rigorous held-out semantic generalization.
10. Recommend whether to proceed to externally recruited pilot, after ethics/methods review, or revise the instrument first.

Report: issue severity, file/line references, reproduction command, expected vs observed, proposal, and whether the issue invalidates a study claim. Treat any observed software metrics as local engineering metrics only.
