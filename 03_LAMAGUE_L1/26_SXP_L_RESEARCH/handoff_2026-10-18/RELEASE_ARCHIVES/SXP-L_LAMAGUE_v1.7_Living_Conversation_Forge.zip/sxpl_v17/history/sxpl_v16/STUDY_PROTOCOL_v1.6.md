# SXP-L v1.6 pilot protocol — NOT EXECUTED WITH PEOPLE

## Research question

After a short common tutorial, can independent adults interpret unfamiliar combinations of previously documented SXP-L roots and established perspective/reference rules, including explicit reply links across three turns? Compare descriptively with explanatory English and typed JSON, not as a randomized evaluation of full conversational fluency.

## Volunteers and consent

Use independent adults and seek any appropriate institutional or local ethics/process review **before** collecting data; if public research claims are intended, consult a qualified methodology reviewer. Obtain informed consent and support withdrawal. Do not recruit people who feel obliged to endorse the language; record prior SXP-L and JSON exposure outside anonymous response exports only with separate permission.

## Instrument

1. Share **only** `SXP-L_TRANSFER_STUDY_LAB_v1.6.html` with a participant. The full research archive contains scored gold answers and must not be disclosed before the test.
2. Allocate arms A/B/C in rotation in advance and document deviations. The participant enters the supplied arm.
3. Participant reads the common tutorial, explicitly sees all three verbs' dictionary glosses, works ten feedback practice questions, then completes 30 scored questions.
4. Scored items receive no correctness feedback. “Unsure” is an encouraged valid answer. Optional confidence is a self-report, and browser duration is not a direct cognitive processing measure.
5. No names, email addresses or other identifying fields. The page runs locally without remote requests, cookies or persistent storage, and it exports an anonymous CSV only when the participant explicitly chooses to download it. External researchers may nevertheless be able to link the file to a participant through other records; handle accordingly.
6. Analyst validates each CSV and gives **descriptive** per-participant, per-task, per-predicate and per-condition scores. Exclusions and incomplete data must be reported. Never treat multiple items from one person as independent participants.

## Outcomes to report

- Exact accuracy and Unsure proportions separately by task (`holder`, `stance`, `reference`, `reply`, `predicate`), register and lexical root.
- Description of errors in pronoun scope, reply links, and ambiguous-reference cases; especially distinguish mistaken resolution from appropriate abstention.
- Whether responses to `luma` / `rava` differ from `liva`, with the reminder that the new words were provided in the glossary.
- Recruitment source, device, sample size, incomplete cases and prior language experience where consented and legally appropriate.

## Avoid unsupported claims

Do not claim “SXP-L is 90% understood”, “more accurate than English”, or “saves thinking time” from synthetic fixtures or a convenience pilot. Confirmatory studies require a preregistered hypothesis, participant sampling and training scheme, pre-specified outcome/size, power rationale, and fair comparator engineering. The v1.5 and v1.6 score banks use similar grammar and cannot serve as independently blinded external replications.

## Audit warnings

- English sentences often spell out the semantic relationship directly; SXP-L sentences require learned parsing. These are not equivalent familiarity conditions.
- `rava` glossed “reconnect with” in a clause is a modelled lexical meaning, not proof of how speakers spontaneously interpret it.
- Trial items are deterministic and source-available. Use a privately prepared fresh key for prospective blinded studies.
- Authenticated permission and real-world action remain outside this language and this study.

**Status on release:** zero human participants, no external experimental results.
