# SXP-L × LAMAGUE v1.6 — The Generalization Forge

**Maturity:** experimental language research / offline pilot instrument. **Date:** 18 October 2026.

This release is *an addition to* v1.5, not a new universal parser. We are testing whether learned SXP-L scope rules transfer to new, grammatical examples using other **existing** predicates, unfamiliar names, and three-turn transcripts. `mi liva ti` and every inherited grammar rule remain unchanged.

## The concrete contribution

- 30 parser-generated **scored** items: five tasks (local first person, innermost stance, third-person reference, explicit reply destination, predicate meaning), six items per task.
- Three matched surface representations per item: SXP-L, controlled explanatory English, typed JSON. Three counterbalanced arms A/B/C, with 10 scored items per register and two per task in each register.
- A **three-turn context** per item, including explicit `repira` reply links and nested attributed frames for the final turn. `repira` means a claimed reply link, **not agreement**.
- Legacy valid predicates `liva` (love), `luma` (miss someone), `rava` (reconnect with) in the last clause. These are **not** newly coined v1.6 roots; they are explained in the glossary. The worked example retains `liva`, while scored items use unfamiliar compositions.
- Ten separate practice items with feedback; no scored answers embedded in participant-facing HTML.
- Independently coded restricted parser (`transfer/oracle16.py`) cross-checks the 30 answer keys. Validated response scorer refuses simulated responses unless explicitly authorized via `--allow-synthetic`.
- Standalone offline browser lab, which requests no names or network permissions and exports an anonymous CSV only on request.

## Use

Participant (share this file **alone**): `transfer/SXP-L_TRANSFER_STUDY_LAB_v1.6.html`.

Researcher commands, from `transfer/`:

```bash
python build_transfer.py
python build_lab16.py
python -m unittest -v test_transfer16
python browser_smoke_test_v16.py   # requires Playwright/Chromium
python analyze_transfer.py SIMULATED_BROWSER_QA.csv --allow-synthetic
```

For **real** volunteer CSV exports (when appropriate consent/review is in place):

```bash
python analyze_transfer.py participant_A.csv participant_B.csv --out descriptive.json
```

**Important:** Bundled CSV is simulated. Do not present it as participant data. Do not give volunteers the research archive: it contains the answer key, synthetic fixtures and code from previous study versions. Publicly posting the organizer key on GitHub could compromise later blinded recruitment; regenerate a fresh private key and holdout set before serious confirmatory research.

## What is not proved

No independent person has completed this v1.6 instrument. We have **no human comprehension result**, no test of listening comprehension, no reliable speed claim, no evidence of language superiority, and no measured production-agent safety advantage. These are small constructed tasks, and the English/JSON comparators are explanatory rather than matched for visual length or familiarity.

See `SPEC_v1.6.md`, `EVIDENCE_REPORT_v1.6.md`, `STUDY_PROTOCOL_v1.6.md`, and `ARGON_AUDIT_BRIEF_v1.6.md`.
