"""Synthetic Chromium UI QA for A/B/C assignment and withdrawal. No human sessions."""
from pathlib import Path
from playwright.sync_api import sync_playwright
html=Path(__file__).with_name('SXP-L_TRANSFER_STUDY_LAB_v1.6.html').read_text()
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for arm in 'ABC':
        page=browser.new_page(accept_downloads=True);errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content(html,wait_until='domcontentloaded')
        page.locator('#arm').select_option(arm);page.locator('#agree').check();page.locator('#begin').click();page.locator('#practiceStart').click()
        for _ in range(10):
            page.locator('input[name=answer]').last.check();page.locator('#next').click();page.locator('#next').click()
        seen={x:0 for x in ['SXP-L','Controlled English','Structured JSON']}
        for _ in range(30):
            seen[page.locator('#conditionHeader').inner_text()]+=1
            page.locator('input[name=answer]').last.check();page.locator('#next').click()
        assert page.locator('#complete').is_visible()
        assert seen=={'SXP-L':10,'Controlled English':10,'Structured JSON':10},seen
        assert not errors,errors
        page.locator('#erase').click()
        assert page.locator('#intro').is_visible()
        assert page.evaluate('records.length')==0
        print(f'arm {arm}: 10 practices, 30 scored, 10/register; zero errors; withdrawal erased session')
        page.close()
    browser.close()
