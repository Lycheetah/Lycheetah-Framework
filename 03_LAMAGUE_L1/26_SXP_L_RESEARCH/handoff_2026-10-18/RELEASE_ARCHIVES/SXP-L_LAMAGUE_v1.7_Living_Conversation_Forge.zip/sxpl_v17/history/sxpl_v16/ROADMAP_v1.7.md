# Roadmap v1.7 — after v1.6

A conditional plan, **not** a promise of verified superiority or a deployment:

1. Invite independent language learners to review instructions and accessibility with informed consent; first validate usability rather than performance claims.
2. Audit v1.6 with Argon and a human linguistics/methodology reviewer; amend the public learner sheet if a confound is found, with proper versioning.
3. Increase genuinely unfamiliar grammatical **structures**, not only predicates; use a secure, unreleased holdout bank and real expert adjudication of semantics.
4. Prototype a stronger discourse-representation baseline and fair familiarization in explanatory English / JSON or a proven controlled natural language.
5. Test actual spoken comprehension only with a stable phonological reference and consented real speech, not a guessed TTS voice.
6. Keep authorization/agent-execution gates independent from any language expression.

Candidate research question: Do explicit viewpoint markers improve participants' ability to **recognize uncertainty** in a long, noisy dialogue compared with matched conventions in existing controlled representations? Test this rather than assuming the result.
