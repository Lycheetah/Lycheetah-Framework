"""Build v1.6 standalone offline transfer study. Participant HTML has NO scored gold."""
from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from build_transfer import build,record,TASKS
scored=build()
practice=[];seen={x['sxpl'] for x in scored};tasks={t:0 for t in TASKS}
for i in range(30,330):
    x=record(i)
    if x['sxpl'] in seen or tasks[x['task']]>=2:continue
    practice.append(x);seen.add(x['sxpl']);tasks[x['task']]+=1
    if len(practice)==10:break
assert len(practice)==10 and all(v==2 for v in tasks.values())
public=[{k:x[k] for k in ('id','task','difficulty','question','options','sxpl','english','json')} for x in scored]
prac=[{k:x[k] for k in ('id','task','difficulty','question','options','gold','sxpl','english','json')} for x in practice]
original=(ROOT/'study'/'build_lab.py').read_text()
page=original.split("page=r'''",1)[1].split("'''\npage=page.replace",1)[0]
page=page.replace('__SCORED__',json.dumps(public,ensure_ascii=False).replace('<','\\u003c'))
page=page.replace('__PRACTICE__',json.dumps(prac,ensure_ascii=False).replace('<','\\u003c'))
page=page.replace('SXP-L v1.5 | Human Understanding Forge','SXP-L v1.6 | Generalization Forge')
page=page.replace('Research v1.5','Research v1.6')
page=page.replace('The Human Understanding Forge','The Generalization Forge')
page=page.replace('Can a newly learned constructed language preserve viewpoint and uncertainty as intelligibly as controlled English or structured JSON?',
                  'Can learners transfer familiar SXP-L rules to new verbs, names, and three-turn conversation contexts?')
page=page.replace('six unscored practice items, and 27 scored questions. Approximately 15–30 minutes depending on reading speed.',
                  'ten unscored practice items, and 30 scored questions. Allow around 20–40 minutes; feel free to withdraw.')
page=page.replace('the three conditions are balanced within each arm for task and difficulty','each arm receives 10 examples per register, with two of each of five tasks per register')
page=page.replace('The three conditions are balanced within each arm for task and difficulty.',
                  'Each arm has 10 trials per register and two of each task type per register.')
page=page.replace('<div><span class="inlinecode">liva</span> love</div>',
 '<div><span class="inlinecode">liva</span> love</div><div><span class="inlinecode">luma</span> miss someone</div><div><span class="inlinecode">rava</span> reconnect with</div>')
page=page.replace('<div><span class="inlinecode">rasufe</span> explicit third-person anchor</div>',
 '<div><span class="inlinecode">rasufe</span> explicit third-person anchor</div><div><span class="inlinecode">repira gonape taba dimotu</span> explicit reply to Turn 1; <span class="inlinecode">tabe</span> names Turn 2</div>')
page=page.replace('All trials describe <strong>someone\'s report</strong>.',
                 'All trials describe a <strong>three-turn synthetic conversation</strong>. The final turn may explicitly reply to Turn 1 or Turn 2, or may not point to a prior turn at all. A reply link is not necessarily agreement. Each final clause uses liva (love), luma (miss), or rava (reconnect with).')
page=page.replace('In controlled English, read the perspective lines in order.',
                 'Always answer about the <strong>final turn</strong>, not the earlier two. The lesson example uses liva; the scored sentences combine the same grammar with luma and rava. In controlled English, read the perspective lines in order.')
page=page.replace('The 27 scored questions give no correctness feedback.',
                 'The 30 scored questions give no correctness feedback.')
page=page.replace("(Math.floor((Number(s.id.slice(1))-1)/9)+arm)","(Math.floor((Number(s.id.slice(1))-1)/10)+arm)")
page=page.replace("'1.5.0'","'1.6.0'").replace("version:'1.5.0'","version:'1.6.0'")
page=page.replace('sxpl_v15_anonymous_','sxpl_v16_anonymous_')
page=page.replace('Experimental SXP-L v1.5', 'Experimental SXP-L v1.6')
page=page.replace('six unscored','ten unscored').replace('27 scored','30 scored')
assert 'Research v1.5' not in page and 'sxpl_v15_anonymous_' not in page
assert '30 scored' in page and "1.6.0" in page
assert 'const ITEMS=' in page
assert len(public)==30 and len(prac)==10
outfile=HERE/'SXP-L_TRANSFER_STUDY_LAB_v1.6.html'
outfile.write_text(page,encoding='utf8')
print('HTML',outfile.stat().st_size,'bytes, 30 trials, 10 practices')
