# SXP-L v1.6 — Transfer instrument specification

**Change class:** evaluation, not grammar or phonology change.

## Inheritance and invariants

- `mi liva ti` remains the original compact declaration (*I love you*). The prior written/spoken `devora` terminator remains unchanged.
- All 177 files from the v1.5 sealed ZIP are mirrored byte-for-byte in this release; its archive is included separately for verification.
- The executable language interpreter is `history/sxpl_v14/perspective14.py`, a limited **text transcript parser**. SXP-L is not presently a complete human language.
- The interpreter does not establish speech authenticity, truth of attributed belief, accurate causality, or permission to act.

## Study subset

```ebnf
study_document = declarations, turn1, turn2, final_turn ;
turn1 = turn_header, simple_leaf, "tevaro" ;
turn2 = turn_header, simple_leaf, "tevaro" ;
final_turn = turn_header, [anchor], [reply], frame+, leaf, "tevaro" ;
simple_leaf = "mi", predicate, "ti", "devora" ;
leaf = "mi", predicate, ("ti" | "sivena"), "devora" ;
predicate = "liva" | "luma" | "rava" ;
frame = ("naveriko" | "belareko" | "nesaluko"), person, person ;
reply = "repira", ("gonape taba dimotu" | "gonape tabe dimotu") ;
```

All `person` references have explicit `gonape NAME dimotu` bounds. Preceding `norava` lines declare people. This grammar summarizes the **generated subset**, not every valid SXP-L sentence. Both prior turns are needed for reply-link tasks, but only the final turn carries nested viewpoint frames in this stimulus bank.

### Semantics measured

1. `holder`: local first person is bound to the **innermost frame's holder**; not the outer speaker.
2. `stance`: identifies whether the innermost frame describes reported speech, attributed belief, or not-knowing-whether.
3. `reference`: local third person is explicitly anchored, uniquely eligible, or ambiguous; ambiguity is never silently converted to a specific individual.
4. `reply`: link points to Turn 1, Turn 2, or no turn; this is discourse bookkeeping, not truth, agreement, or endorsement.
5. `predicate`: meaning of final clause's verb, selected from `liva`, `luma`, `rava`.

### Status boundary

The nested content remains speaker-attributed and unverified. No consent, authorization, or real agent execution follows from any utterance. Predicate glosses are provisional research glosses, not evidence of fully specified lexical semantics in actual use.

## Design and allocation

- `30` generated scenarios = six per task, ten per register per arm, two of each task in every register within each arm.
- Fixed deterministic stimuli built using local `random.Random(161600+i)`.
- Root tally in final clauses: `10` each of `liva`, `luma`, `rava` (verified programmatically).
- Depths range from one to three scope frames; names and frame sequences vary.
- The browser randomizes presentation order **within the fixed condition allocation**; arm A/B/C selection should be researcher-assigned, not participant preference.
- Ten practice examples are distinct full stimuli from the scored set. In contrast to scored items, practice feedback contains answers.

## Caveats

The English condition is explicitly explanatory, and JSON is structured; these are not controlled for reading length, familiarity, or demand characteristics. Because the glossary teaches `luma` and `rava`, this is **compositional transfer after instruction**, *not* zero-shot acquisition of unknown vocabulary. The three-turn transcripts are synthetic, not naturally occurring conversation. Small pilot studies can diagnose confusing instructions but cannot support general claims of superiority.
