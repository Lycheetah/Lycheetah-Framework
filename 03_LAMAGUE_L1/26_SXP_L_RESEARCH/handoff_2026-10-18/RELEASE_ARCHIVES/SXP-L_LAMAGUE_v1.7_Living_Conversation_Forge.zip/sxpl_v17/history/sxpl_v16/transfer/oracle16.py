"""Independently written restricted surface reader for v1.6 generated stimuli.
Not production parser, parses ONLY the 3-turn study subset (separate from perspective14).
"""
from __future__ import annotations
import re
from pathlib import Path
ROOTS={'naveriko':'Reported speech','belareko':'Belief','nesaluko':'Does not know whether'}
PRED={'liva':'love','luma':'miss','rava':'reconnect with'}

def read(text:str)->dict:
    lines=text.strip().split('\n');people=[];pos=0
    while pos<len(lines) and lines[pos].startswith('norava '):
        m=re.fullmatch(r'norava gonape ([a-z]+) dimotu',lines[pos]);assert m
        assert m[1] not in people;people.append(m[1]);pos+=1
    assert 3<=len(people)<=5
    turns=[]
    for num in range(3):
        m=re.fullmatch(r'taviro gonape ([a-z]+) dimotu gonape ([a-z]+) dimotu',lines[pos]);assert m
        sp,au=m.groups();assert sp in people and au in people and sp!=au;pos+=1
        anchor=None;reply=None;frames=[]
        if lines[pos].startswith('rasufe '):
            mm=re.fullmatch(r'rasufe gonape ([a-z]+) dimotu',lines[pos]);assert mm;anchor=mm[1];pos+=1
        if lines[pos].startswith('repira '):
            mm=re.fullmatch(r'repira gonape (taba|tabe) dimotu',lines[pos]);assert mm;reply=mm[1];pos+=1
        while re.match(r'^(naveriko|belareko|nesaluko) ',lines[pos]):
            mm=re.fullmatch(r'(naveriko|belareko|nesaluko) gonape ([a-z]+) dimotu gonape ([a-z]+) dimotu',lines[pos]);assert mm
            op,h,a=mm.groups();assert h in people and a in people and h!=a
            frames.append((op,h,a));pos+=1
        mm=re.fullmatch(r'mi (liva|luma|rava) (ti|sivena) devora',lines[pos]);assert mm
        predicate,target=mm.groups();pos+=1;assert lines[pos]=='tevaro';pos+=1
        if num<2:assert reply is None and anchor is None and not frames and target=='ti'
        turns.append({'speaker':sp,'addressee':au,'frames':frames,'predicate':predicate,'target':target,'anchor':anchor,'reply':reply})
    assert pos==len(lines)
    t=turns[-1];holder,addressee=(t['frames'][-1][1],t['frames'][-1][2]) if t['frames'] else (t['speaker'],t['addressee'])
    candidates=[p for p in people if p not in (holder,addressee)]
    if t['target']=='sivena':
        if t['anchor'] is not None:
            assert t['anchor'] in candidates;reference='Explicitly anchored'
        elif len(candidates)==1:reference='Only one eligible person'
        else:reference='Ambiguous / not resolved'
    else:assert t['anchor'] is None;reference=None
    return {'holder':holder.title(),'stance':ROOTS[t['frames'][-1][0]] if t['frames'] else None,
            'reference':reference,'reply':'Turn 1' if t['reply']=='taba' else ('Turn 2' if t['reply']=='tabe' else 'No explicit reply'),
            'predicate':PRED[t['predicate']]}
