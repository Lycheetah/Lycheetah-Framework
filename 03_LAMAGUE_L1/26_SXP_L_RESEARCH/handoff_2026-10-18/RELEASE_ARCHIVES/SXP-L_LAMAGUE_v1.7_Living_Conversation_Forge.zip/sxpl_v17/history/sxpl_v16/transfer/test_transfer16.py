"""Exact local checks; NO human study findings."""
import csv,copy,json,sys,tempfile,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(HERE));sys.path.insert(0,str(ROOT/'history'/'sxpl_v14'))
from build_transfer import build,record,TASKS
from oracle16 import read
from perspective14 import parse_transcript,render_transcript
from analyze_transfer import validated_sessions,summarize,FIELDS

class TransferTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.items=build()
 def test_gold_independent_reader(self):
  for x in self.items:
   self.assertEqual(x['gold'],read(x['sxpl'])[x['task']],x['id'])
 def test_round_trip_all(self):
  for x in self.items:
   self.assertEqual(render_transcript(parse_transcript(x['sxpl'])),x['sxpl']+'\n')
 def test_three_turns_and_heldout(self):
  self.assertEqual(len(self.items),30)
  self.assertEqual({t:sum(x['task']==t for x in self.items) for t in TASKS},dict.fromkeys(TASKS,6))
  self.assertEqual({p:sum(x['lexical_root']==p for x in self.items) for p in ['liva','luma','rava']},{'liva':10,'luma':10,'rava':10})
  for x in self.items:self.assertEqual(len(parse_transcript(x['sxpl'])['turns']),3)
 def test_comparators(self):
  for x in self.items:
   y=json.loads(x['json'])
   self.assertEqual(y['turns'][-1]['final_clause']['predicate'],x['lexical_root'])
   self.assertIn('All speech, beliefs',x['english'])
 def test_public_has_no_scored_answers(self):
  data=json.loads((HERE/'participant_items_v1.6.json').read_text())
  self.assertEqual(len(data),30)
  self.assertTrue(all('gold' not in x and 'semantic' not in x for x in data))
  html=(HERE/'SXP-L_TRANSFER_STUDY_LAB_v1.6.html').read_text()
  self.assertNotIn('ANSWER_KEY_ORGANIZER_ONLY',html)
  self.assertNotIn('correct_answer',html)
  self.assertNotIn('items_private',html)
 def test_conditions_by_arm(self):
  for arm in range(3):
   for t in TASKS:
    counts={r:sum(x['task']==t and ['sxpl','english','json'][(((int(x['id'][1:])-1)//10)+arm)%3]==r for x in self.items) for r in ['sxpl','english','json']}
    self.assertEqual(set(counts.values()),{2})
 def test_mutated_reply_rejected(self):
  x=self.items[0]['sxpl']
  y=x.replace('repira gonape taba dimotu','repira gonape tabo dimotu')
  with self.assertRaises(Exception):parse_transcript(y)
 def test_mutated_undeclared_name_rejected(self):
  x=self.items[1]['sxpl'];y=x.replace('taviro gonape','taviro gonape unknown dimotu gonape',1)
  with self.assertRaises(Exception):parse_transcript(y)
 def test_mutated_unknown_predicate_rejected(self):
  x=self.items[2]['sxpl'];y=x.replace(' mi liva ',' mi mystery ') if ' mi liva ' in x else x.replace('mi liva ti devora','mi mystery ti devora')
  if y==x:y=x.replace('mi '+self.items[2]['lexical_root'],'mi mystery')
  with self.assertRaises(Exception):parse_transcript(y)
 def test_no_practice_overlap(self):
  from build_lab16 import practice
  self.assertEqual(len(practice),10)
  self.assertFalse(set(x['sxpl'] for x in practice)&set(x['sxpl'] for x in self.items))
 def test_fake_csv_pipeline_and_corruption(self):
  rows=[]
  for idx,x in enumerate(self.items,1):
   reg=['sxpl','english','json'][((idx-1)//10)%3]
   rows.append(dict(version='1.6.0',session='SIMULATED_INTERNAL',arm='A',seed='1616',trial_index=str(idx),item_id=x['id'],task=x['task'],condition=reg,difficulty=str(x['difficulty']),response=x['gold'],confidence='3',elapsed_ms='1000'))
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'fake.csv'
   with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
   with self.assertRaises(ValueError):validated_sessions([p])
   results=validated_sessions([p],allow_synthetic=True)
   self.assertEqual(len(results),1)
   self.assertAlmostEqual(summarize(results)['by_condition']['sxpl']['participant_mean_accuracy'],1)
   rows[0]['condition']='json'
   with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
   with self.assertRaises(ValueError):validated_sessions([p],allow_synthetic=True)
 def test_original_phrase(self):
  import roots
  self.assertEqual(roots.ROOTS['love'],'liva')

if __name__=='__main__':unittest.main()
