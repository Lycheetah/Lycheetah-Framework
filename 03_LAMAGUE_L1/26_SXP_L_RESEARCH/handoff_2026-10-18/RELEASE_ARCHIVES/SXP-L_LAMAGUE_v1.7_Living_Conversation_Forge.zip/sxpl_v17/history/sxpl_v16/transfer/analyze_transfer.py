"""Organizer-side SXP-L v1.6 scorer, standard library only.

Uses a separate private answer key, validates assignment and duplicate trials.
Human claims are impossible from bundled synthetic fixtures without an explicit flag.
No significance assertions, no claim of equal novice experience or publication readiness.
"""
from __future__ import annotations
import argparse,collections,csv,json,random,statistics,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
FIELDS=['version','session','arm','seed','trial_index','item_id','task','condition','difficulty','response','confidence','elapsed_ms']
REG=['sxpl','english','json']

def validated_sessions(paths,allow_synthetic=False):
    key={x['id']:x for x in json.loads((HERE/'ANSWER_KEY_ORGANIZER_ONLY_v1.6.json').read_text())}
    items={x['id']:x for x in json.loads((HERE/'participant_items_v1.6.json').read_text())}
    sessions=[];seen_sessions=set()
    for p in paths:
        with Path(p).open(newline='',encoding='utf-8-sig') as f:
            reader=csv.DictReader(f)
            if reader.fieldnames != FIELDS:raise ValueError(f'{p}: wrong CSV columns')
            rows=list(reader)
        if not rows:raise ValueError(f'{p}: no responses')
        s=rows[0]['session'];a=rows[0]['arm'];seed=rows[0]['seed']
        if not s.startswith('SXPL-') and not (allow_synthetic and s.startswith('SIMULATED_')):
            raise ValueError(f'{p}: nonstandard session ID (synthetic fixtures require --allow-synthetic)')
        if s in seen_sessions:raise ValueError(f'{p}: repeated session id')
        seen_sessions.add(s)
        if a not in 'ABC' or len(a)!=1:raise ValueError(f'{p}: invalid arm')
        if not seed.isdecimal() or int(seed)>2**32-1:raise ValueError(f'{p}: invalid seed')
        if len(rows)!=len(items):raise ValueError(f'{p}: incomplete session ({len(rows)}/{len(items)} trials)')
        byid={}
        seen_indices=set()
        for r in rows:
            if not r['trial_index'].isdigit() or not 1<=int(r['trial_index'])<=len(items) or int(r['trial_index']) in seen_indices:
                raise ValueError(f'{p}: invalid/duplicate trial_index')
            seen_indices.add(int(r['trial_index']))
            if (r['session'],r['arm'],r['seed'],r['version'])!=(s,a,seed,'1.6.0'):
                raise ValueError(f'{p}: inconsistent session columns')
            iid=r['item_id']
            if iid not in items or iid in byid:raise ValueError(f'{p}: missing/duplicate item {iid}')
            x=items[iid]
            expected=REG[(((int(iid[1:])-1)//10)+'ABC'.index(a))%3]
            if (r['condition'],r['task'],r['difficulty'])!=(expected,x['task'],str(x['difficulty'])):
                raise ValueError(f'{p}: inconsistent condition/task/difficulty for {iid}')
            if r['response'] not in x['options']+['Unsure']:raise ValueError(f'{p}: invalid response for {iid}')
            if r['confidence'] not in ('','1','2','3','4','5'):raise ValueError(f'{p}: invalid confidence')
            if not r['elapsed_ms'].isdigit() or int(r['elapsed_ms'])>3_600_000:raise ValueError(f'{p}: invalid elapsed time')
            r['correct']=int(r['response']==key[iid]['correct_answer'])
            byid[iid]=r
        if len(byid)!=len(items) or seen_indices != set(range(1,len(items)+1)):
            raise ValueError('missing item or trial index')
        sessions.append({'session':s,'arm':a,'rows':rows,'file':str(p)})
    return sessions

def ci(values,rng,n=2000):
    if len(values)<5:return None
    means=[]
    for _ in range(n):means.append(sum(rng.choice(values) for x in values)/len(values))
    means.sort()
    return [round(means[int(.025*n)],3),round(means[int(.975*n)-1],3)]

def summarize(sessions):
    rng=random.Random(1515)
    people=[]
    for s in sessions:
        means={cond:statistics.mean(r['correct'] for r in s['rows'] if r['condition']==cond) for cond in REG}
        people.append({'session':s['session'],'arm':s['arm'],'scores':means,'overall':statistics.mean(r['correct'] for r in s['rows'])})
    key={x['id']:x for x in json.loads((HERE/'ANSWER_KEY_ORGANIZER_ONLY_v1.6.json').read_text())}
    summary={'study':'SXP-L v1.6','status':'DESCRIPTIVE PILOT OUTPUT ONLY',
             'sessions':len(sessions),'assignment_counts':dict(collections.Counter(s['arm'] for s in sessions)),
             'trials':sum(len(s['rows']) for s in sessions),'by_condition':{},'paired_differences':{},
             'by_task':{},'by_predicate':{},'cautions':['This is not evidence of language superiority without independent participants, pre-registered design, and valid inference.',
                'All trials are bounded constructed scenarios, not real conversational comprehension.',
                'Order/timing are browser-dependent, and the participant may have prior SXP-L familiarity.',
                'Controlled English and JSON are not neutral baselines; language and task familiarity matter.']}
    for cond in REG:
        vals=[p['scores'][cond] for p in people]
        summary['by_condition'][cond]={'participant_mean_accuracy':round(statistics.mean(vals),3),
          'per_person_scores':{p['session']:round(p['scores'][cond],3) for p in people},
          'bootstrap_95pct_CI_if_n_ge_5':ci(vals,rng)}
    for a,b in [('sxpl','english'),('sxpl','json')]:
        vals=[p['scores'][a]-p['scores'][b] for p in people]
        summary['paired_differences'][a+' minus '+b]={'participant_mean_difference':round(statistics.mean(vals),3),
          'bootstrap_95pct_CI_if_n_ge_5':ci(vals,rng)}
    for task in ['holder','stance','reference','reply','predicate']:
        for cond in REG:
            rows=[r for s in sessions for r in s['rows'] if r['task']==task and r['condition']==cond]
            summary['by_task'][task+'/'+cond]={'correct':sum(r['correct'] for r in rows),'n':len(rows)}
    for predicate in ['liva','luma','rava']:
        for cond in REG:
            rows=[r for s in sessions for r in s['rows'] if key[r['item_id']]['lexical_root']==predicate and r['condition']==cond]
            summary['by_predicate'][predicate+'/'+cond]={'correct':sum(r['correct'] for r in rows),'n':len(rows)}
    summary['lexical_transfer_note']='luma and rava are taught via a glossary but not shown in the worked liva example; this probes recombination after explicit instruction, not zero-shot word discovery.'
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('files',nargs='+',help='One exported participant CSV per file');ap.add_argument('--allow-synthetic',action='store_true',help='Allow bundled test fixtures, not for human research reporting');ap.add_argument('--out',help='write JSON report')
    args=ap.parse_args()
    try:
        sess=validated_sessions(args.files,args.allow_synthetic)
        report=summarize(sess)
        if any(s['session'].startswith('SIMULATED_') for s in sess):report['status']='SYNTHETIC PIPELINE TEST — NO HUMAN RESULTS'
        result=json.dumps(report,indent=2)+'\n'
        if args.out:Path(args.out).write_text(result)
        print(result)
    except (ValueError,OSError,KeyError,ZeroDivisionError) as e:
        print(f'ERROR: {e}',file=sys.stderr);sys.exit(2)
