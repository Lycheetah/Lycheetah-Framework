# SXP-L v1.6 — Reproducible local evidence

**Research status: instrument/engineering QA only, 18 October 2026.** **Human participants: 0.** No claims about human speed, accuracy, transfer success, spoken comprehension, or advantage over an established language.

## Confirmed local checks

| Test | Observed | Interpretation |
|---|---:|---|
| New v1.6 Python suite | **12/12 passed** | Bank integrity, new parser-generated stimuli, allocation, mutated-input rejection, scorer verification, phrase continuity |
| Focused inherited v1.5 study suite | **15/15 passed** | Regression of prior instrument's generator/scorer behavior |
| Focused inherited v1.4 perspective suite | **13/13 passed** | Regression of prior scope/reference parser behavior |
| Total of those **separately run** unit tests | **40/40 passed** | **Not** a rerun of every historical version's test suite |
| Matched scored items accepted by inherited v1.4 parser | **30/30** | All parse and render their source text identically |
| Restricted independent `oracle16` versus answer key | **30/30 agree** | Agreement on bounded surface semantics, not human comprehension |
| New scored items per condition in each arm | **10** | All three arms balanced for register; two each task per register |
| Predicate roots in final clause | **10 liva / 10 luma / 10 rava** | Balanced across the complete 30-item bank |
| Browser end-to-end, arm B | **10 practice + 30 scored + CSV export** | CSV contained 30 scored rows; no detected script errors |
| Browser UI, A/B/C | **all passed** | Each arm completed 10 practice, 30 scored, saw 10/register, could erase in-memory data; 0 reported script errors |
| Export scorer synthetic policy | **passed** | Simulated identifier requires explicit `--allow-synthetic`; malformed condition rejected |

## Commands to reproduce

```bash
cd transfer
python build_transfer.py
python build_lab16.py
python -m unittest -q test_transfer16
python browser_smoke_test_v16.py
python browser_all_arms_qa.py
python analyze_transfer.py SIMULATED_BROWSER_QA.csv --allow-synthetic --out SYNTHETIC_QA_REPORT.json
cd ../study && python -m unittest -q test_study15
cd ../history/sxpl_v14 && python -m unittest -q test_perspective14
```

`browser_smoke_test_v16.py` uses Playwright and system Chromium; all other tests use Python standard library with inherited local modules. The local browser environment used `set_content` (not a user browser/device field test). Synthetic CSV scores have no interpretation as volunteer performance.

## Methodological limitations

1. The task tests compositional recombination of existing words **after providing their meanings in the glossary**, rather than unknown word acquisition or spontaneous dialogue generation.
2. A three-turn text transcript is not the same thing as conversational language use; explicit per-turn parser syntax simplifies interpretation.
3. The controlled-English condition narrates semantic fields explicitly; JSON and SXP-L have different length, familiarity, and formatting. Any future difference in accuracy will be confounded unless trial and instruction design are improved.
4. Only the last turn is scored. Earlier turns affect the reply task, but most stance and reference checks can be answered from the last turn alone.
5. The independently coded oracle is a limited grammar reader, not a third-party expert or full independent language implementation.
6. Anonymized export cannot certify volunteer identity or prevent reuse/replay of sessions. Local data can still become identifiable through outside context.
7. Full project archive includes organizer keys from both v1.5 and v1.6; **never give the complete ZIP to participants**.
8. No prespecified power analysis, preregistration, or independent methodological/ethics approval is claimed.

## Continuity

`mi liva ti` is unchanged. No v1.6 grammar root or parser rule was added. Previous v1.5 release file contents are preserved in the archive and verified through SHA-256 against the sealed v1.5 ZIP. No external agent action or authentication decision has been deployed.
