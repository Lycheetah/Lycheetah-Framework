"""SXP-L v1.6, test-bank generator for COMPOSITIONAL TRANSFER (not a human result).

Every stimulus is accepted by inherited v1.4 parser and round-trip renderer.
The three formats are text representations of the same bounded *reported* semantics.
The organizer's key must never be given to participants.
"""
from __future__ import annotations
import json,random,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'history'/'sxpl_v14'))
from perspective14 import parse_transcript,render_transcript
from continuity13 import turn_id

NAMES=['maka','nara','sela','vera','rovena','tamara']
PRED={'liva':'love','luma':'miss','rava':'reconnect with'}
FRAMES={'naveriko':'Reported speech','belareko':'Belief','nesaluko':'Does not know whether'}
TASKS=['holder','stance','reference','reply','predicate']
Q={'holder':'Who does “mi” (I) refer to in the final clause?',
 'stance':'What kind of attributed perspective directly surrounds the final clause?',
 'reference':'How is the third-person reference in the final clause resolved?',
 'reply':'Which earlier turn does the final turn explicitly reply to?',
 'predicate':'What action or relationship does the final clause express?'}
OPTS={'stance':list(FRAMES.values()),
 'reference':['Explicitly anchored','Only one eligible person','Ambiguous / not resolved'],
 'reply':['Turn 1','Turn 2','No explicit reply'],
 'predicate':['love','miss','reconnect with']}
REFERENCE={'explicit_anchor':'Explicitly anchored','unique_candidate':'Only one eligible person','ambiguous':'Ambiguous / not resolved','unresolved':'Ambiguous / not resolved'}

def record(i:int)->dict:
    # stable, audited deterministic construction; i=0..29 scored; 30+ practice
    task=TASKS[i%len(TASKS)];k=i//len(TASKS);ti=TASKS.index(task)
    rng=random.Random(161600+i)
    num=3 if k%3==0 else 4 if k%3==1 else 5
    people=rng.sample(NAMES,num)
    outer_speaker,outer_addressee=rng.sample(people,2)
    depth=k%3+1
    # change predicate AND nesting depth independently within each condition block
    root=list(PRED)[(ti+k//3+k%3)%3]
    # final turn reference is a third person only in reference task
    pronoun='sivena' if task=='reference' else 'ti'
    anchor=None
    frames=[]
    for d in range(depth):
        op=['naveriko','belareko','nesaluko'][(ti+k+d)%3]
        holder,addressee=rng.sample(people,2)
        frames.append((op,holder,addressee))
    if task=='stance':
        op=['naveriko','belareko','nesaluko'][(k+ti)%3]
        frames[-1]=(op,*frames[-1][1:])
    local_mi,local_ti=frames[-1][1:]
    if task=='reference' and k%3==1:
        anchor=rng.choice([p for p in people if p not in (local_mi,local_ti)])
    # first two conversation turns are natural-looking but formally bounded.
    # Never infer agreement/endorsement from the reply edge.
    t1speaker,t1audience=rng.sample(people,2)
    t2speaker,t2audience=rng.sample(people,2)
    final_reply=turn_id(1 if k%3==0 else 2) if k%3!=2 else None
    first_root=['liva','luma','rava'][(k+1)%3]
    second_root=['liva','luma','rava'][(k+2)%3]
    lines=[f'norava gonape {p} dimotu' for p in people]
    lines.extend([f'taviro gonape {t1speaker} dimotu gonape {t1audience} dimotu',
                  f'mi {first_root} ti devora','tevaro',
                  f'taviro gonape {t2speaker} dimotu gonape {t2audience} dimotu',
                  f'mi {second_root} ti devora','tevaro',
                  f'taviro gonape {outer_speaker} dimotu gonape {outer_addressee} dimotu'])
    if anchor:lines.append(f'rasufe gonape {anchor} dimotu')
    if final_reply:lines.append(f'repira gonape {final_reply} dimotu')
    for op,h,a in frames:lines.append(f'{op} gonape {h} dimotu gonape {a} dimotu')
    lines.extend([f'mi {root} {pronoun} devora','tevaro'])
    sxpl='\n'.join(lines)+'\n'
    doc=parse_transcript(sxpl)
    assert render_transcript(doc)==sxpl
    last=doc['turns'][-1]
    assert len(doc['turns'])==3
    assert last['leaf_roles']['mi']==local_mi and last['leaf_roles']['ti']==local_ti
    assert last['reply_to']==final_reply
    assert last['reference']['status'] in REFERENCE or last['reference']['status']=='not_applicable'
    if task=='holder':options=[p.title() for p in people];gold=local_mi.title()
    elif task=='stance':options=OPTS[task];gold=FRAMES[frames[-1][0]]
    elif task=='reference':options=OPTS[task];gold=REFERENCE[last['reference']['status']]
    elif task=='reply':options=OPTS[task];gold='No explicit reply' if final_reply is None else ('Turn 1' if final_reply==turn_id(1) else 'Turn 2')
    else:options=OPTS[task];gold=PRED[root]
    assert gold in options
    # Human-controlled comparator—note these explicit, explanatory lines do not
    # simulate ordinary English dialogue and can be easier than the SXP-L form.
    en=[f'Declared people: {", ".join(p.title() for p in people)}.',
        f'Turn 1: {t1speaker.title()} addresses {t1audience.title()} and says "I {PRED[first_root]} you."',
        f'Turn 2: {t2speaker.title()} addresses {t2audience.title()} and says "I {PRED[second_root]} you."',
        f'Turn 3: {outer_speaker.title()} addresses {outer_addressee.title()}.',
        'Turn 3 replies to '+('no explicitly named earlier turn.' if final_reply is None else ('Turn 1.' if final_reply==turn_id(1) else 'Turn 2.'))]
    if anchor:en.append(f'Turn 3 explicitly anchors the final third-person reference to {anchor.title()}.')
    for d,(op,h,a) in enumerate(frames,1):
        en.append(f'Attributed perspective {d}: {FRAMES[op]} held by {h.title()}, addressed locally to {a.title()}.')
    en.append(f'Final clause: "I {PRED[root]} '+('a third person.' if pronoun=='sivena' else 'you.')+'"')
    en.append('All speech, beliefs and reference assignments are unverified reports, never permissions.')
    english='\n'.join(en)
    obj={'participants':people,'turns':[
            {'speaker':t1speaker,'addressee':t1audience,'predicate':first_root,'target':'ti','reply_to':None},
            {'speaker':t2speaker,'addressee':t2audience,'predicate':second_root,'target':'ti','reply_to':None},
            {'speaker':outer_speaker,'addressee':outer_addressee,'reply_to':final_reply,
             'third_person_anchor':anchor,
             'frames':[{'kind':FRAMES[op],'holder':h,'local_addressee':a} for op,h,a in frames],
             'final_clause':{'subject':'mi','predicate':root,'target':pronoun}}],
         'authorization':False,'claims_verified':False}
    return {'id':f'T{i+1:02}', 'task':task,'difficulty':depth,'lexical_root':root,
            'question':Q[task],'options':options,'gold':gold,
            'sxpl':sxpl.strip(),'english':english,'json':json.dumps(obj,ensure_ascii=False,indent=2),
            'semantic':{'last_leaf_roles':last['leaf_roles'],'reference':last['reference'],
                        'reply_to':last['reply_to'],'predicate':root,'authorizes':False}}

def build():
    items=[record(i) for i in range(30)]
    assert len({x['id'] for x in items})==30
    assert {t:sum(x['task']==t for x in items) for t in TASKS}==dict.fromkeys(TASKS,6)
    for arm in range(3):
        for task in TASKS:
            reg=lambda x:(['sxpl','english','json'][((int(x['id'][1:])-1)//10+arm)%3])
            # Each contiguous block has 2 instances of each task
            counts={r:sum(x['task']==task and reg(x)==r for x in items) for r in ['sxpl','english','json']}
            assert counts=={'sxpl':2,'english':2,'json':2},counts
        counts={r:sum(['sxpl','english','json'][((int(x['id'][1:])-1)//10+arm)%3]==r for x in items) for r in ['sxpl','english','json']}
        assert counts=={'sxpl':10,'english':10,'json':10}
    return items

def main():
    items=build();HERE.mkdir(exist_ok=True)
    priv=HERE/'items_private_v1.6.json';priv.write_text(json.dumps(items,indent=2,ensure_ascii=False)+'\n')
    key=[{'id':x['id'],'task':x['task'],'correct_answer':x['gold'],'difficulty':x['difficulty'], 'lexical_root':x['lexical_root']} for x in items]
    (HERE/'ANSWER_KEY_ORGANIZER_ONLY_v1.6.json').write_text(json.dumps(key,indent=2,ensure_ascii=False)+'\n')
    public=[{k:x[k] for k in ('id','task','difficulty','question','options','sxpl','english','json')} for x in items]
    (HERE/'participant_items_v1.6.json').write_text(json.dumps(public,indent=2,ensure_ascii=False)+'\n')
    print(f'Built {len(items)} distinct matched items, gold keys kept separate')
if __name__=='__main__':main()
