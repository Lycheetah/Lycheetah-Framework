# v1.7 Meaning Loss Ledger

| Channel / operation | Preserved? | Evidence / mitigation |
|---|---|---|
| `mi liva ti` in compact leaf | Yes | Same canonical tokens as v1.4; regression test. |
| Outer speaker / addressee | Yes | Inherited parsed `taviro` identities. |
| Perspective holder, local `mi`/`ti` | Yes | Inherited v1.4 frame resolution. |
| Ambiguous `sivena` | Yes (as unresolved) | Explicit candidate list; no recency guessing. |
| Reply target `@k` | Yes, in `.sxh` | Inherited `repira` token + sidecar. |
| Clarification request `?k` | **No, in `.sxh` alone** | v1.7 sidecar stores distinct metadata, hash verified. |
| Self-correction `~k` | **No, in `.sxh` alone** | v1.7 sidecar retains the original and `corrected_by` index. |
| Whether a clarification leaf is grammatically a question | **Not established** | Repair metadata is an author intention, not a spoken interrogative. |
| Whether a correction is sincere / authorized by real speaker | **Not established** | Text identities are unverified. |
| Real-world truth / emotional state | **Not established** | Parsed statements remain speaker-attributed assertions. |
| Human comprehension of repair notation | **Not measured** | An independent participant study remains necessary. |
| Sound quality / pronunciation | **Not measured** | This is a punctuation-based authoring notation, not spoken grammar. |

**Critical lesson:** We do not label an export lossless when semantic distinctions are preserved only in a separate artifact. We name the missing distinctions explicitly and require the sidecar to reconstruct the complete Studio meaning.
