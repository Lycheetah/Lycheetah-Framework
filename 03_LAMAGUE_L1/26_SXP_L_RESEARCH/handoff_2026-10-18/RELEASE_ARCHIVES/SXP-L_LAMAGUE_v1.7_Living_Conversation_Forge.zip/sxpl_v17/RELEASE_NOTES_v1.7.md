# SXP-L × LAMAGUE v1.7 — Living Conversation Forge

**Added:** a human-writable authoring shorthand (Studio), explicit metadata-only clarification and self-correction relationships, an append-only legacy transcript + SHA-256-bound sidecar, a loss-of-meaning report, a browser editing/learning preview, a five-turn example, unit tests, and an Argon audit brief.

**Preserved:** `mi liva ti`; old sentence syntax, nested viewpoint and third-person rules; all 199 v1.6 files and a pristine copy of the v1.6 release archive.

**Not added:** a new spoken correction grammar, speech recognition, verified sentiment, new vocabulary, verified speaker identity, or automatic authorization.

**Tests observed:** 18 new + 13 v1.4 focused + 12 v1.6 focused = 43 methods passed across separate runs, including one method generating 600 conversations. Browser export and script passed a real headless Chromium check.

**Next:** native grammatical repair and human learning evidence before any language-power superiority claim.
