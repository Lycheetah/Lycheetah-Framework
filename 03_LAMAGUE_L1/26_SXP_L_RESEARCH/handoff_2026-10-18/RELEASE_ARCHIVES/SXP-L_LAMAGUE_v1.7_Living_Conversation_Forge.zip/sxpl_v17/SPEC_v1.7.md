# SXP-L v1.7 — Conversation Studio Notation (CSN), bounded specification

**Research status: experimental, not SXP-L's canonical spoken grammar.**

## 1. Layers

1. **SXP-L leaf:** an unchanged canonical v1.4-compatible utterance, such as `mi liva ti devora`.
2. **SXP-L v1.4 transcript:** explicit speakers, addressees, optional viewpoint frames, and optional `repira` references.
3. **CSN authoring layer (new):** punctuation-based short lines, corrections and clarification requests.
4. **Semantic sidecar (new):** reconstructable JSON preserving authoring act distinctions that cannot be carried by v1.4 `.sxh` alone.

Every CSN turn is verified against the historical v1.4 parser. A renderer must not silently translate unsupported vocabulary or erase uncertainty.

## 2. Grammar (subset)

```ebnf
document = "people", SP, name, SP, name, {SP, name}, NL, turn, {NL, turn};
turn = name, SP, ">", SP, name, SP, {modifier, SP}, ":", SP, leaf;
modifier = reply | clarify | correct | anchor | viewpoint;
reply = "@", positive_integer;
clarify = "?", positive_integer;
correct = "~", positive_integer;
anchor = "#", name;
viewpoint = "^", ("belareko" | "naveriko" | "nesaluko"), "(", name, ",", name, ")";
leaf = canonical_v1.4_expression_without_terminal_devora;
```

`leaf` in v1.7 authoring is still parsed by the inherited grammar, not by an English parser. The Studio preview only recognizes a three-predicate subset (`liva`, `luma`, `rava`). Both `devora`-terminated and unterminated leaves are accepted by the Python authoring tool; normalized legacy output always carries the terminator.

One modifier among `@`, `?`, `~` is allowed per turn; only one anchor; up to six nested viewpoint frames. Every link must reference an earlier turn. Names must be declared and pronounced within the historical literal-name subset. Maximum: 16 named people, 35 turns, 32,000 characters, 150 nonempty lines.

## 3. Operational semantics

- `@k`: reply-to metadata only; no entailment of support, disagreement or truth.
- `?k`: speaker reports a wish to clarify turn `k`; authoring-act metadata only. It is **not** evidence that the leaf is an interrogative sentence. Only permitted when the linked turn has a different outer speaker.
- `~k`: same speaker declares a replacement of their own earlier turn `k`. The original is retained, marked `corrected_by`, and still visible. Repeating a correction to the *same* turn is rejected; to revise the replacement, target the replacement turn.
- `#p`: explicit third-person anchor for local `sivena` when valid; otherwise inherited parser rejects.
- `^kind(holder,addressee)`: reported perspective frame; binds local `mi`/`ti` according to the innermost frame; remains speaker-attributed and unverified.

**Meaning-loss rule:** v1.4 `repira` represents `@k`, `?k`, and `~k` identically. Exporting only `conversation.sxh` necessarily discards the two distinct repair intentions. Therefore full v1.7 semantic preservation requires `conversation.sxh` **and** `conversation.sxpl17.json`, verified by exact SHA-256 matching and semantic replay. This is integrity checking, **not cryptographic signature verification**.

## 4. Invariants

- `mi liva ti` unchanged; no new pronunciation or root replacements.
- Corrections never erase earlier turns, never make a reported claim true and never authenticate a real person's words.
- All third-person referents remain ambiguous if inherited v1.4 determines more than one candidate.
- No authoring token or transcript grants executable authority.
- Reparsed/re-serialized v1.4 transcript must agree exactly with its canonical form.
- Tampered sidecars or mismatched transcript bytes are rejected; sidecar is not an identity credential.

## 5. Known unsupported language phenomena

Natural spontaneous pronouns, free-form speech repair, self-interruption, multi-clause elliptical fragments, sarcasm, implicit questions, vocal stress, hedges, quoted laughter, and cultural pragmatics. Those require new language research, not a hidden English translation layer.
