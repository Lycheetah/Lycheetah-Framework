"""Convenience entrypoint: launch the Studio compiler with vendored v1.4 imports."""
from pathlib import Path
import runpy
import sys
path=Path(__file__).resolve().parent/'history'/'sxpl_v16'/'history'/'sxpl_v14'
if not path.is_dir():
    raise SystemExit('Historical v1.4 dependency missing; use complete v1.7 release')
sys.path.insert(0,str(path))
runpy.run_module('studio17',run_name='__main__')
