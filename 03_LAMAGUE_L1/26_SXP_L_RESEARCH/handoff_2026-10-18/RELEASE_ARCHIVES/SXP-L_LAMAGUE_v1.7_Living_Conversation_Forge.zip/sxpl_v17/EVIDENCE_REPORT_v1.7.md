# SXP-L × LAMAGUE v1.7 — Engineering evidence report

**Maturity:** bounded experimental text authoring. **Date:** 2026-10-18. No real participant study, no acoustic evidence, no permission deployment.

## Source of truth

- Original historical baseline: `history/RELEASE_v1.6_ORIGINAL.zip` and `history/sxpl_v16/`.
- Underlying formal grammar: untouched `history/sxpl_v16/history/sxpl_v14/perspective14.py`.
- New authoring adapter: `studio17.py`; local executable tests: `test_studio17.py`.
- Browser preview: `LEARNER_LAB_v1.7.html`, limited to three predicates and bounded role structures.

## Confirmed local results

| Verification | Observation |
|---|---|
| New v1.7 Python tests | **18/18 test methods passed**, including 600 deterministic randomly generated conversations compiled and verified via legacy transcript and sidecar. |
| Inherited v1.4 focus tests | **13/13 methods passed**. |
| Inherited v1.6 transfer-study tests | **12/12 methods passed**. |
| Aggregate | **43/43 observed test methods**, separately run; not a claim of 43 independent studies. |
| Browser | Headless Chromium checked initial five-turn case, a one-turn edit, unsupported `jiva` rejection, restoring the original example, exporting a `.studio` file and zero JS errors. Screenshot in `BROWSER_QA_v1.7.png`. |
| v1.6 conservation | **199/199 inherited archive files byte-for-byte unchanged** relative to `RELEASE_v1.6_ORIGINAL.zip`; prior ZIP is retained. |
| Repair fidelity | Legacy `.sxh` has only `repira` links. v1.7 paired sidecar distinguishes a correction from clarification request; `verify_pair` rejects mismatched hashes or unauthorized semantic edits in the checked schema. |

## Deliberately *not* established

1. The authored `?` and `~` markers are *not* new linguistic spoken operators: in `.sxh` they collapse to an ordinary reply. The source plus sidecar preserves them, but the **old transcript alone is lossy**.
2. This prototype has **not** tested comprehension with human learners. All generated fixtures are synthetic.
3. Browser preview and Python validator are not equivalent: the browser intentionally supports a smaller expression subset and cannot verify signed provenance.
4. SHA-256 checksum consistency does **not** authenticate a person, signing authority or original speech; anyone who can alter both files can recompute a matching hash.
5. Textual perspective scope does not prove that someone holds a belief or that a claimed explanation is causally true.
6. No live agent action, external permission, conversation data upload, or official LAMAGUE vocabulary revision was made.

## How to reproduce

```bash
cd sxpl_v17
PYTHONPATH=history/sxpl_v16/history/sxpl_v14 python -m unittest -v test_studio17
PYTHONPATH=history/sxpl_v16/history/sxpl_v14 python studio17.py examples/repair_and_viewpoint.studio --out examples/compiled_check
```

Prior tests can be reproduced from `history/sxpl_v16/history/sxpl_v14` with `python -m unittest -q test_perspective14` and from `history/sxpl_v16` with `PYTHONPATH=history/sxpl_v14 python -m unittest -q transfer.test_transfer16`.

## Evaluation priority

We should now test whether independent readers understand `?k` / `~k` before expanding into a native pronounceable system. A valid v1.8 research question is **whether paired structured repair metadata reduces mistaken interpretation of corrections in multi-person transcripts relative to a generic reply link**, under fair training conditions. Without a human baseline, this remains a hypothesis.
