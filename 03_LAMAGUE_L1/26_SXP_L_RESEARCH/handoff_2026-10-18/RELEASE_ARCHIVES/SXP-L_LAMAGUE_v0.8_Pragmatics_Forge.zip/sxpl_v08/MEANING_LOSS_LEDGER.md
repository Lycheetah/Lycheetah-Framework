# Meaning-Loss Ledger — v0.8

This ledger describes **bounded detectable meaning changes**, not a proof of natural-language equivalence.

| Contrast | Preserved by typed AST? | Claim boundary |
|---|---|---|
| "I want to stay" vs "I intend to stay" | Yes: `stance: desire` vs `intention` | Does not establish action occurred |
| "I hope to stay" vs "I will stay" | Yes: `attitude_report` vs `proposition` | Hope doesn't entail expectation or occurrence |
| "I promise to stay" vs "I intend to stay" | Yes: `promise_report` vs `attitude_report` | Promise record not proven commitment validity |
| "I'm not promising" vs "I can't promise" | Yes: negative `promise_report` vs negative `capacity_report` | Capacity not independently verified |
| "I can promise" vs "I have promised" | Yes: capability report vs promise report | Different asserted act status |
| "I won't stay" vs "I can't promise to stay" | Yes: negative future proposition vs negative capacity report | Nothing infers future event |
| "If I stay, you stay" vs "You will stay" | Yes: `conditional` vs `proposition` | Neither conditional branch asserted in isolation |
| Speaker A corrected their statement | Yes: `repair` relation preserves both utterances | No truth evaluation of old or replacement |
| "The document says" vs verified evidence | Partial: `evida document_claim` + `verified:false` | No actual source inspection or provenance authentication |
| Spoken v0.7 `mi` vs named participant | Grounded only in valid dialogue roster | The system cannot verify speaker identity outside supplied transcript |
| Relationship implied by context | **Not supported** | Must not infer love, consent, kinship from sparse wording |
| "I cannot" (moral vs physical vs social) | **Not distinguished** | v0.8 `kapera` is underspecified |
| Natural speech segmentation and acoustic collisions | **Not measured** | Text codec operates on separated words |
| Metaphor / irony / unsaid implications | **Not supported** | Do not force literal interpretations |

Use `python meaning_diff.py "sentence one" "sentence two"` to inspect changed AST paths. The diff is structural: equality within the typed schema is not proof that the two utterances have equivalent human meaning.
