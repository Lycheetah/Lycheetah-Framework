# v0.8 Release Notes — Pragmatics Forge

**Built:** 2026-10-17. **Status:** tested local research release.

### What actually changed

- First distinct expressive constructions for desire (`vanira`), intention (`nivara`), positive or negated promise (`pamisa`), and claimed capacity/inability to promise (`kapera`), plus hope/fear/belief/knowledge-claim scopes when paired with new `satoma` predicate.
- One new unary verb `satoma` (*stay*) and an explicit if/then frame `sivane ... tanaro ...` that does not independently assert either part.
- v0.8 typed pragmatic ASTs and exact normalized parse/render round trips, without mutating prior v0.3 canonical AST meanings.
- Dialogue-level repair (`repara`) and self-attributed provenance (`evida`), both append-only in the parsed transcript.
- `meaning_diff.py` displays structural semantic differences (including missing vs null fields), with cautious language around its limits.
- Offline HTML practice lab and practical evaluation protocol for *future* human testing.
- Existing v0.2–v0.7 tests retained and passing.

### Changes we rejected

- The draft root `sata` conflicted at single-letter distance with existing `sada` and `sava`. Replaced with `satoma`, without changing the underlying canonical predicate `stay`.
- Refused to represent a promise as a verified authorization, a future event as already real, a claimed source as authenticated evidence, or a speaker-supplied `because` link as established causation.

### Evidence summary

60 unittest methods passed (34 retained + 26 v0.8); 2,500 newly generated v0.8 phrase cases; zero newly introduced one-edit spelling pairs from the seven added words in the screened vocabulary. These are software and orthography results only.
