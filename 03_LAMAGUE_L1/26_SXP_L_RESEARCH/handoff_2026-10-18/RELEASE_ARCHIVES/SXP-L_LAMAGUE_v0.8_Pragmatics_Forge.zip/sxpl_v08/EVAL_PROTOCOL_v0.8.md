# SXP-L v0.8 — Pre-registration draft for next study

**Status:** future human pilot proposal. No volunteers have been recruited; zero human results recorded. Do not interpret the deterministic test suite as a human listening or comprehension study.

## Questions

1. Can novices learn v0.8 lexical distinctions between desire, intention, promise, negated promise, and inability to promise?
2. Can listeners identify `luma/loma`, `mi/ti`, and `fela/fera` from audio by speakers with varying accent backgrounds? No audio TTS in the training labels or reference corpus.
3. Can learners paraphrase if/then sentences without falsely asserting either branch? Can they distinguish correction from silent removal?

## Pilot design

- Exploratory 10–20 participants (multiple first languages if possible); hold out at least 10 additional later for confirmation rather than tuning everything on one group.
- Randomize phrase order and foil labels, give equal exposure to a controlled-English baseline and SXP-L; measure exact learning time and include washout if cross-over design.
- Blind comprehension scoring with a rubric written **before** data collection: actor, time, polarity, stance, proposition content, commitment force, speaker attribution, unsupported/uncertain recognition.
- Separate written reading from listening in noise. Use human recordings and calibrated playback; standardize volume; log environment and device.
- Primary planned outcome: **critical semantic-role errors per correctly attempted sentence**, with confidence interval. Predefine a meaningful improvement threshold before validation.
- Collect negative outcomes and nonresponses. Publish anonymized stimuli, scoring scripts, full denominators, selection criteria and declared exclusions.

## Basic form for anonymized reporting

`participant_code,stimulus_id,condition,modality,first_language,training_minutes,response,correct_roles,critical_errors,nonresponse,notes`

Never invent participant data. The accompanying `study_template.csv` is empty of personal records.

## Technical regression gates

- v0.2–v0.7 legacy regression test methods remain green.
- A new v0.8 expression must preserve its parsed typed AST on render/parse.
- Promise vs intention vs capability and conditional vs assertion must never compare equal.
- Deceptive/out-of-grammar input must fail closed.
- Zero side-effect calls from grammar code.
