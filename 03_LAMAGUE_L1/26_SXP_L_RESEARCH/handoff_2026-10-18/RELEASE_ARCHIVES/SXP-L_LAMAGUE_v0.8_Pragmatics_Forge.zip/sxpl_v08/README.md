# SXP-L × LAMAGUE v0.8 — Pragmatics Forge

Runnable and reproducible experimental language extension (17 October 2026).

## Try the new language

```bash
cd sxpl_v08
python pragmatics.py mi vanira bakumo fura mi satoma tesavo devora
python pragmatics.py mi noka kapera bakumo mi pamisa bakumo fura mi satoma tesavo tesavo devora
python dialogue08.py examples/promise_and_repair.sxh --format summary
python meaning_diff.py 'mi vanira bakumo fura mi satoma tesavo devora' 'mi nivara bakumo fura mi satoma tesavo devora'
python -m unittest discover -v
```

**Python:** standard library only, tested under Python 3.13. CLI arguments must preserve whitespace and lowercase orthography. No execution or network privileges.

## Core files

- `SPEC_v0.8.md`: proposed semantics, roots, grammar, limitations, differentiation.
- `pragmatics.py`: parse and render v0.8 expression ASTs, preserving v0.7 recognized forms.
- `dialogue08.py`: multi-turn attribution, claimed provenance, repair, discourse links, canonical fingerprint.
- `meaning_diff.py`: structural semantic differences between two utterances.
- `examples/promise_and_repair.sxh`: 3 participants, 8 utterances, 3 links, 3 provenance claims, 1 explicit repair.
- `LEARNER_LAB_v0.8.html`: completely offline visual grammar and quiz exercises.
- `MEANING_LOSS_LEDGER.md`: identifiable contrasts and unrepresented meaning.
- `EVAL_PROTOCOL_v0.8.md`, `study_template.csv`: protocol draft for human testing.
- `test_*.py`, `TEST_RESULTS_v0.8.txt`: deterministic software tests.
- Retained v0.2–v0.7 language/parser modules and legacy tests so the package runs standalone.

## Evidence limits

This demonstrates typed structure preservation **inside a controlled subset**. No controlled human test, speech comprehension data, measured improved AI reliability, or broader performance comparison has been conducted. Native-36 symbolic foundations are not altered.

## Useful distinctions

`mi pamisa bakumo fura mi satoma tesavo devora` = recorded wording of promise to stay.

`mi noka pamisa bakumo fura mi satoma tesavo devora` = not promising to stay.

`mi noka kapera bakumo mi pamisa bakumo fura mi satoma tesavo tesavo devora` = reporting inability to make that promise.

No sentence grants a machine execution authority or proves that a person keeps a promise.
