# SXP-L × LAMAGUE v0.8 — Evidence and uncertainty report

**Executed:** 2026-10-17 in the local build environment, CPython 3.13, offline. **Claim maturity:** code-tested research prototype. **External deployments:** none performed. **Human language testing:** none performed.

## Reproducible technical outcomes

- `python -m unittest discover -v`: **60/60 methods green** in approximately 7 seconds. This includes **34 legacy v0.2–v0.7 methods** and **26 v0.8 methods** (new pragmatic and AST-diff modules). Count is of individual test methods, not thousands of independently verified claims.
- **2,500 generated new phrase round trips** with deterministic seed `81017`. Prior retained suite includes a **3,600-case generated spoken-script regression** with seed `71017`. These are synthetic, parser-native distributions, not natural-language corpora or real-user outputs.
- v0.8 example transcript parses and renders identically with **3 participants / 3 turns / 8 utterances / 3 speaker-supplied links / 3 provenance claims / 1 explicit same-speaker repair**.
- Promise, intention, desire, self-reported inability to promise, negated promise, and conditional forms yield different typed representations where required. A structural `meaning_diff.py` enumerates differences without pretending AST identity proves external truth.
- Top-level v0.7 assertions, questions and inert directives remain accepted by v0.8. v0.3's canonical proposition data model is not mutated.
- The initial root `sata` for *stay* conflicted at edit-distance 1 with `sava` and `sada`; it was replaced by `satoma`. Among the **7 new provisional words**, the final spelling inventory introduces **0 new one-edit-distance pairs** against the retained screened v0.7 words. Older confusions such as `loma`/`luma` still exist. This is orthographic screening, not an auditory experiment.
- Code uses the Python standard library only and the grammar performs no network or external tool execution.

## Specific regression distinctions

| Input | What is *not* inferred |
|---|---|
| `mi vanira bakumo fura mi satoma tesavo devora` | Desire ≠ intention, promise, outcome |
| `mi nivara bakumo fura mi satoma tesavo devora` | Intention ≠ promise, outcome |
| `mi pamisa bakumo fura mi satoma tesavo devora` | Promise wording ≠ proven enforceable commitment, fulfillment |
| `mi noka pamisa bakumo fura mi satoma tesavo devora` | Negative promise ≠ inability to promise |
| `mi noka kapera bakumo mi pamisa bakumo fura mi satoma tesavo tesavo devora` | Candidate promise is NOT performed |
| `sivane bakumo fura mi satoma tesavo tanaro bakumo fura ti satoma tesavo devora` | Neither branch independently asserted |
| `evida a1 document_claim` | Claim of document source ≠ proof document exists or supports claim |
| `repara b2 b3` | Old claim retained, not deleted |

## Limitations and planned falsification

1. No acoustic or conversational comprehension data. Full audio segmentation is unaddressed.
2. Human interpretations of `kapera` may differ for ability, permission, willingness and obligation. Split modalities based on blind comprehension errors, not aesthetic preference.
3. Some compressed phrases are awkward. Grammar is restricted and not a general prose translator.
4. No automatic causal or logical inference from `kora because` or if/then structures.
5. Simple fixed grammar plus exact round-trip tests do not establish that SXP-L improves frontier models, reduces overall hallucination, or outperforms Lojban, ACE, JSON, controlled English, or Grammatical Framework.
6. Provenance is only a **speaker assertion of source type**, not cryptographically verified evidence.
7. No real-world action approval, authentication, consent, or external agent execution.
8. Because tests are grammar-native, they may miss usability errors and meaning gaps not representable within the current AST. Conduct blinded studies and ordinary-English paraphrase validation before stronger claims.

## Next honest milestones

- Recruit independent learners for a written and a recorded-speech distinction study, with first-language stratification and frozen scoring rubric.
- Human-readability and listening tests against matched-time controlled English rather than token count alone.
- Introduce permission, willingness, ability, and obligation as distinct typed operators only if learners can discriminate them reliably.
- Add exact-scoped repair/acknowledgment protocols and independent external provenance checks when tied to a concrete agent use case.

**Reporting rule:** proposals ≠ local simulations ≠ tests ≠ field evidence ≠ deployments.
