# SXP-L × LAMAGUE — v1.8 Conversational Repair Forge

A research continuation from v1.7. This release promotes two v1.7 *keyboard editing annotations* into provisional pronounceable **language-level repair speech acts**:

- `kelunaro` — ask for clarification of a previously recorded utterance.
- `remakivo` — correct a previous utterance of your own.

The original `mi liva ti` is **unchanged**. All earlier releases are preserved; the original v1.7 ZIP is bundled unchanged under `history/RELEASE_v1.7_ORIGINAL.zip`.

## Quick start (offline)

Open `REPAIR_LAB_v1.8.html` in a web browser for an interactive learner-oriented subset. It does not replace the Python validator.

With Python 3.10 or later:

```bash
python run_v18.py examples/three_turns.sxp18 --out output
PYTHONPATH=runtime:. python -m unittest -v test_repair18 runtime.test_continuity13 runtime.test_perspective14
```

`runtime/` contains exact copies of the inherited v1.4 Python modules plus the unchanged v1.7 `studio17.py`, so no pip packages or remote services are required for parsing/tests.

Generated bundle: native `.sxp18`, v1.7 `.studio`, legacy `.sxh`, and both meaning sidecars. Preserve these together for reversible history. The `.sxh` alone loses the difference between an ordinary reply, clarification, and self-correction.

The teaching website reads only a restricted root set; it cannot validate the entire v1.4 leaf grammar. No data is transmitted.

## Research status

See `SPEC_v1.8.md`, `EVIDENCE_REPORT_v1.8.md`, `MEANING_LOSS_LEDGER_v1.8.md`, and `ARGON_AUDIT_BRIEF_v1.8.md`. This release adds a narrowly defined grammar property. It does **not** demonstrate natural fluency, listening reliability, human superiority, identity authentication, or safe external execution.
