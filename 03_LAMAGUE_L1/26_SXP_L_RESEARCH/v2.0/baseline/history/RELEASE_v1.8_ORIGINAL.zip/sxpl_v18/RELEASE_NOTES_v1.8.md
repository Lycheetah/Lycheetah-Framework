# Release v1.8 — Conversational Repair Forge

Added bounded pronounceable repair utterances `kelunaro` and `remakivo` and reversible projections to v1.7 Studio/v1.4 transcripts. Clarification semantics are explicitly non-asserting, self-corrections preserve original history, and viewpoint drift is prevented through explicit-name proposals plus same-addressee correction requirements. All historical language roots, including `mi liva ti`, remain unchanged.

Local proof: 49 focused tests green, 700 seeded generated roundtrips, restricted-reader classification agreement, and offline browser smoke test green. No human listening study or real deployment.

The untouched 225-file v1.7 release is stored as `history/RELEASE_v1.7_ORIGINAL.zip` with checksum matching the original. New roots are proposals pending human phonology studies.
