"""Local CLI launcher; historical SXP-L modules remain unmodified in runtime/."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'runtime'))
from repair18 import *
if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser()
    p.add_argument('source');p.add_argument('--out',default='repair18_output')
    a=p.parse_args();result=write_bundle(Path(a.source).read_text(),Path(a.out))
    print(json.dumps(result['meaning18'],indent=2))
