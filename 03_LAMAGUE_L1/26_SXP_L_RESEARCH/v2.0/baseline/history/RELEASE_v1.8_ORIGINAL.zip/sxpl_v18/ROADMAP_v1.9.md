# SXP-L v1.9 — Proposed next experiment

**Research question:** Can the language express “Did you mean *I* missed you?” and “I meant *you* missed me” with concise, transparent pronoun binding and without forcing full repeated names?

Proposed work: specify binder roles and hypothetical speech contexts; independently implement a constrained reader; conduct matched written and listening comprehension tasks with people unfamiliar with SXP-L; measure confusion of reported content, asked-for content, correction, and truth. Preserve v1.8 explicit-name form as a known safe fallback. Do not claim superiority without appropriate controls.
