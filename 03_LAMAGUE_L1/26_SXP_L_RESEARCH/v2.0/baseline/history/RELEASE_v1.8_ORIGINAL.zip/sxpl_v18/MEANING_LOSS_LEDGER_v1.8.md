# v1.8 — Meaning loss and scope ledger

1. **v1.8 native -> v1.7 Studio:** both new speech-act roots become `?k` / `~k`; the *type* is preserved but the **spoken lexical form is lost** without `conversation.sxp18` and its meaning sidecar.
2. **v1.7 Studio -> v1.4 transcript:** `?k`, `~k` and an ordinary `@k` share `repira`. The bare `.sxh` cannot recover the distinction. Both v1.7 and v1.8 sidecars are required for full v1.8 reconstruction.
3. **Clarification viewpoint ambiguity:** v1.8 rejects `mi` and `ti` in a clarification's proposed content and requires explicit names. We prefer a visible restriction to an accidental switch from the original speaker's viewpoint to the questioner's.
4. **Correction viewpoint preservation:** correction requires the original addressee; `ti` therefore retains the intended referent.
5. **Causal/truth limits:** a reported correction is not proof that the old statement was objectively false. Asking “did you mean X?” is not an assertion of X.
6. **Identity/authority:** speaker labels and SHA-256 hashes do not authenticate people; permission phrases never issue capabilities.
7. **Acoustic limitations:** valid written CV structure does not prove that listeners hear scopes and reference codes correctly, especially at conversation speed.
