# SXP-L v1.8 — First conversational repair card

**Our original stays:** `mi liva ti` — *I love you.*

**New candidate words:** `kelunaro` (ke-lu-NA-ro, ask for clarification) and `remakivo` (re-ma-KI-vo, correct my own prior statement). The stress guidance follows existing proposed penultimate stress, not a recording.

### Learn the difference

In `mi kelunaro gonape taba dimotu bakumo ... tesavo devora`, the speaker requests clarification of turn 1. The content between `bakumo` and `tesavo` is a proposed interpretation, **not asserted**.

In `mi remakivo gonape taba dimotu bakumo ... tesavo devora`, the speaker corrects their own turn 1 and supplies a replacement. The original is retained in the historical transcript.

### A new safety rule for clarity

In a clarification's proposed sentence we currently spell out the people by name (for example, `gonape maka dimotu luma gonape nara dimotu devora`). We **do not** silently reinterpret `mi` from the questioner as meaning Maka. Free pronoun binding within repair scopes is future research.

### Try it

Read the example in `examples/three_turns.sxp18` and change a correction's speaker from Maka to Nara. The Python validator should reject it. Then try correcting Maka's original turn while addressing somebody other than Nara—it should also reject because `ti` would change referents.
