"""Playwright smoke test of restricted v1.8 teaching UI; no network required."""
from pathlib import Path
from playwright.sync_api import sync_playwright
p=Path(__file__).resolve().parent
with sync_playwright() as pw:
    b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=b.new_page(accept_downloads=True,viewport={'width':1250,'height':860})
    errors=[]
    page.on('pageerror',lambda x:errors.append(str(x)))
    page.set_content((p/'REPAIR_LAB_v1.8.html').read_text())
    assert page.locator('.turn').count()==3
    assert 'clarification request' in page.locator('#result').inner_text()
    with page.expect_download() as d:page.locator('#save').click()
    d.value.save_as(p/'examples/BROWSER_SAVED.sxp18')
    assert 'kelunaro' in (p/'examples/BROWSER_SAVED.sxp18').read_text()
    page.locator('#source').fill('people maka nara\nmaka > nara : mi liva ti devora\nnara > maka : mi remakivo gonape taba dimotu bakumo mi luma ti devora tesavo devora')
    page.locator('#analyze').click()
    assert 'only the original speaker can correct' in page.locator('#result').inner_text()
    page.locator('#reset').click()
    assert page.locator('.turn').count()==3
    page.locator('#question').select_option('hypothesis')
    page.locator('#answer').click()
    assert 'Correct' in page.locator('#feedback').inner_text()
    page.screenshot(path=str(p/'BROWSER_QA_v1.8.png'),full_page=True)
    assert errors==[],errors
    b.close()
    print('PASS: initial three turns, local export, invalid ownership rejected, reset, quiz feedback, no JS errors')
