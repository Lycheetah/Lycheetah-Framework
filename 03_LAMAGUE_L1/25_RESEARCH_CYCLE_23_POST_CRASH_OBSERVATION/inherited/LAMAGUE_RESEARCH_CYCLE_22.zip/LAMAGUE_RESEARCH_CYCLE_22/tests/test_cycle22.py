import unittest,tempfile,sys,copy,base64,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from cycle22 import experiment
from demo_cycle12 import create_case
from witness21 import adjudicate,Denied
from authority20 import build_binding,classify
from authjournal15 import append,digest

class RealPublisherCrash(unittest.TestCase):
 def run_case(self,fault):
  with tempfile.TemporaryDirectory(prefix='c22-test-') as temp:
   return experiment(Path(temp)/'case',fault)
 def test_actual_crash_yields_one_published(self):
  x=self.run_case('publisher_after_first_commit')
  self.assertEqual(x['recovery']['state'],'PARTIALLY_PUBLISHED')
  self.assertEqual(sorted(x['recovery']['outputs'].values()),['ABSENT','MATCH'])
  self.assertTrue(x['source_preserved'])
  self.assertEqual(x['witness_post_check'],'MATCH')
  self.assertFalse(x['recovery']['retry_allowed'])
 def test_uninterrupted_two_files(self):
  x=self.run_case(None)
  self.assertEqual(x['execution'],'COMPLETED_VERIFIED')
  self.assertEqual(x['recovery']['state'],'PUBLISHED_EVIDENCE_INCOMPLETE')
  self.assertTrue(all(v=='MATCH' for v in x['recovery']['outputs'].values()))
 def test_abort_before_publisher(self):
  x=self.run_case('before_publisher')
  self.assertEqual(x['recovery']['state'],'NOT_PUBLISHED')
 def test_recovery_absent_checkpoint_is_quarantine(self):
  with tempfile.TemporaryDirectory(prefix='c22-d-') as temp:
   root=Path(temp);root.chmod(0o755);jail,data,plan,grant,keys=create_case(root)
   binding=build_binding(plan,grant)
   outcome=classify(binding,jail/'published',journal_stage='INTENT',checkpoint_state='MISSING',ledger_state='IN_PROGRESS')
   self.assertEqual(outcome['state'],'QUARANTINE')
 def test_witness_denies_grant_mutation(self):
  with tempfile.TemporaryDirectory(prefix='c22-sign-') as temp:
   root=Path(temp);root.chmod(0o755);jail,data,plan,grant,keys=create_case(root)
   binding=build_binding(plan,grant);jk=os.urandom(32);wk=os.urandom(32)
   j=root/'journal';j.mkdir();state=root/'state';state.mkdir()
   append(j,jk,digest(binding),'INTENT',{'expected_count':2})
   fake=copy.deepcopy(grant);fake['grant']['nonce']='0'*64
   req={'action':'ANCHOR','plan':plan,'grant':fake,'binding':binding,'journal':base64.b64encode((j/'journal.jsonl').read_bytes()).decode()}
   with self.assertRaises(Denied):adjudicate(req,state,jk,wk,keys)
if __name__=='__main__':unittest.main()
