# LAMAGUE RESEARCH — CYCLE 22
## Actual namespaced two-file publication crash
**Status:** Local research prototype; tested in disposable Linux directories. **Date:** 18 October 2026.

### Question
Can a real rootless-namespace publisher be stopped *after the first successful file commit but before the second*, and can the previously developed recovery classifier identify the resulting partial state accurately?

### Changes
- Preserved Cycle 21 artifacts byte-for-byte as the nested inherited ZIP.
- Added test-only `crash_after_first_commit` support inside the actual Cycle 13 `role_child13.py` publisher loop. On the first successful `copy_one` it calls `os._exit(92)`. **Not a simulation of a filesystem state.**
- The trusted controller routes a new `publisher_after_first_commit` fault through its normal `run_role` launcher, which executes the child within rootless user, mount, and network namespaces after OS fact checks.
- `cycle22.py` uses the signed synthetic grant, Cycle 21 `adjudicate()` original-grant-aware witness checkpoint, Cycle 13 execution with consumed nonce, and Cycle 20 filesystem recovery classification.
- Added five regression tests for crash, normal, pre-publisher refusal, missing checkpoint, and altered grant.

### Measured result
5/5 regression tests passed locally. During the real crash case:

| Field | Observed |
|---|---|
| Publisher exit | Nonzero exit after first verified commit |
| First destination | MATCH expected SHA-256 and length |
| Second destination | ABSENT |
| Source files | Preserved |
| Signed-grant nonce ledger | FAILED_OR_PARTIAL (nonce consumed) |
| Witness checkpoint check | MATCH (only prior INTENT was authenticated) |
| Recovery classification | PARTIALLY_PUBLISHED |
| Recovery auto retry | False |

The normal copy succeeds with 2/2 outputs, while recovery reports `PUBLISHED_EVIDENCE_INCOMPLETE` because the experiment deliberately does not append a post-publication witness record. The pre-publisher abort produces `NOT_PUBLISHED`.

### What this supports
A crash between real commits can leave an authentic authorization and matching witness checkpoint **while only a subset of planned effects exists**. Witness checkpoint consistency cannot, alone, attest publication success. Recovery must independently check output bytes and disclose incomplete evidence.

### What this does not support
- This is not an atomic two-file transaction; one output really becomes visible before the other.
- The witness in this experiment runs via the reusable Cycle 21 adjudicator in the controller process, not as a separately owned persistent service. Cycle 21 independently tests its service variant; end-to-end separated service remains untested.
- The test controller and local inspector remain trusted; malicious concurrent writers, power interruption, volatile-cache durability, path-race completeness, key compromise, persistent independent witness restart during these fault points, and hostile code are out of scope.
- `FAILED_OR_PARTIAL` in the nonce ledger denotes terminal refusal, **not** recovery completeness; recovery must never automatically replay a consumed grant.
- Test only with synthetic grants/files inside disposable directories. Rootless namespaces, `chroot`, seccomp deny-list, permissions and built-in Python routines do not together establish production-grade arbitrary code containment.
- No direct OPA/Rego comparison; no independent human-review outcomes; no evidence that LAMAGUE beats a conventional equivalent implementing the same primitives.

### Next experiment (Cycle 23)
Bind each actual publication commit to independently anchored per-file journal evidence; crash before/after each commit, including witness unavailability. Ensure no automatic retry and report exactly which side effects are observed versus merely journaled. Give the identical mechanism to a conventional baseline.

### Reproducibility
`python -m unittest discover -s tests -v` from archive root, then `PYTHONPATH=src python src/cycle22.py`. Preserve the explicit test-only fault hook; do not ship it in a live publisher. `SHA256SUMS.txt` covers archived files.
