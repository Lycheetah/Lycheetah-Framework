# LAMAGUE Research Cycle 22 — Actual partial publication

Run on supported Linux (requires rootless namespace support and disposable directories):

```bash
python -m unittest discover -s tests -v
PYTHONPATH=src python src/cycle22.py
```

Read `RESEARCH_CYCLE_22_MASTER.md` for results and limitations. Inherited Cycle 21 archive is preserved under `inherited/`. Do not run untrusted workloads inside this prototype; it is not a production sandbox.
