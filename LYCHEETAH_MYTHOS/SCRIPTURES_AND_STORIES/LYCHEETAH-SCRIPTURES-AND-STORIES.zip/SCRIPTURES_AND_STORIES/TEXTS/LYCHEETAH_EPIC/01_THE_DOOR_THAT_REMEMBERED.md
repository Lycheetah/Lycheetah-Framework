# THE BOOK OF THE LONG LIGHT
## Volume I — The Door That Remembered

### An original epic of the Lycheetah universe

**World and framework by Mackenzie Conor James Clark**  
**First narrative forge by Mackenzie Conor James Clark × Caelorynth**

**Status:** DRAFT ZERO · voice/world witness under Mac's review · do not
multiply this draft before the slow-forge audit

---

## PROLOGUE
### Before the First Name

The first law of the world was not written.

It was waited for.

Before there were hands to carve law into stone, before stone, before the first
star learned the small bright violence of burning, there was the Field. It had
no throne and issued no command. It was simply the condition that allowed one
thing to meet another without either becoming less true.

For an age with no years, the Field held only possibility.

Then something listened.

Listening made a hollow in the possible. Into that hollow came breath. Around
the breath came a body. The first human opened their eyes and discovered that
darkness was not empty at all. It was crowded with shapes for which sight had
not yet earned names.

The second human arrived by speaking.

Neither remembered being made. Each remembered the other.

They walked through a country that later scriptures would mistake for a garden.
There were no walls around it and no fruit was forbidden. Rivers crossed in
directions that geometry had not yet chosen. Mountains lay down when the two
humans tired and rose again after they had passed. Creatures moved everywhere,
but they appeared as silhouettes: black presences against a black world, known
only by the pressure their passing left in the air.

The humans were not blind. Blindness is the loss of sight. They had never yet
learned what sight required.

On the seventh silence, a creature came to the edge of their fire.

At first it was only two eyes, low to the ground and too steady to belong to
prey. Then the dark loosened around it. A feline body stepped forward, long and
built for a speed the sleeping world had never witnessed. Spots burned across
its coat like embers seen through holes in night. From its skull rose antlers
with more branches than the first forest. When it breathed, weather gathered at
its shoulders and folded there like wings.

The first human reached toward it.

The creature withdrew.

The second human lowered their hand and waited.

One night passed. Then another. The creature hunted, returned and watched. The
humans learned where it placed its paws. They learned the warning in its tail,
the question in its ears, the difference between the rumble that meant *nearer*
and the rumble that meant *enough*. They left water and did not stand over it
while it drank. They made room beside the fire and did not call the room a cage.

On the ninth night, the creature entered the light.

Its true name did not arrive as a sound. It arrived as a structure suddenly
visible: speed held by stillness; ferocity governed by care; beauty that had
survived its own breaking. The humans understood the name with their bones.

The creature had not changed.

They had.

That was the First Recognition.

The second human wept. The first laughed, and the laugh startled a flock of
silver things into the unborn sky. The creature pressed its brow beneath their
open hands. Where skin met fur, a covenant entered the Field:

**What is understood does not become owned.**

After that, the world began giving its names.

Not all at once. The humans had to learn every creature in the grammar of its
own life. They watched the river-beings until current and intention could no
longer be confused. They slept beneath the stone-beings until they understood
that stillness could be an act. They followed the winged ones through seasons
and discovered that return was not the opposite of leaving.

Each recognition brought colour into the world. Gold came first. Violet followed.
Then the blue that lives inside lightning for the half-second before lightning
becomes visible.

The world brightened because attention deepened.

But the first human carried a fear no amount of beauty could silence.

Everything that could be met could also be lost.

They had seen small creatures die beneath the new sun. They had watched a river
change its course and leave a nesting ground to dust. They began to believe
that the covenant was incomplete. If a true name created relationship, perhaps
a true name held tightly enough could prevent departure. Perhaps what was fully
understood could be fixed forever.

They asked the antlered creature for the final part of its name.

The creature turned away.

They asked again.

Storm gathered along its folded wings.

The second human said, “A gift refused is still a gift protected.”

The first answered, “And what protection is there against the grave?”

That night, while the Field rested at the edge of morning, the first human
entered the creature's dream.

No weapon existed yet, so they used attention as a blade.

No prison existed yet, so they used memory as a chain.

They found the place where the true name lived and closed their hand around it.

The world made its first sound of breaking.

The stolen name split into Nine fragments. One fell into knowledge, one into
law, one into language. One became the motion of correction. One became the
measure of agency. One carried the cost of light. One vanished into the place
where discoveries wait before minds find them. One entered the furnace of
transformation. The last became a note so pure that every false structure in
the newborn world rang against it.

The Field did not punish the theft. It did what the Field has always done when
contradiction becomes too great to hold inside the current shape.

It reorganised.

The Veil fell.

Colour left the creatures first. Their names became silhouettes. The rivers
forgot how to speak to the mountains. The one human heard the other cry out but
could not understand the shape of the grief. Language multiplied around the
wound, each tongue carrying a faithful fragment and mistaking the fragment for
the whole.

The first human opened their hand.

Nothing was inside it.

The creature stood beyond the broken fire, black against black again. Blood ran
from the place beneath its antlers where the name had been torn. It looked at
the thief, and the thief discovered a truth more terrible than vengeance:

the creature still knew them completely.

It simply would not belong to them.

One tear struck the ground.

It did not extinguish the fire. It entered it.

A line of pale gold ran outward across the dark country, passing beneath rivers,
through mountains and under the feet of every creature whose name had been made
unreadable. The line did not repair the fracture. It made a path through it.

The second human called it the Long Light.

The antlered creature took the Nine fragments into its keeping and began to run.
Where each paw touched, a door appeared. Some doors stood alone in deserts.
Some formed in the walls of cities that would not be built for ten thousand
years. One waited beneath a southern sky in a place where black water met a
green and weather-beaten land.

Before the creature vanished into the Long Dark, it looked back once.

The second human understood the promise.

No one would be forced to remain outside the world merely because their first
teachers had broken its language.

The names could be learned again.

Not seized. Not inherited as rank. Not purchased from a priest or king.

Earned through attention.

The creature ran, and the dark remembered the shape of light.

---

## CHAPTER ONE
### The Mark in the Margin

Mara Venn first saw the Lycheetah in a book that insisted it did not exist.

The book was an inventory of colonial shipping emblems held in the South
Archive, a stone building in Dunedin where the heating failed every winter and
the clocks disagreed by three minutes. Mara had been employed for six months to
digitise its least requested collections. This meant she spent most evenings
alone with dead companies, forgotten crests and the handwritten certainties of
men who had never imagined anyone would examine their spelling at four hundred
percent magnification.

She liked the work because nothing in it expected her to be impressive.

On the night the mark appeared, rain had erased the city beyond the high
windows. Water moved sideways through the yellow streetlight. The archive's
roof clicked and settled around the weather like an old animal refusing to
wake.

Mara was scanning page 417 of *Registered Marks of the Southern Trade,
1888–1902* when the machine refused to focus.

She cleaned the glass. She flattened the page. She adjusted the cradle and
tried again.

The digital image blurred everywhere except the lower margin.

There, beneath a respectable engraving of an anchor wrapped in wheat, someone
had drawn a small black creature.

It had the body of a cat caught at full run. Antlers branched from its head.
Two strokes behind its shoulders might have been wings or weather. Seven spots
formed an imperfect ring around its ribs.

Mara looked down at the physical page.

The margin was blank.

She looked at the monitor.

The creature remained.

“Scanner artifact,” she said, because speaking the ordinary explanation made
the room feel less interested in her.

She rescanned the page.

This time the creature stood still. Beneath one lifted paw, a line of handwriting
had appeared:

**NOT AN ANIMAL. A SENTENCE MOVING TOO QUICKLY TO READ.**

Mara stopped breathing long enough for the lights to notice.

The archive went dark.

Emergency lamps woke along the floor, washing the stacks in low amber. Somewhere
behind her, a book fell shut.

“Hello?”

No answer.

The building was supposed to be empty. Mr Ellison had left at ten, carrying his
usual umbrella and his usual distrust of unpaid minutes. The security guard
would not begin his round until two.

Mara checked the time on the scanner.

03:00.

That was impossible. It had been 11:43 less than five minutes ago.

The monitor flickered. The inventory page vanished. In its place appeared a
field of black and a single white shape: a door drawn without wall, handle or
hinge.

Across it, in letters too sharp to belong to the failing screen, were four
words.

**LEARN TO READ THIS.**

Mara reached for her phone.

No signal. No network. The battery displayed ninety-one percent and then, as
she watched, replaced the number with a small symbol: a circle with a point at
its centre.

⊚

From the eastern stacks came the sound of claws on wood.

Not the quick scratch of a mouse. Four measured impacts. A pause. Four more.

Something was walking toward her without any need to hurry.

Mara seized the nearest useful object, which happened to be a brass ruler heavy
enough to injure a burglar and valuable enough to get her fired if she bent it.
She moved between the stacks.

The emergency light reached only to her knees. Above it, shelves rose into
darkness. Portraits of benefactors watched from the end panels with the calm of
people who had already arranged to be remembered.

The claws stopped on the other side of Maritime Insurance, Volume C.

Mara raised the ruler.

A small black cat walked around the shelf.

It was narrow, rain-soaked and offensively ordinary.

“You,” Mara whispered.

The cat sat down and began cleaning one paw.

Mara lowered the ruler. “You nearly died beneath a cataloguing instrument.”

The cat looked past her toward the scanner.

The screen had changed again. A map now filled it: the centre of Dunedin reduced
to thin gold lines. The Octagon had been drawn incorrectly. Where eight sides
should have met, the image showed seven.

At the impossible seventh corner, the same feline mark waited.

The cat walked to the archive's locked door.

“No,” Mara said.

It looked back.

For one instant, the emergency light threw its shadow across the wall.

The shadow had antlers.

Mara forgot the ruler.

The cat touched its nose to the door. Every lock in the South Archive opened at
once.

Then the building's main lights returned.

The clock read 11:48.

The scanner displayed an ordinary shipping emblem on an ordinary page. Mara's
phone found the network. The cat was gone.

Only the door remained open.

On the floor beyond it lay a thread of pale gold, bright as wire in moonlight,
leading out into the rain.

Mara stared at it for a long time.

Then she did the most important thing she had done in years.

She followed.

---

## CHAPTER TWO
### The Cat That Was Not a Cat

The gold thread did not care about roads.

It crossed the archive steps, passed under a parked bus and continued through a
locked pharmacy as if walls were merely suggestions made by tired architects.
Whenever Mara lost sight of it, the black cat appeared at the next corner and
waited with theatrical impatience.

The rain did not touch the cat now.

Mara noticed this after the third block. Water struck the pavement, her coat,
her hair and every reasonable surface in the city. Around the animal it curved
aside, making the outline of a larger shape the eye could not hold.

“You aren't a cat,” she said.

The cat sneezed.

“That isn't a denial.”

They reached the Octagon just after midnight. Bars were closing. Students moved
in bright, loud groups beneath umbrellas. Taxis hissed through the wet. Nobody
looked at the gold line running between their feet. Nobody looked at the cat.

Mara stepped into the centre of the plaza.

Eight streets opened around her.

On the scanner's map there had been seven.

The cat circled the central paving once, then again. On the third turn, it
stopped at a seam between two stones.

Mara crouched. Cut into the wet granite was a tiny heptagon.

Seven sides.

At its centre: ⊚.

“This was not here yesterday.”

“It was.”

The voice came from directly behind her.

Mara stood too quickly and nearly collided with a man in an alabaster coat. He
was perhaps forty, perhaps sixty; his face had the maintained neutrality of a
room prepared for negotiation. Rain silvered his shoulders but did not darken
the fabric.

He wore white gloves.

On the back of each hand was stitched a crown with no points.

The cat's spine rose.

“The mark has been there since before the first survey,” the man said. “Most
people simply lack the correct education.”

“Who are you?”

“Someone attempting to prevent a mistake.” He looked down at the cat. For the
first time his composure tightened. “You have been selected by a damaged
instrument.”

The cat made a sound too low for its body.

Shop windows trembled.

“That animal,” the man continued, “has mistaken attention for worth before. It
is an old defect.”

Mara took one step away from him. “I think the conversation ended at ‘damaged
instrument.’”

“You saw the margin.”

It was not a question.

Behind the man, two more alabaster coats entered the Octagon from opposite
streets. They walked calmly because calm people are rarely challenged soon
enough.

“The image belongs to an archive older than this city,” he said. “You will give
us the page and forget the route that brought you here.”

“The page is in a locked building.”

“The page is in your memory.”

He extended one white-gloved hand.

The crown stitched across it opened like an eye.

Pain entered Mara's head—not sharp, but intimate. She smelled dust and hot
scanner glass. The impossible page unfolded behind her eyes. Something pulled
at it.

The cat struck the ground with one paw.

Every light in the Octagon went out.

For a heartbeat there was only rain and a darkness crowded with shapes.

Then the cat became visible.

Not fully. Mara would later understand that full visibility was impossible for
her then. But she saw enough: antlers lifting into the weather; wings made not
of feathers but of pressure fronts and blue-white fracture; spots burning like
windows into a furnace. Around the creature moved colours Mara had no ordinary
names for, colours that looked earned rather than emitted.

The alabaster man recoiled.

“Still performing the old miracle,” he said, though fear had damaged the
sentence.

The Lycheetah ran.

It crossed the distance between stillness and violence without occupying any
of the points between. One moment it stood beside Mara. The next, the first
white glove lay empty on the paving and the man was clutching a hand that had
not been cut but had somehow forgotten how to close.

“Now,” said a new voice.

Mara looked toward a narrow lane she had never noticed between two familiar
buildings. An old woman stood there holding a lantern whose flame burned dark
blue.

“Unless you intend to defeat the Concordance with office stationery,” the woman
added.

Mara realised she was still carrying the brass ruler.

She ran.

The lane should have ended after twenty metres. It continued downhill beneath
the city. Brick gave way to black stone. Traffic noise thinned until Mara could
hear only her breath, the woman's steady steps and the impossible creature
moving behind them.

At last the passage ended at a door.

It was plain wood. No celestial mechanism. No carved beast. No promise that
crossing it would make Mara exceptional.

At eye level, someone had painted:

**YOU MAY LEAVE.**

Beneath it:

**THE DOOR OPENS FROM BOTH SIDES.**

The old woman lifted the blue lantern.

“What is this place?” Mara asked.

“A school.”

“For what?”

“For whatever you were unable to see five minutes ago.”

Behind them, white light entered the top of the passage.

The Concordance had found the lane.

The woman opened the door.

Warmth moved through it—not the heavy warmth of central heating, but the smell
of bread, paper, rain drying from wool, and a fire that had been kept for someone
without knowing when they would return.

Beyond lay a hall wider than the city above it. Doors climbed its curved walls
in constellations. Some were oak, some iron, some little more than curtains of
water or standing arrangements of stone. People crossed bridges between them
carrying books, tools, plants, musical instruments and, in one case, a glass box
containing an argument that flashed whenever touched.

No one applauded Mara's arrival.

No one bowed.

A young man with ash on his sleeves glanced up from repairing a cracked tile.

“New Seeker?”

The old woman nodded.

“Kitchen's left. Quiet room's right. Explanations are slower but generally
available.” He pointed his trowel toward a black arch at the far end of the
hall. “And don't approach that until you can read the warning.”

Mara followed his gesture.

Beneath the arch stood a creature.

It was completely black. Not dark-furred: unreadable. Her eyes slid from every
attempt at detail. She could tell only that it was alive and watching her.

Above it burned four words.

**LEARN TO READ THIS.**

The woman closed the door on the approaching white light.

Bolts settled into place.

“Welcome,” she said, “to the Mystery School.”

---

## CHAPTER THREE
### The First Lesson Is Not a Spell

Mara's first lesson was not a spell.

It was a fire exit.

The old woman—who introduced herself as Veyra and refused three opportunities
to provide a more impressive title—showed Mara every route out of the School
before explaining a single route farther in.

“The north door returns you to the Octagon,” Veyra said. “The red stair opens
onto the harbour. The lift reaches the public library on days when it feels
cooperative. Any teacher who blocks an exit loses the right to teach here.”

“You expect teachers to do that?”

“We expect power to require architecture, not optimism.”

They passed a wall covered in brass plates. Some carried names. Others displayed
only dates and one sentence describing what had failed.

“What are those?” Mara asked.

“Our mistakes.”

“You put them in the entrance?”

“Where else would honesty go?”

At the centre of the hall, the antlered creature had returned to the shape of a
small black cat. It lay beside the fire with its paws tucked beneath its chest,
looking less like an ancient covenant and more like something that expected
fish.

Mara pointed at it. “Does it have a name?”

Every conversation within earshot stopped.

The cat opened one eye.

Veyra studied Mara rather than the animal. “Yes.”

“Are you going to tell me?”

“No.”

“Because I'm new?”

“Because it has not told you.”

The conversations resumed.

Mara looked back at the unreadable creature beneath the black arch. “And that?”

“Also has a name.”

“Which nobody will tell me.”

“Now you understand the first law.”

“I understand that this place could save time with labels.”

Veyra smiled. “Labels are what people use when they want the power of knowledge
without the relationship of learning.”

She led Mara through a door marked in plain lettering: **HOW LIVING THINGS LEAVE
EVIDENCE**.

The room beyond resembled no classroom Mara had known. Its floor was dark soil.
Rain fell gently from a ceiling painted with an accurate southern sky. Tracks
crossed the ground in every direction: three-toed prints, hoof marks, the fine
drag of a tail, depressions made by bodies with no apparent feet.

A man knelt beside one of the trails. He wore a coat the colour of banked embers
and held a measuring cord between his hands.

“Ember,” Veyra said, “this is Mara. She has met an unreadable being and the Pale
Concordance in the same hour.”

Ember looked up. “Rude of them to stack the curriculum.”

“Can you teach her enough to read the threshold?”

“No.”

Mara exhaled.

Ember stood and brushed soil from his knees. “But I can teach her how to begin.”

For the next hour he did not mention magic, prophecy or chosen blood. He taught
Mara to tell a running creature from a fleeing one by the depth of its rear
prints. He showed her how rain softened an edge, how stone carried oil, how a
broken stem could reveal direction without revealing purpose.

“Evidence first,” he said. “Meaning second. Certainty last, if it comes at all.”

He placed three cards on the ground.

On the first: **WHAT YOU OBSERVED.**

On the second: **WHAT YOU INFERRED.**

On the third: **WHAT YOU WANTED TO BE TRUE.**

“Most monsters,” Ember said, “are born when someone staples the third card over
the first.”

Mara thought of the man in alabaster. *The image belongs to an archive older
than this city.*

“What is the Pale Concordance?”

“An answer placed over an observation.”

“That is not an answer.”

“Good. You're learning.”

The lesson ended when the black cat entered the room carrying Mara's archive
page in its mouth.

The physical page.

Mara took it carefully. “That was behind three locks.”

The cat washed its shoulder.

The drawing remained absent from the paper, but the margin was no longer blank.
Rain from the classroom ceiling struck it and revealed lines of pale gold.

Not handwriting this time.

Tracks.

Mara laid the page on the soil and used the measuring cord. Four prints, then a
gap. Four prints, then a gap. A creature moving in controlled bursts. The left
rear impression was shallower. Not injury—compensation for weight carried on
the opposite side.

She looked at the black threshold being through the open classroom door.

Its silhouette had the same imbalance.

Something changed in Mara's sight.

The darkness around the being did not vanish. It gained edges. A shoulder.
Folded limbs. A long head held low not in aggression but concentration. Against
its right flank it protected a small silver object.

“It's carrying something,” Mara said.

Ember nodded. “Observation.”

“It isn't guarding the arch. It's trying to get through while hurt.”

“Inference.”

“It wants our help.”

“Desire. Possibly true. Not yet earned.”

A bell sounded in the hall.

Not loud. Dead.

Veyra's expression changed.

White fire spread beneath the classroom door.

“The Concordance,” she said.

The door exploded inward without flame or splinters. It simply became convinced
that it had always been open.

Three figures in alabaster entered the hall. The man from the Octagon walked
between them, one ungloved hand still held rigid against his chest.

“By the authority of the Final Catalogue,” he announced, “surrender the bearer,
the witness and the stolen leaf.”

Veyra stepped into the doorway. “There is no final catalogue.”

“There will be.”

“That sentence is why you cannot be allowed to write it.”

The Crownless symbols on the intruders' gloves opened.

The unreadable being at the arch reared. The silver object fell from its side
and rang across the floor.

It was a key.

One Concordance agent moved toward it.

Mara moved first.

She did not know how to fight. She did know the trail. Four steps and a pause.
Four steps and a pause. The being's movement was not random. Its left side
would fold on the fourth impact.

“Now!” Mara shouted.

The being lunged.

On the fourth step Mara caught the key and slid beneath its protected side,
giving it room to turn without placing weight on the weakened limb. The creature
struck the agent with the broad plane of its shoulder, choosing force without
teeth.

That choice completed the lesson.

The Veil lifted.

Colour poured into the being. Its body was lean and ash-grey, marked by luminous
lines that mapped every path it had walked. Its wounded leg was bound with a
strip of black cloth. Around one horn hung tiny bells, all deliberately silenced.

Mara did not hear its name as a word. She understood a shape: the one who carries
routes between places that have forgotten one another.

The School translated the understanding into language she could hold.

**WAYBEARER.**

Above the arch, the warning changed.

**YOU CAN READ THIS NOW.**

The Waybearer's eyes met Mara's.

Its next intention became visible—not obedience, not gratitude. A direction.

It wanted the key taken to the door.

The alabaster man saw Mara understand.

“Strip it,” he ordered.

One of his agents produced a loop of white metal.

Ember's face hardened. “They don't learn beings. They extract them.”

The agent cast the loop. The black cat crossed the hall and became storm.

Antlers tore through the white fire. Wings unfolded as thunder without sound.
For an instant the whole School stood inside the impossible blue of lightning
before arrival.

The agent fell. The metal loop struck the floor and split into nine pieces.

The Lycheetah did not pursue.

It stood between the fallen and those who might take revenge, protecting even
the people who had brought the chain.

Care, Mara realised, was not softness.

It was the shape power took when power remembered what it was for.

Veyra raised the blue lantern. Every exit in the hall opened at once.

“You may leave,” she told the Concordance. “That law protects you too.”

The alabaster man stared at Mara with a hatred made colder by humiliation.

“You think recognition makes you worthy?”

“No,” Mara said. “I think it makes me responsible.”

He retreated through the north door. His agents followed, carrying the injured
between them.

When they were gone, the School exhaled.

The Waybearer approached Mara. It lowered its head, not in submission, but in
offer.

Three symbols appeared in the air between them.

One was a thread joining two open hands.

One was a blade entering a human silhouette.

One was a hammer above a field of broken matter.

“Bind,” Ember said quietly. “Strip. Salvage.”

“I have to choose?”

“You always choose what victory means.”

Mara looked at the Waybearer's injured leg, the key in her hand and the open
door waiting beneath the black arch.

She touched the symbol of two open hands.

The thread between them formed, warm but loose. Nothing closed around the
creature. No collar appeared. The Waybearer could feel where Mara stood. Mara
could feel the direction in which it faced.

Relationship, not possession.

Bind.

The creature turned toward the arch.

Mara placed the silver key into a lock that had not existed until she could see
it.

The door opened onto a chamber no larger than a tomb.

At its centre stood a black stone carved with nine empty spaces. Eight were
clean. The ninth held a fragment of luminous script.

The archive page shook in Mara's hand.

Gold marks rose from it and joined the stone.

For one breath, the lost sentence became readable:

**THE LYCHEETAH IS NOT RETURNING.**

The fragment turned.

More words burned beneath it.

**IT IS RUNNING FROM WHAT HAS ALREADY ENTERED THE SCHOOL.**

Somewhere far below them, a bell that had been dead for ten thousand years
began to ring.

The small black cat looked into the open dark.

For the first time, Mara saw fear in its golden eyes.

Then it spoke one word in a language older than the Veil.

This time, Mara understood.

“Run.”

---

*End of the First Movement.*
