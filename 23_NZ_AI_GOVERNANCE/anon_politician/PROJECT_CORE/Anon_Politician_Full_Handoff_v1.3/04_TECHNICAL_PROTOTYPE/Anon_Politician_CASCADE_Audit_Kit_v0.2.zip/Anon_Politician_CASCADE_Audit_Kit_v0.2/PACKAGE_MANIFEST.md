# Package manifest — Anon Politician CASCADE Audit Kit v0.2

This bundle contains the current research prototype and two audit artifacts.

## Included
- `README.md` — project status and quick start.
- `cascade.py` — conservative dependency/contradiction review-queue prototype.
- `test_cascade.py` — unit tests for structural safety properties.
- `test_run_report.txt` — latest recorded test summary.
- `cascade_block.schema.json` — provisional block schema.
- `source_claims_audit.csv` — 15 source-derived entries with PDF page locators and proposed handling.
- `external_evidence_register.csv` — 11 external sources with notes and URLs.
- `audit_findings.csv` — 10 priority findings.
- `review_protocol.md` — experimental protocol, baselines, metrics, and unimplemented tests.
- `source_ledger_v0_1.csv` — retained earlier working ledger for provenance/history.
- `Anon_Politician_Source_Fidelity_and_Evidence_Audit_v0.2.docx` — narrative research audit.
- `Anon_Politician_Source_Audit_v0.2.xlsx` — audit workbook.

## Explicitly not included
The raw 62-page `Anon Politician.pdf` is not bundled here because it contains identifying information and was treated as a private historical source. Use the source file already in the conversation, or create a carefully reviewed redacted derivative before public release. A redaction does not guarantee anonymity.

## Validation
The current `test_cascade.py` suite contains 11 unit tests. They test code behavior only. They do not validate factual accuracy, political neutrality, predictive performance, or policy quality.
