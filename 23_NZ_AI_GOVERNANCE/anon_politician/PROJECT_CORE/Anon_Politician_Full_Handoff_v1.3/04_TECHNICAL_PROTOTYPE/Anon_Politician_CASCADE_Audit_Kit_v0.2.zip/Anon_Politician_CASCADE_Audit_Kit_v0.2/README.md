# Anon Politician — CASCADE audit kit v0.2

**Status:** research prototype / design proposal. Not a validated political decision system.

## Included
- `source_ledger_v0_1.csv`: preserved initial source ledger snapshot.
- `source_claims_audit.csv`: current page-referenced source claim audit.
- `source_claims_audit.csv`: 15 source-derived claims/concepts with PDF page locators and audit assessments.
- `external_evidence_register.csv`: ten independent sources with URLs, source types and limitations.
- `audit_findings.csv`: ten major findings and required actions.
- `cascade_block.schema.json`: provisional JSON Schema for provenance-first knowledge blocks.
- `cascade.py`: review-queue engine across dependency and explicit-contradiction links.
- `test_cascade.py`: 11 unit tests for key software safety properties.
- `review_protocol.md`: proposed comparative evaluation protocol.
- `test_run_report.txt`: observed unit-test result and limitations.
- `Anon_Politician_Source_Fidelity_and_Evidence_Audit_v0.2.docx`: narrative audit report (also at package root).

## Non-negotiable design rules
1. Internal coherence is not truth.
2. Normative commitments and empirical propositions have different epistemic status.
3. A cascade creates review work; it never automatically promotes, demotes, archives, or deletes a claim.
4. Explicitly contradictory claims and their dependents are also queued for review.
5. Contradictions remain visible until adjudicated with a recorded rationale.
6. Source claims and independent findings must be separately represented.
7. AURA metrics (TE, VTR, PAI) remain unimplemented specifications until formulas, constructs, calibration, and validity tests exist.
8. No single scalar score should determine political or policy truth.

## Quick start
Requires Python 3.10+. From this directory, run:

```bash
python -m unittest -v
```

Latest observed result: **11 tests passed**. This tests software behaviour only, not factual accuracy, predictive value, neutrality, or policy utility.

## Important limitations
The source audit is a focused first pass, not a complete line-by-line review or systematic literature review. Major source entries have PDF page locators; some passages still need quote-by-quote rendered-page verification. External evidence records contextualise the claims but do not resolve all research questions.

## Suggested next milestone
Use New Zealand’s existing environmental-economic accounts (Stats NZ Data to 2024) and UN SEEA Ecosystem Accounting as comparators before developing DEEP: define exactly what added gap it would close. Then freeze a labelled claim-graph benchmark and compare: (A) a static evidence ledger; (B) this dependency/contradiction review queue; and (C) a future metric-triggered system only after AURA is operationally specified. Measure precision, recall, irrelevant alerts, provenance completeness, review workload, political symmetry, and whether the system preserves legitimate disagreement.

## Source integrity
Original input: `Anon Politician.pdf` (62 PDF pages; 4,116,059 bytes). SHA-256: `9a64bba3cdd56887c3f30471fb4272b4c59f8a73e7360c606047c303377de536`. Page locators in the audit report refer to this exact file.
