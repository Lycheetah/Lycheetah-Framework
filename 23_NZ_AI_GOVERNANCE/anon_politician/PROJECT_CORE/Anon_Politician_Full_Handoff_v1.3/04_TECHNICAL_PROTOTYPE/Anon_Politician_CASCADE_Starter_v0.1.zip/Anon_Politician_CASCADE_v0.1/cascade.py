"""Provisional CASCADE review engine for Anon Politician.

Safety posture:
- A dependency change creates review work; it does not silently rewrite beliefs.
- Conflicts remain visible.
- Normative commitments are not treated as empirical proof.
- All status changes require a recorded human/research decision.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Set

@dataclass
class KnowledgeBlock:
    block_id: str
    content: str
    claim_type: str
    status: str = "pending_review"
    dependencies: List[str] = field(default_factory=list)
    contradicts: List[str] = field(default_factory=list)
    evidence_ids: List[str] = field(default_factory=list)
    provenance_ids: List[str] = field(default_factory=list)
    review_required: bool = False
    history: List[dict] = field(default_factory=list)

@dataclass
class CascadeReview:
    changed_block_id: str
    affected_block_ids: List[str]
    reason: str
    automatic_status_changes: List[str] = field(default_factory=list)

class KnowledgeGraph:
    def __init__(self, blocks: List[KnowledgeBlock]):
        self.blocks: Dict[str, KnowledgeBlock] = {b.block_id: b for b in blocks}
        if len(self.blocks) != len(blocks):
            raise ValueError("Duplicate block_id")
        for block in blocks:
            missing = set(block.dependencies + block.contradicts) - set(self.blocks)
            if missing:
                raise ValueError(f"{block.block_id} references missing blocks: {sorted(missing)}")

    def dependents_of(self, block_id: str) -> Set[str]:
        if block_id not in self.blocks:
            raise KeyError(block_id)
        return {
            b.block_id for b in self.blocks.values()
            if block_id in b.dependencies
        }

    def transitive_dependents_of(self, block_id: str) -> Set[str]:
        seen: Set[str] = set()
        frontier = list(self.dependents_of(block_id))
        while frontier:
            current = frontier.pop()
            if current in seen:
                continue
            seen.add(current)
            frontier.extend(self.dependents_of(current) - seen)
        return seen

    def propose_cascade(self, changed_block_id: str, reason: str) -> CascadeReview:
        """Mark dependent blocks for review; never auto-archive or auto-promote."""
        if changed_block_id not in self.blocks:
            raise KeyError(changed_block_id)
        affected = sorted(self.transitive_dependents_of(changed_block_id))
        for block_id in affected:
            self.blocks[block_id].review_required = True
        return CascadeReview(
            changed_block_id=changed_block_id,
            affected_block_ids=affected,
            reason=reason,
            automatic_status_changes=[]
        )

    def record_decision(self, block_id: str, new_status: str, rationale: str, timestamp: str, actor: str):
        if block_id not in self.blocks:
            raise KeyError(block_id)
        block = self.blocks[block_id]
        prior = block.status
        block.status = new_status
        block.review_required = False
        block.history.append({
            "event": "status_decision",
            "timestamp": timestamp,
            "actor": actor,
            "reason": rationale,
            "prior_status": prior,
            "new_status": new_status,
        })

    def conflicts(self):
        """Return explicit contradiction links without resolving them automatically."""
        return [
            (b.block_id, target)
            for b in self.blocks.values()
            for target in b.contradicts
        ]
