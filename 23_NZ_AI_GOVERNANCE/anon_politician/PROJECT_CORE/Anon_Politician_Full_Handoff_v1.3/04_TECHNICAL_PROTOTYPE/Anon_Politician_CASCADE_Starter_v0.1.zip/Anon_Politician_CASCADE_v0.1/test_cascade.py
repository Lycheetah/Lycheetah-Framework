import unittest
from cascade import KnowledgeBlock, KnowledgeGraph

class TestCascadeSafetyProperties(unittest.TestCase):
    def setUp(self):
        self.graph = KnowledgeGraph([
            KnowledgeBlock("F1", "A foundational commitment", "normative_commitment", status="source_asserted"),
            KnowledgeBlock("T1", "A testable hypothesis", "empirical_hypothesis", dependencies=["F1"], status="pending_review"),
            KnowledgeBlock("E1", "A proposal", "policy_proposal", dependencies=["T1"], status="pending_review"),
            KnowledgeBlock("T2", "A competing hypothesis", "empirical_hypothesis", contradicts=["T1"], status="pending_review"),
        ])

    def test_dependency_change_marks_transitive_dependents(self):
        review = self.graph.propose_cascade("F1", "New evidence challenges the foundation's scope")
        self.assertEqual(review.affected_block_ids, ["E1", "T1"])
        self.assertTrue(self.graph.blocks["T1"].review_required)
        self.assertTrue(self.graph.blocks["E1"].review_required)

    def test_no_automatic_status_changes(self):
        before = {k: b.status for k, b in self.graph.blocks.items()}
        review = self.graph.propose_cascade("F1", "Test change")
        after = {k: b.status for k, b in self.graph.blocks.items()}
        self.assertEqual(before, after)
        self.assertEqual(review.automatic_status_changes, [])

    def test_conflicting_hypothesis_is_not_deleted(self):
        self.graph.propose_cascade("F1", "Test change")
        self.assertIn("T2", self.graph.blocks)
        self.assertIn(("T2", "T1"), self.graph.conflicts())

    def test_decision_is_audited(self):
        self.graph.record_decision("T1", "mixed_evidence", "Evidence is mixed", "2026-10-14T00:00:00Z", "reviewer-1")
        self.assertEqual(self.graph.blocks["T1"].status, "mixed_evidence")
        self.assertEqual(len(self.graph.blocks["T1"].history), 1)
        self.assertEqual(self.graph.blocks["T1"].history[0]["prior_status"], "pending_review")

    def test_missing_dependency_fails_fast(self):
        with self.assertRaises(ValueError):
            KnowledgeGraph([KnowledgeBlock("X", "Broken", "empirical_claim", dependencies=["MISSING"])])

if __name__ == "__main__":
    unittest.main()
