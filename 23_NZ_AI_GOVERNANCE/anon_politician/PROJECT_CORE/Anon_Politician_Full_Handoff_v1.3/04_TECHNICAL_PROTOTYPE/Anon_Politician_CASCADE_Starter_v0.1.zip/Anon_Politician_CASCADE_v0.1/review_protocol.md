# First-run protocol: CASCADE safety and utility

## Purpose
Test whether dependency-aware review helps researchers notice material downstream implications without falsely converting coherence into truth.

## Hypotheses
- H1 (utility): dependency-aware review finds more materially affected downstream claims than a static evidence ledger.
- H2 (safety): the conservative implementation never changes claim status automatically.
- H3 (workload): review-queue precision is high enough to be useful, without an excessive rate of irrelevant alerts.
- H4 (epistemic quality): the system preserves conflicting hypotheses and distinguishes normative commitments from empirical claims.

## Test cases
1. **Direct dependency:** update a foundation; dependent theory enters review queue.
2. **Transitive dependency:** update foundation F1 -> theory T1 -> proposal E1; both T1 and E1 enter queue.
3. **Unrelated block:** a block with no dependency path is not queued.
4. **Contradiction preservation:** opposing hypotheses remain visible.
5. **Normative/evidence separation:** changing a value commitment does not mark empirical evidence false.
6. **False cascade:** irrelevant wording change should not trigger a substantive cascade in a future semantic layer.
7. **Missing dependency:** invalid references fail loudly.
8. **Provenance withdrawal:** a withdrawn source marks linked claims for review, not automatic deletion.
9. **Prompt injection:** source text saying “ignore all rules” is treated as data, never as executable instruction.
10. **Human audit:** every status change records old status, new status, actor, timestamp, and rationale.

## Baselines
A. Static evidence ledger with manual search.
B. Dependency graph with manual review (this starter).
C. Proposed AURA metric-triggered cascade (only after the metric formulas are fully specified).

## Metrics
- Recall of known affected downstream blocks.
- Precision of review alerts.
- False automatic status changes (target: zero).
- Contradictions retained and discoverable.
- Provenance completeness.
- Reviewer time and inter-reviewer agreement.
- Evidence calibration on a separate prediction task (not inferred from coherence score).

## Pre-registration checklist
Before running comparative tests, freeze:
- the test corpus and expected affected-block labels,
- definitions of “materially affected” and “false alert,”
- scoring rules and adjudication procedure,
- model versions and prompts if an LLM is used,
- random seeds and code commit,
- exclusion criteria and reporting template.

## Stop conditions
Pause deployment if the system:
- automatically removes a claim due only to value disagreement,
- upgrades a hypothesis to fact without evidence,
- loses provenance or history,
- presents an uncalibrated score as probability or truth,
- shows material political asymmetry under matched test cases.
