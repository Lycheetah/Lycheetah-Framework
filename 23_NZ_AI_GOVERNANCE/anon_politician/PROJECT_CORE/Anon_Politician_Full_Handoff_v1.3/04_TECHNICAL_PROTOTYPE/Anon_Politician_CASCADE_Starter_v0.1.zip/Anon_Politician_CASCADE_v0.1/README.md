# Anon Politician — CASCADE starter v0.1

**Status:** research prototype / design proposal. Not a validated political decision system.

## Included
- `source_ledger.csv`: starter register of claims and concepts transcribed from the original `Anon Politician.pdf`.
- `cascade_block.schema.json`: provisional JSON Schema for a provenance-first knowledge block.
- `cascade.py`: small dependency graph that creates a review queue when upstream material changes.
- `test_cascade.py`: unit tests for key safety properties.
- `review_protocol.md`: first-run test protocol and interpretation rules.

## Non-negotiable design rules
1. Internal coherence is not truth.
2. Normative commitments and empirical propositions have different epistemic status.
3. A cascade triggers review; it does not automatically delete, demote, or promote a proposition.
4. Contradictions remain visible until adjudicated with a recorded rationale.
5. Source claims and independent findings must be separately represented.
6. AURA metrics (TE, VTR, PAI) remain unimplemented specifications until formulas, constructs, calibration, and validity tests exist.
7. No single scalar score should determine political or policy truth.

## Quick start
Requires Python 3.10+.

```bash
python -m unittest -v
```

## Important limitation
The starter ledger preserves the source terminology and records preliminary classifications. It is not yet a complete page-and-line citation audit. Before publication, each source-derived entry must be linked to a precise PDF page/line locator and the transcript's surrounding context. No external evidence has been independently reviewed in this starter package.

## Suggested next milestone
Run the unit tests, then compare this conservative review-queue approach against:
- a static evidence ledger,
- a simple dependency graph with manual review,
- the original proposed metric-triggered cascade.
Measure correctness, missed dependencies, false cascades, reviewer workload, and whether the system preserves legitimate disagreement.
