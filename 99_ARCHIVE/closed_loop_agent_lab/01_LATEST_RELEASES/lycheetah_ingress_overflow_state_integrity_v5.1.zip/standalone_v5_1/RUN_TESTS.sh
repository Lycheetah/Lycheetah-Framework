#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
(cd "$ROOT/v5_0" && python -m unittest -v test_shared_ingress_quota)
(cd "$ROOT/v5_1" && python -m unittest -v test_shared_ingress_quota)
