# Bounded-Cardinality Overflow State — v5.0 / v5.1

This focused bundle contains the v5.0 bounded-cardinality overflow-shard implementation and v5.1 overflow-state integrity hardening, tests, baseline fixture, and verified local test logs.

## Rerun

From `v5_1/`, run:

```bash
python -m unittest -v test_shared_ingress_quota
```

Expected: 54 tests pass. For the v5.0 baseline, run the same command from `v5_0/`; expected: 50 tests pass.

The module has no hosted-service dependency. These are local reference tests, not upstream CI or production certification. Use the cumulative lab for historical context and broader regressions.
