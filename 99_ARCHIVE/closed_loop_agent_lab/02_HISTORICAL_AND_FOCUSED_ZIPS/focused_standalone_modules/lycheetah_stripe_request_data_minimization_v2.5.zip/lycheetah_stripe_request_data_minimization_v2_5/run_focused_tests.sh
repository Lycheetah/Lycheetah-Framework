#!/usr/bin/env sh
set -eu
python -m unittest -v test_stripe_test_adapter.py
