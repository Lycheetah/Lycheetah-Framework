# Lycheetah Stripe Webhook Inbox v2.6 — standalone kit

This package contains the R16 signed Stripe snapshot-webhook inbox and loopback HTTP test receiver. It is a local reference implementation, not production-certified software; no Stripe credentials are included and no hosted Stripe calls or real refunds are performed.

## Run it

Requires Python 3.10+ and the standard library. From the extracted folder:

```bash
cd r16_webhook_reconciliation_v2_6
python run_webhook_tests_v2_6.py
python run_local_smoke.py
sha256sum -c SHA256SUMS_v2.6.txt
```

Expected local result: 54 focused tests pass. The loopback smoke should show `200 / INGESTED`, followed by `200 / DUPLICATE`, and a `RETRIEVE_CURRENT_PROVIDER_STATE` hint. A webhook cannot directly mark a refund successful.

## Production boundary

Use Stripe's official SDK signature verifier against the exact raw request body, with the endpoint's `Stripe-Signature` header and endpoint secret. Use a production HTTP framework/proxy with bounded request sizes, timeouts and explicit HTTP framing rules. Keep the inbox integrity key outside the database; HMAC authenticates records but does not encrypt them. Apply account scoping, retention, deletion, key rotation and current-state retrieval controls before use.

Sources and limitations are documented in `PROVIDER_CONTRACT_SOURCES_v2.6.md` and `RESULTS_v2.6.md`.
