# Lycheetah Closed-Loop Agent Lab — Current Index v3.5

**Current focus:** anti-rollback freshness verification through an external spent-challenge registry.

## Latest artifact: External Spent-Nonce Registry v3.5

- `r25_external_spent_nonce_v3_5/spent_nonce_registry.py` implements an HTTP protocol simulator with client HMAC authentication, per-request replay IDs, signed Ed25519 responses, and an atomic spent-challenge transition in a separate SQLite store.
- `r25_external_spent_nonce_v3_5/remote_monotonic_verifier.py` composes the retained v3.4 quorum verifier with the external registry; external consumption occurs before local consumption so an uncertain external response fails closed.
- **15 new registry integration tests** and 70 retained tests pass, for **71 tests in one combined local invocation**. The suite includes a positive case showing a primary-ledger-only rollback is rejected while the registry remains current.
- Two negative controls remain visible: a local-only rollback can replay, and a coordinated rollback of both the primary and registry ledgers also allows replay. Those are explicit limits, not successful defences.
- All five frozen v3.2 baseline acceptance cases were reproduced again.

## Downloads

- `lycheetah_external_spent_nonce_registry_v3.5.zip` — standalone v3.5 protocol, retained verifier, tests, source pins and docs.
- `lycheetah_closed_loop_agent_lab_v3.5.zip` — complete research history through v3.5.

## Research trajectory

The lab progressed from parser/receipt contract audits to authorization witness provenance, durable action outboxes, provider-specific refund recovery, signed webhook reconciliation, integrity key rotation, remote checkpoint anchors, independent witness quorums, local durable freshness challenges, and now external one-use challenge consumption.

## Limits and next milestone

The external registry is a **local HTTP simulator** with a separate SQLite file, not a production non-rollbackable trust domain. Coordinated restoration of both databases permits replay. The real next step is to deploy a protected registry in a separately administered account/domain, verify backup/restore and failover preserve spent state, and run conformance tests against that service. No upstream source was changed and no upstream CI was run.

See `r25_external_spent_nonce_v3_5/THREAT_MODEL_v3.5.md` and `r25_external_spent_nonce_v3_5/RESULTS_v3.5.md`.
