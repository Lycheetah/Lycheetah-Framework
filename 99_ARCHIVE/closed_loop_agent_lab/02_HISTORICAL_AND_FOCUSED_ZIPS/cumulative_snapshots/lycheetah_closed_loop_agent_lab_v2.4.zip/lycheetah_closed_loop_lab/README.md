# Lycheetah Closed-Loop Agent Lab — current index v2.4

**Current focus:** adversarial recovery-state audit of a test-mode-shaped Stripe Refund HTTP adapter. This is a local reference implementation with HTTP/SQLite tests—not an official Stripe SDK, production payment adapter, hosted Stripe certification or upstream Lycheetah integration.

## Latest artifact: Stripe Recovery State Audit v2.4

- `r14_stripe_recovery_state_audit_v2_4/stripe_test_adapter.py`: HMAC-authenticated SQLite operation ledger, request fingerprinting, `IN_FLIGHT` persistence before POST, safe recovery entrypoint, target preflight, data-minimized provider response storage, and conservative retry/reconciliation.
- `r14_stripe_recovery_state_audit_v2_4/stripe_contract_simulator.py`: loopback-only, deliberately incomplete HTTP provider simulator.
- `r14_stripe_recovery_state_audit_v2_4/test_stripe_test_adapter.py`: 76 focused HTTP, persistence, state-machine and adversarial test methods.
- `r14_stripe_recovery_state_audit_v2_4/run_complete_tests_v2_4.py`: retained R10–R12 suites plus the R14 adapter tests.
- `r14_stripe_recovery_state_audit_v2_4/RECOVERY_STATE_AUDIT_v2.4.md`, `SOURCE_LOG_v2.4.md`, and `RESULTS_v2.4.md`: design findings, official documentation sources, and evidence boundaries.

## Verification

**76/76 focused tests passed. 193/193 combined test methods passed.** Python compilation and the local lost-response smoke scenario passed. The smoke test uses only the local simulator on `127.0.0.1`: the simulated provider commits a refund, drops the response, then recovery reuses the same stored key and observes one simulated effect.

No hosted Stripe API call was made, no real Stripe credential was supplied, no real refund was created, no upstream Lycheetah source was changed, and full upstream CI was not run. This is local evidence for the code and simulator—not evidence that hosted Stripe behavior matches every simulated failure.

## Core policy and limitations

The adapter writes intent before HTTP, authenticates the local row with HMAC, pins request/account/API-version/currency context, commits `IN_FLIGHT` before the refund POST, and avoids retaining unnecessary provider response fields. HMAC provides integrity, not confidentiality. The adapter retrieves and checks a Charge/PaymentIntent snapshot before the POST, but that snapshot is not atomic with Stripe's later refund commit. The 23-hour cutoff is a conservative local policy, not a Stripe retention SLA. Old, incomplete, missing, duplicate, or ambiguous reconciliation results do not authorize a speculative second refund.

## Run

Python 3.10+ and standard library only:

```bash
python r14_stripe_recovery_state_audit_v2_4/run_complete_tests_v2_4.py
python r14_stripe_recovery_state_audit_v2_4/run_local_smoke.py
```

## Research history retained

- `r10_evidence_lease_v2_0/`: SQLite evidence leases, concurrency and crash recovery.
- `r11_provider_contracts_v2_1/`: general provider contract and retry policy.
- `r12_stripe_refund_contract_v2_2/`: offline provider-specific refund recovery policy.
- `r13_stripe_testmode_http_adapter_v2_3/`: first HTTP/SQLite adapter and initial adversarial tests.
- `r14_stripe_recovery_state_audit_v2_4/`: retry cutoff, in-flight state, target preflight, response minimization and recovery-state audit.
- Earlier receipt/policy schema audits, witness provenance and durable action outbox research remains archived.

## Promotion gate

Before any production proposal: run controlled Stripe test-mode conformance with an authorized account and pinned API version; test Connect context, lost responses, idempotency concurrency, webhook/retrieval recovery, local secret rotation, data migration/backups, monitoring and failure reconciliation. A local authorization store cannot atomically enforce its evidence predicate at Stripe's remote commit boundary. Independent security review is required.
