# Lycheetah Closed-Loop Agent Lab — current index v2.3

**Current focus:** an HTTP-level, test-mode-only Stripe Refund adapter built on the v2.2 offline recovery contract. This is a local contract-tested reference implementation—not a production payment adapter, upstream integration, or hosted Stripe certification.

## Latest artifact: Stripe Test-Mode HTTP Adapter v2.3

- `r13_stripe_testmode_http_adapter_v2_3/stripe_test_adapter.py`: test-key-only HTTP client, durable SQLite intent store, row HMAC, exact request/context binding, no redirect following, and conservative retry/reconciliation.
- `r13_stripe_testmode_http_adapter_v2_3/stripe_contract_simulator.py`: local loopback-only HTTP provider simulator; not a complete Stripe emulator.
- `r13_stripe_testmode_http_adapter_v2_3/test_stripe_test_adapter.py`: 51 endpoint-specific HTTP/SQLite adversarial tests.
- `r13_stripe_testmode_http_adapter_v2_3/run_complete_tests_v2_3.py`: retained v2.0–v2.2 suites plus the new HTTP adapter suite.
- `r13_stripe_testmode_http_adapter_v2_3/STRIPE_TESTMODE_HTTP_ADAPTER_v2.3.md`, `SOURCES_v2.3.md`, and `RESULTS_v2.3.md`: design, official documentation source log, and evidence boundaries.

## Verification

**51/51 focused tests passed. 117/117 retained tests passed. 168/168 combined test methods passed.** Python compilation and local smoke scenario passed. The smoke test dropped a response after the mock provider committed; recovery reused the same persisted key and returned the previously stored simulated refund, with exactly one effect.

No hosted Stripe API calls were made, no real Stripe credentials were supplied, no refund was created, no live-mode key is accepted, no upstream Lycheetah source was changed, and the full upstream package CI was not run. This is local evidence for the code and simulator—not evidence that the hosted provider behaves exactly like the simulator.

## Current recovery rule

The adapter writes intent before sending HTTP, HMAC-authenticates the full local ledger row, pins the request body, account scope, connected-account header, test mode, API version and expected currency, and refuses arbitrary HTTPS endpoints or redirects by default. It reuses the same persisted idempotency key only within a conservative 23-hour cutoff. A stored API v1 500, stale key, mismatch, incomplete pagination, duplicate match, bad response or zero correlated refunds goes to reconciliation, not a speculative new refund.

## Run

Requires Python 3.10+ and only the standard library:

```bash
python r13_stripe_testmode_http_adapter_v2_3/run_complete_tests_v2_3.py
python r13_stripe_testmode_http_adapter_v2_3/run_local_smoke.py
```

The local simulator runs on `127.0.0.1`. The smoke test uses only a mock test-shaped key. The adapter is configured to refuse live-mode keys.

## Research history retained

- `r10_evidence_lease_v2_0/`: SQLite evidence leases, race and crash recovery.
- `r11_provider_contracts_v2_1/`: generic provider contract and retry policy.
- `r12_stripe_refund_contract_v2_2/`: offline endpoint-specific Stripe recovery policy.
- `r13_stripe_testmode_http_adapter_v2_3/`: actual local HTTP interface and persistent operation ledger.
- Earlier receipt/policy schema audits, witness provenance, durable outbox and authority-boundary work remain in the research archive.

## Promotion gate

Before a production proposal: run controlled Stripe test-mode conformance with the intended account and pinned API version; test Connect context, lost responses and retries, webhook/retrieval recovery, idempotency races, rate limiting, local secret rotation, data migration/backups, and failure reconciliation. A local authorization store cannot atomically enforce its evidence predicate at Stripe's remote commit boundary.
