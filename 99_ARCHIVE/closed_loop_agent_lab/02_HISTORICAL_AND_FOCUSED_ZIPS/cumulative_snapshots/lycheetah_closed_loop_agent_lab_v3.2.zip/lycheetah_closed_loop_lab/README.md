# Lycheetah Closed-Loop Agent Lab — Current Index v3.2

**Current focus:** detect equivocation and stale-view rollback in the remote checkpoint protocol. v3.2 adds an independent witness-quorum reference protocol to the v3.1 signed remote-anchor client/server simulator.

## Latest artifact: Checkpoint Witness Quorum v3.2

- `r22_checkpoint_quorum_v3_2/checkpoint_witness_quorum.py` verifies primary-signed checkpoint records, creates per-witness Ed25519 votes, builds 3-of-4 quorum certificates for a one-witness fault budget, locks per-database sequence heads through a guard, verifies history continuity, requests nonce-fresh head reports, and extracts signed equivocation evidence.
- `r22_checkpoint_quorum_v3_2/test_checkpoint_witness_quorum.py` includes 31 focused test methods for valid/invalid anchor records, same-sequence forks, quorum thresholds, backup restore against surviving guard state, stale certificate/current-head mismatches, fresh challenge replay, concurrent competing heads, and one-/two-witness compromise cases.
- `r22_checkpoint_quorum_v3_2/RESULTS_v3.2.md` records 31 focused tests plus the 74 retained v3.1 tests, all passed in five separate process invocations (105 total methods). This is **not** a monolithic all-tests run or upstream CI.
- The local SQLite monotonic guard remains a reference/test adapter. It cannot prevent coordinated rollback of both its own file and the witness's local ledger. A production installation needs independently operated witness services with protected keys and an external monotonic/CAS store.

## Quick start

```bash
cd r22_checkpoint_quorum_v3_2
python -m pip install -r requirements.txt
./run_v3_2_tests.sh
python demo_quorum_v3_2.py
```

## Historical research

Previous versions are retained for traceability: R10 evidence leases; R11 provider contracts; R12–R15 Stripe refund recovery and HTTP-adapter hardening; R16 webhook inbox; R17 transactional reconciliation queue; R18 trusted read-only reconciliation worker; R19 key rotation; R20 external freshness checkpoint; and R21 signed remote-anchor HTTP protocol. Earlier policy parser, receipt-schema and witness provenance audits remain in their versioned directories.

## Safety / integration boundary

- No hosted Stripe/anchor API calls, no real refunds, and no upstream Lycheetah code changes were made.
- Upstream default branch remains observed at commit `8ae1b367dcf09997e82ce66f9ad5d30ff36e5d65`; no branch, pull request or CI run was created.
- The witness quorum is a reference protocol, not a production deployment, a standardized transparency-log implementation, or proof the checkpointed state is safe. See `README_v3.2.md` and `r22_checkpoint_quorum_v3_2/THREAT_MODEL_v3.2.md`.

---

Previous release indexes remain available as `README_v3.0.md` and versioned changelogs/manifests.
