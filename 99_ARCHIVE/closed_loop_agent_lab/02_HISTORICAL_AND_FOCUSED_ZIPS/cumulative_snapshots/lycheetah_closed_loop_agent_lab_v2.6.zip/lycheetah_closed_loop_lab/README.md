# Lycheetah Closed-Loop Agent Lab — current index v2.6

**Current focus:** making uncertain tool-side effects recoverable without turning an authenticated message, stale snapshot, or provider webhook into false proof of success. The lab contains a chain of local experiments, reference implementations, fault models and regression tests. It is not a production-certified safety platform.

## Latest artifact: Stripe Webhook Reconciliation Inbox v2.6

- `r16_webhook_reconciliation_v2_6/stripe_webhook_inbox.py`: exact-raw-body signature verifier (reference), strict event parser, account-bound HMAC-authenticated minimal event inbox, deduplication and reconciliation hints.
- `r16_webhook_reconciliation_v2_6/webhook_http_receiver.py`: loopback-only HTTP test receiver with Content-Length/body-size guards and sanitized results.
- `r16_webhook_reconciliation_v2_6/test_stripe_webhook_inbox.py`: signature, replay/dedup, parsing, privacy, account, tamper and concurrency regression tests.
- `r16_webhook_reconciliation_v2_6/test_webhook_http_receiver.py`: actual loopback HTTP tests.
- `r16_webhook_reconciliation_v2_6/STRIPE_WEBHOOK_INBOX_DESIGN_v2.6.md`: trust boundary and threat model.
- `r16_webhook_reconciliation_v2_6/PROVIDER_CONTRACT_SOURCES_v2.6.md`: official Stripe docs and verifier references.
- `r16_webhook_reconciliation_v2_6/RESULTS_v2.6.md`: results and limitations.

The rule is intentional: a verified webhook can only trigger retrieval of current provider state or manual reconciliation. It cannot directly mark an action successful. Raw webhook JSON and arbitrary metadata are not retained.

## Verification

**54/54 focused webhook tests passed; 256/256 combined retained test methods passed.** Python compilation and a loopback HTTP smoke passed. The smoke produced `200 / INGESTED`, then `200 / DUPLICATE`, and a `RETRIEVE_CURRENT_PROVIDER_STATE` hint without persisting the raw payload.

No hosted Stripe call was made, no real refund was created, no Stripe credential was supplied, no upstream Lycheetah file was changed, and complete upstream CI was not run. This is evidence for the reference implementation and synthetic provider contracts only—not hosted Stripe conformance.

## Run

Python 3.10+ and the standard library only for the reference package:

```bash
cd r16_webhook_reconciliation_v2_6
python run_webhook_tests_v2_6.py
python run_local_smoke.py
```

From the complete research archive root:

```bash
bash r16_webhook_reconciliation_v2_6/run_complete_tests_v2_6.sh
```

Production should use Stripe's official SDK webhook verification with exact raw request bytes; the standard-library verifier and loopback receiver here are bounded research artifacts, not production server components. See Stripe's [webhook endpoint guidance](https://docs.stripe.com/events/manage-webhook-endpoints).

## Core safety lessons carried forward

- Content hashes provide integrity only relative to a trusted digest; authentication requires a protected MAC/signature key.
- Local authorization state cannot atomically lock or transact with a remote provider's effect commit.
- Use durable intents and stable provider idempotency only within documented provider semantics and retention windows.
- Unknown outcomes should route to current-state reconciliation, not optimistic retry.
- Webhooks are delivered asynchronously and can be duplicated; verify signatures, deduplicate by event ID and retrieve current state before terminal decisions.
- HMAC is not encryption. Minimized local records still need access control, key rotation, retention and deletion policy.

## Research history retained

- `r10_evidence_lease_v2_0/`: SQLite evidence leases, concurrency and crash recovery.
- `r11_provider_contracts_v2_1/`: provider contract and retry decision policy.
- `r12_stripe_refund_contract_v2_2/`: offline provider-specific refund recovery policy.
- `r13_stripe_testmode_http_adapter_v2_3/`: first HTTP/SQLite adapter and initial fault injection.
- `r14_stripe_recovery_state_audit_v2_4/`: retry cutoff, in-flight state, target preflight and response minimization.
- `r15_stripe_privacy_state_hardening_v2_5/`: request privacy, bounded response reads, lifecycle state guards, clock trust and dispatch claims.
- `r16_webhook_reconciliation_v2_6/`: signed webhook inbox, account-scope revalidation and duplicate delivery protection.
- Earlier authority-gate, finality, receipt/policy schema, witness-provenance and durable-outbox experiments remain archived in this package.

## Promotion gate

Before any production proposal: use Stripe's official SDK, deploy behind a production-grade HTTP framework/proxy, run controlled test-mode conformance with a configured endpoint and connected-account context, test webhook retries and current-state retrieval, implement retention/monitoring/key rotation, run independent security review, and pass the upstream package suite/CI. No local test can make separate local and remote transactions atomic by assertion.
