# Lycheetah Closed-Loop Agent Lab — Current Index v3.4

**Current focus:** durable one-use freshness challenges for the checkpoint-witness quorum.

## Latest artifact: Durable Freshness Challenge v3.4

- `r24_durable_freshness_v3_4/durable_freshness_verifier.py` persists freshness challenges, binds each to the database and a fingerprint of protocol version/trusted public keys/fault budget/clock window/TTL, HMAC-authenticates each row, and atomically consumes a challenge only after the retained v3.3 chain and raw reports verify.
- `r24_durable_freshness_v3_4/test_durable_freshness_verifier.py` adds 19 lifecycle tests, including eight contenders racing on the same nonce.
- Combined retained v3.3 quorum + v3.4 lifecycle suite: **56 test methods passed**.
- One passing test is an intentional negative control: restore a pre-consumption SQLite snapshot and replay becomes possible. This keeps the known rollback limitation explicit; it is not reported as a successful defence.
- Five frozen v3.2 baseline acceptance cases were re-run and reproduced.
- No hosted API calls, no real refunds, no upstream branch/PR/source changes.

## Downloads

- `lycheetah_durable_freshness_challenge_v3.4.zip` — standalone v3.4 implementation, tests, and frozen v3.2 baseline.
- `lycheetah_closed_loop_agent_lab_v3.4.zip` — complete versioned history through v3.4.

## Research trajectory

The project moved from assurance receipt/policy contract audits into admission-witness provenance, durable action outboxes, evidence leases, provider-specific retry contracts, a Stripe refund test-mode adapter, webhook/reconciliation queues, integrity key rotation, remote checkpoint anchoring, independent witness quorums, and now durable challenge lifecycle enforcement.

## Limits and next milestone

A local SQLite database and HMAC are tamper-evident against row edits without the key, but not rollback-resistant if the whole pre-consumption snapshot is restored. Production needs separately administered non-rollbackable nonce-consumption state, protected key custody, authenticated roster governance, and real independent failure domains. The immediate next work is to define and test an externally administered challenge-consumption/CAS interface, not claim SQLite is sufficient.

See `r24_durable_freshness_v3_4/THREAT_MODEL_v3.4.md` and `r24_durable_freshness_v3_4/RESULTS_v3.4.md`.
