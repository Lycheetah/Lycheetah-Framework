# Lycheetah Closed-Loop Agent Lab — v0.3

**Status: R0 research prototype.** This pack combines a synthetic regulator comparison, an analytical observer-sensitivity grid, a test-evaluator calibration microtask, and a mathematical common-mode error model. It is not a production agent, hardened sandbox, live-model evaluation, or evidence of deployment safety.

## Research question

Can an explicit task-outcome observer detect failures missed by conventional coding-agent controls—and can we trust the evaluator enough to authorize that observer to change decisions? The program is to establish useful capability while preserving observability, controllability, recoverability, and human review.

## What's new in v0.3

- `observer_probe_v0_3/`: a local microtask with one explicit behavioral contract, a weak three-case public suite, a 19-check contract suite, two valid implementations with different structures, and six planted defects.
- `PROBE_RESULTS.md` and `probe_results.json`: candidate-by-candidate results. The public suite accepts four deliberately flawed candidates; the contract suite rejects these six authored defects and accepts both known-valid implementations.
- `COMMON_MODE_ERRORS.md`, `correlated_observers.py`, `correlated_observer_grid.csv`, and `correlated_observer_results.json`: formula and sensitivity grid showing how correlated observer errors can undermine an assumption of independent evidence.
- `CYBERNETIC_INTERPRETATION.md`: maps plant, target, controller, actuator, sensors, comparator, feedback, disturbances, and stop conditions to the coding-agent use case.

These results are calibration evidence about a small locally authored fixture, not results from a model or a representative benchmark.

## Earlier work retained

- `harness.py`: fourteen authored cases comparing conventional process gates with an extra postcondition/change-set observer.
- `test_harness.py`: eight tests of that synthetic decision fixture.
- `observer_stress.py`: 72 analytical sensitivity scenarios across assumed prevalences, sensitivities and specificities.
- `OBSERVER_VALIDATION_PROTOCOL.md`: frozen contract, trusted execution evidence, blinded adjudication, adversarial test checks, metrics, and promotion gates.
- `NEXT_EXPERIMENT.md`: proposed path to an instrumented real-task dry run and paired trial.

## Reproduce

Requires Python 3.10+ and only standard-library modules.

Run the original fixture and its tests from this directory:

```bash
python harness.py
python observer_stress.py
python -m unittest -v
```

Run the v0.3 calibration probe and tests:

```bash
cd observer_probe_v0_3
python run_probe.py
python correlated_observers.py
python -m unittest -v
```

Expected results: 13 tests in the original suite and 10 tests in the v0.3 probe suite pass; each command writes deterministic output files. These validate authored logic, not real-world accuracy.

## Key result from the local probe

The three-case public suite accepted 6/8 candidates, including four of six deliberately defective candidates. The larger contract suite accepted the two known-valid candidates and rejected all six planted defects. Crucially, a second valid implementation with a different internal structure was accepted; the suite checks behavior rather than matching the reference code's shape.

The result is deliberately scoped: all candidates and labels were authored in one fixture. That a hand-authored contract test passes planted examples is not proof that the contract is complete, and it says nothing directly about model quality.

## Cybernetic interpretation

A loop is not trustworthy merely because it closes. The reference state may be underspecified, a sensor may miss the essential variable, multiple sensors may share the same mistake, evidence may become stale, or the actuator may fail to enforce a stop. See `CYBERNETIC_INTERPRETATION.md` and `COMMON_MODE_ERRORS.md`.

## External context

OpenAI's July 8, 2026 audit of SWE-bench Pro estimated around 30% of tasks in the audited benchmark were broken, describing overly strict tests, underspecified prompts, low-coverage tests, and misleading prompts. This motivates evaluation quality controls but does not validate this prototype: https://openai.com/index/separating-signal-from-noise-coding-evaluations/

METR describes task-completion evaluations using repeated attempts, fixed environments and human review for potential reward hacking. This is relevant methodology to study when designing a paired pilot; it is not an endorsement of this particular prototype: https://metr.org/time-horizons/

## Current status and limits

- 14-case original decision fixture: authored deterministic scenarios.
- 72-row sensitivity grid: hypothetical parameters, no measured rates.
- v0.3 calibration task: eight local candidates, two labeled valid and six planted defects, no LLM-generated patch.
- Common-mode results: formula-based expectations, no observed correlation data.
- No live model was called; no real Lycheetah repository-maintenance task was executed; no sandbox or external effect was tested; no GitHub repository files were changed.
- No safety superiority, general model capability, or production reliability claim is supported.

Repository context: https://github.com/Lycheetah/Lycheetah-Framework
