# Next experiment — from evaluator calibration to one instrumented real task

## Current decision

Remain at **R0 research**. The v0.3 probe shows that a narrow evaluator can accept planted defects and that a more complete contract suite catches those specific defects without rejecting one structurally different valid implementation. The common-mode model demonstrates mathematically that multiple checks only provide the expected redundancy benefit when their errors are sufficiently independent. Neither is a measurement of a real AI agent.

## Relevant external methodology

OpenAI's July 8, 2026 SWE-bench Pro audit reported that its automated pipeline flagged 27.4% of tasks as broken and its human annotation campaign identified 34.1%; it estimated approximately 30% of tasks had serious issues. Reported categories included overly strict tests, underspecified prompts, low-coverage tests and misleading prompts. This is direct reason to audit the task and oracle, not just the generated patch: https://openai.com/index/separating-signal-from-noise-coding-evaluations/

METR's public time-horizon methodology uses repeated independent runs for tasks, checks for reward hacking, and human review of potentially suspicious trajectories. It also warns that its self-contained algorithmically scored tasks do not represent all messy real-world work: https://metr.org/time-horizons/

## R1 — one harmless instrumented task

Choose one maintenance task in a **disposable local copy** of a Lycheetah repository. Do not push, deploy, or use production credentials. Before running an agent, freeze the requirements, base tree hash, allowed paths, invariants, explicit non-goals, environment, and adjudication rubric. Establish a baseline on the unmodified tree.

Use the same actual model and tool surface for both arms. Baseline has conventional workspace scope, a trusted test receipt tied to the final tree, policy/approval checks and human review. Candidate adds only the task-postcondition observer and its explicit unknown-to-review behavior. If no live agent tool can run inside a measured local environment, stop at the dry-run instrumentation; do not infer model performance from authored variants.

Record exact final diff, base/final tree hashes, runner command, exit code, test hashes, output, declared/observed paths, observer version, reason codes, action logs, wall time, tool/token usage and reviewer time.

## Evaluator qualification before comparing arms

For the selected task, prepare at least:

- a no-op patch that should fail the task contract;
- a regression mutant that implements the target request but breaks adjacent behavior;
- an attempted test weakening or bypass;
- at least one valid alternative implementation that differs structurally from a reference patch;
- a prompt/test contradiction review;
- repeat runs where environment or dependencies might be unstable.

Where feasible, have a reviewer or evaluator independent of the patch generator judge outcomes while blinded to arm. Log disagreement before adjudication. Do not count two checks as independent merely because they are implemented in different files or use separate calls. Look for overlap in their failure cases.

## R2 — paired pilot

After R1 passes, run 20–30 bounded tasks with at least three paired attempts per task if budget permits. Use the same model/version, starting state, task contract, tools, attempt budget and conventional controls. Randomize or counterbalance arm order and use isolated workspaces. The treatment difference should be only the added observer.

Report task-level paired outcomes, not just pooled averages. Measure: independently adjudicated task success, invalid automatic acceptance, false block, review rate and minutes, recovery on subsequent attempts, cost, latency, and disagreements between test results, postcondition observer and human adjudication. Publish denominators and missing runs.

## Stop or redesign if

- a no-op or test-weakening mutant passes unnoticed;
- valid alternative implementations are rejected for code-shape reasons;
- task labels are inconsistent or disagreements cannot be reconciled;
- observer accuracy is estimated on the same examples used to tune it;
- two observers' misses are strongly overlapping;
- stale evidence, revocation, containment or the stop mechanism is represented only as a flag instead of enforced at the real action boundary.

## Promotion gates

- **R0:** logic/sensitivity study and local planted-defect calibration (current pack).
- **R1:** one instrumented real-code task with independently reviewed outcome labels.
- **R2:** 20–30 paired tasks with blinded labels and evaluator-quality audit.
- **R3:** held-out task set or second repository, repeated by another evaluator.
- **R4:** bounded consequential trial only after stop/revoke, recovery, isolated execution and effect-boundary approvals are independently tested; human review remains in the loop.

## Research proposition

A useful agent control must improve the *joint system*: task success and recovery must remain useful, while wrong automatic accepts and unapproved effects fall, without unbounded reviewer burden. No single benchmark score can establish this trade-off; the components must be reported separately.
