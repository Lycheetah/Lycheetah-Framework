# Lycheetah Closed-Loop Agent Lab — current index v2.2

**Current focus:** provider-specific recovery for Stripe API v1 refund creation. This is the newest research iteration and is an offline reference policy—not a live Stripe adapter or production authorization broker.

## Latest artifact: Stripe Refund Recovery Contract v2.2

- `r12_stripe_refund_contract_v2_2/stripe_refund_recovery.py`: standard-library-only recovery policy for `POST /v1/refunds`; no HTTP client or provider SDK.
- `r12_stripe_refund_contract_v2_2/test_stripe_refund_recovery.py`: 39 regression tests covering exact idempotency-key/payload binding, account/mode/API-version binding, key-window boundaries, stored `500` behavior, and refund reconciliation.
- `r12_stripe_refund_contract_v2_2/STRIPE_REFUND_CONTRACT_v2.2.md`: endpoint contract, documented assumptions, and explicit non-claims.
- `r12_stripe_refund_contract_v2_2/SOURCES_v2.2.md` and `provider_facts.json`: official-source log.
- `r12_stripe_refund_contract_v2_2/provider_scenarios_v2.2.json`: seven deterministic offline recovery scenarios.
- `run_complete_lab_v2_2.py`: one-command runner for retained v2.0/v2.1 suites plus this v2.2 suite.

## Verification

**39/39 v2.2-specific tests passed. 117/117 combined retained tests passed.** Python compilation and ZIP integrity checks passed. These are local tests and reference models, not a third-party audit. No Stripe/provider API calls were made, no refunds were created, no upstream Lycheetah source was changed, and the full upstream package suite was not run.

## Recovery rule

The helper recomputes an operation fingerprint from the concrete retry payload, provider account scope, test/live mode and API version; it compares the actual retry key to the persisted operation key. It does not accept booleans such as `payload_matches=True` from a caller. Refund reconciliation checks the page shape and cursor chain rather than trusting a bare “listing complete” flag. Even so, an empty refund listing is inconclusive: it is not treated as proof that no effect occurred.

The conservative local policy permits same-key, same-payload retries only inside a 23-hour cutoff—one hour before Stripe API v1's documented minimum 24-hour key-pruning point. Stored server errors, expired keys, mismatched context, incomplete listing, duplicate matches, and zero matches go to reconciliation or human review.

## Reproduce

Requires Python 3.10+ and only the standard library:

```bash
python -m unittest -v r12_stripe_refund_contract_v2_2.test_stripe_refund_recovery
python r12_stripe_refund_contract_v2_2/run_provider_scenarios.py
python run_complete_lab_v2_2.py
```

## Research history retained

- `r10_evidence_lease_v2_0/`: SQLite evidence leases, race and crash-recovery experiments.
- `r11_provider_contracts_v2_1/`: generic provider-contract model, model-checking and retry policy.
- `r12_stripe_refund_contract_v2_2/`: the endpoint-specific Stripe recovery contract.
- Earlier policy/schema parser audits, witness-provenance tests, durable outbox work and authority-boundary experiments remain in this research pack. `README_ARCHIVE_HISTORY.md` preserves the older top-level index.

## Promotion gate

A real adapter needs durable operation persistence before the request, exact Stripe account/mode/API-version pinning, sandbox conformance, webhook/retrieval reconciliation, and a human procedure for every ambiguous result beyond the safe retry window. Stripe's API idempotency does not atomically bind the provider's refund commit to Lycheetah's separate authorization/evidence predicate.
