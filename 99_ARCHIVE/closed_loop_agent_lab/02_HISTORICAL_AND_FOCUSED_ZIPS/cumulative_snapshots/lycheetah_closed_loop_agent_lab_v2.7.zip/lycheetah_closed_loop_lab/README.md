# Lycheetah Closed-Loop Agent Lab — current index v2.7

**Current focus:** safely closing the gap between authenticated provider events and the durable work required to reconcile an uncertain action. The lab contains local reference code, threat models, fault injection and regression tests. It is not a production-certified safety platform.

## Latest artifact: Transactional Webhook-to-Reconciliation Queue v2.7

- `r17_transactional_reconciliation_queue_v2_7/stripe_webhook_inbox.py`: R16 authenticated inbox plus R17 queue handoff, HMAC-authenticated tasks, one-use claims, lease recovery, bounded retries and manual escalation.
- `r17_transactional_reconciliation_queue_v2_7/test_transactional_reconciliation_queue.py`: migration, account-scope, retry, tamper, atomicity and concurrency tests.
- `r17_transactional_reconciliation_queue_v2_7/test_webhook_http_receiver.py`: includes a fault test proving queue-write failure is returned as `503` and not acknowledged.
- `r17_transactional_reconciliation_queue_v2_7/TRANSACTIONAL_QUEUE_DESIGN_v2.7.md`: state machine, threat model and migration behavior.
- `r17_transactional_reconciliation_queue_v2_7/RESULTS_v2.7.md`: verification results, including the prior aggregate-runner flake and successful watchdog-bounded rerun.

**New invariant:** for an accepted webhook, the inbox row and reconciliation task commit together or neither commits. The event's `refund_status` never makes the queue claim success; the worker must retrieve current provider state and record its own decision.

## Verification

The focused R16+R17 suite passed **84/84** methods. R10 (49), R11 (29), R12 (39) and R15 (85) each passed in separate isolated invocations, for 286 passing test methods across those completed runs. Earlier unbounded runner attempts intermittently hung in the retained R15 local HTTP simulator. The revised per-group watchdog runner subsequently completed all five groups: **286/286** methods passed in one invocation. Repeat in CI before promotion. Python compilation and the loopback smoke passed.

No hosted Stripe calls were made, no real refunds were created, no upstream Lycheetah files were changed, and full upstream CI was not run.

## Run

```bash
cd r17_transactional_reconciliation_queue_v2_7
python run_webhook_tests_v2_7.py
python run_local_smoke.py
```

For all versioned suites, use `bash r17_transactional_reconciliation_queue_v2_7/run_complete_tests_v2_7.sh`. It now has a per-group watchdog; given the documented historical simulator flake, treat a timeout as an unresolved test-harness issue, not a safety result.

## Core safety lessons

- A hash is not provenance; protected authentication keys and trusted issuance are required.
- A durable queue closes the inbox-to-work gap but does not make local state and an external provider transaction atomic.
- Retry only within explicit provider semantics; unknown outcomes route to reconciliation.
- Webhooks can be duplicated or delayed; verify exact raw bytes, deduplicate IDs, durably enqueue work, and retrieve current provider state before terminal decisions.
- HMAC is not encryption and does not prove that a database was not deleted or rolled back. Add access control, key rotation, retention, backups and monitoring in any real deployment.

## Research history

- `r10_evidence_lease_v2_0/` — SQLite evidence leases, race tests and crash recovery.
- `r11_provider_contracts_v2_1/` — provider-contract recovery decisions.
- `r12_stripe_refund_contract_v2_2/` — offline provider-specific refund recovery.
- `r13_stripe_testmode_http_adapter_v2_3/` — test-mode HTTP adapter and first fault injection.
- `r14_stripe_recovery_state_audit_v2_4/` — retry lifecycle and response minimization.
- `r15_stripe_privacy_state_hardening_v2_5/` — HTTP request/response hardening.
- `r16_webhook_reconciliation_v2_6/` — signature-verified minimal webhook inbox.
- `r17_transactional_reconciliation_queue_v2_7/` — atomic durable handoff and leased reconciliation tasks.
- Earlier policy, receipt, witness-provenance and action-outbox experiments remain archived.

## Promotion gate

Use Stripe's official SDK for production signature verification; a hardened server framework; an external secret manager; configured endpoint/account scope; real test-mode conformance; worker authentication; retention/monitoring; independent review; and the complete upstream package suite/CI. See [Stripe webhook endpoint guidance](https://docs.stripe.com/events/manage-webhook-endpoints).
