# Lycheetah Closed-Loop Agent Lab — Current Index v4.0

**Current research focus:** validating both sides of the remote witness quorum boundary—mTLS witness RPC and mTLS coordinator ingress—while retaining HMAC request authentication, signed responses, replay detection and checkpoint quorum checks.

## Latest artifact: Coordinator mTLS Registry Gateway v4.0

- `r30_mtls_registry_gateway_v4_0/registry_gateway_mtls.py` adds an mTLS ingress adapter around the existing quorum-guarded registry dispatcher.
- Both TLS certificate-chain validation and an explicit coordinator URI-SAN allowlist are required before application dispatch.
- The gateway requires the existing HMAC request authentication; successful responses and error envelopes are verified under the existing Ed25519 response-signing contract.
- Only POST and two explicit route forms are allowed. Host/Content-Type/Content-Length validation, Transfer-Encoding rejection and a 128 KiB limit are enforced before registry dispatch.
- The harness carries four mTLS witness subprocesses, TLS server/client identity checks, durable replay protection and append-only quorum checkpoints.
- **38 retained quorum tests and 39 remote-witness/gateway tests passed separately (77 total).** Eight source fingerprints and compilation passed.

## Downloads

- `lycheetah_mtls_registry_gateway_v4.0.zip` — standalone gateway implementation, local witnesses, tests, source pin and run logs.
- `lycheetah_closed_loop_agent_lab_v4.0.zip` — complete retained research history through v4.0.

## Critical limitation

This validates a local reference architecture, not an independent distributed trust topology: four witnesses and the coordinator share one host/operator. Test CA and certificates are ephemeral. Production CA lifecycle/revocation, secret distribution, resource/rate limits, cross-host deployment, upstream project CI and production certification remain unvalidated. No hosted service was contacted and no upstream source was changed.

Read `r30_mtls_registry_gateway_v4_0/RESULTS_v4.0.md`, `THREAT_MODEL_v4.0.md`, and `UPSTREAM_INTEGRATION_PLAN_v4.0.md` for exact results and promotion criteria. Earlier experiments remain archived in this directory.
