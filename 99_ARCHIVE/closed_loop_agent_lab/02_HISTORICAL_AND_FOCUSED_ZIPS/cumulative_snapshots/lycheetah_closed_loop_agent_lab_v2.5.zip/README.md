# Lycheetah Closed-Loop Agent Lab — Stripe Recovery Branch v2.5

This archive is the Stripe refund recovery sub-workstream R10–R15. Its version numbering is local to this branch and distinct from the broader lab's current index.

Run from `lycheetah_closed_loop_lab/r15_request_data_minimization_v2_5/`:

```bash
python -m unittest -v test_stripe_test_adapter.py
python run_complete_tests_v2_5.py
python run_local_smoke.py
```

All tests use a local loopback simulator; no hosted Stripe API calls or real refunds. Results are local reference evidence only, not production certification or upstream CI.
