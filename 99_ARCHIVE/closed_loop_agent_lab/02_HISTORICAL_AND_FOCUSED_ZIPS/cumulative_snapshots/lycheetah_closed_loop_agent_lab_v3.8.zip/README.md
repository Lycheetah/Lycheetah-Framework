# Lycheetah Closed-Loop Agent Lab — Current Index v3.8

**Current research focus:** validating the spent-challenge anti-rollback checkpoint quorum across an actual HTTP/process boundary rather than calling witness objects in-process.

## Latest artifact: Remote Witness Process Boundary v3.8

- The registry coordinator now communicates with four distinct witness service subprocesses through a strict HTTP RPC client.
- Every witness process has a separate SQLite vote ledger file and its own Ed25519 witness key.
- RPC requests use per-witness HMAC authentication, a fresh timestamp and unique request ID, and bind method/path/body digest.
- Duplicate transport request IDs are rejected by a durable replay ledger.
- Server/client endpoints are numeric-loopback-only, redirects are disabled, routes/bodies are strict, and request size is bounded.
- Tests exercise bootstrap/mutation over HTTP, restart persistence, lost vote response after commit, one-witness outage tolerance, two-witness fail-closed behavior, body tampering, wrong key, replay, oversized request, and quorum anti-alias behavior.
- **38 inherited v3.7 tests and 17 new v3.8 tests passed in separate invocations (55 total).** Source fingerprint verification and Python compilation passed.

## Downloads

- `lycheetah_registry_remote_witness_process_v3.8.zip` — standalone implementation, inherited sources, tests and run logs.
- `lycheetah_closed_loop_agent_lab_v3.8.zip` — complete research history through v3.8.

## Critical limitation

Four processes on one host do not establish four independent machines or administrative trust domains. Test keys are loaded from local JSON configuration, and RPC uses HTTP + HMAC on loopback rather than production TLS/mTLS. A privileged same-host attacker could access all local data and key files. Full upstream CI was not run and no upstream source was changed.

Read `r28_remote_witness_process_v3_8/RESULTS_v3.8.md`, `THREAT_MODEL_v3.8.md`, and `UPSTREAM_INTEGRATION_PLAN_v3.8.md` for exact evidence and promotion criteria.
