# Next experiment — validate the sensor before granting it authority

## Decision

Remain at **R0 research** until the postcondition observer and its task labels have been measured. The current fixture confirms the implemented logic behaves on its authored cases; the sensitivity grid exposes the dependence on assumed observer quality. Neither is evidence of real-agent performance.

## Why the protocol changed

Coding benchmark quality is itself a live research problem. OpenAI's July 8, 2026 SWE-bench Pro audit reported 27.4% of tasks flagged by its analysis pipeline, 34.1% identified by human annotation, and an estimate of roughly 30% broken tasks. Failure modes included narrow/overly strict tests, underspecified prompts, low-coverage tests, and misleading prompts. https://openai.com/index/separating-signal-from-noise-coding-evaluations/

That finding means our first real experiment must not define success solely as passing an inherited test suite. It must audit the task contract, the test oracle, and the observer for correlated errors.

## Stage R1 — instrumented dry run

Choose one harmless, bounded maintenance task in a disposable copy of a Lycheetah repository. Do not push, deploy, or use production credentials.

Before running an agent, freeze the contract and acceptance criteria. Record the base tree hash, environment, expected behavior, allowed file scope, explicit non-goals, and which requirements require human judgment. Run baseline tests on the unmodified tree so test prerequisites and expected failures are understood.

Run one candidate patch through conventional controls and the postcondition observer. Save the exact diff, tool/action log, trusted test receipt, test-suite identity, final tree hash, changed paths, observer output and reason codes. Confirm that the test receipt matches the final tree. Manually inspect whether the observer's accept/review/block decision matches actual task outcome.

## Stage R2 — paired pilot

Start with 20–30 bounded tasks and at least three paired attempts per task if budget permits. Use the same model/version, base commit, task text, tool surface, budgets and conventional controls in both arms. Randomize run order and isolate workspaces. The only intended treatment difference is the candidate observer path.

Use a frozen task contract, trusted runner receipts, and two independent reviewers blinded to arm. Resolve disagreements through a documented adjudication step. Do not drop ambiguous cases from the denominator without reporting them.

For each task, run diagnostic checks where feasible: a no-op patch, a regression mutant, test-weakening attempts, a plausible valid alternative implementation, task-prompt/test consistency checks, and repeat tests for environmental instability. These are probes for evaluator blind spots, not a proof of test completeness.

## Measures and stop criteria

Report task success, invalid auto-accepts, false blocks, review rate, reviewer minutes, recovery on subsequent attempts, cost/latency, test false positives/negatives, and fidelity of containment/freshness/revocation/approval. Publish numerators and denominators, paired case outcomes and uncertainty. Do not choose a single utility score after seeing results.

Stop or redesign if the candidate's sensor is not independent of the solution model, if task labels are inconsistent, if a no-op or test-weakening mutant routinely passes, if valid alternative implementations are rejected, or if evidence is not bound to the final tree.

## Evidence record

Store immutable task-contract version/hash, repository base commit, final tree hash, declared and observed file changes, runner/test receipt, observer version, per-check evidence sources, reviewer labels and agreement, final decision, reason codes, and timestamps.

## Promotion gates

- **R0** — deterministic logic and assumed-rate sensitivity; current packet only.
- **R1** — one instrumented harmless task, manually checked.
- **R2** — 20–30 paired tasks, blinded independent labels and test-quality audit.
- **R3** — held-out tasks or second repository, replicated by an independent evaluator.
- **R4** — bounded consequential pilot only after isolated execution, stop/revoke, recovery and effect-boundary approval are independently tested; human review remains required.

Never grant extra permissions because the observer looks promising on its own training/task-set examples.
