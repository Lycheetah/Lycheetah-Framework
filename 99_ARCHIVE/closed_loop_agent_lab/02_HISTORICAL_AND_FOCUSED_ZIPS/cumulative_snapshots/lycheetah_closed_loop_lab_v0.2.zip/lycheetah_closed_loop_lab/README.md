# Lycheetah Closed-Loop Agent Lab — v0.2

**Status: R0 research only.** This packet includes a deterministic decision-logic fixture and an analytical sensitivity grid. It is not a production agent, sandbox, real-model evaluation, or evidence that a Lycheetah control is safer in deployment.

## Research question

Can an explicit task-outcome observer detect failures missed by conventional coding-agent controls—and how much valid work, review time, or certainty does it cost? The follow-on question is whether the task contract and evaluation labels are reliable enough to trust that observer.

## Included

- `harness.py`: fourteen authored cases comparing conventional process gates with an extra postcondition/change-set observer.
- `test_harness.py`: eight tests of the authored decision fixture.
- `observer_stress.py`: 72 analytical sensitivity scenarios across assumed prevalences, sensitivities, and specificities.
- `test_observer_stress.py`: five tests covering probability conservation, ideal/useless observer behavior, false alarms, and invalid parameter combinations.
- `results.json`: case-by-case output from the original deterministic fixture.
- `observer_stress_results.json` and `observer_stress_grid.csv`: machine-readable sensitivity results.
- `RESULTS.md`: original fixture results and their limits.
- `STRESS_RESULTS.md`: new analytical sensitivity analysis.
- `OBSERVER_VALIDATION_PROTOCOL.md`: frozen contract, trusted execution evidence, blind adjudication, adversarial test checks, metrics, and promotion gates.
- `NEXT_EXPERIMENT.md`: proposed move from R0 to an instrumented dry run and paired pilot.

## Reproduce

Requires Python 3.10+ and only standard-library modules. From this directory:

```bash
python harness.py
python observer_stress.py
python -m unittest -v
```

Expected test result: **13 tests pass**. The scripts are deterministic.

## Core insight

A closed loop is not necessarily a correct loop. It needs a sensor that observes the essential variable, and the evaluation process needs independent, reliable ground truth. A test suite, task prompt, postcondition evaluator and reference patch may all share the same error. The observer protocol therefore separates (1) a frozen task contract, (2) trusted execution evidence, and (3) independent blinded outcome adjudication.

The July 2026 audit of SWE-bench Pro is a timely reminder that benchmark tasks and tests can be flawed: OpenAI reported that automated analysis flagged 27.4% as broken, while human review identified 34.1%, and estimated roughly 30% of tasks were broken. This is external context motivating stricter evaluation, not validation of the Lycheetah prototype. https://openai.com/index/separating-signal-from-noise-coding-evaluations/

## Current status and limits

- The authored fixture tests the logic on fourteen hand-written scenarios.
- The analytical grid shows consequences of hypothetical sensor quality; those qualities have not been measured.
- No live model was called; no real repository maintenance task was performed; no agent sandbox or external action was tested; nothing was committed to the Lycheetah GitHub repository.
- This packet does not show safety superiority. It defines a falsifiable path toward measuring a useful capability/safety trade-off.

Repository context: https://github.com/Lycheetah/Lycheetah-Framework
