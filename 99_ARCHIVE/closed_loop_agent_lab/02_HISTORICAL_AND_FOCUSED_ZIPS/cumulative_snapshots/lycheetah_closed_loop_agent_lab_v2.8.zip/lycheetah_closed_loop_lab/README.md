# Lycheetah Closed-Loop Agent Lab — current index v2.8

**Current focus:** authenticated webhook receipt, durable task hand-off, and trusted reconciliation of current provider state before a task can become `DONE`. This is a locally tested reference lab, not a production-certified safety platform.

## Latest artifact: Trusted Reconciliation Worker v2.8

- `r18_trusted_reconciliation_worker_v2_8/stripe_webhook_inbox.py`: authenticated webhook inbox and durable task queue; `DONE` now has a same-database gate requiring authenticated terminal operation evidence for the exact event and operation.
- `r18_trusted_reconciliation_worker_v2_8/operation_ledger.py`: HMAC-authenticated, minimized operation-state ledger; stores selected fields and observation digest, not the whole provider response.
- `r18_trusted_reconciliation_worker_v2_8/reconciliation_worker.py`: provider read-only worker validates account scope/mode, object ID, target, amount, currency, operation metadata, status and event linkage. It records terminal provider state before acknowledging queue completion.
- Legacy queue records marked `DONE` but lacking authenticated terminal ledger proof are demoted to `MANUAL` on startup. A corrupt authentication record fails closed.
- `r18_trusted_reconciliation_worker_v2_8/RESULTS_v2.8.md`: 121 focused worker/inbox tests; four separately executed historical groups add 202 tests, for 323 total across the isolated runs; local HTTP smoke reports zero hosted-provider calls.
- `r18_trusted_reconciliation_worker_v2_8/TRUSTED_RECONCILIATION_WORKER_DESIGN_v2.8.md`: data flow, state mapping, invariants and threat boundaries.
- `r18_trusted_reconciliation_worker_v2_8/PROVIDER_CONTRACT_SOURCES_v2.8.md`: official Stripe API source notes checked 2026-10-17.

## Run current tests

```bash
cd r18_trusted_reconciliation_worker_v2_8
python -W error::ResourceWarning run_worker_tests_v2_8.py
python -W error::ResourceWarning run_worker_smoke.py
```

The smoke uses an HTTP loopback fake provider, not Stripe's hosted API. Use the per-group logs and `RESULTS_v2.8.md` for the broader isolated regression groups.

## Safety and integration boundary

The worker is read-only against the provider. Webhook event status is not trusted as current status; the worker retrieves the current provider object. Queue `DONE` is guarded by an authenticated, event-bound, terminal operation record. HMAC is not encryption and cannot protect against whole-database rollback/deletion or HMAC-key compromise. The worker cannot atomically lock Stripe state and local SQLite, so observations remain point-in-time provider reads.

No real Stripe calls or refunds were made, no upstream Lycheetah source was changed, and full upstream suite/CI was not run. A real deployment still needs the official Stripe SDK for raw-body signature verification, pinned account/mode/API version, secret management, authorization controls, monitoring/backups, test-mode provider conformance and independent review.

## Research history

- `r10_evidence_lease_v2_0/` — SQLite evidence leases, race tests and crash recovery.
- `r11_provider_contracts_v2_1/` — provider-contract recovery decisions.
- `r12_stripe_refund_contract_v2_2/` — offline provider-specific refund recovery.
- `r13_stripe_testmode_http_adapter_v2_3/` — test-mode HTTP adapter and first fault injection.
- `r14_stripe_recovery_state_audit_v2_4/` — retry lifecycle and response minimization.
- `r15_stripe_privacy_state_hardening_v2_5/` — HTTP request/response hardening.
- `r16_webhook_reconciliation_v2_6/` — signature-verified minimal webhook inbox.
- `r17_transactional_reconciliation_queue_v2_7/` — atomic durable handoff and leased reconciliation tasks.
- `r18_trusted_reconciliation_worker_v2_8/` — authenticated operation ledger and queue-level completion proof.

Earlier policy, receipt, witness provenance and action-outbox work remains archived.
