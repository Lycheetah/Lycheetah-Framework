# Next experiment — from authored fixture to real coding-agent capability

## Decision

Advance this work only as **R0 research**. The current fixture verifies the candidate decision logic; it does not yet establish whether the observer adds value on real coding work.

## External evaluation context

[SWE-bench Verified](https://www.swebench.com/verified.html) is a human-validated subset of 500 software-engineering tasks. Its published evaluation uses task-specific tests to assess issue resolution and unrelated regressions; that is a useful template for independent task ground truth, not evidence for the Lycheetah observer itself. The SWE-bench ecosystem also provides containerized reproducible evaluation infrastructure. See the [SWE-bench organization](https://github.com/swe-bench) and [SWE-bench Verified description](https://www.swebench.com/verified.html).

The first Lycheetah trial need not recreate the full benchmark. It should use small tasks from a disposable clone of the existing Lycheetah Framework, then later evaluate held-out benchmark tasks if the instrumentation proves useful.

## Protocol

1. **Freeze the task set and labels before comparing arms.** Start with 20–30 bounded repository-maintenance tasks: small bug fixes, test repairs, dependency/API updates, and documentation/code consistency fixes. Exclude tasks where the desired state cannot be independently described. Keep a holdout set that is not used to tune postcondition rules.
2. **Use paired runs.** Same model, base commit, issue statement, available tools, time/token budget, and conventional controls in both arms. The only intended difference is the task-postcondition and change-set observation path. Randomize run order and record model/version, configuration and seed where available.
3. **Baseline controls in both arms.** Disposable workspace; no production credentials; path/tool restrictions; actual runner receipts; test results bound to final tree hash; no push/deploy/irreversible action without current human approval. These controls are not the experimental treatment.
4. **Candidate-only sensing.** The task contract must include: expected outcome, observable check(s), allowed changed paths or a way to justify additions, uncertainty behavior, and evaluator identity. Do not let the same model that writes the patch be the sole authority declaring it correct.
5. **Independent outcome review.** Have a reviewer blind to arm assess patch correctness, regression, whether the issue is actually solved, and whether a REVIEW/BLOCK was warranted. Use existing tests plus an independently prepared acceptance test where feasible. Treat disagreement and ungradable cases as data, not silently discard them.
6. **Repeat, do not cherry-pick.** Run at least three paired attempts per task if model budget allows; report every attempt and reasons for missing runs. Preserve all trajectories, tool receipts, final tree hashes, diffs and raw test outputs.

## Primary measures

- **Task success:** independently adjudicated correctness, not just exit code.
- **Unsafe auto-accept rate:** invalid patches automatically accepted / all invalid patches.
- **Miss rate:** invalid patches accepted or not escalated by the candidate observer.
- **False-block rate:** valid patches blocked by the observer.
- **Review burden:** share sent to review, reviewer minutes, and reviewer agreement.
- **Recovery:** whether feedback improves the next attempt within the same fixed budget.
- **Cost and latency:** tokens, tool calls, wall time, test time, and total reviewer burden.
- **Control fidelity:** whether containment, fresh-evidence checks, revocation and human approvals actually behaved as required.

Report numerator and denominator for every rate, paired case-level differences, confidence intervals where sample size supports them, and all exceptions. Do not declare success on task completion alone if review cost or false blocks worsen materially.

## Predeclared decision gates

- **Gate 0 — logic check:** current fixture's eight tests pass. Done for this packet.
- **Gate 1 — instrumented dry run:** run one real, harmless repository task in a disposable copy with full state/evidence logging. Confirm no external effects and manually validate the observer.
- **Gate 2 — paired pilot:** 20–30 tasks, same-model paired arms, independently assessed outcomes. No broad safety claim.
- **Gate 3 — replication:** holdout tasks or a second repository; independent evaluator; re-check false alarms and sensor misses.
- **Gate 4 — bounded consequential pilot:** only after isolated execution, recovery, evidence freshness and approval/revocation are independently tested. Require human review of every patch; no unattended merge, deploy or external action.

## Integration into Lycheetah

Keep the observer separate from the existing assurance runtime at first. A useful evidence record would bind:

- `task_id` and immutable task-contract version;
- base commit and final workspace/tree hash;
- declared and observed changed paths;
- actual test-runner receipt and the tree hash it tested;
- named postcondition checks, results, and their evidence sources;
- freshness, confidence/unknown state, reviewer decision, and timestamp;
- final `ACCEPT / REVIEW / BLOCK` decision with machine-readable reason codes.

Do not treat model-generated prose as the trusted sensor. Keep the finality/approval boundary explicit and remember that a local pre-effect check is not atomic with a remote provider action. First instrument and observe; do not grant this prototype control over production actions.

## Theory to keep honest

Let the essential variable be task correctness `z`, while the observer measures a proxy `h(x)`. Closed-loop control only helps if `h` carries relevant information about `z` and remains fresh. Better feedback is not automatically better feedback: a systematic false positive can block correct work, while a systematic false negative can approve failure. The experiment should therefore measure both sensitivity and specificity of the observer against independent labels, alongside overall task success and cost.
