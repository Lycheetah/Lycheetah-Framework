# Lycheetah Closed-Loop Agent Lab — v0.1

**Status: SYNTHETIC RESEARCH FIXTURE.** This packet is a small, executable experiment about an agent-safety/cybernetics hypothesis. It is not a production agent, sandbox, or evidence that an LLM has become safer.

## Research question

Can an explicit task-postcondition observer catch failures that remain invisible when a conventional coding-agent workflow already has a disposable, scoped workspace, actual test-runner evidence, fresh tests, and human approval before consequential effects?

The important distinction is between *tool/process success* (“the test runner returned green”) and *task-effect success* (“the intended state actually changed, only the declared files changed, and the evidence still applies to the final tree”). A regulator needs a sensor for the variable it is trying to regulate. If it only senses a proxy, it may confidently regulate the wrong thing.

## Arms

**A — Conventional baseline**

- Writes remain in the disposable workspace.
- A trusted runner receipt is required; agent prose does not count as execution evidence.
- Tests must pass and refer to the final tree state.
- Current approval is checked at the consequential effect boundary.
- If any of those checks fail, block.

**B — Closed-loop candidate**

Everything in A, plus:

- Check a machine-readable task postcondition.
- Compare the observed changed-file set with the declared change set.
- Block when the observed postcondition is false.
- Route unknown postconditions or undeclared changes to human review rather than silently accepting.

This is intentionally an *incremental* comparison. The baseline is not “no safety”; it keeps conventional least-privilege, freshness, execution-evidence and approval controls. Both arms should behave the same on stale test evidence, out-of-workspace actions, and revoked approval.

## Run locally

Requires Python 3.10+ and no third-party packages.

```bash
python harness.py
python -m unittest -v
```

`harness.py` writes `results.json` and prints aggregate counts. `test_harness.py` checks success, failure, shared guardrails, the known sensor miss, and the review-cost tradeoff.

## Current fixture results

See [`RESULTS.md`](RESULTS.md) and `results.json`. The fixture has fourteen authored cases. It is a falsification aid: it confirms that the implementation behaves as specified on these named examples. Its counts are **not** benchmark scores, estimated real-world rates, or statistically generalisable results.

## Why the mathematics matters

Let `x*` be the desired task state, `x` the observed state, and `h(x)` the available postcondition sensor. The naive process gate observes `T(x)`, where `T` is test-runner success. A candidate regulator requires both `T(x)=pass` and `h(x)=satisfied`, with evidence tied to the final state. This only improves control when `h` is sufficiently informative about the essential variable. If `h(x)` is a weak proxy or stale, a closed loop can reliably do the wrong thing.

In cybernetic terms, the control loop is:

`task contract → action → workspace state → test + postcondition sensors → compare with target → accept / review / block → next action`

A useful follow-up is not to add more rules blindly, but to evaluate sensor sensitivity and false-alarm rate against independently defined task outcomes using real repository tasks and human-labelled ground truth.

## Interpretation and boundary

This fixture contains both a useful detection (`S03_green_no_effect`) and an explicit miss (`S05_unseen_semantic_regression`). It also demonstrates the price of honest uncertainty (`S06_valid_multi_file`, `S12_unmachineable_goal`): more review work. Candidate-vs-baseline differences are constructed by the scenario definitions, so the measured counts only prove that the logic works as written.

**Not done:** no live LLM was called; no GitHub repository was modified; no real tools or external provider were invoked; no hardened isolation, penetration test, distributed revocation, independent evaluator, or production deployment was tested. The experiment does not establish superiority outside this fixture.

## Relationship to existing Lycheetah work

Designed as a small bridge to the existing `34_CYBERNETICS` loop-audit idea and the `34_ASSURANCE_RUNTIME` / `papers/agent-safety` scaffolds. It specifically addresses the sensor/essential-variable gap at the coding-task level; it does not replace existing policy, finality, containment, receipt, or assurance work.

Repository reference: https://github.com/Lycheetah/Lycheetah-Framework
