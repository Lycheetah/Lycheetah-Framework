# Lycheetah Closed-Loop Agent Lab — Current Index v4.8

**Current focus:** agent authorization, durable recovery, remote witness integrity, mTLS ingress and tested abuse-resistance controls.

## Latest artifact: Hierarchical IPv6 Prefix Quotas v4.8

v4.7 added IPv6 `/64`-based peer buckets to prevent source-address rotation within one subnet from multiplying connection slots. v4.8 adds an **optional broader aggregate cap**, so a configured delegation such as one `/56` can have a total active-connection ceiling across many `/64`s. The broader cap is off by default to avoid assuming a universal network-fairness policy. Leaf and aggregate reservations use one process-local critical section or one shared SQLite write transaction; schema-5 configuration pins prefix semantics so mixed-policy replicas fail closed.

### Downloads

- [Standalone hierarchical IPv6 quota kit](sandbox:/mnt/data/lycheetah_ingress_hierarchical_ipv6_quotas_v4.8.zip)
- [Complete research lab through v4.8](sandbox:/mnt/data/lycheetah_closed_loop_agent_lab_v4.8.zip)
- [v4.8 checksums](sandbox:/mnt/data/lycheetah_v4.8_checksums.sha256)
- [v4.8 archive verification](sandbox:/mnt/data/lycheetah_v4.8_archive_verification.json)
- [v4.8 standalone test runner](r38_hierarchical_ipv6_quotas_v4_8/run_v4.8_tests.sh)

### Verification

- 26 exact local source/document fingerprints verified; Python compilation passed.
- Shared ingress store: 33 tests.
- Shared coordinator quota store: 13 tests.
- Checkpoint quorum: 38 tests.
- mTLS gateway/remote witness lifecycle suite: 59 tests across 15 shards, with zero errors, failures or surviving non-main threads.
- **143 passing methods across the four full local suite groups.** The v4.7/v4.8 differential probe observes three distinct `/64` addresses admitted under v4.7's per-leaf policy, versus two admitted and one denied under v4.8's explicit `/56` aggregate ceiling of two; a different `/56` remains independent.

### Boundaries

These are local reference results, not upstream CI or production certification. Local fingerprints pin this artifact, not byte identity to upstream files. The quota authority is SQLite for same-host processes in the same Linux PID namespace. Broader prefix caps can group unrelated legitimate clients and remain opt-in. Rate tokens apply after TCP accept, not to SYN traffic or upstream link saturation. No upstream source, branch or pull request was changed and no hosted service was called.

Earlier iterations and test artifacts remain archived in `lycheetah_closed_loop_lab/`.
