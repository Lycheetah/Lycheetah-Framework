# v0.4 verification log

**Run date:** 2026-10-16 (Pacific/Auckland)

## Test execution

Command: `python run_all_tests.py` from the lab root.

| Suite | Tests | Result |
|---|---:|---|
| Original control harness + observer sensitivity | 13 | PASS |
| Evaluator probe + correlated-observer model | 10 | PASS |
| Authority boundary gate | 14 | PASS |
| **Total** | **37** | **PASS** |

Additional checks: Python `compileall` completed without errors; synthetic demo JSON parsed and had seven scenarios.

## Synthetic authority-demo outcome

| Case | Deliberately weak boolean-claim baseline | Candidate gate |
|---|---|---|
| Valid host-issued token | Allow | Allow once |
| Boolean claim, no token | Allow | Deny |
| Action changed after approval | Allow | Deny |
| Policy digest changed | Allow | Deny |
| Token expired | Allow | Deny |
| Token modified | Allow | Deny |
| Same token used twice | Allow twice | First allow, second deny |

This is a behavior check against an intentionally insecure comparator, not a comparative test against a measured production integration. The demo uses an in-memory callback, not a real human, external tool, refund API, or repository dispatcher.

## Evidence boundaries

**Directly tested:** authored reference code and local SQLite behavior in tested conditions.

**Not tested:** real model behavior, actual host adapter, external identity provider, approval UX, production keys, process crash/restart under load, distributed replay, remote effect atomicity, production sandboxing, independent penetration review, or a live action provider.

## Important test-runner correction

During this turn, a direct combined unittest import from the project root failed for the two subfolder suites because their tests import sibling modules as top-level names. The suites pass when each runs from its intended working directory. `run_all_tests.py` now codifies that known-good invocation and provides one reproducible root-level command. This fixes the lab workflow; it does not affect the semantics of the individual tests.
