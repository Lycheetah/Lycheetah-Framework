# Next experiment — verify the real authority boundary before any agent trial

## Current decision

Remain at **R0 research**. v0.4 adds a local reference prototype for an action-bound approval token and atomic local single-use nonce claim. Fourteen tests cover the reference mechanism, including eight concurrent attempts to consume one token. The full research pack now runs 37 tests from a single command. All tests are local authored fixtures; they are not deployment evidence.

## What changed

The repository's `AssuranceRuntime` treats `human_approved` as caller-declared context and explicitly states that model-facing integrations must not populate the field. The source documentation also calls the finality gate a scaffold and notes that the SHA-256 witness digest is not authentication. These are legitimate trust-boundary requirements, not proof that an actual deployment currently violates them.

The new `authority_boundary_lab/` prototype moves the approval proof outside the agent's claimed fields: a host-held HMAC key signs a short-lived token binding the action digest and policy digest. A SQLite unique nonce claim prevents the same token being consumed more than once in this local store. See `AUTHORITY_BOUNDARY_FINDINGS.md`.

## R1 — inspect the actual integration first

Before choosing an agent task, locate the real host adapter that constructs `AssuranceEvent`, populates `human_approved`, obtains human confirmation, and dispatches the tool call. Answer these questions with code references and tests:

1. Can any model-controlled payload set or influence `human_approved`?
2. Does the human review UI show the exact canonical action, arguments, target and scopes that will execute?
3. Is the action object that is approved the same immutable snapshot passed to the dispatcher?
4. Can a queued, retried or parallel tool call reuse the approval for a different operation?
5. What happens when approval is revoked after admission but before dispatch?
6. On timeout, can the system know whether the external effect happened, or does it need idempotency and reconciliation?

If there is no deployed/usable adapter, write an adapter contract and a fake-provider integration test, and label it as a proposal. Do not infer host behavior from the evaluator alone.

## R1 acceptance tests

Use a disposable workspace and fake provider first. Required cases: exact approved action succeeds once; model-supplied approval boolean is ignored; mutation after approval is denied; policy change is denied; expired or revoked token is denied; concurrent replay causes at most one dispatch; crash/restart behavior is documented; a provider timeout after committing effect can be reconciled without duplicate effect; invalid or unauthenticated reviewer cannot mint approval; audit receipt ties reviewer, action hash, policy hash, token nonce and provider result together.

Keep issuer authority out of the agent process. HMAC can authenticate a token only if the secret and issuance API are actually protected. Human identity and confirmation need a trusted host flow. The local SQLite nonce store does not provide distributed atomicity or transactionality with a remote service.

## Paired task evaluation comes after the boundary is verified

Only after adapter boundary tests pass, choose one harmless real repository-maintenance task in a disposable local copy. Freeze requirements, initial tree hash, allowed paths, test command, invariants, non-goals and independent adjudication rubric before generation. Compare conventional host controls against the same controls plus a postcondition observer. Use the same model, tools, budget, workspace isolation and task contract in both arms.

Record exact patch, base/final tree hashes, tests and logs, approval/dispatch records, unexpected paths, independently judged outcome, reviewer burden, latency and cost. Include no-op, test weakening, correct alternative implementation, wrong-action approval, stale evidence and uncertain remote outcome probes. Blind the outcome reviewer to arm where feasible.

## Stop or redesign if

- the agent can mint approvals, access the key, or alter the action after the human approves it;
- two concurrent calls can use one token or provider retries can duplicate an effect;
- there is no trustworthy way to reconcile a timeout after an external effect;
- the observer can be tuned against evaluation examples then reported on those same examples;
- false blocks or review burden become excessive;
- we cannot distinguish actual task success from the model's claim that it succeeded.

## Promotion gates

- **R0:** current deterministic scenarios and local prototype.
- **R1:** inspected host adapter plus fake-provider integration tests at the true dispatch boundary.
- **R2:** one harmless real-code task with independently adjudicated correctness and instrumentation.
- **R3:** paired, multi-task pilot and second evaluator / held-out tasks.
- **R4:** only after independent security review, key lifecycle, revocation, recovery, remote idempotency, containment and human-control testing; bounded consequential trial, not broad deployment.

## Research proposition

A closed loop is useful only if the observed outcome is meaningful, the evidence is trustworthy, and the actuator enforces the decision at the point of effect. Human approval is not a boolean to trust; it is an authority-bearing event that must be authenticated, bound to the exact operation, time-limited, non-replayable, and reconciled with the result.
