# Lycheetah Closed-Loop Agent Lab — Current Index v3.6

**Current focus:** external spent-challenge registry hardening, monotonic service time, and bounded authenticated request replay state.

## Latest artifact: Registry Clock Monotonicity v3.6

- Builds on v3.5's external HTTP spent-challenge registry and durable freshness verifier.
- Adds a persisted HMAC-authenticated clock high-water mark, checked and advanced inside the serialized write transaction.
- Pins the client-request timestamp window so configuration cannot silently widen after stale replay IDs are pruned.
- Prunes request-ID records only after they are older than the authenticated cutoff; ordinary SQL changes to live request rows are refused.
- Rejects future-issued challenges before `issued_at_ms` and reuses one validated clock sample for authentication/high-water/route decisions.
- **11 new tests; 82 retained plus new methods pass** in one combined local invocation. Source pins, compilation and retained demonstrations pass.

## Downloads

- `lycheetah_registry_clock_monotonicity_v3.6.zip` — standalone R26 package with source pin, runbook, scenario matrix, tests and logs.
- `lycheetah_closed_loop_agent_lab_v3.6.zip` — complete research history through v3.6.

## What remains unproven

The registry still stores its own monotonic clock in SQLite. A coordinated rollback of its database (and the primary verifier database) to a valid prior snapshot can restore an old high-water mark and permit replay; the existing negative control remains in the suite. The simulator has no production TLS deployment, independent account, WORM anchor, privileged-admin hardening, rate limiting or restore/failover service. No upstream source was changed and upstream CI was not run. No hosted service or Stripe request was made.

The next milestone is not another local counter; it is deployment of the registry into a separately administered trust domain, followed by real backup/restore, failover and conformance drills against that service.

See `r26_registry_clock_monotonicity_v3_6/RESULTS_v3.6.md` and `r26_registry_clock_monotonicity_v3_6/THREAT_MODEL_v3.6.md`.
