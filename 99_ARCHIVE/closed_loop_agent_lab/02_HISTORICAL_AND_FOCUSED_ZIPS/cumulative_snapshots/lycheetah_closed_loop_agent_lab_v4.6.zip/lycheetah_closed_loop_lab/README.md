# Lycheetah Closed-Loop Agent Lab — Current Index v4.6

**Current focus:** agent authorization, durable action recovery, provider contracts, remote witness integrity, mTLS ingress, and pre-authentication quota correctness.

## Latest artifact: Attempt-Based Shared Ingress Quotas v4.6

v4.5 tied quota leases to process identity, process-start ticks, and Linux PID-namespace identity. v4.6 addresses an admission-accounting flaw: active/per-IP denials happened before global rate-token debit, letting rejected connection attempts hammer pre-auth quota paths without spending the attempt budget. v4.6 charges the global token before active/per-peer checks and canonicalizes IPv4-mapped IPv6 addresses to their IPv4 identity. Shared DB configuration pins the revised semantics so same-boot v4.5/v4.6 mixing fails closed.

### Downloads

- [Standalone ingress attempt-budget kit](sandbox:/mnt/data/lycheetah_ingress_attempt_budget_v4.6.zip)
- [Complete research lab through v4.6](sandbox:/mnt/data/lycheetah_closed_loop_agent_lab_v4.6.zip)
- [v4.6 checksums](sandbox:/mnt/data/lycheetah_v4.6_checksums.sha256)
- [v4.6 archive verification](sandbox:/mnt/data/lycheetah_v4.6_archive_verification.json)

### Verification

- 16 exact local reference fingerprints verified; Python compilation passed.
- Shared ingress store: 24 tests.
- Shared coordinator quota store: 13 tests.
- Checkpoint quorum: 38 tests.
- mTLS gateway/remote witness lifecycle suite: 53 tests; no surviving non-main threads.
- **128 passing methods across four suites.** A first buffered gateway run timed out at a rate-limit integration case; the isolated pair passed, the full unbuffered gateway run passed, and the final unbuffered all-suite runner passed all 128 tests. The unexplained initial timeout is retained in `r36_ingress_attempt_budget_v4_6/RESULTS_v4.6.md`.

### Boundaries

Local reference evidence, not upstream CI or production certification. The quota authority is SQLite for same-host processes in the same Linux PID namespace. Rate tokens apply after TCP accept, not to SYN traffic. The current gateway binds IPv4 only; mapped IPv6 canonicalization is tested at the generic store/helper boundary. No IPv6 `/64` prefix quota is implemented. No upstream source or pull request was changed and no hosted service was called.

Earlier iterations and test artifacts remain archived in `lycheetah_closed_loop_lab/`.
