# Lycheetah Closed-Loop Agent Lab — current index v3.0

**Current focus:** external freshness checkpoints and anti-rollback verification for Lycheetah's authenticated SQLite operations state. v3.0 fingerprints the entire logical database and compares it to an operator-approved monotonic checkpoint held in a separate reference store. This remains a research/reference tool, not a production-certified safety platform.

## Latest artifact: External Freshness Checkpoint v3.0

- `r20_external_checkpoint_v3_0/external_checkpoint.py` calculates a stable logical snapshot across the database schema and table contents, verifies signed operational tables, requires exact-state operator-HMAC approval for checkpoint changes, and detects a primary-only rollback when the latest external checkpoint remains available.
- `r20_external_checkpoint_v3_0/external_checkpoint_cli.py` provides fingerprint, publish and read-only verify modes. Verification requires no operator key.
- `r20_external_checkpoint_v3_0/RESULTS_v3.0.md` records 33 passing focused test methods. Tests cover stale primary restore, uncheckpointed state, schema drift, tampered anchor, exact-state approval, replay rejection and compare-and-swap races.
- The local SQLite anchor is a reference adapter only. It cannot detect an attacker who restores both primary and anchor files to the same older valid pair. Production requires an independently controlled remote monotonic/CAS anchor with durable high-water mark.
- Full historical groups are retained as separate logs. A recent all-groups diagnostic attempt did not exit cleanly after the R18 process printed a passing summary; no fresh monolithic aggregate pass or upstream CI is claimed. See `r20_external_checkpoint_v3_0/REGRESSION_SCOPE_v3.0.md`.

## Run current tests

```bash
cd r20_external_checkpoint_v3_0
./run_v3_tests.sh
```

No hosted Stripe API calls or real refunds were made. No upstream Lycheetah source, branch, or pull request was changed.

---

## Previous baseline: Integrity-Key Rotation v2.9

The v2.9 work remains an important prior milestone, and its files are retained below for history. The current iteration and its execution limits are summarized at the top of this index.


- `r19_integrity_key_rotation_v2_9/integrity_key_rotation.py` validates and atomically re-signs all HMAC-authenticated records across the v2.8 webhook inbox, reconciliation queue, and operation ledger under a replacement local integrity key.
- The utility refuses tampered records before backup, protects an SQLite backup with mode `0600` where supported, compares live database content against the backup after taking an exclusive transaction, applies re-signing as one transaction, and verifies the new key before commit and after it.
- It is **offline single-key rotation**, not an online key ring. All services using the database must be stopped, then restarted with the new key together.
- It rotates only the local database HMAC key. It does not rotate Stripe API keys or webhook signing secrets.
- `r19_integrity_key_rotation_v2_9/ROTATION_RUNBOOK_v2.9.md` contains operator steps and recovery boundaries. `RESULTS_v2.9.md` records 20 passing focused tests.

## Run current tests

```bash
cd r19_integrity_key_rotation_v2_9
python -W error::ResourceWarning -m unittest -v test_integrity_key_rotation.py
```

The recorded aggregate is 343 methods across separate isolated invocations: 323 retained regressions and 20 new rotation tests. The individual group logs and `ISOLATED_REGRESSION_SUMMARY_v2.9.json` show this boundary; a chained shell attempt showed an intermittent harness hang, so no single combined-run pass is claimed. Counts are not a substitute for the complete upstream Lycheetah test suite.

## Safety and integration boundary

HMAC is not encryption and cannot prevent deletion or whole-database rollback. A protected backup contains operational records and must be stored under deployment access/retention controls. Offline rotation needs a maintenance window. The logical fingerprint guard reduces the chance of re-keying a stale backup, but it cannot replace stopping every writer.

The v2.8 trusted reconciliation worker is read-only against Stripe and never creates refunds. All Stripe provider behavior in local tests uses a loopback fake; no hosted Stripe API calls or real refunds were made. No upstream Lycheetah source was changed and full upstream suite/CI remains unrun.

## Research history

This repository contains R10 evidence leases; R11 provider-contract policy; R12 refund recovery; R13–R15 HTTP adapter hardening; R16 webhook inbox; R17 transactional queue; R18 trusted reconciliation worker; and R19 integrity-key rotation. Earlier assurance parser, witness provenance and action-outbox work remains archived in their versioned directories.
