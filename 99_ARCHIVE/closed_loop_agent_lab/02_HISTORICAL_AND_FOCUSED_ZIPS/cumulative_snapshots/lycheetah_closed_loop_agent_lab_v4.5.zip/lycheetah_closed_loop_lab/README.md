# Lycheetah Closed-Loop Agent Lab — Current Index v4.5

**Current focus:** secure authorization, durable action recovery, remote witness integrity, mutual TLS ingress, and shared pre-authentication resource fairness.

## Latest artifact: Process-Bound Shared Pre-TLS Leases v4.5

v4.4 used lease TTL alone to reclaim ingress connection reservations, which can let a live-but-paused process resume after another replica has claimed its slot. v4.5 ties each lease to the owner process PID and Linux process-start ticks, binds the shared config to the Linux PID namespace inode, and reclaims an expired lease only when the owner is demonstrably dead or the PID has been reused. Stores inherited across `fork()` fail closed until reinitialized.

### Downloads

- [Standalone process-bound ingress quota kit](sandbox:/mnt/data/lycheetah_process_bound_ingress_v4.5.zip)
- [Complete research lab through v4.5](sandbox:/mnt/data/lycheetah_closed_loop_agent_lab_v4.5.zip)

### Verification

- 14 exact local source fingerprints verified; Python compilation passed.
- Shared ingress store: 20 tests passed.
- Shared coordinator quota store: 13 tests passed.
- Checkpoint quorum: 38 tests passed.
- Remote witness/mTLS gateway suite: 51 tests passed; the runner reports no surviving non-main threads.
- Total: 122 passing test methods across four separate invocations. Two relevant shared-ingress gateway tests were also rerun in a focused final-code invocation.

### Boundaries

Local reference evidence, not an upstream patch or production certification. The shared authority is SQLite for processes on the same host and same Linux PID namespace. It assumes trusted local storage and matching configuration. A live wedged process can pin capacity, and a resumed handler is not forcibly fenced from executing arbitrary work. No upstream source or CI was changed and no hosted service was called.

See `r35_process_bound_ingress_v4_5/RESULTS_v4.5.md`, `THREAT_MODEL_v4.5.md`, and `UPSTREAM_INTEGRATION_PLAN_v4.5.md`. Earlier versions remain archived.
