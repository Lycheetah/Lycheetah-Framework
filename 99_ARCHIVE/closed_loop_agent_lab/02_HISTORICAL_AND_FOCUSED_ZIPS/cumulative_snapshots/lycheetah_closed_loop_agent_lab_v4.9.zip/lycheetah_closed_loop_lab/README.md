# Lycheetah Closed-Loop Agent Lab — Current Index v4.9

**Current focus:** agent authorization, durable recovery, remote witness integrity, mTLS ingress, and tested abuse-resistance controls.

## Latest artifact: Hierarchical Attempt-Rate Quotas v4.9

v4.8 added optional aggregate IPv6 active-connection quotas across many leaf `/64` buckets. v4.9 adds **optional per-peer and IPv6-aggregate attempt-rate buckets**, so one high-rate source cannot consume the entire shared global new-connection attempt budget before unrelated sources get a chance.

### Downloads

- [Standalone hierarchical attempt-rate quota kit](sandbox:/mnt/data/lycheetah_ingress_hierarchical_attempt_quotas_v4.9.zip)
- [Complete research lab through v4.9](sandbox:/mnt/data/lycheetah_closed_loop_agent_lab_v4.9.zip)
- [v4.9 checksums](sandbox:/mnt/data/lycheetah_v4.9_checksums.sha256)
- [v4.9 archive verification](sandbox:/mnt/data/lycheetah_v4.9_archive_verification.json)
- [v4.9 standalone test runner](r39_hierarchical_attempt_quotas_v4_9/run_v4.9_tests.sh)
- [v4.9 verification results](r39_hierarchical_attempt_quotas_v4_9/RESULTS_v4.9.md)
- [v4.9 machine-readable results](r39_hierarchical_attempt_quotas_v4_9/results_v4.9.json)

### Verification

- 31 exact local source/document fingerprints verified; Python compilation passed.
- Shared ingress store: 42 tests.
- Shared coordinator quota: 13 tests.
- Checkpoint quorum: 38 tests.
- mTLS gateway/remote witness lifecycle: 60 tests across 15 isolated shards; every shard recorded zero errors, failures, and surviving non-main threads.
- **153 passing methods across the four full local suite groups.**
- Differential probe reproduces a source-flood fairness delta: under v4.8's global-only five-attempt budget, the noisy peer uses all five tokens and blocks an unrelated peer. With v4.9's optional peer cap of two, six further noisy-peer attempts are rejected at the peer bucket and the unrelated peer is admitted and the post-admission snapshot has about two global tokens remaining (fractional refill varies slightly).

### Boundaries

These are local reference results, not upstream CI or production certification. Local fingerprints pin this artifact, not byte identity to upstream GitHub. The quota authority is SQLite for same-host processes in the same Linux PID namespace. Prefix caps can group unrelated clients behind NAT or within shared IPv6 allocations and remain opt-in. Rate tokens apply after TCP accept, not to SYN floods or upstream link saturation. No upstream source, branch, or pull request was changed and no hosted service was called.

Earlier iterations and test artifacts remain archived in `lycheetah_closed_loop_lab/`.
