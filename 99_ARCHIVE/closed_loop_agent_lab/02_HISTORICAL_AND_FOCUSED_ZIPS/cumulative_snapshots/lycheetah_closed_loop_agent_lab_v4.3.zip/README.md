# Lycheetah Closed-Loop Agent Lab — Current Index v4.3

**Current focus:** secure authorization, durable action recovery, remote witness integrity, bounded mTLS ingress, authenticated-coordinator fairness, and now shared same-host quota enforcement across gateway processes.

## Latest artifact: Shared Coordinator Quotas v4.3

v4.3 extends v4.2's authenticated coordinator request limits with an opt-in transactional SQLite quota authority. When multiple gateway processes on the same host share the same database path and exact quota configuration, active slots and request-rate tokens are shared instead of multiplying per process.

### Downloads

- `lycheetah_shared_coordinator_quota_v4.3.zip` — standalone module, gateway integration, tests and runbook.
- `lycheetah_closed_loop_agent_lab_v4.3.zip` — complete research history through v4.3.

### Verification

- 10 local source fingerprints verified.
- Python compilation passed.
- Shared quota store suite: 13 passed.
- Retained checkpoint quorum suite: 38 passed.
- mTLS gateway / remote witness suite: 49 passed.
- Total: 100 local test methods passed across three separate invocations.
- Hosted service calls: none; upstream repository and CI unchanged.

### Important boundaries

The shared quota authority is SQLite for processes on one host, not a distributed quota service. Global/per-IP pre-TLS bounds remain process-local and authenticated quota enforcement begins only after HTTP headers parse. Quota buckets reset after OS boot-ID change, because monotonic timestamps cannot be compared across boots. Production CA lifecycle, OS-level FD limits, reverse proxy, multi-host topology and upstream CI remain unverified.

See `r33_shared_coordinator_quota_v4_3/RESULTS_v4.3.md`, `THREAT_MODEL_v4.3.md`, and `UPSTREAM_INTEGRATION_PLAN_v4.3.md`. Earlier versions remain archived.
