#!/usr/bin/env python3
"""Run v0.7 tests in-process to avoid nested unittest orchestration stalls."""
from __future__ import annotations
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parent
SUITE_DIR = ROOT / "authority_boundary_lab_v0_7"
sys.path.insert(0, str(SUITE_DIR))
suite = unittest.defaultTestLoader.loadTestsFromName("test_crash_recovery")
result = unittest.TextTestRunner(verbosity=2).run(suite)
if not result.wasSuccessful():
    raise SystemExit(1)
print("v0.7 crash/recovery suite passed (26 tests)")
