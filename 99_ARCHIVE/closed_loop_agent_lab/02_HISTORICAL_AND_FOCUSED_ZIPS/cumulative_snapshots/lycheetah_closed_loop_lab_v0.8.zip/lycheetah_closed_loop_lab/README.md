# Lycheetah Closed-Loop Agent Lab — v0.8

**Status: R0 research prototype.** This pack combines a synthetic regulator comparison, observer-sensitivity analysis, evaluator calibration, a local authority boundary prototype, separate-process crash recovery, and a trusted tool-catalog adapter. It is not a production agent, hardened sandbox, live-model evaluation, or evidence of deployment safety.

## Research question

Can an explicit task-outcome observer detect failures missed by conventional coding-agent controls—and can we trust the evaluator enough to authorize that observer to change decisions? The program is to establish useful capability while preserving observability, controllability, recoverability, and human review.

## What's new in v0.8

- `authority_boundary_lab_v0_8/tool_catalog.py`: trusted host catalog stamps the model proposal's canonical tool/arguments with side-effect class, scopes, dispatcher identity/version and host context. The proposal schema rejects model-supplied approval metadata.
- The active policy file must pin the exact catalog digest; changing the registry breaks the binding until the trusted policy is updated.
- `authority_boundary_lab_v0_8/test_tool_catalog.py`: 18 passing tests, including an end-to-end local run through the v0.7 separate-process fake host/provider and post-approval action-tampering rejection.
- `SIDE_EFFECT_CLASSIFICATION_AUDIT_v0.8.md`: documents a source-level concern in the actual Guard decision interface and, importantly, explains why it is not evidence that the Guard itself dispatches tools or is vulnerable in deployment.
- `CHANGELOG_v0.8.md`: version record and evidence boundaries.

## What's new in v0.7

- `authority_boundary_lab_v0_7/`: distinct host/provider OS processes, durable SQLite approval/operation and effect ledgers, crash injection, policy/revocation fence and recovery protocol.
- `CRASH_RECOVERY_RESULTS_v0.7.md`: 26 passing crash/recovery tests and explicit limitations, including why the shared SQLite fence is only a fake provider contract.
- The v0.7 suite is run separately from legacy suites because the combined nested runner did not finish reliably; see `NEXT_EXPERIMENT.md`.

## What's new in v0.6

- `HOST_ADAPTER_INTEGRATION_v0.6.md`: a synthetic outer-host workflow connected to the v0.5 reference gate and an in-memory idempotent fake provider.
- `authority_boundary_lab_v0_5/fake_host_adapter.py`: stable operation IDs, fake-reviewer display, trusted-registry dispatch, and reconciliation after provider timeouts.
- Eight additional tests cover approved dispatch, denial without approval, changed action/policy, revocation, concurrent duplicate use, timeout-after-commit reconciliation, and timeout-before-commit stop behavior.
- The legacy runner executes 65 tests across its four retained suites; v0.7 and v0.8 use independent runners.

## What's new in v0.5

- `HOST_BOUNDARY_AUDIT_v0.5.md`: read-only source audit of the actual Lycheetah Guard MCP component and its outer-host enforcement contract. The inspected server returns structured decisions; it does not dispatch external actions.
- `authority_boundary_lab_v0_5/`: corrective reference design after reproducing a callback-selection gap in v0.4. The execute API uses a trusted dispatcher registry and no longer accepts a per-call callback, current-policy digest, or time override.
- Dispatcher identity/version and deployment audience are signed; policy and clock are read from trusted host dependencies; local revocation and single-use consumption are covered by tests.
- `reproduce_v0_4_dispatcher_substitution.py`: bounded local counterexample. It records a mismatched callback label in memory and contacts no external system.
- `CHANGELOG_v0.5.md`: iteration record and limits.

## What's new in v0.4

- `authority_boundary_lab/`: host-signed, action-bound, time-limited, single-use approval gate for consequential actions, backed by a SQLite replay registry in this local prototype. It binds token validity to the canonical action and policy digests and dispatches the approved snapshot.
- `authority_boundary_lab/run_demo.py` / `demo_results.json`: seven synthetic cases compare a deliberately unsafe boolean-claim baseline against the candidate. The baseline is a failure-mode illustration, not a claim about the deployed Lycheetah integration.
- `authority_boundary_lab/test_authority_gate.py`: fourteen tests including wrong action/policy, expiry, tampering, sequential replay, concurrent token replay, frozen action snapshots, and uncertain effect handling.
- `AUTHORITY_BOUNDARY_FINDINGS.md`: evidence status, limitations, relation to established security practice and next engineering gate.
- `VERIFICATION_RESULTS.md`: recorded test counts, synthetic scenario outcomes and evidence limitations.
- `run_all_tests.py`: single project-root runner for all suites; it runs each suite from its required working directory, fixing the brittle cross-folder invocation.

## What's new in v0.3

- `observer_probe_v0_3/`: a local microtask with one explicit behavioral contract, a weak three-case public suite, a 19-check contract suite, two valid implementations with different structures, and six planted defects.
- `PROBE_RESULTS.md` and `probe_results.json`: candidate-by-candidate results. The public suite accepts four deliberately flawed candidates; the contract suite rejects these six authored defects and accepts both known-valid implementations.
- `COMMON_MODE_ERRORS.md`, `correlated_observers.py`, `correlated_observer_grid.csv`, and `correlated_observer_results.json`: formula and sensitivity grid showing how correlated observer errors can undermine an assumption of independent evidence.
- `CYBERNETIC_INTERPRETATION.md`: maps plant, target, controller, actuator, sensors, comparator, feedback, disturbances, and stop conditions to the coding-agent use case.

These results are calibration evidence about a small locally authored fixture, not results from a model or a representative benchmark.

## Earlier work retained

- `harness.py`: fourteen authored cases comparing conventional process gates with an extra postcondition/change-set observer.
- `test_harness.py`: eight tests of that synthetic decision fixture.
- `observer_stress.py`: 72 analytical sensitivity scenarios across assumed prevalences, sensitivities and specificities.
- `OBSERVER_VALIDATION_PROTOCOL.md`: frozen contract, trusted execution evidence, blinded adjudication, adversarial test checks, metrics, and promotion gates.
- `NEXT_EXPERIMENT.md`: proposed path to an instrumented real-task dry run and paired trial.

## Reproduce

Requires Python 3.10+ and only standard-library modules. Run retained suites separately from this directory:

```bash
python run_all_tests.py          # legacy suites: 65 tests
python run_v0_7_tests.py         # separate-process crash/recovery: 26 tests
python run_v0_8_tests.py         # trusted catalog + host/provider integration: 18 tests
```

Each command passed independently. A combined nested-runner invocation did not finish reliably, so this pack does not claim one aggregate 109-test invocation. See `VERIFICATION_RESULTS.md`, `CRASH_RECOVERY_RESULTS_v0.7.md`, and `NEXT_EXPERIMENT.md` for the separate run records. Reproduce the original authority boundary demo and the v0.4 callback-gap counterexample with:

```bash
python authority_boundary_lab/run_demo.py
python authority_boundary_lab_v0_5/reproduce_v0_4_dispatcher_substitution.py
```

Run the original fixture and its tests from this directory:

```bash
python harness.py
python observer_stress.py
python -m unittest -v
```

Run the v0.3 calibration probe and tests:

```bash
cd observer_probe_v0_3
python run_probe.py
python correlated_observers.py
python -m unittest -v
```

The separate commands below remain available for focused debugging. They validate authored logic, not real-world accuracy.

## Key result from the local probe

The three-case public suite accepted 6/8 candidates, including four of six deliberately defective candidates. The larger contract suite accepted the two known-valid candidates and rejected all six planted defects. Crucially, a second valid implementation with a different internal structure was accepted; the suite checks behavior rather than matching the reference code's shape.

The result is deliberately scoped: all candidates and labels were authored in one fixture. That a hand-authored contract test passes planted examples is not proof that the contract is complete, and it says nothing directly about model quality.

## Cybernetic interpretation

A loop is not trustworthy merely because it closes. The reference state may be underspecified, a sensor may miss the essential variable, multiple sensors may share the same mistake, evidence may become stale, or the actuator may fail to enforce a stop. See `CYBERNETIC_INTERPRETATION.md` and `COMMON_MODE_ERRORS.md`.

## External context

OpenAI's July 8, 2026 audit of SWE-bench Pro estimated around 30% of tasks in the audited benchmark were broken, describing overly strict tests, underspecified prompts, low-coverage tests, and misleading prompts. This motivates evaluation quality controls but does not validate this prototype: https://openai.com/index/separating-signal-from-noise-coding-evaluations/

METR describes task-completion evaluations using repeated attempts, fixed environments and human review for potential reward hacking. This is relevant methodology to study when designing a paired pilot; it is not an endorsement of this particular prototype: https://metr.org/time-horizons/

## Current status and limits

- 14-case original decision fixture: authored deterministic scenarios.
- 72-row sensitivity grid: hypothetical parameters, no measured rates.
- v0.3 calibration task: eight local candidates, two labeled valid and six planted defects, no LLM-generated patch.
- Common-mode results: formula-based expectations, no observed correlation data.
- No live model was called; no real Lycheetah repository-maintenance task was executed; no sandbox or external effect was tested; no GitHub repository files were changed. The assurance and MCP source was inspected through read-only repository access; the local checkout did not include the full repository.
- v0.4 callback-selection gap is reproducible in the lab reference API. v0.5 removes the per-call callback and binds dispatch to a host-owned target ID/version, but trusted-host isolation and external effect reconciliation remain outside this prototype.
- The authority gate assumes a trusted host protects the HMAC key and issuance route, and authenticates the human. It does not do this itself. The current repository MCP server is a receipt issuer, not a downstream tool dispatcher; no live MCP host dispatch path was exercised. v0.7 models a durable fake provider using local SQLite and shared-store fencing; a local lock cannot provide remote atomicity. v0.8 supplies catalog binding and a local fake-host/provider integration, but no authenticated reviewer or OS-separated trusted host is present.
- No safety superiority, general model capability, or production reliability claim is supported.

Repository context: https://github.com/Lycheetah/Lycheetah-Framework
