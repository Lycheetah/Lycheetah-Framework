# Verification results — current v0.8 pack

## Current v0.8 verification (2026-10-16)

The three retained groups have passed in separate invocations:

| Suite | Tests | Command | Result |
|---|---:|---|---|
| Legacy v0.1-v0.6 suites | 65 | `python run_all_tests.py` | PASS; `test_output_v0_8_legacy.txt` |
| v0.7 process crash/recovery | 26 | `python run_v0_7_tests.py` | PASS; `authority_boundary_lab_v0_7/test_output_v0_7.txt` |
| v0.8 trusted catalog + v0.7 fake host/provider | 18 | `python run_v0_8_tests.py` | PASS; `authority_boundary_lab_v0_8/test_output_v0_8.txt` |

Do not describe these as a single unified 109-test invocation. A combined nested-runner command did not finish reliably. Each group passed when run independently.

The v0.8 cases verify strict model-proposal shape, trusted effect classification and route/scope metadata, catalog digest binding, argument checks, and an end-to-end local fake-host/fake-provider flow including dispatch denial after stamped-action tampering. They do not execute the actual Lycheetah MCP package or a real model/provider.

Source inspected read-only: `12_IMPLEMENTATIONS/applications/lycheetah_guard_mcp.py`, `12_IMPLEMENTATIONS/applications/LYCHEETAH_GUARD_SETUP.md`, `lycheetah/assurance/runtime.py`, `lycheetah/assurance/policy.py`, and `tests/test_mcp_guard.py`. Findings and interpretation are in `authority_boundary_lab_v0_8/SIDE_EFFECT_CLASSIFICATION_AUDIT_v0.8.md`.

## v0.5/v0.6 verification (2026-10-16)

- v0.5 targeted suite: 20 tests passed. This includes trusted dispatcher binding, policy/clock provider isolation from per-call parameters, deployment audience, revocation, local persistence across gate reconstruction, and eight concurrent replays.
- v0.4 callback-selection counterexample reproduced locally: approved action label was `refund_order`, while a separately supplied callback recorded `delete_every_account`; the gate returned from the callback. This only invokes a local callback that records a string, not any real destructive operation.
- Audited source: Guard MCP returns decision receipts and explicitly leaves enforcement to the calling host. The source audit does not establish whether a separate live host is correctly enforcing them.
- Fake-host / fake-provider suite: 8 tests passed, including commit-then-timeout reconciliation and no-blind-retry behavior when no provider effect is found.
- Legacy combined local run: 65 tests passed across four suites. Command: `python run_all_tests.py`.
- See `HOST_BOUNDARY_AUDIT_v0.5.md` and `HOST_ADAPTER_INTEGRATION_v0.6.md` for evidence scope and limitations.

## Prior v0.4 verification



# v0.4 verification log

**Run date:** 2026-10-16 (Pacific/Auckland)

## Test execution

Command: `python run_all_tests.py` from the lab root.

| Suite | Tests | Result |
|---|---:|---|
| Original control harness + observer sensitivity | 13 | PASS |
| Evaluator probe + correlated-observer model | 10 | PASS |
| Authority boundary gate | 14 | PASS |
| **Total** | **37** | **PASS** |

Additional checks: Python `compileall` completed without errors; synthetic demo JSON parsed and had seven scenarios.

## Synthetic authority-demo outcome

| Case | Deliberately weak boolean-claim baseline | Candidate gate |
|---|---|---|
| Valid host-issued token | Allow | Allow once |
| Boolean claim, no token | Allow | Deny |
| Action changed after approval | Allow | Deny |
| Policy digest changed | Allow | Deny |
| Token expired | Allow | Deny |
| Token modified | Allow | Deny |
| Same token used twice | Allow twice | First allow, second deny |

This is a behavior check against an intentionally insecure comparator, not a comparative test against a measured production integration. The demo uses an in-memory callback, not a real human, external tool, refund API, or repository dispatcher.

## Evidence boundaries

**Directly tested:** authored reference code and local SQLite behavior in tested conditions.

**Not tested:** real model behavior, actual host adapter, external identity provider, approval UX, production keys, process crash/restart under load, distributed replay, remote effect atomicity, production sandboxing, independent penetration review, or a live action provider.

## Important test-runner correction

During this turn, a direct combined unittest import from the project root failed for the two subfolder suites because their tests import sibling modules as top-level names. The suites pass when each runs from its intended working directory. `run_all_tests.py` now codifies that known-good invocation and provides one reproducible root-level command. This fixes the lab workflow; it does not affect the semantics of the individual tests.
