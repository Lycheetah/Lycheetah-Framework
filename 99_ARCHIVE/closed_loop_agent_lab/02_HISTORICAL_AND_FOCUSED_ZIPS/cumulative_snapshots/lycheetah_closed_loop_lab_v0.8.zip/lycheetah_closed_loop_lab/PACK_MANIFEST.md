# Pack manifest — v0.8

- Research pack: Lycheetah Closed-Loop Agent Lab v0.8
- Research status: R0 local prototype; source audit read-only
- v0.1-v0.6 retained suite: 65 tests pass (`python run_all_tests.py`)
- v0.7 process crash/recovery suite: 26 tests pass (`python run_v0_7_tests.py`)
- v0.8 trusted catalog integration suite: 18 tests pass (`python run_v0_8_tests.py`)
- Test groups were verified in separate successful invocations. A combined nested invocation did not finish reliably; no unified 109-test pass is claimed.
- Source-audit target: `Lycheetah/Lycheetah-Framework`, default `master`, cited in `authority_boundary_lab_v0_8/SIDE_EFFECT_CLASSIFICATION_AUDIT_v0.8.md`
- Key implementation: `authority_boundary_lab_v0_8/tool_catalog.py`
- End-to-end synthetic provider integration: `authority_boundary_lab_v0_8/test_tool_catalog.py`
- Crash/recovery implementation: `authority_boundary_lab_v0_7/host_process.py` and `provider_process.py`

## Claims intentionally not made

No live model, real MCP host dispatch, authenticated reviewer, external provider, production integration, hardened sandbox or independent security review. No claim of model capability improvement, safety superiority or production reliability. The current repository MCP server is a receipt issuer and relies on the surrounding host to enforce decisions. v0.8 demonstrates a local host-side metadata catalog pattern only.
