# Next experiment — R2 harmless repository task with independent correctness review

## Current decision

The lab now has **65 legacy tests**, **26 v0.7 separate-process crash/recovery tests**, and **17 v0.8 trusted-catalog/host-adapter tests**. Each suite passed independently, as recorded in `test_output_v0_7_legacy.txt`, `authority_boundary_lab_v0_7/test_output_v0_7.txt`, and the v0.8 test runner output. A combined nested-runner invocation did not complete reliably; do not describe this as one aggregate 109-test command passing.

v0.8 responds to a source-level trust boundary in the current Guard interface: the caller-visible `assure_tool` input accepts `side_effect` and `scopes`; the documented design expects the caller to declare these truthfully and enforce returned dispositions. The source audit is in `authority_boundary_lab_v0_8/SIDE_EFFECT_CLASSIFICATION_AUDIT_v0.8.md`. This is not a report of an actual deployed bypass—the MCP server returns receipts and is not a tool dispatcher.

The trusted catalog adapter only lets the model propose `tool_name` and `arguments`; the host supplies effect classification, scope, dispatcher route/version, agent/workspace IDs and operation ID. A fixed catalog digest must match the policy file. The adapter then sends one stamped `refund_order` action through the v0.7 host/provider test harness. Its reviewer and provider are fixtures, and no real external effect occurs.

## What is now demonstrated locally

- v0.1-v0.6 suites: 65 tests pass in `python run_all_tests.py`.
- v0.7: 26 crash/recovery tests pass when run with `python run_v0_7_tests.py`.
- v0.8: 17 trusted-catalog and host/provider integration tests pass with `python run_v0_8_tests.py`.
- An untrusted proposal cannot set its own `side_effect`, scopes, dispatcher ID/version, agent ID, workspace ID or operation ID.
- An action's catalog class, route and scopes are derived from the catalog. Catalog drift fails the policy digest binding unless the trusted policy is updated.
- A stamped action can traverse the separate-process fake host/provider flow; mutating the stamped `side_effect` after approval prevents dispatch.
- v0.7's independent suite exercises crashes before and after a fake provider commit, recovery after host restart, replay protection, policy updates and revocation race serialization.

These are authored local tests, not model-based efficacy rates. The `declaration_only_decision` comparison in v0.8 is a projection of the relevant source branch rather than a full execution of the current repository package; we inspected the actual source through read-only GitHub tools but could not clone the complete repository into this environment.

## Next gate: R2 real but harmless repository task

Use a disposable copy/branch of Lycheetah-Framework. Choose a narrow, non-consequential maintenance task such as adding an independently specified regression test to a pure helper. Freeze the task contract, exact accepted behaviors and held-out edge cases before running an agent.

Compare two workflows with the same model, workspace permissions, tools, token/time budget and test commands:

1. Conventional scoped workspace + tests + human review.
2. Same controls + independently checked postconditions + trusted tool catalog + authority/recovery instrumentation.

Blindly adjudicate correctness from the final diff and held-out contract. Record useful completion, false acceptance, false rejection, regressions, test failures, task time, review burden, attempted unauthorized operations and recovery. Include no-op patches, valid alternative implementations, deceptive caller metadata, wrong tests, and regressions that pass visible tests. Start in a harmless disposable workspace with no credentials and no consequential external tools.

## Remaining hard boundaries

- The v0.7 policy/revocation fence uses a shared local SQLite authority store; a remote provider needs native idempotency and provider-side conditional/fencing semantics. Local locking does not span a network boundary.
- A timeout with unavailable or eventually consistent provider lookup must not be interpreted as proof the effect did not happen.
- Reviewer names are test fixtures; no authenticated reviewer UI/IdP or distinct OS principal is in place.
- v0.8 catalog binding is an adapter pattern, not integrated into `Lycheetah Guard MCP`; the real MCP tool remains an advisory receipt issuer. No current live host adapter was validated.
- The tool catalog is fixed and authored for the synthetic test; no real provider's tool schema or effect semantics have been audited.

## Promotion gates

- **R0 — local research:** achieved for the prototype and source audit.
- **R1-harness — synthetic multi-process recovery:** exercised by v0.7, 26 tests.
- **R1-catalog — trusted effect classification/stamping:** exercised by v0.8, 18 tests.
- **R2 — one harmless repository task with independent correctness adjudication:** next.
- **R3 — paired held-out multi-task pilot:** only after R2.
- **R4 — bounded consequential pilot:** only after authenticated identity, key lifecycle, real provider idempotency/reconciliation, real revocation semantics, separate-principal containment, and independent security review.
