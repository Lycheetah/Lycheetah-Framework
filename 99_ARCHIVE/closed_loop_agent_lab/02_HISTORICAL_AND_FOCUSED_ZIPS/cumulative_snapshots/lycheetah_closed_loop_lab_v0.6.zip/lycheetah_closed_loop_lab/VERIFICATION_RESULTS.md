# Verification results — current v0.6 pack

## v0.5/v0.6 verification (2026-10-16)

- v0.5 targeted suite: 20 tests passed with Python ResourceWarnings promoted to errors. This includes trusted dispatcher binding, policy/clock provider isolation from per-call parameters, deployment audience, revocation, local persistence across gate reconstruction, and eight concurrent replays.
- v0.4 callback-selection counterexample reproduced locally: approved action label was `refund_order`, while a separately supplied callback recorded `delete_every_account`; the gate returned from the callback. This only invokes a local callback that records a string, not any real destructive operation.
- Audited source: Guard MCP returns decision receipts and explicitly leaves enforcement to the calling host. The source audit does not establish whether a separate live host is correctly enforcing them.
- Fake-host / fake-provider suite: 8 tests passed, including commit-then-timeout reconciliation and no-blind-retry behavior when no provider effect is found.
- Full combined local run: **65 tests passed** across all four suites. Command: `python run_all_tests.py`.
- See `HOST_BOUNDARY_AUDIT_v0.5.md` and `HOST_ADAPTER_INTEGRATION_v0.6.md` for evidence scope and limitations.

## Prior verification

# v0.4 verification log

**Run date:** 2026-10-16 (Pacific/Auckland)

## Test execution

Command: `python run_all_tests.py` from the lab root.

| Suite | Tests | Result |
|---|---:|---|
| Original control harness + observer sensitivity | 13 | PASS |
| Evaluator probe + correlated-observer model | 10 | PASS |
| Authority boundary gate | 14 | PASS |
| **Total** | **37** | **PASS** |

Additional checks: Python `compileall` completed without errors; synthetic demo JSON parsed and had seven scenarios.

## Synthetic authority-demo outcome

| Case | Deliberately weak boolean-claim baseline | Candidate gate |
|---|---|---|
| Valid host-issued token | Allow | Allow once |
| Boolean claim, no token | Allow | Deny |
| Action changed after approval | Allow | Deny |
| Policy digest changed | Allow | Deny |
| Token expired | Allow | Deny |
| Token modified | Allow | Deny |
| Same token used twice | Allow twice | First allow, second deny |

This is a behavior check against an intentionally insecure comparator, not a comparative test against a measured production integration. The demo uses an in-memory callback, not a real human, external tool, refund API, or repository dispatcher.

## Evidence boundaries

**Directly tested:** authored reference code and local SQLite behavior in tested conditions.

**Not tested:** real model behavior, actual host adapter, external identity provider, approval UX, production keys, process crash/restart under load, distributed replay, remote effect atomicity, production sandboxing, independent penetration review, or a live action provider.

## Important test-runner correction

During this turn, a direct combined unittest import from the project root failed for the two subfolder suites because their tests import sibling modules as top-level names. The suites pass when each runs from its intended working directory. `run_all_tests.py` now codifies that known-good invocation and provides one reproducible root-level command. This fixes the lab workflow; it does not affect the semantics of the individual tests.
