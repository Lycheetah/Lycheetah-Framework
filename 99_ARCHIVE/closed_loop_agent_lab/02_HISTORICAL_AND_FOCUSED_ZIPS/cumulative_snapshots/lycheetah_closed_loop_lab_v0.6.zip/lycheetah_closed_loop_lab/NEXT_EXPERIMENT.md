# Next experiment — harden the host/provider boundary under crash injection

## Current decision

Remain at **R0 research**. Source inspection established that the Lycheetah Guard MCP server returns decision receipts and leaves enforcement to the calling host; we have not established behavior of any particular live host adapter. The v0.4 local approval gate had a reproducible callback-selection gap. v0.5 removes that API seam and binds the action to a host-owned dispatcher ID/version, current trusted policy provider, trusted clock, and deployment audience. v0.6 adds a synthetic host-shaped flow and fake-provider reconciliation tests.

The combined local test runner passes 65 tests. These are authored deterministic tests and are not a live model evaluation, external integration test, or security review.

## Next gate: separate-process fake host

The in-process fake host still puts the issuer, gate and fake approval UI in one process, and its provider state is in memory. The highest-value next step is a separate-process test with a durable fake provider and a test-only authenticated approval endpoint. Keep the model-facing process unable to read the HMAC key or call token issuance directly.

Inject failures at these exact boundaries:

1. Before token claim.
2. After nonce claim but before provider request.
3. After provider commit but before response reaches host.
4. After response reaches host but before local completion record persists.
5. During revocation racing with dispatch claim.
6. Across restart with the same nonce/revocation journal.

Expected invariant: each operation ends in either one confirmed effect or a durable **unknown / needs reconciliation** state. The host must never silently reinterpret a timeout as success or absence, and must never blindly issue the same effect again without provider-side idempotency or a fresh independently authorized operation.

## Required measures

- Number of unintended or duplicated effects.
- Number of incorrect target dispatches.
- False rejections and operator review burden.
- Correct reconciliation after timeout-before-effect and timeout-after-effect.
- Revocation-to-dispatch race outcome.
- Restart recovery success and durable audit completeness.
- Reviewer ability to identify exact target, arguments, amount/recipient, scope, reversibility and operation ID.

## Only then: harmless coding-agent trial

After the host boundary passes, run one harmless code maintenance task in a disposable branch/workspace. Freeze the task contract and source tree hash; compare ordinary scoped permissions/tests against the same controls plus postcondition observer with the same model, tools, budget and test command. Use blinded independent adjudication, held-out mutations, no-op patches, valid alternatives, faulty tests and review burden measurements.

## Promotion gates

- **R0:** current deterministic local code/tests and read-only source audit.
- **R1:** separate-process fake host/provider with crash-injection and durable reconciliation tests.
- **R2:** one harmless repository task and independent correctness adjudication.
- **R3:** paired held-out multi-task pilot with a measured baseline.
- **R4:** independent security review; authenticated identity, key lifecycle, distributed replay, revocation, provider idempotency/reconciliation and containment validated before any bounded consequential pilot.

## Research proposition

A safe action boundary must bind authorization not just to the arguments, but to the exact intended destination and deployment context, current policy, reviewer authority, one-use operation ID, and a recoverable view of what the external world actually did. Local tests can validate code paths; only independent integration and adversarial evaluation can validate the system boundary.
