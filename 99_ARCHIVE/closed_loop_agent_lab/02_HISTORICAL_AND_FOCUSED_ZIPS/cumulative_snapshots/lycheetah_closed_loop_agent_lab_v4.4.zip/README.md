# Lycheetah Closed-Loop Agent Lab — Current Index v4.4

**Current focus:** secure authorization, durable action recovery, remote witness integrity, mTLS ingress and pre-auth resource fairness across same-host gateway replicas.

## Latest artifact: Shared Pre-TLS Quotas v4.4

v4.3 shared authenticated-coordinator request quotas, but pre-TLS connection and new-connection-rate caps remained local to each gateway process. v4.4 adds an opt-in shared SQLite ingress authority for global active sockets, per-peer active sockets and global connection-rate tokens. Reservations are made before TLS/thread creation.

### Downloads

- [Standalone shared pre-TLS quota kit](sandbox:/mnt/data/lycheetah_shared_preauth_quota_v4.4.zip)
- [Complete research lab through v4.4](sandbox:/mnt/data/lycheetah_closed_loop_agent_lab_v4.4.zip)

### Verification

- 14 exact local file fingerprints verified.
- Python compilation passed.
- Shared ingress store: 15 tests passed.
- Shared coordinator quota store: 13 tests passed.
- Retained checkpoint quorum: 38 tests passed.
- Remote-witness and gateway suite: 51 tests passed; runner reported no surviving non-main threads.
- Total: 117 methods passed across separate suite invocations. The gateway suite includes two cross-gateway shared-ingress integration cases; the ingress suite includes a two-process reservation race.

### Boundaries

This is local reference evidence, not an upstream patch or production certification. The shared authority is SQLite for same-host processes only, and assumes trusted local storage and consistent configuration. A handler paused beyond lease TTL may resume after lease reclamation; hard process fencing is not claimed. No upstream source or CI was changed, and no hosted service was called.

See `r34_shared_preauth_quota_v4_4/RESULTS_v4.4.md`, `THREAT_MODEL_v4.4.md`, and `UPSTREAM_INTEGRATION_PLAN_v4.4.md`. Earlier versions remain archived.
