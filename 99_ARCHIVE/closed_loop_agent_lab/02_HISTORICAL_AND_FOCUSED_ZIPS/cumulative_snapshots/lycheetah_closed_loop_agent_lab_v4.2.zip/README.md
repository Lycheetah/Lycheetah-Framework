# Lycheetah Closed-Loop Agent Lab — Current Index v4.2

**Current focus:** secure authorization, durable action recovery, remote witness integrity, and bounded/fair coordinator ingress.

## Latest artifact: Authenticated Coordinator Fairness v4.2

v4.2 extends the v4.1 bounded mTLS gateway with independent active-dispatch and request-rate quotas per authenticated coordinator identity. It requires exactly one allow-listed SPIFFE URI SAN per certificate, emits signed `429` responses on quota exhaustion, and keeps operational snapshots aggregate-only.

### Downloads

- `lycheetah_authenticated_coordinator_fairness_v4.2.zip` — standalone v4.2 gateway, tests, runbook and source pins.
- `lycheetah_closed_loop_agent_lab_v4.2.zip` — complete research history through v4.2.

### Verification

- Source pins: 8 reference file fingerprints pass.
- Python compilation: pass.
- Retained quorum suite: 38 tests passed.
- mTLS witness/gateway suite: 47 tests passed.
- Combined across separate invocations: 85 test methods passed.
- Hosted service calls: none; upstream repository and CI unchanged.

### Important boundaries

Authenticated quotas are process-local and begin after HTTP headers have parsed. They do not provide distributed identity quotas, pre-header identity fairness, multi-host DDoS protection, or production certification. Four witness processes and the gateway share one host/operator. Production CA lifecycle, OS resource caps, external ingress controls, multi-host testing, and upstream CI remain unverified.

See `r32_authenticated_coordinator_fairness_v4_2/RESULTS_v4.2.md`, `THREAT_MODEL_v4.2.md`, and `UPSTREAM_INTEGRATION_PLAN_v4.2.md`. Earlier research sections remain archived.
