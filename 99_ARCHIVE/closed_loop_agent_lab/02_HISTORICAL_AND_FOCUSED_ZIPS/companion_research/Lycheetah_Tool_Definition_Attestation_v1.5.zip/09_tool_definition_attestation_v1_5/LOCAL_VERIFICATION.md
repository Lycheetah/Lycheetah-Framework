# Local Verification — Tool Definition Attestation v1.5

**Status:** measured synthetic engineering observation · 2026-10-16  
**Runtime:** Python 3.12 standard library  
**Production:** not deployed

## Verification record

| Check | Result | Scope |
|---|---|---|
| Unit tests | 21/21 passed | Canonicalisation, pin HMAC, policy/server/definition drift, strict JSON, dispatch wrapper, benchmark counterexample. |
| Benchmark cases | 15 executed | Self-authored synthetic tool definitions and trust-context changes. |
| Authored definition mutation cases flagged | 5/5 | Five metadata mutation variants route to `REVIEW`; the allowlist baseline accepts all five. |
| Clean cases retained as `ALLOW` | 2/2 | Exact definition and JSON object-key reordering only. |
| Pin missing/tampered/key missing | All route to `REVIEW` | Locally authored fail-closed expectations. |
| Server identity fingerprint changed | Candidate `BLOCK` | Test fixture supplies a changed fingerprint for the same configured server ID. |
| Tool implementation behavior changes with unchanged visible definition and identity | Not detected | Explicit negative result: both baseline and candidate allow. |
| CLI smoke test | Clean pin `ALLOW`; changed description `REVIEW` | Temporary HMAC key and temporary pin; no secret or test pin retained. |
| Syntax compilation | Passed | `py_compile` on module, benchmark, and tests. |

## Reproduction commands

From this directory:

```bash
python3 -m py_compile tool_attestation.py benchmark.py tests/test_tool_attestation.py
python3 -m unittest discover -s tests -v
python3 benchmark.py
python3 tool_attestation.py digest-json examples/policy.json
```

The CLI smoke test created a temporary pin using a one-run environment key, tested the unchanged tool and a changed description, then deleted the temporary pin. The log observed `ALLOW` for the unchanged definition (exit 0) and `REVIEW` for description drift (exit 2).

## Interpretation boundary

The tests exercise the code under authored input conditions. They are not independent security review, formal verification, a live MCP integration, model-agent benchmark, or production validation. The baseline is a static server-ID/tool-name allowlist; stronger conventional systems can also pin definitions. The synthetic server identity fingerprint is based on a test string, not an actual package, binary, endpoint certificate, or measured deployment identity.

No real tool call, production secret, external provider, or customer record was used.
