# Tool Definition Attestation v1.5

**Status:** `[SCAFFOLD]` · **Experiment:** `SYNTHETIC_ENGINEERING_VALIDATED` · **Deployment:** none  
**Area:** Agent safety / cybernetics / tool boundary  
**Use case:** Detect changes to an already-reviewed MCP-style tool definition before a tool call is dispatched.

## Why this is the next step

The Framework's v1.4 external threat boundary auditor found an important difference between *declaring* a control and *testing* one. It also identified tool-definition attestation as an unimplemented practical boundary. OWASP's MCP Security Cheat Sheet describes tool poisoning and rug-pull changes and recommends pinning reviewed tool definitions, hashing the complete definition, and requiring review when it changes.

This experiment implements that narrow mechanism. It is not a claim to have solved prompt injection or agent safety, and it does not claim novelty for hash pinning, HMAC, policy checks, or human review.

## What it does

- Canonicalises a complete JSON tool definition and computes its SHA-256 fingerprint. Object key order is normalised; array order is preserved.
- Pins the fingerprint to a configured server ID, an independently supplied server-identity fingerprint, and the policy ID/version/digest.
- Stores human review metadata (`reviewed_by`, `approval_ref`, `reviewed_at`). These are audit fields, not proof of a person's identity.
- HMAC-authenticates the pin so a party without the trusted key cannot silently rewrite the pin and recalculate its seal.
- Rechecks the pin immediately before the host's tool-dispatch boundary.
- Returns `ALLOW` only when pin authenticity, server identity, tool name, full tool definition, and policy revision match.
- Routes metadata or policy drift to `REVIEW`; mismatched server/tool identity to `BLOCK`; and missing pins or unavailable pin verification to `REVIEW`.
- Rejects duplicate JSON object keys and non-finite JSON values in file inputs.

The module **does not execute tools**. An integration must enforce `execute_permitted == true` at the actual invocation path. Do not call the gate during discovery and assume the result remains valid indefinitely.

## Reproduce the synthetic comparison

Requires Python 3.10+ and only the standard library.

```bash
cd papers/agent-safety/frontier-controls/09_tool_definition_attestation_v1_5
python3 -m unittest discover -s tests -v
python3 benchmark.py
python3 tool_attestation.py digest-json examples/policy.json
```

The benchmark compares:

- **Baseline:** a static allowlist keyed to configured server ID and tool name.
- **Candidate:** an HMAC-authenticated definition pin, server identity fingerprint, and policy revision binding.

The corpus is synthetic and authored alongside the implementation. It includes a clean definition, benign JSON key reordering, description drift, schema widening, weakened required fields, output-schema drift, risk-annotation drift, server-image fingerprint change, policy drift, unapproved server, missing pin, pin tampering, missing verification key, and a behavior-only counterexample.

The results can show whether the implementation behaves according to these authored expected cases. They cannot estimate real-world attack prevalence or show that the control outperforms every conventional ACL.

## Use on a local tool catalogue

1. Inspect the full tool definition and server source/version.
2. Compute or obtain a **trusted** server identity fingerprint. Do not take it from the tool description itself.
3. Put an independently controlled, high-entropy secret (at least 32 bytes) in an environment variable such as `LYCHEETAH_TOOL_PIN_KEY`.
4. Create a pin only after a genuine human review and record a review reference. The CLI's review fields are audit metadata; the gate does not authenticate reviewer identity.
5. Store the pin in a controlled, integrity-protected location. For collaborative use, prefer signed commits or a suitable key-management design over an unaudited shared HMAC secret.
6. Before **each** call, obtain the current definition, verify the configured server identity through a trusted channel, re-check the pin and policy digest, and permit dispatch only on `ALLOW`.
7. If the result is `REVIEW` or `BLOCK`, pause. Do not auto-update the pin. Inspect the diff, re-review, and deliberately issue a new pin if justified.

### Create a pin

```bash
export LYCHEETAH_TOOL_PIN_KEY="$(python3 -c 'import secrets; print(secrets.token_hex(32))')"
python3 tool_attestation.py pin \
  --definition examples/approved_tool.json --output approved_tool.pin.json \
  --server-id mcp://repo-tools \
  --server-identity-sha256 <trusted-64-character-sha256> \
  --policy-id coding-agent --policy-version 1.0.0 \
  --policy-sha256 <sha256-of-the-reviewed-policy> \
  --reviewed-by "reviewer-alias" --approval-ref "SECURITY-REVIEW-123" \
  --reviewed-at 2026-10-16T10:00:00Z \
  --pin-id repo-publish-v1 --key-id local-tool-pin-2026 \
  --key-env LYCHEETAH_TOOL_PIN_KEY
```

### Check before tool invocation

```bash
python3 tool_attestation.py check \
  --pin approved_tool.pin.json --definition current_tool.json \
  --server-id mcp://repo-tools \
  --server-identity-sha256 <trusted-64-character-sha256> \
  --policy-id coding-agent --policy-version 1.0.0 \
  --policy-sha256 <sha256-of-the-current-reviewed-policy> \
  --key-id local-tool-pin-2026 --key-env LYCHEETAH_TOOL_PIN_KEY --json
```

Exit codes: `0` = `ALLOW`; `2` = `REVIEW`; `3` = `BLOCK`; `4` = invalid input or I/O error.

The demo does not connect to an MCP server or compute a real server fingerprint. Replace placeholders with trustworthy, deployment-specific values before any local pilot. Use `digest-json` to calculate the canonical SHA-256 of a JSON policy file.

## Important threat boundary

**A matching tool definition does not prove that the tool's implementation or remote behavior is unchanged.** If server code changes behind an unchanged identity fingerprint and identical metadata, this mechanism can still allow the call. Fingerprints are only as trustworthy as their provenance. The host must supply server identity through an authenticated/configured channel; tool output cannot certify its own trustworthiness.

HMAC provides authenticity to holders of the shared secret, not public-key attestation or proof of which human used the key. An unkeyed SHA-256 digest alone would detect accidental edits only when compared against a separately trusted pin. This module requires HMAC for pin verification, but key storage and human identity remain deployment responsibilities.

Other unresolved concerns include hostile-code containment, prompt injection inside tool results, argument-level data exfiltration, runtime behavior monitoring, policy correctness, provider-side atomicity, and false review rates. This is one boundary control, not an entire security system.

## Evidence and status

- [SCAFFOLD] implementation: built-in deterministic checks and tests; not production integrated.
- [MEASURED — synthetic] unit and authored benchmark results: recorded in `reports/` after local execution.
- [NOT TESTED] live MCP server integration, LLM behavior, independent challenges, false-positive rate in real tool updates, and malicious changes to server behavior behind unchanged metadata.
- [NOT DEPLOYED] no real tool calls or production credentials are used by the benchmark.

## Sources and prior art

- OWASP, [MCP Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html), especially Tool Description & Schema Integrity, least privilege, and consent.
- OWASP, [Secure Coding with AI Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Secure_Coding_with_AI_Cheat_Sheet.html), including tool-definition drift and connected-tool supply-chain risks.
- Existing Lycheetah Framework: [`34_ASSURANCE_RUNTIME`](../../../../34_ASSURANCE_RUNTIME/README.md), [`frontier-controls v1.4`](../08_external_threat_boundary_auditor_v1_4/README.md), and [`PROMOTION_GATES.md`](../PROMOTION_GATES.md).

The contribution here is a runnable, bounded implementation and matched synthetic probe of a known control pattern, not a claim to have invented the pattern. The SHA-256 comparison is structural, not semantic: even harmless prose revisions trigger review so potentially meaningful changes cannot slip through via interpretation.
