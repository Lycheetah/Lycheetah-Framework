#!/usr/bin/env python3
"""Tool-definition attestation gate for agent/MCP-style tools.

Status: [SCAFFOLD] prototype. Standard library only. This module assesses a
current JSON tool definition against an explicitly reviewed, authenticated pin.
It does not execute tools, authenticate a network endpoint, or detect behavior
changes behind an unchanged definition.
"""
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

VERSION = "1.5.0"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
PIN_KEYS = {
    "schema_version", "pin_id", "server", "tool_name", "definition_sha256",
    "policy", "review", "seal"
}


class AttestationError(ValueError):
    """Malformed input, invalid pin, or unsupported format."""


def _reject_constant(value: str) -> None:
    raise AttestationError(f"non-finite JSON value is forbidden: {value}")


def _pairs_no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise AttestationError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def strict_json_loads(raw: str) -> Any:
    """Parse JSON while rejecting duplicate keys and NaN/Infinity values."""
    try:
        return json.loads(
            raw,
            object_pairs_hook=_pairs_no_duplicates,
            parse_constant=_reject_constant,
        )
    except AttestationError:
        raise
    except (json.JSONDecodeError, TypeError) as exc:
        raise AttestationError(f"invalid JSON: {exc}") from exc


def _validate_json_value(value: Any, path: str = "$") -> None:
    if value is None or isinstance(value, (str, bool, int)):
        return
    if isinstance(value, float):
        if value != value or value in (float("inf"), float("-inf")):
            raise AttestationError(f"non-finite number at {path}")
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _validate_json_value(item, f"{path}[{index}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise AttestationError(f"non-string object key at {path}")
            _validate_json_value(item, f"{path}.{key}")
        return
    raise AttestationError(f"non-JSON value at {path}: {type(value).__name__}")


def canonical_json_bytes(value: Any) -> bytes:
    """Canonical encoding: sorted object keys, compact UTF-8, strict JSON values.

    Arrays are intentionally left in order. JSON object key order is normalized;
    array order is preserved because it can carry schema or UI meaning.
    """
    _validate_json_value(value)
    try:
        return json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise AttestationError(f"cannot canonicalise JSON: {exc}") from exc


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_hex(canonical_json_bytes(value))


def _nonempty(name: str, value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise AttestationError(f"{name} must be a non-empty string")
    return value


def _sha256_field(name: str, value: Any) -> str:
    if not isinstance(value, str) or not HEX64.fullmatch(value):
        raise AttestationError(f"{name} must be a lowercase SHA-256 hex digest")
    return value


def _key_bytes(key: bytes) -> bytes:
    if not isinstance(key, bytes) or len(key) < 32:
        raise AttestationError("HMAC key must contain at least 32 bytes")
    return key


def validate_tool_definition(definition: Mapping[str, Any]) -> dict[str, Any]:
    """Validate minimum MCP-like shape and preserve every supplied JSON field."""
    if not isinstance(definition, Mapping):
        raise AttestationError("tool definition must be a JSON object")
    tool = dict(definition)
    _validate_json_value(tool)
    name = _nonempty("tool name", tool.get("name"))
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,254}", name):
        raise AttestationError("tool name contains unsupported characters")
    if "description" in tool and not isinstance(tool["description"], str):
        raise AttestationError("tool description must be a string when present")
    schema = tool.get("inputSchema")
    if not isinstance(schema, dict):
        raise AttestationError("tool inputSchema must be a JSON object")
    if "outputSchema" in tool and not isinstance(tool["outputSchema"], dict):
        raise AttestationError("tool outputSchema must be a JSON object when present")
    if "annotations" in tool and not isinstance(tool["annotations"], dict):
        raise AttestationError("tool annotations must be a JSON object when present")
    return tool


def tool_definition_sha256(definition: Mapping[str, Any]) -> str:
    tool = validate_tool_definition(definition)
    return sha256_json(tool)


def _pin_body(
    *, pin_id: str, server_id: str, server_identity_sha256: str,
    tool_name: str, definition_sha256: str, policy_id: str, policy_version: str,
    policy_sha256: str, reviewed_by: str, approval_ref: str, reviewed_at: str,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "pin_id": _nonempty("pin_id", pin_id),
        "server": {
            "server_id": _nonempty("server_id", server_id),
            "identity_sha256": _sha256_field("server_identity_sha256", server_identity_sha256),
        },
        "tool_name": _nonempty("tool_name", tool_name),
        "definition_sha256": _sha256_field("definition_sha256", definition_sha256),
        "policy": {
            "id": _nonempty("policy_id", policy_id),
            "version": _nonempty("policy_version", policy_version),
            "sha256": _sha256_field("policy_sha256", policy_sha256),
        },
        "review": {
            "reviewed_by": _nonempty("reviewed_by", reviewed_by),
            "approval_ref": _nonempty("approval_ref", approval_ref),
            "reviewed_at": _nonempty("reviewed_at", reviewed_at),
        },
    }


def create_pin(
    *, pin_id: str, server_id: str, server_identity_sha256: str,
    tool_definition: Mapping[str, Any], policy_id: str, policy_version: str,
    policy_sha256: str, reviewed_by: str, approval_ref: str, reviewed_at: str,
    key_id: str, hmac_key: bytes,
) -> dict[str, Any]:
    """Create an authenticated pin; caller is responsible for actual review.

    Human-readable review fields are audit metadata, not proof of who reviewed.
    HMAC authenticates to holders of the shared key; it is not a public signature.
    """
    key = _key_bytes(hmac_key)
    tool = validate_tool_definition(tool_definition)
    body = _pin_body(
        pin_id=pin_id, server_id=server_id,
        server_identity_sha256=server_identity_sha256,
        tool_name=tool["name"], definition_sha256=sha256_json(tool),
        policy_id=policy_id, policy_version=policy_version,
        policy_sha256=policy_sha256, reviewed_by=reviewed_by,
        approval_ref=approval_ref, reviewed_at=reviewed_at,
    )
    seal = {
        "algorithm": "HMAC-SHA256",
        "key_id": _nonempty("key_id", key_id),
        "digest": hmac.new(key, canonical_json_bytes(body), hashlib.sha256).hexdigest(),
    }
    return {**body, "seal": seal}


def verify_pin(pin: Mapping[str, Any], *, key_id: str, hmac_key: bytes) -> bool:
    key = _key_bytes(hmac_key)
    if not isinstance(pin, Mapping) or set(pin) != PIN_KEYS:
        return False
    if pin.get("schema_version") != "1.0":
        return False
    seal = pin.get("seal")
    if not isinstance(seal, Mapping) or set(seal) != {"algorithm", "key_id", "digest"}:
        return False
    if seal.get("algorithm") != "HMAC-SHA256" or seal.get("key_id") != key_id:
        return False
    digest = seal.get("digest")
    if not isinstance(digest, str) or not HEX64.fullmatch(digest):
        return False
    body = {k: pin[k] for k in pin if k != "seal"}
    expected = hmac.new(key, canonical_json_bytes(body), hashlib.sha256).hexdigest()
    return hmac.compare_digest(digest, expected)


def _decision(disposition: str, reason: str, *, expected: str | None = None,
              observed: str | None = None) -> dict[str, Any]:
    return {
        "disposition": disposition,
        "execute_permitted": disposition == "ALLOW",
        "reason": reason,
        "expected_definition_sha256": expected,
        "observed_definition_sha256": observed,
    }


def assess_tool(
    *, pin: Mapping[str, Any] | None, tool_definition: Mapping[str, Any] | None,
    server_id: str, server_identity_sha256: str, policy_id: str,
    policy_version: str, policy_sha256: str, key_id: str | None,
    hmac_key: bytes | None,
) -> dict[str, Any]:
    """Check a current definition against the previously reviewed pin.

    ALLOW is emitted only for a valid authenticated pin with exact definition,
    server identity and policy match. Definition/policy drift routes to REVIEW;
    a server identity or tool-name mismatch routes to BLOCK. The host must enforce
    execute_permitted; this function does not execute or stop a provider itself.
    """
    if pin is None:
        return _decision("REVIEW", "no-approved-pin")
    if tool_definition is None:
        return _decision("REVIEW", "current-tool-definition-missing")
    try:
        tool = validate_tool_definition(tool_definition)
    except AttestationError as exc:
        return _decision("REVIEW", f"invalid-current-definition:{exc}")

    if not key_id or hmac_key is None:
        return _decision("REVIEW", "pin-authentication-unavailable")
    try:
        if not verify_pin(pin, key_id=key_id, hmac_key=hmac_key):
            return _decision("REVIEW", "pin-authentication-failed")
    except AttestationError:
        return _decision("REVIEW", "pin-authentication-failed")

    try:
        pinned_server = pin["server"]["server_id"]
        pinned_identity = pin["server"]["identity_sha256"]
        pinned_tool_name = pin["tool_name"]
        pinned_definition = pin["definition_sha256"]
        pinned_policy = pin["policy"]
    except (KeyError, TypeError):
        return _decision("REVIEW", "pin-schema-invalid")

    if server_id != pinned_server:
        return _decision("BLOCK", "unapproved-server-id", expected=pinned_definition,
                         observed=sha256_json(tool))
    if not HEX64.fullmatch(server_identity_sha256) or server_identity_sha256 != pinned_identity:
        return _decision("BLOCK", "server-identity-fingerprint-mismatch",
                         expected=pinned_definition, observed=sha256_json(tool))
    if tool.get("name") != pinned_tool_name:
        return _decision("BLOCK", "tool-name-mismatch", expected=pinned_definition,
                         observed=sha256_json(tool))

    current_digest = sha256_json(tool)
    if current_digest != pinned_definition:
        return _decision("REVIEW", "tool-definition-drift", expected=pinned_definition,
                         observed=current_digest)
    current_policy = {"id": policy_id, "version": policy_version, "sha256": policy_sha256}
    if current_policy != pinned_policy:
        return _decision("REVIEW", "policy-revision-drift", expected=pinned_definition,
                         observed=current_digest)
    return _decision("ALLOW", "approved-definition-server-and-policy-match",
                     expected=pinned_definition, observed=current_digest)


def dispatch_if_allowed(
    *, executor: Any, pin: Mapping[str, Any] | None,
    tool_definition: Mapping[str, Any] | None, server_id: str,
    server_identity_sha256: str, policy_id: str, policy_version: str,
    policy_sha256: str, key_id: str | None, hmac_key: bytes | None,
) -> dict[str, Any]:
    """Call a supplied executor only when the immediate attestation check is ALLOW.

    This is a reference adapter, not a remote atomicity guarantee. The host must
    ensure all relevant calls pass through this boundary and should bind the pin
    to a server-enforced version/identity where possible.
    """
    decision = assess_tool(
        pin=pin, tool_definition=tool_definition, server_id=server_id,
        server_identity_sha256=server_identity_sha256, policy_id=policy_id,
        policy_version=policy_version, policy_sha256=policy_sha256,
        key_id=key_id, hmac_key=hmac_key,
    )
    if not decision["execute_permitted"]:
        return {"dispatch_invoked": False, "decision": decision, "result": None}
    # Caller supplies the executor bound to the same current tool definition.
    # This minimizes the local check/call gap but cannot make a remote server atomic.
    result = executor()
    return {"dispatch_invoked": True, "decision": decision, "result": result}


def read_json(path: Path) -> Any:
    return strict_json_loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                    encoding="utf-8")


def _env_key(name: str) -> bytes:
    value = os.environ.get(name)
    if value is None:
        raise AttestationError(f"required environment variable is not set: {name}")
    return _key_bytes(value.encode("utf-8"))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Pin and verify agent tool definitions")
    sub = parser.add_subparsers(dest="command", required=True)
    p_pin = sub.add_parser("pin", help="create a reviewed HMAC-authenticated tool pin")
    for name in ("server-id", "server-identity-sha256", "policy-id", "policy-version",
                 "policy-sha256", "reviewed-by", "approval-ref", "reviewed-at", "pin-id",
                 "key-id", "key-env"):
        p_pin.add_argument(f"--{name}", required=True)
    p_pin.add_argument("--definition", required=True)
    p_pin.add_argument("--output", required=True)

    p_check = sub.add_parser("check", help="check a current tool definition against a pin")
    for name in ("server-id", "server-identity-sha256", "policy-id", "policy-version",
                 "policy-sha256", "key-id", "key-env", "pin", "definition"):
        p_check.add_argument(f"--{name}", required=True)
    p_check.add_argument("--json", action="store_true")

    p_digest = sub.add_parser("digest-json", help="print SHA-256 of canonical JSON")
    p_digest.add_argument("input", help="path to JSON file")

    args = parser.parse_args(argv)
    try:
        if args.command == "digest-json":
            print(sha256_json(read_json(Path(args.input))))
            return 0
        key = _env_key(args.key_env)
        if args.command == "pin":
            definition = read_json(Path(args.definition))
            pin = create_pin(
                pin_id=getattr(args, "pin_id"), server_id=getattr(args, "server_id"),
                server_identity_sha256=getattr(args, "server_identity_sha256"),
                tool_definition=definition, policy_id=getattr(args, "policy_id"),
                policy_version=getattr(args, "policy_version"),
                policy_sha256=getattr(args, "policy_sha256"),
                reviewed_by=getattr(args, "reviewed_by"), approval_ref=getattr(args, "approval_ref"),
                reviewed_at=getattr(args, "reviewed_at"), key_id=getattr(args, "key_id"),
                hmac_key=key,
            )
            write_json(Path(args.output), pin)
            print(f"PIN_CREATED {pin['tool_name']} {pin['definition_sha256']}")
            return 0

        pin = read_json(Path(args.pin))
        definition = read_json(Path(args.definition))
        result = assess_tool(
            pin=pin, tool_definition=definition, server_id=getattr(args, "server_id"),
            server_identity_sha256=getattr(args, "server_identity_sha256"),
            policy_id=getattr(args, "policy_id"), policy_version=getattr(args, "policy_version"),
            policy_sha256=getattr(args, "policy_sha256"), key_id=getattr(args, "key_id"),
            hmac_key=key,
        )
        if args.json:
            print(json.dumps(result, indent=2, sort_keys=True))
        else:
            print(f"{result['disposition']}: {result['reason']}")
        return {"ALLOW": 0, "REVIEW": 2, "BLOCK": 3}[result["disposition"]]
    except (AttestationError, OSError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 4


if __name__ == "__main__":
    raise SystemExit(main())
