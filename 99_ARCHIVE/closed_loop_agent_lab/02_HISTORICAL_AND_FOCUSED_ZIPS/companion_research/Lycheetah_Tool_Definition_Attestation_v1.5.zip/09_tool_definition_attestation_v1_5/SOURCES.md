# Sources and Prior-Art Boundary

**Reviewed:** 2026-10-16

This document records the external motivation for the component. The implementation is a narrow prototype informed by existing practices, not a novelty claim.

## 1. OWASP — MCP Security Cheat Sheet

URL: https://cheatsheetseries.owasp.org/cheatsheets/MCP_Security_Cheat_Sheet.html

Relevant guidance includes:
- MCP tool poisoning through descriptions, schemas, or results;
- rug-pull attacks where tool definitions change after approval;
- inspect the full description, parameter schema, and return schema;
- pin reviewed tool definitions with cryptographic hashes and require review when they change;
- treat tool annotations as hints, not enforcement;
- apply authorization and consent at execution time;
- protect tool invocations and outbound data flow.

**What it supports:** tool-definition drift is a recognised security concern, and review/pinning is an established mitigation pattern.

**What it does not support:** the claim that this specific implementation is safe, novel, or better than established controls.

## 2. OWASP — Secure Coding with AI Cheat Sheet

URL: https://cheatsheetseries.owasp.org/cheatsheets/Secure_Coding_with_AI_Cheat_Sheet.html

The guidance identifies MCP servers, connected tool metadata, repository content, and persistent instruction files as potential attack surfaces. It recommends allowlisting servers/tools, pinning tool definitions, and detecting changes after approval.

**What it supports:** the chosen threat family and the need to combine integrity checks with least privilege.

## 3. Existing Lycheetah work

- [`34_CYBERNETICS`](https://github.com/Lycheetah/Lycheetah-Framework/tree/master/34_CYBERNETICS): explicitly separates sensors, comparators, actuators, and loop closure; identifies the limits of text proxies and unclosed loops.
- [`34_ASSURANCE_RUNTIME`](https://github.com/Lycheetah/Lycheetah-Framework/tree/master/34_ASSURANCE_RUNTIME): existing decision receipts, evidence-capped enforcement, policy evaluation, and same-corpus regression gates.
- [Agent-safety frontier controls](https://github.com/Lycheetah/Lycheetah-Framework/tree/master/papers/agent-safety/frontier-controls): v1.4 external threat boundary auditor identified tool-definition attestation as a practical gap.
- [Existing MCP/customer-support assurance walkthrough](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/34_ASSURANCE_RUNTIME/CUSTOMER_SUPPORT_WALKTHROUGH.md): illustrates approval and policy checks for consequential tools.

## Prior-art statement

Cryptographic hashing, HMAC, allowlists, policy digests, explicit review, and tool-definition pinning are established techniques. The contribution here is to implement and test a bounded combination inside the Lycheetah research line, compare it with a declared static server/tool-name allowlist, and preserve an explicit counterexample showing the limit of metadata pinning.
