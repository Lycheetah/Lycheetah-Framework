# Cybernetic Mapping — Tool Definition Attestation v1.5

**Status:** `[SCAFFOLD]` — model of the proposed control, not a claim of a closed production loop.

The Lycheetah Cybernetics folder defines a regulator by its sensor, essential variable, comparator, actuator, and feedback path. It also cautions that a diagram showing those parts is not enough: the loop closes only where the code's effect reaches an enforceable action boundary.

## Mapping

| Cybernetic part | v1.5 instantiation | Status / limitation |
|---|---|---|
| Sensor | The current complete JSON tool definition, plus server identity fingerprint and current policy identity, supplied by the trusted host. | The module validates the shape and hashes the values it receives. It does not prove that the endpoint or fingerprint source is authentic. |
| Reference / setpoint | Human-reviewed pinned definition digest, expected server identity, policy id/version/digest, and authenticated review pin. | Pin is trustworthy only if the HMAC key and pin storage are controlled. Review metadata is not proof of reviewer identity. |
| Comparator | Canonical digest equality, policy equality, server identity equality, tool-name equality, and pin HMAC verification. | Deterministic comparison for the supplied values. Does not establish that the accepted tool is benign or that the policy is correct. |
| Disposition | `ALLOW`, `REVIEW`, or `BLOCK`. | Drift leads to a pause for review; server/tool identity mismatch blocks. These are policy choices in the prototype. |
| Actuator | `dispatch_if_allowed()` calls the provided executor only after an `ALLOW` disposition. | A reference adapter only. Every tool-call path must use it for the check to constrain the host. An alternate call path can bypass it. |
| Feedback / recurrence | Recompute the comparison immediately before each call; re-evaluate following tool-list change notifications or policy revisions. | The prototype has pre-dispatch checks but no post-effect behavioral monitor. A remote server can still change behavior behind unchanged metadata. |

## Why this matters

A one-time install scan is a snapshot, not continuous regulation. A definition can change after approval. Rechecking the current definition immediately before dispatch adds a temporal comparison between the approved reference and the observed tool. Binding the policy revision prevents a pin from being silently reused after its governing policy changes.

## What the loop does not close

1. If the server's implementation changes while the endpoint fingerprint and exposed definition remain the same, this loop does not observe it.
2. If the server identity fingerprint is supplied by the same untrusted source as the tool definition, the comparator has no independent reference.
3. If the host receives `REVIEW` but still invokes the tool through another path, the software check has not constrained the effect.
4. If the definition is unchanged but the tool arguments are harmful, tool-definition attestation alone does not authorise the invocation. Argument-level policy, scoped credentials, action-bound human confirmation, and egress controls remain necessary.
5. If the remote provider changes the tool after the last client-side comparison but before executing the request, client-side checking cannot make the remote call atomic. Server-side version binding or an authenticated immutable implementation identity would strengthen this boundary.

**Cybernetic conclusion:** v1.5 is an implemented local sensor/comparator with a testable dispatch hook. It is not a complete closed regulator for a remote MCP server until an actual host integration enforces the hook, source identity is trusted, and the provider-side time-of-use boundary is addressed.

## Linguistic boundary: integrity is not meaning

A tool description is both metadata and language placed into an agent's context. A hash answers, "Is this the same canonical JSON definition that was reviewed?" It does not answer, "Does this description mean the same thing? Is it deceptive? Does the declared behavior match the implementation?"

This implementation deliberately chooses structural identity over a learned semantic equivalence judgement. Consequently, a harmless wording revision routes to `REVIEW`; a deceptive description already present at initial approval may still be pinned. Human inspection, source provenance, least privilege, and behavior-level checks remain necessary. This is a useful example of evidence-capped design: deterministic identity checking can establish exact change, but it cannot establish intent or harmlessness.

## Minimal invariant

For tool definition `T`, server context `S`, policy context `P`, pin `I`, and key `K`, the candidate returns `ALLOW` only if:

```text
ALLOW(T,S,P,I,K) =
    verify_hmac(I,K)
    AND S.server_id == I.server_id
    AND S.identity_fingerprint == I.identity_fingerprint
    AND T.name == I.tool_name
    AND SHA256(canonical_json(T)) == I.definition_sha256
    AND P == I.policy_identity
```

This is a conjunction over *supplied values*. The invariant does not prove those values originate from trustworthy sources, that the pin was honestly reviewed, or that `T` describes the code that will actually run.
