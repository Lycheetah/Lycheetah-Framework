# Integration Note — Proposed Frontier Control v1.5

**Status:** `[PROPOSAL]` · No changes to the live `lycheetah.assurance` runtime are made by this packet.

## Suggested repository placement

`papers/agent-safety/frontier-controls/09_tool_definition_attestation_v1_5/`

It follows v1.4's external threat boundary auditor as one implementation experiment for the identified `tool-definition attestation` gap.

## Suggested integration contract

1. MCP host discovers tool definitions from an authenticated/configured server.
2. A human reviews the complete definition and relevant server/package identity.
3. The operator pins the definition and policy revision in a controlled store.
4. Before every invocation, the host obtains the current definition and independently established server identity.
5. The host calls this attestation gate and proceeds only on `ALLOW`.
6. `REVIEW` pauses and presents an inspectable diff. `BLOCK` stops the call.
7. Tool argument authorization, human confirmation, data-flow controls, sandboxing, and outcome receipts remain separate controls.

## Integration invariants

- No model-visible argument can mint or alter the pin, HMAC key, reviewer identity, or approval record.
- No tool server can declare its own identity trustworthy via its returned description.
- Pin creation is an operator/review action, not automatic acceptance of changed tools.
- The gate runs at the actual call boundary; a stale cached `ALLOW` cannot be reused.
- The host must have no unguarded alternate invocation path.
- Any provider-side version or immutable deployment identity should be bound into the request where supported.
- `ALLOW` means metadata/identity/policy conditions matched; it does not mean the tool is safe, its output is true, or its arguments are authorised.

## Proposed next experiments

1. Integrate with one selected MCP host using a local fake server and no production credentials.
2. Change the tool description/schema after approval and verify the host surfaces the diff and dispatches no call.
3. Verify a benign tool update can be intentionally re-pinned only after review.
4. Attempt a bypass through alternate dispatch paths.
5. Change server behavior while leaving metadata constant; confirm this remains an exposed gap and assess server-side build attestation / runtime outcome monitoring.
6. Have an independent contributor author held-out mutations and benign compatibility cases.
7. Measure pause rate, operator comprehension, latency, and false reviews before promoting any runtime claim.
