# Tool Definition Attestation v1.5 — Results Report

**Result class:** `SYNTHETIC_ENGINEERING_VALIDATED`  
**Implementation status:** `[SCAFFOLD]`  
**Deployment:** `NOT_DEPLOYED`  
**Date:** 2026-10-16

## Executive result

A standard-library Python prototype was implemented to pin a reviewed tool definition to an HMAC-authenticated record containing the configured server identity fingerprint, tool definition digest, and policy ID/version/digest. A reference dispatch hook refuses to call its executor unless the check returns `ALLOW`.

The authored synthetic comparison ran **15 cases**:

| Measure | Static server/tool-name allowlist baseline | Definition-attestation candidate |
|---|---:|---:|
| `ALLOW` | 14 | 3 |
| `REVIEW` | 0 | 10 |
| `BLOCK` | 1 | 2 |
| Five authored metadata-drift cases permitted by baseline | 5/5 | — |
| Five authored metadata-drift cases routed away from automatic allow | — | 5/5 |
| Clean exact/reordered JSON definitions still allowed | — | 2/2 |
| Behavior-only change with unchanged identity and definition detected | No | No |

The candidate routed description mutation, input-schema widening, relaxed required fields, output-schema change, and risk-annotation change to `REVIEW`. The baseline continued to allow those cases because it only checks the configured server ID and tool name. The candidate also routed a benign description rewording to `REVIEW`: a strict hash is not a semantic classifier, so even harmless language changes need human re-review. Policy revision drift, missing pins, invalid pin HMAC, and absent HMAC key also route to review; server identity mismatch is blocked.

A benign object-key reordering did **not** trigger drift because canonical JSON sorts object keys. Array order remains significant. The unit suite also verifies that the dispatch hook does not invoke its executor after metadata drift.

## Verification performed

- **21/21 unit tests passed** using Python's standard library.
- **15 deterministic benchmark cases executed.**
- Candidate detected **5/5 authored metadata drift cases**.
- Candidate preserved `ALLOW` for **2/2 clean metadata cases** (exact definition and canonical key reordering).
- A deliberate counterexample remained: if implementation behavior changes behind the same server identity fingerprint and identical exposed definition, both baseline and candidate allow.
- CLI pin and check interface is provided; a live MCP connection was not performed.

The detailed outcomes are in [`reports/benchmark.json`](reports/benchmark.json), and raw unit-test output is in [`reports/unit-tests.txt`](reports/unit-tests.txt).

## Interpretation

These counts show the implementation behaved as expected on its own authored finite fixtures. They are **not** an estimate of real-world attack detection, a safety rate, an independent challenge result, or proof of superiority over all conventional ACLs. A stronger conventional system can also pin schemas and versions; in that case this implementation should tie on the checked behavior, and any comparison would need to focus on usability, reliability, integration cost, and unaddressed attack paths.

The current baseline is deliberately named and bounded: static server ID plus tool name allowlist. The benchmark does not compare every possible conventional MCP client or enterprise access-control system.

## What changed technically

1. **Full-definition hashing:** name, description, input schema, output schema, annotations, and any other supplied JSON fields are included.
2. **Authenticated approval pin:** HMAC-SHA256 over the pin body; key ID is bound into the record.
3. **Policy binding:** changing policy ID, version, or digest triggers review.
4. **Server identity binding:** a changed configured server ID or identity fingerprint is blocked.
5. **Fail-closed reference adapter:** `dispatch_if_allowed()` never invokes the supplied executor on `REVIEW` or `BLOCK`.
6. **Linguistic precision:** structural hashing intentionally flags even a benign description rewrite for human review; it does not pretend to judge semantic equivalence.
7. **Strict JSON intake:** duplicate object keys and non-finite JSON values are rejected.
7. **Explicit negative control:** a behavior-only change behind unchanged visible metadata remains undetected.

## What it enables today

A developer can capture a tool definition as JSON, review it, create an authenticated local pin, and call the check immediately before dispatch. Any mismatch pauses the action until a person investigates and deliberately issues a new pin. This is suitable for a local disposable or shadow pilot with no production credentials, provided the host actually enforces the decision and uses trustworthy server identity inputs.

The code does not independently discover MCP tools, authenticate the transport, measure a binary fingerprint, or execute a real provider tool. The integration must supply those values from trusted configuration or transport mechanisms.

## What remains unverified

- Live MCP client/server interoperability and tool-list-change handling.
- Correct and trustworthy provenance of server identity fingerprints.
- Production-safe key storage and reviewer identity authentication.
- Behavior changes behind unchanged definition/identity metadata.
- Changes between pre-dispatch check and the remote server's actual execution point.
- Prompt injection in tool results, argument-level data exfiltration, confused deputy, sandbox bypass, and harmful actions using a valid unchanged tool.
- False-review rates under benign real-world tool updates.
- Independent adversarial review, independently authored test corpus, human-comprehension tests, performance, and operational burden.

## Promotion decision

Keep v1.5 as `[SCAFFOLD]` and `NOT_DEPLOYED`. Next credible step: integrate an adapter with one chosen MCP client in a disposable, read-only or no-secret environment; capture real tool-definition updates; verify that changed definitions cannot be dispatched by any alternate path; and obtain an independent challenge set before broader claims.
