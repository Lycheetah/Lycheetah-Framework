# Rabbit Holes — A Living Inquiry Architecture

**Framework status:** `[PROPOSAL]` · **Version:** 0.3 · **Updated:** 2026-10-16  
**Scope:** Mystery School cross-Wing inquiry layer · **Implementation status:** Design proposal only.

## 1. Governing idea

A Rabbit Hole is a learner-owned, evolving record of a journey of inquiry. It begins with a spark, follows a thread, records discoveries and wrong turns, opens branches, captures evidence and uncertainty, and leaves useful return points for the learner or another person.

It is not required to reach a definitive answer. Its value may be a supported conclusion, a better question, a map of competing explanations, a reproducible test, or a clear account of what is not yet known.

**Design law:** Preserve the path, preserve provenance, preserve the right to disagree, and preserve the right to leave.

## 2. Why it belongs in the School

Rabbit Holes give informal curiosity a place in the School's connected environment for inquiry, practice, source inspection, reader-authored work, and voluntary return without demanding that every interest become curriculum.

They can capture questions that arise while reading, building, practising, or conversing; connect disciplines; preserve the route from one question to another; make sources inspectable; hold competing explanations; accept corrections without erasing history; help people resume after long gaps; and allow useful work to inform curriculum while preserving provenance.

## 3. What it is — and is not

A Rabbit Hole **is** an inquiry narrative, a traceable set of questions/claims/sources/contributions, a place for disagreement and uncertainty, and a portable artifact that can be resumed, challenged, extended, forked, or connected.

It is **not** a popularity contest, badge, rank, proof of wisdom, demand to publish personal reflection, substitute for expert review, automatic source of School Canon, or engagement mechanism designed to make learners dependent.

## 4. Keep status axes separate

Never collapse these fields into one status.

### Inquiry phase — where the journey is
- `SPARKED` — origin question recorded.
- `EXPLORING` — paths and sources being gathered.
- `BRANCHING` — a sub-question needs its own trace.
- `EVIDENCE_CHECK` — specific claims or methods are being evaluated.
- `CONTESTED` — credible disagreement or material evidence gaps remain.
- `SYNTHESISING` — branches are being compared and connected.
- `DORMANT` — paused and preserved.
- `REOPENED` — new evidence or interest has resumed it.
- `INTEGRATION_REVIEW` — a derivative has been proposed for curriculum review.

`STABLE_FOR_NOW` may describe a dated claim/inquiry assessment, not a permanent final state. Any record can be reopened.

### Claim evidence status — what current evidence supports
- `SUPPORTED`
- `SUPPORTED_WITH_LIMITS`
- `CONTESTED`
- `NOT_ASSESSED`
- `SPECULATIVE`
- `CONTRADICTED_OR_UNSUPPORTED`
- `NOT_APPLICABLE` (questions, personal reflections, or values not asserted as factual claims)

These labels describe a particular claim as currently written, never a person's worth or the worth of asking the question.

### Framework / implementation maturity
Preserve the Framework's existing vocabulary where relevant:
- `[PROPOSAL]` — offered for dialogue; not yet accepted or externally validated.
- `[SCAFFOLD]` — useful structure exists, with named gaps.
- `[CONJECTURE]` — substantive claim remains unproven.
- `[ACTIVE]` — the specified mechanism or claim meets the repository's applicable verification standard.

A record format can be `[ACTIVE]` while a particular claim remains `NOT_ASSESSED`. Popularity, publication, or confidence must never upgrade evidence status.

### Publication scope — who can see it
- `PRIVATE`
- `INVITED_GROUP`
- `SCHOOL_COMMONS`
- `PUBLIC`

Nothing moves from private to shared automatically.

## 5. Placement in the School topology

The School is the whole place; Wings are modes of thought; Halls are courses; Classes are steps; Gates are real acts; Subjects are terrain; Teachings are examinable claims or practices; Threads are explicit cross-Wing links.

Rabbit Holes are a **cross-school inquiry layer**. They are neither a new Wing nor a status hierarchy.

### Proposed connections
- **Field Book:** Private sparks, field notes, unresolved thoughts, and return cards can start an inquiry. The learner explicitly chooses what, if anything, is shared.
- **Wings and Halls:** An inquiry can link to any number of relevant subjects without needing one permanent home.
- **Threads:** A Thread can link related Rabbit Holes or established School material; the link should explain *why* it matters.
- **Confluence / Commons:** Shared inquiries invite additions, challenges, alternative interpretations, and forks. Contributions do not silently become canon.
- **Identity and voluntary return:** A learner remains STUDENT. No title, contribution count, or completion state ranks human worth. Return is optional and guilt-free.
- **AURA / sovereignty principles:** Preserve agency, consent, inspectability, correction, and the ability to refuse or leave.
- **CASCADE:** A future implementation might reorganise links when new evidence changes a conceptual arrangement. This is a proposed integration, not an existing capability.
- **LAMAGUE:** A future implementation might support compact indexing. Any compressed representation must remain recoverable to ordinary language, context, provenance, and uncertainty.
- **TIM / revision history:** Dates, versions, access dates, and change sequence help preserve temporal integrity.

## 6. The inquiry lifecycle

1. **Capture the spark.** Record a question, observation, contradiction, artifact, or surprising claim. One sentence is enough; no minimum length or disclosure requirement.
2. **Name the scope.** State the current question and, where useful, what is outside scope. Preserve the original wording as the question evolves.
3. **Create a return card.** Record the current question, what is known, what is unknown, the next one to three actions, and any cautions for resuming.
4. **Build the path.** Record meaningful turns: new questions, sources, hypotheses, rejected leads, failed attempts, and changes in interpretation. Preserve important turns, not every trivial click.
5. **Separate claims.** Break important factual propositions into claim-level entries and link the evidence that supports, challenges, contextualises, or fails to resolve them.
6. **Branch when needed.** Create a child inquiry when a sub-question needs its own source trail or method. Keep the parent link and explain why the branch exists.
7. **Invite contribution by choice.** Keep it private, invite specific people, or publish a selected version to the Commons. Private notes are never a hidden feed for public content.
8. **Review and challenge.** Add sources, challenge claims, supply translation/context, reproduce methods, or fork an alternative explanation.
9. **Synthesize without forced closure.** State which claims appear supported, which interpretations compete, what evidence is missing, what would change the assessment, and which branches should remain separate.
10. **Pause, resume, or propose integration.** The learner may stop, return, fork, archive, or nominate a synthesis for curriculum review. None is a moral/status judgment.

## 7. Branching model

Use these relationships explicitly:
- **Child branch:** a sub-question of the parent.
- **Fork:** an independent inquiry that challenges or explores a different interpretation; the origin is retained.
- **Cross-link:** a relationship to another inquiry without shared parentage.
- **Synthesis:** a dated comparison across branches; it does not overwrite them.

Branch when a question, evidence base, method, or audience has become meaningfully distinct — not whenever a new keyword appears.

### Example family: ancient monumental engineering
1. Ellora's Kailasa Temple: monolithic planning, sequencing, and rock removal.
2. Petra: sandstone, tool marks, facade planning, and water management.
3. Egyptian pyramids: surveying, quarrying, transport, labour coordination, and construction hypotheses.
4. Ancient measurements, geometry, and practical mathematics.
5. How craft knowledge moved through apprenticeship and workshops.
6. What would count as evidence for a lost technique or technology.

These are research routes, not implied evidence for one hidden explanation.

## 8. Evidence architecture

A Rabbit Hole needs relationships between **claims and sources**, not merely a bibliography at the bottom.

Each source link should identify which claim it bears on; whether it supports, challenges, contextualises, or is inconclusive; the relevant passage/page/timestamp/figure/dataset/artifact; source type and creator; publication/access date; and limitations, provenance concerns, translation questions, or conflicts of interest.

A source can be relevant without supporting a claim. A primary source is not automatically accurate, complete, or neutral. Several sources may repeat the same origin; repetition is not independent corroboration.

### Claim types
`OBSERVATION`, `HISTORICAL_FACT_CLAIM`, `SCIENTIFIC_CLAIM`, `INTERPRETATION`, `HYPOTHESIS`, `PERSONAL_REPORT`, `VALUE_OR_DESIGN_PROPOSAL`, `OPEN_QUESTION`.

Different claim types need different evaluation. A personal report can be recorded sincerely without being treated as universally generalisable. A design proposal can be coherent without being empirically validated.

### Minimum evidence note
For material claims, try to answer:
1. What exactly is being claimed?
2. What evidence bears on it?
3. What does that evidence actually establish?
4. What are its limits?
5. What would meaningfully challenge the claim?

## 9. Commons-to-curriculum boundary

A shared Rabbit Hole is a Commons contribution, not official teaching.

Proposed pathway:
1. `PRIVATE_INQUIRY` — visible to its owner.
2. `SHARED_INQUIRY` — explicitly published or invited.
3. `CONTRIBUTED_INQUIRY` — additions logged with attribution.
4. `REVIEW_REQUESTED` — optional structured review.
5. `CURRICULUM_CANDIDATE` — someone proposes a bounded derivative for a Hall, class, guide, or teaching.
6. `ACCEPTED / NEEDS_WORK / DECLINED / WITHDRAWN` — explicit decision with rationale.
7. `INTEGRATED_DERIVATIVE` — a versioned School artifact links back to the source inquiry and states what was accepted, omitted, or remains disputed.

The original Rabbit Hole is never rewritten into official doctrine. An accepted teaching is a derivative with provenance. Commons material can challenge School Canon without automatically replacing it.

## 10. AI assistance boundaries

AI may suggest questions, structure notes, identify missing citations, summarise sources, surface competing interpretations, and create return cards.

AI must not silently publish private notes; attribute thoughts without approval; invent sources; upgrade evidence status without a documented argument; treat model output as independent corroboration; flatten disagreement for narrative smoothness; make identity decisions for a learner; or declare an inquiry settled because the answer is convenient.

AI-generated material should be identifiable where material, reviewable, editable, and removable. Contributors choose which suggestions to adopt.

## 11. Safety, consent, sovereignty

The system should follow the School's PROTECTOR, HEALER, and BEACON constraints.
- **PROTECTOR:** reduce foreseeable harm, privacy exposure, harassment, and careless handling of sensitive material.
- **HEALER:** do not hide complexity, exploit uncertainty, or present speculation as fact.
- **BEACON:** increase agency; do not pressure disclosure, return, conformity, or deference to a model.

Respect consent, copyright, cultural protocols, and reasonable privacy expectations. Some knowledge has community-specific permissions or restrictions; public access does not automatically imply ethical permission to reproduce or reinterpret it.

## 12. How success should be measured

Do not optimise for time in the School, streaks, return frequency, number of Rabbit Holes, or volume of AI interaction.

Look instead for: resumable inquiries; traceable claims; legible branches; visible corrections; disagreement without erasure; private material remaining private unless shared; learners able to explain what is supported and uncertain; curriculum integration with provenance; and the ability to leave without losing ownership.

A Rabbit Hole that helps someone reach “I don't know, and now I know exactly why” can be a success.

## 13. Minimum viable implementation

**MVP 0 — Markdown practice:** one template, manual registry, YAML metadata, claim ledger, source links, change log, explicit visibility, no scoring or automatic publication.

**MVP 1 — Community workflow:** contribution types, revision history, branch/fork/cross-link conventions, review requests/decisions, source and claim IDs, privacy controls.

**MVP 2 — Search and navigation:** search by question/topic/Wing/claim/source/status/open door; show relationship types; return cards and dated synthesis.

**MVP 3 — Bounded AI support:** proposed links and branch suggestions, claim-source alignment checks, revision summaries, visible provenance, human confirmation before shared edits.

These phases are proposals, not claims that the software already exists.

## 14. First pilot and definition of done

Pilot with a few real inquiries from spark to pause/resume. Test whether another person can add a source or challenge a claim without destroying the original path. Record friction, privacy concerns, confusion, and places the template is too heavy. Do not claim learning outcomes from a few informal examples.

**Core principle:** The Commons has many hands. The map is allowed to break. The learner remains sovereign.


## 17. Experience and implementation companion documents

This architecture is expanded by the companion proposal files: `RABBIT_HOLE_EXPERIENCE_SPEC.md` (interaction contract), `USER_FLOWS_AND_WIREFRAMES.md` (journeys), `CONTRIBUTION_INBOX_AND_RETURN_POLICY.md` (collaboration and return), and `MVP_BUILD_CONTRACT.md` (pilot scope and acceptance tests). They remain proposals until tested and reviewed.
