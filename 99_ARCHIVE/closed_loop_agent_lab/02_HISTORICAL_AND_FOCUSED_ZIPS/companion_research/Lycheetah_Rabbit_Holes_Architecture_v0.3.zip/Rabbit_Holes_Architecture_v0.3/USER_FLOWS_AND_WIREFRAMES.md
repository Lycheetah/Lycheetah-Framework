# Rabbit Holes — User Flows and Text Wireframes

**Framework status:** `[PROPOSAL]` · **Version:** 0.3

These are content-first wireframes for discussion. They are not screenshots of an existing application.

## Flow 1 — Catch a thought in the middle of learning

```text
[SCHOOL / HALL / FIELD BOOK / ARTICLE]

                                    [ + Catch a thought ]
                                              |
                                              v
+-------------------------------------------------------+
| CATCH A THOUGHT                                       |
| What caught your attention?                           |
|                                                       |
| [ A question, observation, contradiction, or idea… ]  |
|                                                       |
| Optional: [source] [topic] [voice note]               |
| Visibility: PRIVATE (default)                         |
|                                                       |
| [Save privately]                  [Keep exploring]    |
+-------------------------------------------------------+
                    |
                    v
+-------------------------------------------------------+
| SAVED                                                 |
| Your thought is private. Nothing was published.       |
|                                                       |
| [Leave it here] [Explore now] [Connect an inquiry]    |
+-------------------------------------------------------+
```

**Design test:** Can someone catch a thought in one small interaction without first understanding the whole Rabbit Hole system?

## Flow 2 — Develop it into an inquiry

```text
+-------------------------------------------------------+
| NEW RABBIT HOLE                                       |
|                                                       |
| Original spark: [ preserved verbatim ]                |
| Title:           [ suggested / editable ]             |
| Current question:[ what do I want to understand? ]    |
|                                                       |
| Optional prompts:                                     |
| - What do I already know?                             |
| - What am I unsure about?                             |
| - What would count as useful evidence?                |
|                                                       |
| Related School places: [ add Wing / Hall / Thread ]  |
| Visibility: PRIVATE                                   |
|                                                       |
| [Save inquiry] [Keep as Spark] [Cancel]               |
+-------------------------------------------------------+
```

Saving does not require a source list or evidence classification. Those become useful as claims emerge.

## Flow 3 — Inquiry home

```text
+----------------------------------------------------------------+
| RABBIT HOLE: How did ancient builders create monuments?         |
| Origin: What methods made these structures possible?            |
| Current question: Which site's evidence should we examine first?|
| Phase: EXPLORING     Visibility: PRIVATE     Updated: YYYY-MM-DD|
+----------------------------------------------------------------+
| RETURN CARD                                                    |
| Current understanding: This is a broad question, not a verdict. |
| Unknown: Which method best fits one specific site?              |
| Next: choose a site; find scholarly sources; extract claims.    |
| [Continue] [Update card] [Leave for later]                      |
+----------------------------------------------------------------+
| VIEWS: [Path] [Branches] [Claims & Sources] [Contributions]     |
+----------------------------------------------------------------+
| PATH                                                           |
| 1. Spark captured                                               |
| 2. Separated three sites into possible branches                 |
| 3. Identified a need to check archaeology, not assume technique |
|                                                                |
| [ + Add a meaningful turn ]  [ + Create a branch ]              |
+----------------------------------------------------------------+
```

**Hierarchy rule:** The current question and return card precede metadata. The user should not have to read the full record to understand where they left off.

## Flow 4 — Branch creation

```text
CREATE A BRANCH

Parent: How did ancient builders create monuments?
Selected passage / moment: [ step 2 ]

What deserves its own inquiry?
[ What evidence constrains the construction sequence at Ellora? ]

Relationship:
(o) Child branch — grew from the parent question
( ) Fork — explore a distinct or competing interpretation
( ) Cross-link — related, but not a child

Why should this be separate?
[ Its site, sources, and methods need an independent trace. ]

Inherited links (review before copying): [3 source links]

[Create draft branch] [Cancel]
```

The parent retains a branch link. No source or narrative is removed from the parent automatically.

## Flow 5 — Inspect a claim

```text
CLAIM CL-0007

Claim: [Exact sentence being assessed]
Type: HISTORICAL_FACT_CLAIM
Evidence status: NOT_ASSESSED
Reason: No source has yet been evaluated against this exact wording.
Last assessed: Never

SOURCES
[ + Add source ]
- Source A  | CONTEXTUALISES | page 12 | note…
- Source B  | CHALLENGES     | section 4 | note…

Limits / alternative explanations
[ Free text ]

What would change the assessment?
[ Free text ]

[Save changes] [Return to inquiry]
```

A source can be linked as contextual information without being represented as proof. Evidence status changes should carry a dated rationale.

## Flow 6 — Contribution received

```text
CONTRIBUTION OFFER
Type: CHALLENGE CLAIM
Target: CL-0007
Contributor: chosen public identity

Summary: This article suggests the date is later than the current record says.
Evidence: [source link + exact passage]
Limits: The article cites an older survey; another report may supersede it.

[Link into claim record]
[Keep as alternate interpretation]
[Ask a question]
[Decline integration with reason]
[Report concern]
```

The contribution remains attributed. It does not rewrite the original author’s prose. Where a material disagreement remains, keep the relationship visible instead of pretending the claim is settled.

## Flow 7 — Return after months away

```text
WELCOME BACK TO THIS INQUIRY

You were exploring:
[ current question and a one-paragraph return card ]

Since your last visit:
- one source was added (view contribution)
- one claim was challenged (view dispute)
- no other changes

You do not need to catch up all at once.

[Continue] [Review one change] [Update return card] [Leave for later]
```

If there were no changes, say so plainly. Do not manufacture a notification or create urgency.

## Flow 8 — Propose a curriculum derivative

```text
PROPOSE A SCHOOL DERIVATIVE

What bounded material should be considered?
[ selected synthesis / selected claims ]

Proposed destination: [ Wing / Hall / class / reference page ]
Why is it useful for learners?
What evidence supports it?
What limitations and disagreement must remain visible?
What must not be inferred from it?

[Submit for review] [Keep in Commons]

Notice: Submission is a request for review, not canonisation.
```

## Navigation concept

Prefer a small number of stable views over many decorative pages:
- **Path:** chronology of meaningful turns.
- **Branches:** child, fork, and cross-link map.
- **Claims & Sources:** evidence ledger.
- **Contributions:** collaboration queue and history.
- **Return:** compact resume state.

Whether these become tabs, panels, or routes should be decided through a working prototype and accessibility testing.
