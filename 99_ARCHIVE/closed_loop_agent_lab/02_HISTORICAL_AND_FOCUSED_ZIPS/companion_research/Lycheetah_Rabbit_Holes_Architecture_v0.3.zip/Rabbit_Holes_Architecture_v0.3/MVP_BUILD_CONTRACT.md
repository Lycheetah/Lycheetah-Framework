# Rabbit Holes — MVP Build Contract

**Framework status:** `[PROPOSAL]`  
**Version:** 0.3  
**Purpose:** Specify a modest first pilot without pretending the software already exists.

## 1. Pilot objective

Test whether a simple, portable record lets a person capture an inquiry, resume it after a gap, and accept contributions without losing provenance or agency.

The pilot should validate the *workflow and record model*, not claim to prove that Rabbit Holes improve learning or solve knowledge management generally.

## 2. Non-goals for the first pilot

Do not build yet:
- a social feed;
- points, XP, titles, rankings, streaks, or public contribution leaderboards;
- a fully automated research agent;
- automatic source truth scoring;
- automatic publication or canonisation;
- complex graph visualisation;
- a proprietary database that prevents plain Markdown export;
- a system that imports all personal chats by default.

## 3. Minimal file layout

Proposed repository landing area, consistent with the Framework's contribution process:

```text
public_building/
└── proposed_mystery_school/
    └── mac/
        └── rabbit_holes/
            ├── README.md
            ├── RABBIT_HOLES_ARCHITECTURE.md
            ├── RABBIT_HOLE_EXPERIENCE_SPEC.md
            ├── USER_FLOWS_AND_WIREFRAMES.md
            ├── RECORD_MODEL_AND_SCHEMA.md
            ├── CONTRIBUTION_AND_GOVERNANCE.md
            ├── TEMPLATE_RABBIT_HOLE.md
            ├── DECISIONS_AND_OPEN_QUESTIONS.md
            ├── rabbit_holes.schema.json
            ├── registry.json
            └── examples/
                └── RH-EXAMPLE-0001-ANCIENT-MONUMENTAL-ENGINEERING.md
```

This is a proposed destination only. No repository changes are made by this document.

## 4. MVP capabilities

### Must have
- Create a Spark with free text.
- Save privately by default.
- Convert Spark to inquiry without losing original wording.
- Edit title and current question separately.
- Maintain path / change history.
- Add claim records and source records.
- Link sources to claims using an explicit relation.
- Add parent/child/fork/cross-link relationships.
- Create a return card.
- Export the inquiry as readable Markdown.
- Explicitly change visibility, with a confirmation that explains what becomes visible.
- Keep framework status, inquiry phase, evidence status, and visibility separate.

### Should have
- A contribution template with attribution and rationale.
- Dated synthesis snapshots.
- Change summaries after a return.
- Plain-language help on source and evidence labels.

### Could have later
- Audio capture and transcripts.
- Search across shared inquiries.
- Optional user-requested reminders.
- AI-assisted citation alignment and counter-evidence discovery.

## 5. Acceptance tests

1. A single sentence can be saved as a private Spark.
2. Saving a Spark does not create a Commons entry.
3. Renaming an inquiry does not erase the original spark.
4. A claim with no checked evidence defaults to `NOT_ASSESSED`.
5. A source can be tagged as `CONTEXTUALISES` or `INCONCLUSIVE_FOR`; the UI does not force support/challenge only.
6. Branching preserves the parent and records why the branch exists.
7. A fork identifies its source version.
8. A contribution cannot silently modify the author's text.
9. A material disagreement can be represented without forcing consensus.
10. Private-to-shared transition requires explicit confirmation.
11. Export contains the current question, claim/source relations, branches, return card, and revision history.
12. A dormant inquiry has no decay, penalty, badge loss, or guilt message.
13. AI suggestions, if included, remain drafts until approved.
14. A learner can delete or export their private local record under a clear policy; public-content deletion and retention rules are separately explained.

## 6. Data integrity requirements

- Every claim has a stable ID.
- Every source-claim relationship records its type and relevant locator.
- Any evidence status change is dated and explained.
- Original spark and prior published versions remain retrievable where legally and ethically permissible.
- Shared edits have attribution.
- No private Field Book content appears in a public export unless selected explicitly.
- Schema validation catches invalid enum values and missing required metadata but does not pretend to validate truth.

## 7. Human review requirements

The pilot requires a human operator or editor to review contributions. A rule-based validator can check the shape of data, not whether a historical claim is true. AI can draft summaries but cannot act as the final judge of evidence quality or canon status.

## 8. Pilot plan

### Pilot A — One person, several inquiries
Use the template on a few topics with different evidence profiles: a historical-engineering question, a technical question, and a conceptual question. Test the capture and return card, including a deliberately dormant inquiry.

### Pilot B — One invited contributor
Ask another person to add a source and challenge a claim. Observe whether authorship, provenance, and disagreement remain clear.

### Pilot C — Export / import
Export to Markdown, move the folder, and reopen it without the original UI. Record what was lost or ambiguous.

Do not infer broad benefits from these small pilots. Use them to discover workflow failure modes.

## 9. What to measure — carefully

Measure task success and clarity, not engagement addiction:
- Can the learner resume the inquiry with the return card alone?
- Can a contributor point to the claim their evidence affects?
- Can the author explain why a source supports or challenges a claim?
- Did any private content become visible unexpectedly?
- Did branching clarify or fragment the work?
- Did the schema make the inquiry feel too bureaucratic to start?
- Were any claims made to look more certain than the evidence warranted?

Do not use time-on-platform, number of visits, streaks, or volume of AI messages as success metrics.

## 10. Release gate

Keep the system labelled `[PROPOSAL]` until the pilot has been run, failure cases recorded, and a governance review completed. If the pilot is useful but incomplete, mark the relevant implementation `[SCAFFOLD]` with named gaps rather than declaring the system `[ACTIVE]` prematurely.
