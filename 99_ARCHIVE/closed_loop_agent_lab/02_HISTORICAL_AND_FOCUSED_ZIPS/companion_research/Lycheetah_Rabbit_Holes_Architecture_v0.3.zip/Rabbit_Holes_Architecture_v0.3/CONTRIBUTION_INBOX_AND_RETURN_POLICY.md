# Rabbit Holes — Contribution Inbox and Voluntary Return Policy

**Framework status:** `[PROPOSAL]`  
**Version:** 0.3

## 1. The contribution inbox is not a popularity feed

Its purpose is to make incoming evidence and editorial changes inspectable. It should not create social pressure, performative debate, or an obligation to answer every contributor.

Sort and filter by:
- contribution type;
- target claim or section;
- date;
- whether the item includes a source locator;
- review state;
- whether it changes a material claim.

Do not sort primarily by reactions, follower status, or social status.

## 2. Contribution states

- `SUBMITTED` — contribution has been sent to the record's published surface.
- `NEEDS_CLARIFICATION` — additional detail would make it reviewable.
- `LINKED` — contribution has been attached to the relevant claim or path without merging its prose into the main narrative.
- `INCORPORATED` — the owner or designated editor incorporated the contribution, retaining attribution and history.
- `RETAINED_AS_ALTERNATIVE` — useful disagreement remains visible as an alternate interpretation.
- `DECLINED_FOR_INTEGRATION` — not integrated into the main text; rationale recorded where appropriate.
- `UNDER_MODERATION` — a safety, privacy, or conduct concern is being reviewed.
- `WITHDRAWN` — contributor withdraws their contribution where possible; history follows the published retention policy.

`LINKED` and `INCORPORATED` are different. A contribution can be visible and useful without being merged into the author's text.

## 3. Who controls what?

### Inquiry owner
Controls the title, main narrative, visibility, current question, and whether to ask for curriculum review. Cannot rewrite another contributor's submitted words as though they were their own. Can choose not to incorporate a contribution into the primary narrative.

### Contributor
Controls their own wording and display preference within platform capabilities, can revise or withdraw their contribution subject to transparent history and policy, and can challenge an interpretation with reasons and evidence. Cannot alter the owner's text or force a curricular decision.

### Steward / moderator
Can respond to safety, privacy, attribution, spam, or conduct issues. Must act proportionally and document the reason. Should not decide truth solely by authority or popularity.

### Curriculum reviewer
Can recommend, accept, request revision, or decline a derivative for curriculum. Cannot silently change the original shared record or represent the whole inquiry as settled if important disagreement remains.

These roles are proposed and should map onto existing governance rather than creating a parallel hierarchy.

## 4. Disagreement display

A material dispute should show:
- the precise claim under dispute;
- each position in its own words or faithful summary;
- sources and relevant passages;
- shared ground, if any;
- unresolved differences;
- last review date;
- what evidence would help distinguish the positions.

Do not resolve disputes by counting reactions. Do not present two positions as equally evidenced merely because both exist; compare their actual evidence and state the limits.

## 5. Correction protocol

When a material error is found:
1. Identify the exact old claim.
2. Add the correction and evidence.
3. Mark the old wording as corrected or superseded, not silently erased.
4. Update the claim status with a dated rationale.
5. Regenerate the return card and synthesis if affected.
6. Preserve a link from the old public version to the correction where feasible.

Privacy or safety removals may require a different process; transparency does not justify repeating harmful personal data.

## 6. Return is an invitation, not a demand

The default return model is **pull, not push**: the learner comes back when useful.

Potential opt-in controls:
- `No reminders` (default).
- `Remind me on a date` (user-chosen).
- `Tell me when a contribution affects a claim I follow` (opt-in, configurable).
- `Mute this inquiry`.
- `Pause all notifications`.

No automatic reminder should say or imply that the learner is late, falling behind, abandoning work, or disappointing the School. There are no lost streaks or expiring opportunities.

## 7. Resume summary rules

A return summary should be short, dated, and linked to the underlying changes. It should distinguish:
- new evidence;
- new interpretation;
- a simple editorial change;
- unresolved dispute;
- moderation or visibility change.

A model-generated summary is a convenience view, not the source of truth. If a user disputes the summary, they can inspect the underlying event log.

## 8. Data and privacy boundaries

- Personal Field Book entries remain private by default.
- Converting a private note into a shared inquiry copies only the selected content the user approves.
- Links to private source notes should not reveal their titles or content to people without permission.
- The system should explain what a public export contains before producing it.
- Platform-specific deletion, retention, and contributor withdrawal rules must be documented before deployment; this proposal does not pretend those systems already exist.
