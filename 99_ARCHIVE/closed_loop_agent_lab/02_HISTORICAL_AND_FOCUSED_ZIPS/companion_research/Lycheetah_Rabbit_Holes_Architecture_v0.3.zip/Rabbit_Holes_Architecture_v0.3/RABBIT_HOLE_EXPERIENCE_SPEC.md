# Rabbit Hole Experience Specification

**Framework status:** `[PROPOSAL]`  
**Version:** 0.3  
**Purpose:** Define the lived experience from capturing a passing thought to returning to a mature inquiry.

## 1. Product promise

A learner should be able to catch a thought without interrupting their curiosity, develop it into an inquiry when ready, follow its branches, inspect the evidence, invite others by choice, and return later without having to reconstruct the whole journey.

The experience should feel like opening a well-kept field notebook with a map of paths—not entering a feed that demands attention.

### Experience goals

- **Capture lightly:** a first spark takes seconds, not a form-filling session.
- **Develop gradually:** structure appears as the inquiry grows; blank fields never block exploration.
- **Keep the path visible:** the learner can see how one thought led to another.
- **Keep evidence inspectable:** claims point to sources and limits.
- **Make collaboration additive:** contributions do not silently rewrite the original work.
- **Return gently:** the system helps resume but never shames inactivity.
- **Preserve sovereignty:** no automatic publication, forced AI use, streaks, ranks, or emotional dependence.

## 2. The primary journey

`Catch a thought → Keep it as a Spark → Develop into a Rabbit Hole → Explore and branch → Review claims and sources → Share by choice → Receive contributions → Synthesize or pause → Return when useful`

This is a possible route, not a mandatory funnel. A Spark may remain a Spark. A private Rabbit Hole may never be shared. A public inquiry may remain unresolved. A learner can archive or leave at any time.

## 3. Entry points

The action **“Catch a thought”** should be available from relevant School contexts without forcing the learner to leave the current activity.

Possible entry points:
- a global School action;
- a Field Book entry;
- a passage or source the learner is reading;
- a lesson or Hall;
- a conversation or transcript the learner has permission to use;
- an existing Rabbit Hole or Thread.

The exact UI is a product decision. The invariant is that capture should not require navigating through several pages first.

## 4. Flow A — capture a Spark

### Minimum capture

Required: **one question, thought, or observation**.

Optional: title, source link, tags, related Wing, short voice note, or “what made this interesting?”

Defaults:
- Visibility: `PRIVATE`.
- Inquiry phase: `SPARKED`.
- AI assistance: off until requested.
- No required category, evidence rating, or due date.

### Proposed microcopy

**Catch a thought**  
*What caught your attention? A question, a contradiction, a possibility, a thing you want to understand.*

Buttons: `Save privately` · `Keep exploring`

The interface must not use “Publish” as the primary action for a first thought. Saving a thought is not consent to share it.

### After capture

Show a small confirmation with three non-coercive options:
- **Leave it here** — save and return to what I was doing.
- **Explore this now** — open an inquiry canvas.
- **Connect it** — link it to an existing Rabbit Hole or Thread.

Do not show a badge, streak, reward animation, or urgency message. A simple saved state is enough.

## 5. Flow B — develop a Spark into a Rabbit Hole

The first screen should focus on the question, not metadata.

Suggested sequence:
1. The Spark is shown verbatim.
2. Learner may name it; generated titles are suggestions, never replacements without approval.
3. Learner chooses a current question (it may initially match the Spark).
4. The system offers optional prompts: “What would you like to find out?”, “What do you already know?”, “What are you unsure about?”
5. Learner optionally links sources or a relevant Wing/Hall.
6. The record stays private unless the learner chooses a visibility change.

No question-quality gate should prevent saving. The system can gently offer a scope prompt if the inquiry becomes unwieldy.

## 6. Flow C — the Rabbit Hole home

The overview should answer four questions immediately:
1. What is this inquiry about?
2. What question am I following now?
3. What has changed since I last visited?
4. What is the most useful next step?

### Proposed information hierarchy

**Header**
- Title.
- Original spark / origin question.
- Current question.
- Inquiry phase.
- Visibility indicator.
- Last meaningful update.

**Return card**
- Current understanding in a few lines.
- Best-supported points.
- Most important uncertainties.
- Next one to three possible actions.

**Path**
- A chronological trail of meaningful turns, discoveries, sources, corrections, and forks.

**Branches**
- A map of child inquiries, forks, and cross-links.

**Claims & Sources**
- Claim ledger with evidence status and direct source relationships.

**Contributions**
- Additions, disagreements, corrections, and editorial decisions.

**History**
- Versioned change record and dated synthesis snapshots.

The first view should remain readable when a Rabbit Hole grows. Use progressive disclosure: users should not have to see every source and branch at once.

## 7. Flow D — branch without losing the origin

A branch action should ask one clear question:

> **What part deserves its own inquiry?**

It then creates a child record prefilled with:
- the selected sub-question;
- the parent Rabbit Hole ID;
- the point in the parent's path where it emerged;
- the reason for branching;
- the sources already relevant to it (links, not cloned copies, unless required).

The learner can edit these before saving. Branching must not remove the question from the parent; the parent displays a link and a short branch summary.

Create a **fork** instead of a child branch when the intent is to examine a genuinely competing path or preserve an alternate interpretation independently. Use a **cross-link** when two inquiries relate without one arising from the other.

## 8. Flow E — inspect a claim

Selecting a claim opens a focused panel:
- exact wording of the claim;
- claim type;
- current evidence status and date assessed;
- evidence links grouped by supports / challenges / context / inconclusive;
- relevant passage, page, timestamp, or data location;
- caveats and competing interpretations;
- what would change the assessment;
- history of status changes.

A status label should always be accompanied by a short rationale. Colour may assist but must never be the only signal.

Example: `NOT_ASSESSED — no source has yet been reviewed against this exact wording.`

The UI must not imply that a linked source supports a claim until that relationship has been evaluated. A source that merely mentions a topic is not automatically supporting evidence.

## 9. Flow F — receive a contribution

Contributions arrive as attributed proposed changes, not silent edits to the author's narrative.

Each contribution card shows:
- type (new source, challenge, correction, context, branch, or cross-link);
- exact target claim or location;
- contributor-selected display identity;
- summary and rationale;
- evidence links;
- review state.

Available owner actions may include:
- link into the main path;
- accept as an additional source or claim note;
- retain as a visible alternative interpretation;
- discuss or request clarification;
- decline integration while leaving an appropriately published contribution visible where governance allows;
- report for moderation if it violates rules.

**Important:** author control over the main narrative must not become a power to make legitimate disagreement disappear. A material dispute can remain linked and visible with provenance, subject to safety, privacy, and moderation rules. Conversely, a contributor should not be able to rewrite another person's authored text without permission.

## 10. Flow G — return after a gap

Opening a dormant inquiry should not greet the learner with guilt or a wall of unread notifications.

Show a calm **Return card**:
- “You were exploring…”
- the last current question;
- the most recent synthesis;
- what changed since the last return, if anything;
- a reminder of unresolved uncertainties;
- next actions (optional);
- `Continue`, `Take another branch`, `Update the return card`, `Leave it for later`.

No countdown, streak loss, “you are behind” message, or requirement to catch up. If many contributions arrived, present a concise, provenance-linked change summary and let the learner inspect each item.

Notifications or reminders should be opt-in, user-configurable, and easy to disable. Default to no unsolicited return pressure.

## 11. Flow H — synthesis and pause

A synthesis is a dated snapshot, not a final verdict. It should state:
- what the current evidence supports;
- what is supported only with limits;
- which claims remain contested or unassessed;
- what interpretations were rejected and why;
- what new evidence changed the map;
- what remains open;
- where future work would be most useful.

Pause options:
- `Dormant — keep it available`;
- `Create a return card`;
- `Fork a new inquiry`;
- `Propose a curriculum derivative`;
- `Archive my view` (with clear distinction from deleting private information or public content).

Nothing about pause or archive implies failure.

## 12. AI affordances

AI actions should be small, clearly labelled, and reversible:
- **Suggest next questions** — alternatives, not instructions.
- **Find counter-evidence** — a search task, not a guarantee that counter-evidence exists or was exhausted.
- **Inspect this source** — extract relevant passages with the source locator.
- **Compare interpretations** — show disagreements and evidence differences.
- **Make a return card** — draft for approval.
- **Suggest a branch** — create a draft link only after confirmation.
- **Summarise changes** — link every important summary point to the contributing record.

Never permit a single AI action to publish, merge into School Canon, change another person's attribution, or alter an evidence status without review and a traceable rationale.

## 13. Accessibility and inclusion

- Keep a plain-language route through every inquiry.
- Ensure core functions work without colour, animation, or a visual graph.
- Make long inquiries navigable by headings and screen readers.
- Support text-first capture and optional audio.
- Avoid assuming familiarity with academic citation formats; offer a simple source field and progressive guidance.
- Preserve original-language wording where meaningful and provide translation notes rather than silently replacing it.
- Make keyboard navigation, export, and low-bandwidth reading core requirements for any future application.

## 14. Experience acceptance tests

The design passes its first review when:
- A learner can save a Spark with one meaningful sentence and no extra required fields.
- A Spark saves as private by default.
- The original wording remains available after title or question changes.
- A learner can create a child branch, fork, and cross-link without confusing them.
- Every material claim can be connected to a source or labelled unassessed.
- A contribution cannot silently rewrite the original inquiry.
- A dispute can remain visible without forcing consensus.
- A learner can return after a long gap and orient themselves from the Return card.
- No action requires streak maintenance or public participation.
- An export remains readable as Markdown without the UI.

## 15. Open questions for later product discovery

- Should the main navigation prefer a path/timeline, a branch map, or user-selected view?
- How should private notes link to shared inquiries while protecting the source note?
- Which contributor identity options fit platform capabilities and privacy obligations?
- Should the app store source snapshots or only stable metadata and locators?
- Which notifications, if any, should exist beyond explicit reminders and followed inquiries?
- How can an AI-assisted claim check expose uncertainty and source dependence in a way novices understand?

These are design questions for testing, not settled implementation facts.
