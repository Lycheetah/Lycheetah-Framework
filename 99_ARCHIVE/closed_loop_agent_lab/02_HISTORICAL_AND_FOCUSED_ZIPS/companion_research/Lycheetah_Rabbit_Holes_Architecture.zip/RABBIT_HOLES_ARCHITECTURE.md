# Rabbit Holes — A Living Inquiry Architecture
## Lycheetah Mystery School · Architecture Proposal

**Status:** Architectural proposal / field sketch  
**Created:** 16 October 2026  
**Scope:** A shared, expandable system for documenting exploratory research journeys across the Mystery School.  
**Classification:** Direction, not an implemented feature.

---

## 1. The idea

A **Rabbit Hole** is a documented journey of curiosity: one question leads to a connection, that connection opens another question, and the learner follows the thread far enough to discover evidence, uncertainty, competing interpretations, or a new field of study.

Rabbit Holes are not merely bookmarks, link collections, or finished essays. They preserve the *path of inquiry*:

- What sparked the question.
- Which questions emerged along the way.
- Which sources, texts, artifacts, experiments, or experiences were examined.
- Which connections were found.
- Which claims became better supported, weaker, or more complicated.
- Where evidence ended and speculation began.
- What remains unresolved.
- Where another learner might continue.

The purpose is to make curiosity cumulative. A learner's exploratory journey can become a resource that others inspect, challenge, extend, correct, fork, or connect to other journeys.

> **Design principle:** Preserve not only what a learner concluded, but how the inquiry unfolded and what remains open.

## 2. Why the School needs this

The Mystery School is a living architecture for inquiry, not only a fixed curriculum. Its authored backbone can coexist with learner questions, revisions, contradictions, threads, echoes, and deep chambers.

Rabbit Holes provide a formal home for organic exploration without forcing every discovery into a predetermined lesson or Wing.

They help the School:
1. Preserve curiosity that begins outside the formal curriculum.
2. Connect disciplines usually taught separately.
3. Keep unresolved questions visible rather than prematurely closing them.
4. Let community members contribute without silently rewriting the authored curriculum.
5. Preserve provenance, context, and disagreements across time.
6. Turn individual explorations into shared learning paths.
7. Make it possible to return to a question months or years later without starting from zero.

## 3. Architectural placement

Rabbit Holes should be a **cross-school inquiry layer**, not a separate silo or a replacement for existing Wings.

They connect to the School's existing architecture:

- **School:** The authored curriculum, standards, and stable reference material.
- **Sol / faculty and council:** Curation, review, contextualisation, and routing.
- **Field Book:** Personal observations, questions, revisions, reflections, and session context.
- **Wings and Halls:** Disciplinary homes for subject matter.
- **Knowledge graph / cross-linking:** Connections between claims, sources, concepts, artifacts, and other Rabbit Holes.
- **Rite of Return / continuity practices:** Resuming unfinished inquiries after an absence.
- **Confluence:** Cross-disciplinary and human–AI inquiry without flattening different perspectives.
- **AURA / integrity principles:** Provenance, uncertainty, accountable revision, and clear boundaries.
- **CASCADE:** Potentially reorganising connections when new evidence changes an inquiry's structure.
- **LAMAGUE:** Potentially compressing or indexing an inquiry, while ensuring every symbol has a recoverable meaning.
- **TIM / continuity:** Dates, versions, sequence, and revision history.

These are proposed relationships, not claims that the functionality already exists in software.

Suggested surface: **SCHOOL · SOL · FIELD BOOK · RABBIT HOLES**

Rabbit Holes should be discoverable through an index and contextually visible inside relevant Wings, Halls, Field Book entries, and linked concepts.

## 4. Anatomy of a Rabbit Hole

### Required core fields
- **Title:** Clear, memorable name.
- **Origin question:** The question or observation that opened the inquiry.
- **Spark:** What prompted the learner to investigate.
- **Path:** The sequence of questions, sources, discoveries, and turns.
- **Evidence ledger:** Claims and evidence supporting or challenging them.
- **Uncertainty:** What remains unknown, disputed, or speculative.
- **Connections:** Related Wings, Halls, concepts, sources, artifacts, and Rabbit Holes.
- **Open doors:** The most useful unanswered questions or next steps.
- **Provenance:** Contributor, dates, source details, and revision history.
- **Status:** Current state of the inquiry.
- **Permissions:** Private, group, School, or public visibility.

### Optional fields
Audio/video timestamps; images and diagrams; maps and timelines; reproducible procedures; competing hypotheses; glossaries; audio-friendly summaries; “start here” paths; private reflections separated from public claims; creative work inspired by the inquiry.

## 5. Inquiry states

A Rabbit Hole should not be judged only by whether it reaches a final answer.

1. **Sparked** — a question has been captured.
2. **Exploring** — evidence and possible paths are being gathered.
3. **Branching** — the inquiry has opened distinct sub-questions.
4. **Evidence Check** — claims are being tested against sources or methods.
5. **Contested** — credible interpretations conflict or important evidence is missing.
6. **Stable for Now** — the current conclusion is supported for its stated scope.
7. **Dormant / Return Later** — paused but preserved.
8. **Reopened** — new evidence or a new question has revived it.
9. **Integrated** — useful findings have been incorporated into a lesson, Hall, or reference artifact.

“Stable for Now” does not mean permanently settled. New evidence can reopen any inquiry. “We don't know yet” can be a valuable outcome.

## 6. Evidence and interpretation

Rabbit Holes should encourage bold questions while protecting the School from turning speculation into fact.

Use explicit claim labels:

- **Well-supported:** Multiple strong lines of evidence support the claim.
- **Supported with limits:** Evidence exists, but scope or interpretation is qualified.
- **Plausible hypothesis:** A possible explanation that needs more testing.
- **Speculative:** Interesting but not presently established by direct evidence.
- **Contradicted / unsupported:** Available evidence does not support the claim or conflicts with it.
- **Open question:** Evidence is insufficient for a responsible assessment.

These labels describe the evidence for a claim, not the worth of a person or question.

For historical inquiry, distinguish what a primary source records, what later historians infer, what is disputed, what remains unknown, and what is modern speculation. Primary sources are not automatically truthful or complete: provenance, context, incentives, translation, and independent corroboration matter.

For scientific and medical subjects, distinguish historical use from demonstrated efficacy. For ancient cosmologies, distinguish textual and cultural meaning from claims of literal scientific prediction.

## 7. Contribution model: add without erasing

Rabbit Holes are shared inquiry spaces. Contributions should extend the record without silently replacing earlier work.

### Contribution types
- **Add a source:** Explain what it supports.
- **Add a branch:** Open a related question as a linked sub-inquiry.
- **Challenge a claim:** Explain the disagreement and provide evidence.
- **Correct the record:** Document the correction and why it is warranted.
- **Add context:** Contribute a translation, historical setting, method, or missing perspective.
- **Replicate / test:** Reproduce an analysis or experiment where possible.
- **Connect inquiries:** Link two Rabbit Holes and explain the relationship.
- **Summarise:** Produce an accessible overview without erasing nuance.
- **Fork the inquiry:** Explore a distinct interpretation while preserving the shared parent.
- **Return with new evidence:** Reopen a dormant or stable inquiry.

### Contribution rules
1. Preserve the original question and revision history.
2. Attribute contributions clearly.
3. Separate evidence from interpretation and personal reflection.
4. Link sources to the specific claims they support.
5. Explain corrections rather than merely overwriting content.
6. Make disagreement legible and respectful.
7. Do not treat repeated claims derived from one source as independent corroboration.
8. Do not require consensus for an inquiry to remain useful.
9. Respect privacy, copyright, safety, and consent.

The aim is collaborative correction, not a popularity contest.

## 8. Branching without losing the thread

A Rabbit Hole can become enormous. Branch without losing the path that made it meaningful.

- **Parent Rabbit Hole:** Original curiosity and main narrative.
- **Branches:** Distinct questions with their own evidence trails.
- **Echoes:** Short references to related ideas elsewhere in the School.
- **Crossings:** Connections between different Rabbit Holes or Wings.
- **Deep Chambers:** Advanced, technical, or highly contested subtopics.
- **Return points:** Summaries that help a learner resume the inquiry.
- **Synthesis:** A dated account of what the branches collectively suggest, without pretending they all agree.

Every branch retains a link to its origin and makes its evidence status visible.

### Example: Ancient monumental engineering

Parent question: **How did ancient builders carve and construct monumental architecture?**

Possible branches:
- Ellora's Kailasa Temple: monolithic planning and rock removal.
- Petra: sandstone geology, tool marks, water systems, and Nabataean craft.
- Egyptian pyramids: surveying, quarrying, transport, labour organisation, and construction hypotheses.
- Ancient measurement systems and geometry.
- How specialist knowledge was transmitted through workshops and apprenticeships.
- What evidence would distinguish sophisticated known methods from a proposed lost technology.

Each branch is investigated on its own evidence. A shared parent question does not imply a shared answer.

## 9. From Rabbit Hole to curriculum

A Rabbit Hole should not automatically become official curriculum.

1. **Community inquiry:** Capture and explore the question.
2. **Evidence development:** Document sources, methods, disagreements, and uncertainty.
3. **Peer contribution:** Invite additions, challenges, replication, and context.
4. **Curatorial review:** Assess accuracy, usefulness, safety, and fit.
5. **Integration decision:** Link it, summarise it, adapt it into a lesson, or leave it open.
6. **Versioned integration:** If it enters the authored curriculum, preserve the original Rabbit Hole as provenance.

Popularity is not proof. A minority interpretation is not automatically wrong. Review should focus on evidence, reasoning, relevance, and transparent uncertainty.

## 10. Discovery and navigation

People should find Rabbit Holes by topic, Wing, Hall, origin question, evidence status, unanswered questions, recent updates, related sources, contributor interests (subject to privacy), beginner-friendly paths, cross-disciplinary connections, and requests for review or replication.

Avoid ranking solely by clicks or popularity. Consider surfacing well-sourced work, thoughtfully contested inquiries, useful updates, and connections between isolated disciplines.

## 11. AI's role

AI can assist with:
- Suggesting related concepts and Rabbit Holes.
- Extracting questions from notes or transcripts.
- Building timelines and glossaries.
- Identifying unsupported jumps in reasoning.
- Finding source passages relevant to claims.
- Suggesting counterarguments and alternative hypotheses.
- Summarising long inquiries at different levels.
- Tracking contradictions and changes in confidence.
- Helping contributors resume after a long gap.

AI should not silently invent citations, upgrade evidence status without justification, rewrite contributor meaning without a change record, treat model agreement as independent verification, hide disagreement for narrative smoothness, or declare an unresolved inquiry settled just to produce a tidy answer.

AI-generated material should be identifiable, reviewable, and correctable. Human contributors retain meaningful control over their work.

## 12. Privacy, safety, and governance

Not every exploration should be public by default.

Distinguish:
- **Private Field Book material:** Personal notes and reflections.
- **Shared Rabbit Hole:** Collaborators invited by the owner or group.
- **Community Rabbit Hole:** Visible to the School community.
- **Public Rabbit Hole:** Published for anyone to read.
- **Restricted material:** Content requiring special access controls or exclusion from publication.

Personal reflections should not be exposed merely because they sit beside a public inquiry. Handle sources, quotations, images, and datasets according to rights and consent.

Moderation should target harassment, doxxing, manipulation, and unsafe content without treating unusual hypotheses as misconduct merely because they are unpopular.

## 13. Contribution template

```markdown
# [Rabbit Hole Title]

**Status:** Sparked / Exploring / Branching / Evidence Check / Contested / Stable for Now / Dormant / Reopened / Integrated
**Visibility:** Private / Group / School / Public
**Started:** YYYY-MM-DD
**Contributors:**

## The spark
What prompted this inquiry?

## Origin question
What are we trying to understand?

## Current path
What have we investigated so far, and how did the question change?

## Claims and evidence
| Claim | Evidence/source | What it supports | Limits or counterevidence | Status |
|---|---|---|---|---|

## Competing interpretations
What are the strongest alternative explanations?

## Connections
Related Wings, Halls, concepts, sources, and Rabbit Holes.

## Open doors
What should the next person investigate?

## Contribution history
Who added or changed what, and why?

## Return summary
What should a future reader know to resume this inquiry?
```

## 14. Minimum viable roadmap

### Phase 1 — Practice
Use Markdown, one index, and one file per Rabbit Hole. Record sources, evidence labels, branches, and open questions. Link inquiries to existing School material.

### Phase 2 — Shared contribution
Establish attribution and revision conventions. Add review and correction workflows. Allow branches and cross-links. Make privacy and publication status explicit.

### Phase 3 — Integrated School architecture
Connect Rabbit Holes to Wings, Halls, Field Book entries, and the knowledge graph. Add search, filters, return points, and contribution requests. Introduce AI-assisted navigation with visible provenance and human review.

### Phase 4 — Living inquiry network
Track how questions evolve. Surface connections across disciplines. Preserve competing interpretations and evidence changes. Allow mature inquiries to inform curriculum without erasing their exploratory history.

These phases are a proposed roadmap, not a statement of current implementation.

## 15. Success criteria

The system is working if:
- A learner can resume an old inquiry without reconstructing its history.
- Another person can contribute evidence without erasing the original path.
- Claims can be traced to sources.
- Contradictions remain visible until resolved.
- Speculation is allowed but clearly labelled.
- Different Wings connect through meaningful questions.
- A Rabbit Hole can change direction without losing its history.
- The School can learn from community inquiry while preserving standards.
- The system rewards careful investigation, not only confident conclusions.

## 16. The principle to preserve

The School should not demand that every curiosity become a lesson, every question receive an answer, or every disagreement be resolved.

Some questions become knowledge. Some become better questions. Some reveal that evidence is missing. Some connect fields that had been isolated from each other. Some wait years for a new source or method.

**A Rabbit Hole is a preserved path through uncertainty — open to the next curious person.**

That is how individual curiosity can become shared, cumulative inquiry.
