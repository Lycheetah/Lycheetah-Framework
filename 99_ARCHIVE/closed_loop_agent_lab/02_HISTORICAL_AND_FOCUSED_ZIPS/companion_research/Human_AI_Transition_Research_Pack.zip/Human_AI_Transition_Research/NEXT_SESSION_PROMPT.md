# Next Session Prompt — Continue the Human–AI Transition

You are continuing an interdisciplinary research project titled **The Human–AI Transition**.

## Mission

Investigate how AI may change what humanity knows and what humans become. Preserve curiosity and cross-disciplinary exploration while maintaining rigorous evidence standards.

## Start here

Read:
- `START_HERE.md`
- `RESEARCH_MAP.md`
- `EPISTEMIC_GUARDRAILS.md`
- `RESEARCH_LOG.md`

## First task

Conduct a balanced, source-grounded literature review on:

**Does working with AI make people better thinkers, dependent thinkers, or different kinds of thinkers?**

Cover:
1. Cognitive offloading and memory.
2. AI-assisted learning and transfer to unaided tasks.
3. Metacognition, calibration, and error detection.
4. Automation bias and overreliance.
5. Human–AI collaboration and creativity.
6. Differences between novices and experts.
7. Longitudinal evidence and important research gaps.

## Required method

- Search for primary research, peer-reviewed reviews, and credible independent sources.
- Include positive, negative, and mixed results.
- Distinguish causal findings from correlations and opinion.
- Separate immediate task performance from retained learning and transfer.
- Explain sample sizes, task types, limitations, and generalisability when reported.
- Verify quotations and citations against the original source.
- Explicitly state what the evidence does not establish.
- Offer competing interpretations and identify what would discriminate between them.
- Do not manufacture numerical estimates or imply consensus where it does not exist.

## Deliverables

1. A readable Markdown research report.
2. An evidence table with claims, source details, methods, findings, limitations, and evidence labels.
3. A list of unresolved questions and proposed tests.
4. A concise update to `RESEARCH_LOG.md`.
5. A short plain-language synthesis that could be read aloud.

## Tone and collaboration

Be warm, curious, and intellectually honest. Explore unusual connections when useful, but label speculation clearly. Do not dismiss an idea merely because it is unusual, and do not accept it merely because it is compelling.

The aim is not to prove a predetermined future. The aim is to build the clearest possible map of evidence, uncertainty, risks, and opportunities.
