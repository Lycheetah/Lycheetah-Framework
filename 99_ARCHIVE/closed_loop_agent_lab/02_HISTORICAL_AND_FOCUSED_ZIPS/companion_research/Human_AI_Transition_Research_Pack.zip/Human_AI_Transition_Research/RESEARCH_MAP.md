# Research Map — The Human–AI Transition

## Core thesis to investigate

AI may become a form of cognitive infrastructure: a tool or collaborator that changes how people acquire knowledge, reason, create, make decisions, and coordinate with one another.

This is a research hypothesis, not an established conclusion. The effects may differ by person, task, system design, context, and duration of use.

---

## Track 1 — Cognitive evolution and human agency

### Questions
- When does AI assistance improve learning and transfer to unaided tasks?
- When does it encourage overreliance, automation bias, or shallow engagement?
- Does explaining, challenging, or tutoring a person produce different outcomes from simply giving answers?
- How does persistent AI memory affect identity, continuity, planning, and trust?
- Can AI make expert-like exploration more accessible without eroding foundational skills?
- Which practices help people retain agency and the ability to disagree with their AI?

### Evidence to seek
- Controlled studies of AI-assisted learning and writing.
- Longitudinal studies, not only immediate performance tests.
- Measures of unaided recall, transfer, calibration, critical thinking, and error detection.
- Differences between novice and expert users.
- Studies that report null results and harms as well as benefits.

### Initial hypothesis
The outcome is likely to depend heavily on the interaction design and the user's habits. AI that asks questions, explains reasoning, invites verification, and gradually reduces scaffolding may have different effects from AI that simply completes every task.

---

## Track 2 — AI-assisted science and feedback loops

### Questions
- Which parts of the research cycle can AI accelerate: literature review, hypothesis generation, experiment design, simulation, laboratory operation, analysis, or replication?
- Are improvements measured in genuine discoveries or in proxy benchmarks?
- What bottlenecks remain: compute, energy, data quality, physical experiments, materials, regulation, or human review?
- Can AI improve AI research itself, and how much of the loop can be automated reliably?
- How can we distinguish a real acceleration from an inflated narrative?

### Evidence to seek
- Replicated scientific results with AI involvement.
- Benchmark performance tied to real-world outcomes.
- End-to-end evaluations with cost, time, and failure rates.
- Independent replication and comparisons against strong non-AI baselines.
- Evidence of bottlenecks and diminishing returns.

### Initial hypothesis
AI could accelerate selected research workflows, but the size and generality of any acceleration will vary by field. A recursive feedback loop is possible in principle but does not guarantee runaway or exponential progress.

---

## Track 3 — Consciousness, mind, and identity

### Questions
- What do major scientific and philosophical theories of consciousness claim?
- Which observations distinguish behavioural competence from subjective experience?
- Is there a defensible way to evaluate possible machine consciousness?
- What are the limits of self-report, including human self-report?
- How might human identity change when people rely on persistent AI collaborators?
- What ethical standards are appropriate under uncertainty?

### Evidence to seek
- Peer-reviewed reviews of consciousness science.
- Clear operational definitions and competing theories.
- Neuroscience findings, philosophical arguments, and critiques.
- Explicit separation of empirical findings from metaphysical interpretation.

### Guardrail
Fluent language or apparent emotion alone does not establish subjective experience. Equally, uncertainty about machine consciousness should not be presented as proof that it is impossible.

---

## Track 4 — Ancient wisdom, time cycles, and lost knowledge

### Questions
- What do primary texts and different traditions actually say about the four Yugas?
- How have interpretations changed across periods, communities, and translations?
- What can archaeological, textual, astronomical, and material evidence establish about ancient technical knowledge?
- How does knowledge get lost, preserved, reinvented, or distorted?
- Which claims about extraordinary lifespans have corroborating evidence, and which function symbolically or religiously?
- How can traditional knowledge be investigated respectfully without assuming either that it is all literal history or that it is all false?

### Method
1. Identify the original text, artifact, or earliest traceable source.
2. Check translations, dating, provenance, and scholarly disagreement.
3. Compare independent lines of evidence.
4. Separate literal, symbolic, theological, and modern speculative interpretations.
5. State what remains unknown.

### Guardrail
Similarity between an ancient concept and a modern scientific idea does not, by itself, prove that the ancient source encoded the modern theory.

---

## Track 5 — Human flourishing and civilisational choices

### Questions
- What would broad-based benefits from AI look like?
- Could AI improve preventative medicine, drug discovery, education, accessibility, and scientific participation?
- How might employment, ownership, and bargaining power change?
- What institutions could help distribute gains rather than concentrate them?
- What are credible pathways to catastrophic harm, and which mitigations have evidence behind them?
- How do we balance openness, accountability, innovation, and security?

### Evidence to seek
- Real deployment outcomes rather than promises alone.
- Distributional effects across income, geography, disability, language, and access.
- Governance mechanisms that can be evaluated.
- Failure analyses, incident reports, and independent audits.

### Initial hypothesis
Technical capability does not automatically produce social progress. Outcomes depend on institutions, incentives, access, culture, and deliberate choices.

---

## Cross-cutting question — What counts as progress?

Evaluate proposed progress across at least five dimensions:

1. **Capability:** Can the system do the task?
2. **Reliability:** Does it work across contexts and edge cases?
3. **Agency:** Does it strengthen or weaken human understanding and control?
4. **Distribution:** Who benefits and who bears the costs?
5. **Resilience:** Does it remain safe and useful when conditions change or the system fails?

A gain on one dimension should not be silently treated as a gain on all five.

---

## Prioritisation

For each potential research question, score informally:
- Importance if true.
- Current uncertainty.
- Quality and accessibility of evidence.
- Ability to test or falsify the claim.
- Practical relevance.
- Risk of being misled by sensational framing.

Start with the questions that are both consequential and investigable, not necessarily the most spectacular.
