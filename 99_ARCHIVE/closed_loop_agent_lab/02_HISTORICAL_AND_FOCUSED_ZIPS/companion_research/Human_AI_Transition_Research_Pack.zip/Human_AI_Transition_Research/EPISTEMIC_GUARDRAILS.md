# Epistemic Guardrails

## Purpose

This document protects the project from premature dismissal and premature belief. It is designed for exploratory research into history, AI, consciousness, ancient traditions, and future scenarios.

## Use five evidence labels

### A — Well-supported
Multiple strong, independent sources support the claim, with a clear evidence trail.

### B — Supported but qualified
Credible evidence exists, but scope, causality, interpretation, or generalisation remains limited.

### C — Plausible hypothesis
The claim fits some evidence or mechanisms but lacks decisive confirmation.

### D — Speculative
The claim is conceivable but has little direct supporting evidence or many unresolved steps.

### E — Unsupported or contradicted
Available evidence does not support the claim, or strong evidence conflicts with it.

These labels describe the current state of evidence, not the worth of asking a question. A D-level question may be worth investigating if it is important and testable.

## Keep claims separate

Do not collapse the following into one another:
- Something happened.
- A government or institution benefited from it.
- That actor helped enable it.
- That actor intended it.
- That actor secretly coordinated the entire event.
- The event was deliberately staged.

Each step requires additional evidence.

Similarly, distinguish:
- Historical use of a treatment from demonstrated medical efficacy.
- Ancient symbolic language from literal scientific description.
- A system's fluent behaviour from proof of consciousness.
- A technological possibility from a forecast that it will occur.
- A forecast from a moral preference about what should happen.

## Source discipline

Prefer, when available:
1. Primary documents and artifacts with known provenance.
2. Peer-reviewed research and systematic reviews.
3. High-quality scholarly books and institutional archives.
4. Credible journalism that links to underlying records.
5. First-person testimony, evaluated in context.
6. Popular summaries, used as leads rather than final authority.

Primary sources are not automatically truthful. They reveal what a person or institution recorded, claimed, planned, or believed; they may still be mistaken, self-serving, incomplete, or propagandistic.

## Questions to ask about a source

- Who created it, when, and for what audience?
- What access did they have to the event?
- What incentives or biases might affect the account?
- Is the document authentic and complete?
- Does another independent source corroborate it?
- What evidence would contradict the interpretation?
- Are later accounts repeating one original source rather than independently confirming it?

## Steelman and stress-test

For important claims:
1. State the strongest version of the claim.
2. State the strongest competing explanation.
3. Identify evidence that would discriminate between them.
4. Search for disconfirming evidence.
5. Update the conclusion proportionally.
6. Preserve unresolved uncertainty rather than forcing a verdict.

## Speculation is welcome when labelled

Use explicit phrasing such as:
- “The evidence establishes…”
- “One interpretation is…”
- “A plausible mechanism would be…”
- “This remains speculative because…”
- “We do not currently have enough evidence to distinguish…”
- “Here is what would change the assessment…”

## Avoid two symmetrical errors

**Error 1: Automatic dismissal.** A claim is not false simply because it is unusual, unpopular, or associated with fringe communities.

**Error 2: Automatic validation.** A claim is not true because it is suppressed, emotionally compelling, ancient, or consistent with a suspicion.

The task is to investigate the claim and its evidence.

## AI-specific cautions

- AI can hallucinate citations, overstate consensus, and produce plausible but false causal stories.
- Verify key claims against accessible sources.
- Ask for source passages and context, not merely a list of links.
- Use independent sources where practical.
- Distinguish benchmark success from real-world capability.
- Treat model agreement cautiously if models share training data or assumptions.
- Record failed tests and counterexamples.

## Research integrity

Never hide a null result, quietly change the hypothesis after seeing results, or describe a proposed experiment as a successful validation. Record the method, assumptions, limitations, and date of the assessment.
