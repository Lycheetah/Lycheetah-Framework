# [Rabbit Hole Title]

**Framework status:** `[PROPOSAL]`  
**Visibility:** `PRIVATE`  
**Inquiry phase:** `SPARKED`  
**Owner:** `[local alias or identifier]`  
**Created:** `YYYY-MM-DD`  
**Updated:** `YYYY-MM-DD`

> Start small. A question, a spark, and one next step are enough.

---

## 1. The spark

What started this inquiry? A conversation, artifact, passage, contradiction, observation, or intuition?

## 2. Origin question

Write the first question as it appeared. Preserve the wording even if the question later changes.

## 3. Current question

What are we trying to understand *now*?

## 4. Scope

What does this inquiry cover? What is outside scope for the moment?

## 5. Path so far

| Date / step | Question or event | What was examined | What changed | Next link |
|---|---|---|---|---|

## 6. Claims and evidence

| Claim ID | Exact claim | Type | Evidence status | Supporting links | Challenges / limits | Last assessed |
|---|---|---|---|---|---|---|

Evidence status: `SUPPORTED`, `SUPPORTED_WITH_LIMITS`, `CONTESTED`, `NOT_ASSESSED`, `SPECULATIVE`, `CONTRADICTED_OR_UNSUPPORTED`, `NOT_APPLICABLE`.

## 7. Source register

| Source ID | Source / creator | Type | Locator | Relevant passage / timestamp | Relationship to claim | Limitations |
|---|---|---|---|---|---|---|

Record whether a source is primary or secondary, provenance where relevant, and what it does *not* establish.

## 8. Competing interpretations

What are the strongest plausible alternatives? What evidence would help distinguish them?

## 9. Branches and crossings

- Parent inquiry:
- Child branches:
- Forks:
- Cross-links to other Rabbit Holes:
- Related Wings / Halls / subjects:
- Why each link matters:

## 10. Open doors

Which questions remain unanswered? Which next action would be most informative?

1. 
2. 
3. 

## 11. Return card

**Current understanding:**  
**Best-supported points:**  
**Most uncertain points:**  
**Next one to three actions:**  
**Sources to reopen:**  
**Cautions / context for a returning reader:**

## 12. Personal reflection (optional)

Keep personal reflections private unless you explicitly choose to publish this section. A public inquiry does not require public disclosure.

## 13. Contribution history

| Date | Contributor | Type | Change | Rationale / evidence | Version |
|---|---|---|---|---|---|

## 14. Synthesis snapshots

### YYYY-MM-DD — Synthesis N

**What is currently supported:**  
**What remains contested:**  
**What remains unassessed:**  
**What changed since the previous synthesis:**  
**What would change this assessment:**

---

*This template is a proposed record format. Completing every field is not required to capture a spark or begin a private inquiry.*
