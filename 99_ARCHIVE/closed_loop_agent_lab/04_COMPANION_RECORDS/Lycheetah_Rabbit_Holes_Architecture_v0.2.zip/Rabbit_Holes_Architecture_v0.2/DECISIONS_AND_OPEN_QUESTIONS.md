# Rabbit Holes — Decisions and Open Questions

**Framework status:** `[PROPOSAL]` · **Version:** 0.2

## Decisions in this proposal

### D1 — Cross-school inquiry layer, not a new Wing
Rabbit Holes can span any subject, Wing, Hall, or practice. They describe how an inquiry develops, not a discipline or rank.

### D2 — Personal, Commons, and Canon are separate
Personal notes are private by default; shared work is explicitly published; curriculum integration requires a separate recorded decision. This preserves consent and the boundary between Personal Canon, Commons, and School Canon.

### D3 — Status axes stay independent
Track inquiry phase, claim evidence status, framework/implementation maturity, and visibility separately. This prevents “published”, “active”, “popular”, or “finished” from being mistaken for “true”.

### D4 — Preserve history and provenance
Additions, corrections, synthesis snapshots, and forks retain links to prior versions. Inquiry becomes more accurate without erasing how it changed.

### D5 — No engagement pressure
No streaks, completion pressure, ranks, penalties for dormancy, or AI dependency incentives. This matches voluntary-return principles and learner sovereignty.

### D6 — Human confirmation before sharing or integration
AI may assist but cannot silently publish or canonise content. This protects agency, attribution, and epistemic accountability.

### D7 — “Stable for now” is revisable
Stability is a dated assessment, not a permanent terminal state. New evidence can reopen an inquiry.

### D8 — Markdown first
Start with readable Markdown and a lightweight registry before building an application. This is portable, auditable, and easy to revise.

## Open decisions

### O1 — ID format
Should published IDs be sequential (e.g. `RH-2026-0001`) or opaque UUIDs with a display alias? **Initial recommendation:** UUID internally; short alias for people. Private IDs should not expose identity.

### O2 — Who can create a Commons inquiry?
Should every community member publish directly or should initial public sharing need review? **Initial recommendation:** ordinary Commons contributions may be published with clear proposal/evidence states; reserve review for moderation and curriculum integration. Exact platform permissions remain open.

### O3 — Source archives
Should records store only metadata/links, or also permitted snapshots, hashes, and passages? **Initial recommendation:** begin with metadata and stable locators, note access dates, and archive only when legally and ethically permitted.

### O4 — Cultural and restricted knowledge
What governance applies when communities restrict publication or interpretation? **Initial recommendation:** support private/restricted records and “do not republish” notices; do not assume public access means permission.

### O5 — Contributor attribution
Should authors choose a real name, School identity, pseudonym, or uncredited contribution? **Initial recommendation:** explicit choice, subject to platform integrity and legal needs; never force personal reflection into a public profile.

### O6 — Canon review
Who reviews a candidate teaching and how are conflicts of interest disclosed? **Initial recommendation:** follow existing School governance rather than inventing a separate Rabbit Hole authority.

### O7 — AI source checks
What minimum review is required when AI proposes a claim-source link? **Initial recommendation:** AI links remain suggestions until a person or validated process checks the actual passage.

### O8 — Discovery ranking
How can useful, contested, or under-explored work be surfaced without popularity incentives? **Initial recommendation:** transparent filters and curated pathways; no worth or rank from views/reactions/activity.

### O9 — Field Book bridge
Should a private Field Book entry be converted by copying a selected excerpt, linking it, or creating a new record? **Initial recommendation:** user-controlled “create from selection”; original stays private and unchanged.

### O10 — Branch size
When should an inquiry split? **Initial recommendation:** when a question, evidence base, method, or audience can stand independently. A return card links it to the parent.

## Pilot questions

- Can a new contributor understand evidence labels without training?
- Is the template light enough to capture a spark?
- Can another person add a counter-source without appearing to overwrite the author?
- Can someone resume a dormant inquiry in a few minutes?
- Does branching improve clarity or merely multiply files?
- Are private notes reliably kept private?
- Can an inquiry remain valuable without a neat conclusion?
- Is the canonical integration boundary clear to ordinary learners?

## Acceptance criterion

Do not describe the proposal as `[ACTIVE]` until its record format and workflows have been exercised with real inquiries, failures have been documented, and implementation status is updated according to Framework governance.
