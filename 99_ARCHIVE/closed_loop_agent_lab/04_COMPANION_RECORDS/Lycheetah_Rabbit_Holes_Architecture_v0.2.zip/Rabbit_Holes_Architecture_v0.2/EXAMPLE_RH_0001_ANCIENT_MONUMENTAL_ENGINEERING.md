# RH-EXAMPLE-0001 — How Did Ancient Builders Create Monumental Architecture?

**Framework status:** `[PROPOSAL]`  
**Record status:** Illustrative example; not a live Commons inquiry  
**Inquiry phase:** `SPARKED`  
**Visibility:** `PRIVATE`  
**Evidence review:** Not yet conducted

## 1. The spark

A recurring fascination with ancient engineering: the rock-cut temples of India, Petra's cliff-carved facades, the pyramids of Egypt, ancient languages, lost craft knowledge, and the practical methods that let earlier societies build extraordinary structures.

The spark is not the assertion that a lost super-technology existed. It is the question of how people organised knowledge, labour, materials, surveying, tools, and technique — and how much of that process survives in evidence today.

## 2. Origin question

**How did ancient builders plan, carve, transport, raise, and finish monumental structures — and what parts of their methods can we reconstruct from surviving evidence?**

## 3. Current question

Which individual site or technique offers the best starting point for a source-led investigation?

Potential starting sites:
- Ellora's Kailasa Temple, India.
- Petra, Jordan.
- The pyramids at Giza, Egypt.

Do not treat the sites as one engineering tradition. Each has its own history, geology, chronology, tool marks, cultural context, and evidence base.

## 4. Questions worth branching

### Branch A — Ellora's Kailasa Temple
- What is the site's chronology and archaeological context?
- What is known about the order and direction of rock removal?
- Which tool marks and unfinished areas are documented?
- What surveying, planning, staging, and labour coordination are plausible?
- Which reconstruction details are supported, and which are conjectural?

### Branch B — Petra
- What can geology and tool marks reveal about the carving sequence?
- How were facades laid out and accessed during work?
- How did architecture relate to water management and local settlement?
- Which techniques can be inferred directly from the stone, and which are reconstructed by scholars?

### Branch C — Egyptian pyramid construction
- What do archaeological remains reveal about quarrying, transport, ramps, sledges, levers, and lifting?
- Which techniques have experimental or physical support?
- Where do researchers disagree about sequencing and logistics?
- How were surveying, workforce organisation, provisioning, and administration coordinated?

### Branch D — Knowledge transmission
- How were specialist techniques taught through apprenticeship, workshops, and oral instruction?
- Which ancient technical texts, inscriptions, diagrams, or administrative records survive?
- What tacit knowledge is difficult to reconstruct from a finished object alone?
- How do conquest, language change, institutional collapse, and environmental loss affect continuity?

### Branch E — Lost technology: what would count as evidence?
- What specific capability is being proposed?
- What physical, textual, or experimental trace should it leave?
- Could known tools and techniques explain the same evidence?
- What measurement or experiment could discriminate between explanations?
- What evidence would falsify or substantially weaken the lost-technology hypothesis?

## 5. Claim ledger — starter state

| ID | Claim / proposition | Claim type | Evidence status | Note |
|---|---|---|---|---|
| CL-001 | The selected site was created using a specific sequence of tools and operations. | Historical / archaeological claim | `NOT_ASSESSED` | Must be site-specific and tied to evidence. |
| CL-002 | Tool marks, unfinished areas, quarry traces, and material context can help constrain reconstruction of a building process. | Methodological claim | `NOT_ASSESSED` | Locate scholarly archaeological sources and examples. |
| CL-003 | Some craft knowledge can be lost even when the resulting structure survives. | Historical hypothesis | `NOT_ASSESSED` | Investigate documented cases; do not assume every ancient technique was lost. |
| CL-004 | A lost technology was necessary to build the selected monument. | Hypothesis | `SPECULATIVE` | The monument's impressiveness alone does not establish this; define the proposed capability and test alternatives. |

These entries demonstrate claim separation. They are not researched conclusions or citations.

## 6. Source strategy

Start with archaeological site publications and excavation reports; scholarly studies of the specific site; conservation and engineering surveys; relevant inscriptions and technical texts with expert translation; experimental archaeology; and credible museum or heritage-institution materials as accessible entry points.

For each source, record the relevant passage, what it supports, what it does not establish, date, and whether other sources depend on it.

## 7. Working rules

- Investigate one site deeply before comparing sites.
- Do not merge confirmed methods with disputed reconstructions.
- Do not treat “we don't know exactly” as proof of hidden technology.
- Do not treat the conventional account as complete merely because it is conventional.
- Keep alternatives live in proportion to their evidence.
- Respect cultural context and communities for whom the sites remain living heritage.
- Distinguish “not yet understood by this investigator” from “not understood by researchers.”

## 8. Return card

**Current understanding:** This is a broad research question, not a conclusion.  
**Best next step:** Choose one site and gather high-quality archaeological and engineering sources.  
**Unknowns:** Which construction sequence has strongest support; which details remain contested; where craft knowledge transmission can be traced.  
**Don't assume:** One shared mysterious cause across different cultures or sites.  
**Next actions:** (1) Pick one site. (2) Build a source list with an archaeological/heritage report and a scholarly analysis. (3) Extract specific claims and identify their evidence.

## 9. Why this is a useful Rabbit Hole

The inquiry can branch into geology, geometry, ancient languages, material science, logistics, craft training, state capacity, cultural memory, and the archaeology of technology. Its branches remain connected by common curiosity without being forced to share one answer.
