# Rabbit Holes — Contribution and Governance Protocol

**Framework status:** `[PROPOSAL]` · **Version:** 0.2

## 1. Constitutional boundary

Rabbit Holes make inquiry cumulative without making the School an authority that owns a learner's thoughts. They should respect:
- **PROTECTOR:** reduce foreseeable harm and privacy exposure.
- **HEALER:** do not hide complexity or exploit uncertainty.
- **BEACON:** increase agency; do not make learners dependent.
- **The Commons Has Many Hands:** contributors can extend and challenge work.
- **The Map Is Allowed to Break:** maps and frameworks remain revisable.
- **No Name Owns Its Bearer:** labels do not own the person.
- **The Ninth Door Opens Outward:** learning supports the ability to go beyond the School.

## 2. Personal / Commons / Canon

### Personal inquiry
Owned by the learner. It may contain unfinished ideas, personal reflection, rough notes, and private transcripts. It is not public by default.

### Commons inquiry
Material the learner explicitly shares. Its visibility and authorship are clear. It is open to additions and challenges but is not necessarily endorsed, verified, or canon.

### School Canon and curriculum
Selected material with an explicit governance decision, scope, rationale, version, and provenance. Canon remains small and governed. A Rabbit Hole may inform a derivative teaching; it never becomes canon silently.

## 3. Contribution types

| Type | Use when | Minimum expectation |
|---|---|---|
| Add source | New material is relevant | Identify the source and explain relevance |
| Challenge claim | A claim appears incorrect or overstated | Identify the exact claim and provide reasoning/evidence |
| Correction | A material error is found | Explain correction and preserve prior version |
| Context | Missing context, translation, or perspective matters | Explain what context changes |
| Replication / test | A method or result can be checked | Record steps, conditions, failures, limitations |
| Add branch | A sub-question becomes its own inquiry | State parent question and why branch is useful |
| Fork | A distinct interpretation needs independence | Link source version and state the departure |
| Cross-link | Another inquiry is meaningfully related | Explain the relation, not just keyword overlap |
| Synthesis | Branches need a current map | Preserve disagreement and assessment date |
| Accessibility summary | Another format improves access | Preserve caveats and meaning |

Disagreement is contribution, not misconduct. Quality is not measured by agreement with the original author.

## 4. Publication workflow

1. Create privately or in a private Field Book.
2. Review before sharing: remove private material, secrets, third-party personal information, and material not cleared for publication.
3. Select visibility: invited group, School Commons, or public.
4. Publish a snapshot that reflects what the author intended to share.
5. Receive attributed, logged contributions.
6. Request structured review if useful; not every inquiry needs official review.
7. Propose curriculum integration only when appropriate, using existing School governance.
8. Preserve the original; any accepted teaching is a derived artifact linked to the contributing inquiry.

Nothing requires a learner to publish, respond, return, or complete an inquiry.

## 5. Review protocol

A review asks:
- Is the question clearly scoped?
- Are factual claims separated from interpretations and personal reports?
- Do citations support the specific claims attached to them?
- Is the source trail independent enough for the conclusion?
- Are alternatives and counterevidence represented fairly?
- Are uncertainty and methodological limits visible?
- Are cultural, privacy, safety, copyright, and consent considerations addressed?
- Does the proposed integration preserve learner agency and anti-cult commitments?

A review does not ask whether the work agrees with authority, is popular, or sounds sufficiently mystical or scientific.

## 6. Curriculum decision

Suggested outcomes: `ACCEPTED_FOR_INTEGRATION`, `NEEDS_WORK`, `DECLINED_WITH_REASON`, `WITHDRAWN_BY_PROPOSER`, `REMAINS_OPEN_COMMONS_WORK`.

Record the bounded material under consideration, decision-maker, date, rationale, evidence, and revision/appeal path. Declining curriculum integration does not require deleting an otherwise lawful, safe Commons inquiry.

## 7. Evidence assessment and moderation are different

A weakly supported claim is not automatically a moderation violation; it may need a `SPECULATIVE` or `NOT_ASSESSED` label. Moderation concerns include harassment, threats, doxxing, non-consensual disclosure, copyright abuse, manipulation, and foreseeable unsafe instructions. Explain moderation and use the least restrictive effective response.

Do not moderate a claim solely because it is unusual, unpopular, uncomfortable, or challenges School Canon.

## 8. Cultural knowledge and sensitive sources

Public availability does not automatically mean ethical permission to reproduce, commercialise, or reframe knowledge. For Indigenous, sacred, restricted, community-held, or context-dependent knowledge:
- identify relevant community guidance where feasible;
- follow explicit use restrictions;
- avoid extracting a claim from its cultural context to decorate an unrelated theory;
- record translation and permission limits;
- keep material private or omit it where publication is inappropriate.

Do not imply that similarity proves shared ancestry or that every tradition belongs to a single universal system.

## 9. AI assistance rules

AI can propose structure, compare passages, suggest counterevidence, and prepare summaries. It cannot silently publish personal data or decide what a learner meant.

For substantive AI-generated claims: label AI assistance where relevant; validate citations against original sources; distinguish suggestions from accepted edits; retain a human review path; and do not treat model agreement as independent evidence when evidence bases may overlap.

## 10. Return without pressure

No streaks, scarcity timers, guilt, rank penalties, variable-ratio rewards, or companion dependency are permitted as Rabbit Hole mechanics. A reminder may be initiated by the learner. A return card may make resumption easier. The system must not imply that dormancy is failure or the School is owed attention.

## 11. Appeals and repair

Contributors should be able to challenge an assessment, moderation decision, attribution, or integration decision through a recorded process. Reviewers should correct mistakes openly. Where content is removed for safety or privacy, preserve only the minimum necessary audit information; do not expose private details in the name of transparency.
