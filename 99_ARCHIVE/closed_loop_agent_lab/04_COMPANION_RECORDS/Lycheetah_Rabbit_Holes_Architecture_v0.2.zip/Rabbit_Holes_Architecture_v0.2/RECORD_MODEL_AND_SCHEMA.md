# Rabbit Holes — Record Model and Schema

**Framework status:** `[PROPOSAL]` · **Version:** 0.2

## 1. Object model

| Entity | Purpose | Minimum requirement |
|---|---|---|
| `Inquiry` | The main exploratory journey | Stable ID, origin question, owner, phase, visibility |
| `Question` | A question guiding the inquiry | Text, type (origin/current/branch/open), date |
| `Claim` | A proposition that can be assessed | Exact wording, claim type, evidence status |
| `Source` | A source or primary artifact | Identity, locator, source type, metadata where available |
| `ClaimSourceLink` | Explains a source's relationship to a claim | Claim ID, source ID, relation, relevant passage, note |
| `Contribution` | An addition, challenge, correction, or change | Contributor, type, date, target, rationale |
| `BranchLink` | Parent/child, fork, or cross-link relationship | Source inquiry, target inquiry, relationship, rationale |
| `Synthesis` | A dated snapshot of current understanding | Summary, limits, uncertainty, date |
| `ReturnCard` | Lets someone resume the inquiry | Current state, knowns, unknowns, next steps |
| `IntegrationDecision` | Decision to adapt work into curriculum | Reviewer, decision, rationale, derivative reference |

IDs should remain stable if a title changes. Suggested aliases:
- Inquiry: `RH-YYYY-NNNN` for published records; local/private records may use local IDs.
- Claim: `CL-<INQUIRY-ID>-NNN`
- Source: `SRC-<INQUIRY-ID>-NNN`
- Contribution: `CT-<INQUIRY-ID>-NNN`
- Synthesis: `SYN-<INQUIRY-ID>-NNN`

A technical implementation may use UUIDs internally and display a short alias.

## 2. Do not merge four kinds of status

**Inquiry phase** describes the journey. **Evidence status** describes an individual claim. **Framework maturity** describes a document or mechanism. **Visibility** describes who can access it.

Example: phase `EXPLORING`; claim status `NOT_ASSESSED`; maturity `[PROPOSAL]`; visibility `PRIVATE`.

## 3. Suggested Markdown front matter

```yaml
---
id: RH-LOCAL-0001
title: "How did ancient builders create monumental architecture?"
framework_status: "[PROPOSAL]"
inquiry_phase: "SPARKED"
visibility: "PRIVATE"
owner_id: "local-owner"
contributors: []
created_at: "YYYY-MM-DD"
updated_at: "YYYY-MM-DD"
parent_id: null
relationships: []
related_wings: []
current_question_id: Q-1
tags: ["history", "engineering", "archaeology"]
---
```

Private owner IDs should not expose real identity in public export unless the owner chooses to identify themselves.

## 4. Source relation vocabulary

Use one or more of: `SUPPORTS`, `CHALLENGES`, `CONTEXTUALISES`, `DESCRIBES`, `PROVIDES_METHOD`, `REPLICATES`, `INCONCLUSIVE_FOR`, `CITES_OR_DERIVES_FROM`.

`CITES_OR_DERIVES_FROM` reveals dependence between sources. Five articles repeating the same press release are not five independent sources.

## 5. Claim record

```yaml
claim_id: CL-RH-LOCAL-0001-001
text: "Exact proposition being evaluated."
claim_type: "HISTORICAL_FACT_CLAIM"
evidence_status: "NOT_ASSESSED"
scope: "Time, place, population, system, or conditions the claim concerns."
supporting_links: []
challenging_links: []
qualifications: []
counterexamples: []
what_would_change_assessment: []
last_assessed_at: null
assessment_note: "Not yet reviewed."
```

### Claim types
`OBSERVATION`, `HISTORICAL_FACT_CLAIM`, `SCIENTIFIC_CLAIM`, `INTERPRETATION`, `HYPOTHESIS`, `PERSONAL_REPORT`, `VALUE_OR_DESIGN_PROPOSAL`, `OPEN_QUESTION`.

### Evidence status
`SUPPORTED`, `SUPPORTED_WITH_LIMITS`, `CONTESTED`, `NOT_ASSESSED`, `SPECULATIVE`, `CONTRADICTED_OR_UNSUPPORTED`, `NOT_APPLICABLE`.

Do not assign a status without a short rationale. The status applies only to the claim as written and can be revised.

## 6. Source record

```yaml
source_id: SRC-RH-LOCAL-0001-001
title: "Source title"
creator: "Author, institution, or unknown"
source_type: "PRIMARY_DOCUMENT"
publication_date: null
access_date: "YYYY-MM-DD"
locator: "URL, archive call number, page, timestamp, or artifact details"
language: "en"
source_provenance: "How this copy was located and whether it is complete/authenticated."
limitations: []
derived_from: []
notes: "What this source may be useful for; do not imply support before review."
```

Potential source types: `PRIMARY_DOCUMENT`, `ARCHAEOLOGICAL_ARTIFACT`, `DATASET`, `PEER_REVIEWED_STUDY`, `SCHOLARLY_BOOK`, `ARCHIVAL_CATALOGUE`, `CREDIBLE_REPORTING`, `ORAL_HISTORY`, `TRANSLATION`, `SECONDARY_SUMMARY`, `OTHER`.

A primary source records a perspective or artifact; it is not automatically accurate, complete, or neutral.

## 7. Contribution record

```yaml
contribution_id: CT-RH-LOCAL-0001-001
type: "ADD_SOURCE"
contributor_id: "contributor-alias"
created_at: "YYYY-MM-DDThh:mm:ssZ"
target_id: "CL-RH-LOCAL-0001-001"
summary: "What changed."
rationale: "Why this matters."
evidence_links: []
supersedes: null
visibility: "SAME_AS_PARENT"
review_status: "UNREVIEWED"
```

Contribution types: `ADD_SOURCE`, `ADD_BRANCH`, `CHALLENGE_CLAIM`, `CORRECTION`, `CONTEXT`, `REPLICATION`, `CROSS_LINK`, `SUMMARY`, `FORK`, `NEW_EVIDENCE`, `EDITORIAL_CHANGE`.

Corrections retain prior text in history. A claim can be marked superseded, but the record of its earlier publication should not silently disappear.

## 8. Return card

```yaml
return_card:
  current_question: "What are we trying to understand now?"
  current_understanding: "Short summary, including limits."
  strongest_supported_points: []
  disputed_or_unassessed_points: []
  next_steps:
    - "One useful action."
  sources_to_reopen: []
  cautions: []
  updated_at: "YYYY-MM-DD"
```

Keep the card short enough to resume from without reading the entire file. It does not replace the full history.

## 9. Versioning and change history

- IDs remain stable as titles and wording change.
- Significant factual revisions get a contribution/change-log entry.
- Published versions remain retrievable.
- A source URL changing should not silently change the interpretation attached to it.
- Synthesis is dated; old synthesis remains available when superseded.
- A fork records the version it forked from.
- Publication changes are explicit and logged.
- Private-to-shared transitions require explicit owner action.

Git history can help, but user-facing provenance should not depend on contributors knowing Git.

## 10. Interoperability rule

Records must remain readable as ordinary Markdown without a custom renderer. YAML and JSON enable tools, but the core meaning must remain readable if the software disappears.
