# Rabbit Holes
## Lycheetah Mystery School — Proposed Inquiry Layer

**Framework status:** `[PROPOSAL]` · **Version:** 0.2 · **Date:** 2026-10-16  
**Intended location:** `14_MYSTERY_SCHOOL/RABBIT_HOLES/`  
**Implementation status:** Design files only; not merged into the Framework and not a deployed feature.

> **A Rabbit Hole is a preserved path through uncertainty — open to the next curious person.**

## What this is

Rabbit Holes are learner-owned inquiry journeys. A question opens a path; the path branches; sources and ideas are examined; conclusions change; new questions emerge. The record preserves not only what a person thinks they learned, but how the inquiry unfolded and what remains unresolved.

## Keep three spaces separate

1. **Personal inquiry:** private notes and unfinished thoughts owned by the learner.
2. **Commons inquiry:** material the learner explicitly chooses to share. It is open to contribution and challenge, but is not automatically endorsed by Lycheetah.
3. **School Canon / curriculum:** a small, governed body of selected learning material. Entry requires explicit review and a recorded decision.

Publishing to the Commons is not the same as canonisation. A useful inquiry may remain open forever without becoming a lesson.

## Files in this pack

- `RABBIT_HOLES_ARCHITECTURE.md` — purpose, concepts, lifecycle, and School integration.
- `RECORD_MODEL_AND_SCHEMA.md` — entities, metadata, evidence links, and versioning.
- `CONTRIBUTION_AND_GOVERNANCE.md` — sharing, review, branch, correction, safety, and governance rules.
- `TEMPLATE_RABBIT_HOLE.md` — reusable inquiry record.
- `EXAMPLE_RH_0001_ANCIENT_MONUMENTAL_ENGINEERING.md` — illustrative starting inquiry, not researched conclusions.
- `DECISIONS_AND_OPEN_QUESTIONS.md` — explicit decisions and unresolved questions.
- `rabbit_holes.schema.json` — lightweight machine-readable metadata schema.
- `registry.json` — empty starter registry; example inquiries do not automatically enter it.

## Fit with the School

The current Mystery School checkpoint describes the School as the whole place; Wings as modes of thought; Halls as courses; Classes as steps; Gates as real acts; Subjects as terrain; Teachings as examinable claims or practices; and Threads as explicit cross-Wing links.

**Rabbit Holes are not another Wing or rank.** They are a cross-school inquiry layer that can travel through any subject, Wing, Hall, or practice.

They should preserve the School's existing commitments:
- `[PROPOSAL]` is not `[ACTIVE]`.
- Personal Canon belongs to its bearer.
- Commons proposals can challenge or extend the work but never become canon silently.
- No private words enter the Commons automatically.
- Return is voluntary: no streaks, guilt, rank pressure, or companion dependency.
- STUDENT remains the common identity; labels describe work or practice, never human worth.
- The intended outcome is a learner capable of outgrowing Lycheetah.

## First implementation principle

Start with Markdown and explicit human choices. Do not build a large application before the record model, contribution rules, and privacy boundaries have been tested in practice.

## Related source documents

- [Mystery School README](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/14_MYSTERY_SCHOOL/README.md)
- [Mystery School architecture checkpoint](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/LYCHEETAH_MYTHOS/SCRIPTURES_AND_STORIES/LIVING_SCRIPTURE/handoff/MYSTERY_SCHOOL_CHECKPOINT.md)
- [Identity and voluntary return](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/14_MYSTERY_SCHOOL/IDENTITY_AND_RETURN/README.md)
- [Framework contribution guide](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/CONTRIBUTING.md)
- [Governance](https://github.com/Lycheetah/Lycheetah-Framework/blob/master/29_GOVERNANCE/GOVERNANCE.md)
